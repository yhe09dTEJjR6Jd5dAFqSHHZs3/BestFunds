                       
from __future__ import annotations

# Must be set before other imports so later imports cannot create .pyc beside the script.
import sys
sys.dont_write_bytecode = True

# ===== 标准库 / 全局配置 =====
import concurrent.futures
import copy
import ctypes
import datetime as _dt
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from email.utils import parsedate_to_datetime
import base64
import binascii
import bisect
import calendar
import gzip
import gc
import hashlib
import hmac
import html
from html.parser import HTMLParser
from http import HTTPStatus
import io
import importlib
import json
import math
import multiprocessing as mp
import platform
import struct
import os
import queue
import random
import sqlite3
import re
import shutil
import statistics
import subprocess
import threading
import time
import tempfile
import traceback
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path


def _schema_fingerprint(payload) -> str:
    """Deterministic identity derived from the persisted field/schema definition itself."""
    encoded = json.dumps(payload, sort_keys=True, ensure_ascii=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sqlite_schema_fingerprint(payload) -> int:
    """Map a schema digest into SQLite PRAGMA user_version's non-negative signed integer domain."""
    digest = hashlib.sha256(str(payload).encode("utf-8")).digest()
    signed_bits = struct.calcsize("I") * 8 - 1
    mask = (1 << signed_bits) - 1
    value = int.from_bytes(digest[:struct.calcsize("I")], "big") & mask
    return value or 1


APP_NAME = "Best Funds"
APP_DATA_DIRNAME = "BestFundsData"
# Writable state is deliberately unbound at import time. No write-capable path exists until
# the user-selected runtime folder has been validated and bound.
BASE_DIR: Path | None = None
CACHE_PATH: Path | None = None
CACHE_ROLLBACK_PATH: Path | None = None
MODEL_PATH: Path | None = None
SETTINGS_PATH: Path | None = None
DEPS_DIR: Path | None = None
DEPS_TMP_DIR: Path | None = None
DEPS_BACKUP_DIR: Path | None = None
DEPS_DIR_PREFIX = "BestFunds_deps_"
MODEL_ROLLBACK_PATH: Path | None = None
RUNTIME_TMP_DIR: Path | None = None
RUNTIME_FOLDER_BOUND = False
_RUNTIME_WRITE_AUDIT_INSTALLED = False
# Fixed local disks use WAL/NORMAL. Other writable non-system drives (removable or mapped)
# fall back to the more conservative rollback journal + FULL sync profile.
SQLITE_JOURNAL_MODE = "WAL"
SQLITE_NORMAL_SYNCHRONOUS = "NORMAL"
SQLITE_STORAGE_PROFILE = "fixed-local"
DEPENDENCY_MANIFEST_FILENAME = "BestFunds_dependency_manifest.json"
DEPENDENCY_MANIFEST_FIELDS = (
    "app", "generation", "created_at", "selection_rule", "python_abi", "package_specs", "import_versions",
    "wheel_sha256", "wheel_size_bytes", "installed_tree_sha256", "installed_tree_files", "installed_tree_bytes",
)
DEPENDENCY_MANIFEST_FINGERPRINT = _schema_fingerprint(DEPENDENCY_MANIFEST_FIELDS)
WINDOWS_LEGACY_MAX_PATH = 260  # Win32 MAX_PATH compatibility boundary when long-path opt-in is unavailable.

# Release dependency rule: for each admitted CPython minor, select the highest stable
# PyPI release available at release time that simultaneously has a Windows x64 binary wheel,
# satisfies that interpreter's Requires-Python/ABI contract, fits this program's dependency
# graph, and has a release-file SHA-256 that can be pinned and verified before installation.
# A failed download never substitutes a different numerical stack at runtime.
DEPENDENCY_SELECTION_RULE = (
    "highest stable release available at release time with target CPython compatibility, "
    "Windows x64 binary wheel, dependency-graph compatibility, and pinned release-file SHA-256"
)
_DEPENDENCY_PY310 = {
    "numpy": "numpy==2.2.6",
    "scipy": "scipy==1.15.3",
    "lightgbm": "lightgbm==4.7.0",
}
_DEPENDENCY_PY311 = {
    "numpy": "numpy==2.4.6",
    "scipy": "scipy==1.17.1",
    "lightgbm": "lightgbm==4.7.0",
}
_DEPENDENCY_MODERN = {
    "numpy": "numpy==2.5.2",
    "scipy": "scipy==1.18.1",
    "lightgbm": "lightgbm==4.7.0",
    "xgboost_cpu": "xgboost-cpu==3.4.1",
    "xgboost_gpu": "xgboost==3.4.1",
}
DEPENDENCY_PROFILES = {
    "3.10": (dict(_DEPENDENCY_PY310),),
    "3.11": (dict(_DEPENDENCY_PY311),),
    "3.12": (dict(_DEPENDENCY_MODERN),),
    "3.13": (dict(_DEPENDENCY_MODERN),),
    "3.14": (dict(_DEPENDENCY_MODERN),),
}
TRUSTED_WHEEL_SHA256 = {
    "numpy-2.2.6-cp310-cp310-win_amd64.whl": "f0fd6321b839904e15c46e0d257fdd101dd7f530fe03fd6359c1ea63738703f3",
    "scipy-1.15.3-cp310-cp310-win_amd64.whl": "9d61e97b186a57350f6d6fd72640f9e99d5a4a2b8fbf4b9ee9a841eab327dc13",
    "numpy-2.4.6-cp311-cp311-win_amd64.whl": "1e254a00cdf42b1e4d5b3d68d33af63268d41340d8885df2ab6470f2e1500147",
    "scipy-1.17.1-cp311-cp311-win_amd64.whl": "d30e57c72013c2a4fe441c2fcb8e77b14e152ad48b5464858e07e2ad9fbfceff",
    "numpy-2.5.2-cp312-cp312-win_amd64.whl": "28ac63476ec7651484215ee7fa15a1f78b57c14621f01e392afe17b9a1390ce4",
    "numpy-2.5.2-cp313-cp313-win_amd64.whl": "85aaccb24182c25df891ad0ec333585967e115269d5f1b17f2c9ae005bc96657",
    "numpy-2.5.2-cp314-cp314-win_amd64.whl": "7587f53dfbd5edc0f7b87c6217b4c6d2d1f2ef9c3da70bc1315e7db5f8d7ec9d",
    "scipy-1.18.1-cp312-cp312-win_amd64.whl": "5e4d44984abc0020154ea81b247adeddcc3ac5527b975ff798bd1ba0adc513c2",
    "scipy-1.18.1-cp313-cp313-win_amd64.whl": "559ed65f60c1af5a03f3912605a1b5114f522c7c32fb23c3376ae8f03219fe28",
    "scipy-1.18.1-cp314-cp314-win_amd64.whl": "78a0d7c918e74a232394117160e7e3db503377572a45bcef8826e4ab8a35feba",
    "lightgbm-4.7.0-py3-none-win_amd64.whl": "f42d1e5b32b6f170e606d7c689c6165671da98d7bf37f1addec2623efc8740c9",
    "xgboost_cpu-3.4.1-py3-none-win_amd64.whl": "ceb0f7c786511e1876df6ca83a6f837a3187159bde51d8dcc5cdf5e2de76e366",
    "xgboost-3.4.1-py3-none-win_amd64.whl": "2d30fa513673101f542fdcbd18f30c8f96c064046f798635ac08663e9969f81b",
}


MIN_RUNTIME_PYTHON = (3, 10)  # PEP 604 union annotations require Python 3.10+.
MAX_VERIFIED_NATIVE_ML_PYTHON = (3, 14)  # Native wheels remain fail-closed to explicit ABI/hash profiles.


def _runtime_python_supported() -> bool:
    """Base GUI/SQLite/network runtime accepts future CPython 3.x minors; native ML is gated separately."""
    return bool(
        sys.implementation.name == "cpython"
        and sys.version_info.major == MIN_RUNTIME_PYTHON[0]
        and sys.version_info.minor >= MIN_RUNTIME_PYTHON[1]
    )


def _native_ml_runtime_supported() -> bool:
    """Native ML is enabled only when this exact CPython minor has a wheel/hash-verified profile."""
    return bool(sys.implementation.name == "cpython" and _dependency_profiles_for_runtime())


def _supported_python_text() -> str:
    return f"{MIN_RUNTIME_PYTHON[0]}.{MIN_RUNTIME_PYTHON[1]}+"


def _native_python_profile_text() -> str:
    return ", ".join(sorted(DEPENDENCY_PROFILES, key=lambda value: tuple(map(int, value.split("."))))) or "none"


def _base_runtime_capability_probe() -> tuple[bool, str]:
    """Probe stdlib capabilities required by the base app without touching disk or the network."""
    try:
        connection = sqlite3.connect(":memory:")
        try:
            connection.execute("SELECT 1").fetchone()
        finally:
            connection.close()
        import tkinter  # noqa: F401 - capability probe only; no Tk root is created here.
        if not callable(getattr(urllib.request, "urlopen", None)):
            return False, "urllib.request.urlopen 不可用"
        return True, "GUI/SQLite/urllib 基础能力可用"
    except (ImportError, sqlite3.Error, AttributeError, OSError) as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _dependency_profiles_for_runtime() -> tuple[dict, ...]:
    key = f"{sys.version_info.major}.{sys.version_info.minor}"
    profiles = DEPENDENCY_PROFILES.get(key)
    return tuple(dict(profile) for profile in profiles) if profiles else ()

LOCAL_DEPENDENCY_PINS = (
    dict(_dependency_profiles_for_runtime()[0]) if _dependency_profiles_for_runtime() else {}
)
DISPLAY_TOP_N = 100
MIN_LONG_TERM_HORIZON_YEARS = 3
SHADOW_STRICT_PIT_RECHECK_DAYS = 30
FORMAL_PURCHASABLE_STATUSES = frozenset({"public_open", "limited_purchasable"})

# Process-wide cancellation used by GUI workers, HTTP retries and long-running pip subprocesses.
_GLOBAL_STOP_EVENT = threading.Event()
_ACTIVE_CHILD_PROCESSES: set[subprocess.Popen] = set()
_ACTIVE_CHILD_LOCK = threading.Lock()
_ACTIVE_TRAINING_PROCESSES: set[mp.Process] = set()
_ACTIVE_TRAINING_LOCK = threading.Lock()
_TRAINING_DEPENDENCY_OVERRIDE: Path | None = None
_TRAINING_CHILD_EVENT_SINK = None
_DEPENDENCY_INSTALL_LOCK = threading.Lock()
_DEPENDENCY_TREE_VERIFY_CACHE: dict[tuple[str, str], tuple[tuple[int, int, int], bool, str]] = {}
_DEPENDENCY_IMPORT_VERIFY_CACHE: dict[tuple[str, str, tuple[int, int, int]], tuple[bool, str]] = {}
_HTTP_GENERATION_LOCK = threading.Lock()
_HTTP_GENERATION = 0

def _begin_http_generation() -> int:
    """Advance the business refresh generation so blocked first-sample children from older work are killed."""
    global _HTTP_GENERATION
    with _HTTP_GENERATION_LOCK:
        _HTTP_GENERATION += 1
        return _HTTP_GENERATION

def _current_http_generation() -> int:
    with _HTTP_GENERATION_LOCK:
        return _HTTP_GENERATION

def _cancel_requested() -> bool:
    return _GLOBAL_STOP_EVENT.is_set()

def _sleep_interruptible(seconds: float) -> bool:
    return _GLOBAL_STOP_EVENT.wait(max(0.0, float(seconds)))

def _terminate_child_processes() -> None:
    with _ACTIVE_CHILD_LOCK:
        processes = list(_ACTIVE_CHILD_PROCESSES)
    for proc in processes:
        try:
            if proc.poll() is None:
                proc.terminate()
        except OSError:
            pass
    deadline = time.monotonic() + _objective_work_timeout(max(1, len(processes)))
    for proc in processes:
        try:
            remaining = max(0.0, deadline - time.monotonic())
            proc.wait(timeout=remaining)
        except Exception:
            try:
                if proc.poll() is None:
                    proc.kill()
            except OSError:
                pass

def _terminate_training_processes() -> None:
    with _ACTIVE_TRAINING_LOCK:
        processes = list(_ACTIVE_TRAINING_PROCESSES)
    for proc in processes:
        try:
            if proc.is_alive():
                proc.terminate()
        except (OSError, ValueError):
            pass
    deadline = time.monotonic() + _objective_work_timeout(max(1, len(processes)))
    for proc in processes:
        try:
            proc.join(timeout=max(0.0, deadline - time.monotonic()))
            if proc.is_alive() and hasattr(proc, "kill"):
                proc.kill()
                proc.join(timeout=time.get_clock_info("monotonic").resolution)
        except (OSError, ValueError):
            pass


def _run_process_cancellable(command: list[str], *, timeout: float | None, env=None, cwd: str | Path | None = None) -> subprocess.CompletedProcess:
    """Run a child cancellably; every child receives a finite application-level total deadline."""
    if _cancel_requested():
        raise concurrent.futures.CancelledError("程序正在退出")
    effective_timeout = (
        _objective_external_process_timeout(command) if timeout is None
        else max(time.get_clock_info("monotonic").resolution, float(timeout))
    )
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, cwd=None if cwd is None else str(cwd))
    with _ACTIVE_CHILD_LOCK:
        _ACTIVE_CHILD_PROCESSES.add(proc)
    started = time.monotonic()
    try:
        while True:
            if _cancel_requested():
                try:
                    proc.terminate()
                except OSError:
                    pass
                try:
                    proc.communicate(timeout=_objective_work_timeout(1))
                except Exception:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    try:
                        proc.communicate(timeout=time.get_clock_info("monotonic").resolution)
                    except Exception:
                        pass
                raise concurrent.futures.CancelledError("程序正在退出")
            elapsed = time.monotonic() - started
            if elapsed >= effective_timeout:
                try:
                    proc.terminate()
                    proc.communicate(timeout=_objective_work_timeout(1))
                except Exception:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    try:
                        proc.communicate(timeout=time.get_clock_info("monotonic").resolution)
                    except Exception:
                        pass
                raise subprocess.TimeoutExpired(command, effective_timeout)
            poll = min(
                _process_poll_seconds(),
                max(time.get_clock_info("monotonic").resolution, effective_timeout - elapsed),
            )
            try:
                stdout, stderr = proc.communicate(timeout=poll)
                return subprocess.CompletedProcess(command, proc.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                continue
    finally:
        with _ACTIVE_CHILD_LOCK:
            _ACTIVE_CHILD_PROCESSES.discard(proc)


_STORAGE_COMMIT_LOCK = threading.RLock()


class WorkerManager:
    """Track top-level GUI workers so shutdown stops new work and waits for existing workers to unwind."""
    def __init__(self, stop_event: threading.Event):
        self.stop_event = stop_event
        self._threads: set[threading.Thread] = set()
        self._lock = threading.Lock()
        self._accepting = True

    def start(self, *, name: str, target) -> threading.Thread | None:
        with self._lock:
            if not self._accepting or self.stop_event.is_set():
                return None

        def runner():
            try:
                target()
            finally:
                with self._lock:
                    self._threads.discard(threading.current_thread())

        thread = threading.Thread(target=runner, name=name, daemon=True)
        with self._lock:
            if not self._accepting or self.stop_event.is_set():
                return None
            self._threads.add(thread)
        thread.start()
        return thread

    def shutdown(self, deadline: float | None = None) -> int:
        """Stop accepting work and wait only until one shared absolute shutdown deadline."""
        with self._lock:
            self._accepting = False
            threads = list(self._threads)
        poll = max(time.get_clock_info("monotonic").resolution, sys.getswitchinterval())
        if deadline is None:
            wait_budget = max(
                _windows_hung_app_timeout_seconds(),
                _objective_work_timeout(max(1, len(threads))),
            )
            deadline = time.monotonic() + wait_budget
        else:
            deadline = float(deadline)
        for thread in threads:
            if thread is threading.current_thread():
                continue
            while thread.is_alive():
                remaining = deadline - time.monotonic()
                if remaining <= 0.0:
                    break
                thread.join(timeout=min(poll, remaining))
        alive = [thread.name for thread in threads if thread is not threading.current_thread() and thread.is_alive()]
        if alive:
            _record_diagnostic(
                "worker-shutdown",
                f"shutdown deadline reached; daemon workers still alive: {','.join(alive)}",
                "ShutdownDeadline",
            )
        return len(alive)


# Optional AI packages are activated only after the selected runtime folder is bound.
# No unmanifested legacy directory is ever trusted or prepended to sys.path.
def _bootstrap_local_dependency_path() -> None:
    settings = _load_install_settings()
    target = _active_dependency_dir(settings)
    if target is None:
        return
    ok, detail, _ = _verify_dependency_generation(
        target, settings, require_import_probe=False, force_tree_rehash=False, force_import_probe=False
    )
    if not ok:
        settings["dependency_install_status"] = "active-verify-failed"
        settings["dependency_install_error"] = str(detail)
        settings["active_dependency_dir"] = ""
        _save_install_settings(settings)
        _record_diagnostic("dependency-active-activate", detail, "ImportVerifyFailed")
        return
    text = str(target)
    if text not in sys.path:
        sys.path.insert(0, text)
    importlib.invalidate_caches()

# Dependency activation is intentionally deferred until after the user-selected runtime folder is bound.
#
# Numeric policy: values below are either protocol/calendar facts, direct product requirements,
# or are derived from observable workload/data/hardware conditions.  We intentionally avoid
# hand-tuned thresholds: when no objective measurement exists, the neutral value is used.
PUBLIC_DATA_SOURCE_FAMILIES = ("东方财富", "新浪财经")
PUBLIC_SOURCE_COUNT = len(PUBLIC_DATA_SOURCE_FAMILIES)
MODEL_SELECTION_SIZE = DISPLAY_TOP_N  # direct product target: the model evaluates the same Top100 the UI delivers
MONTHS_PER_YEAR = len(calendar.month_name) - 1
QUARTERS_PER_YEAR = len(("Q1", "Q2", "Q3", "Q4"))
MARKET_WEEKDAYS_PER_WEEK = len(range(calendar.MONDAY, calendar.FRIDAY + 1))
SECONDS_PER_MINUTE = int(_dt.timedelta(minutes=1).total_seconds())
SECONDS_PER_HOUR = int(_dt.timedelta(hours=1).total_seconds())
SECONDS_PER_DAY = int(_dt.timedelta(days=1).total_seconds())
AVERAGE_GREGORIAN_DAYS_PER_YEAR = 365.2425  # Gregorian 400-year mean year length.
BITS_PER_BYTE = struct.calcsize("B") * 8
BYTES_PER_KIB = 1024  # IEC/ISO binary-prefix definition: 1 KiB = 1024 bytes
BYTES_PER_MIB = BYTES_PER_KIB * BYTES_PER_KIB
BYTES_PER_GIB = BYTES_PER_KIB * BYTES_PER_MIB
MIB_PER_GIB = BYTES_PER_GIB // BYTES_PER_MIB
MILLISECONDS_PER_SECOND = 1000  # SI prefix definition used by browser/provider timestamps
AVERAGE_GREGORIAN_DAYS_PER_MONTH = AVERAGE_GREGORIAN_DAYS_PER_YEAR / MONTHS_PER_YEAR

# External platform/protocol constants. These are fixed by standards or documented OS/API
# contracts, so they are named facts rather than tunable numeric thresholds.
X64_POINTER_BITS = struct.calcsize("Q") * BITS_PER_BYTE
WINDOWS_FILETIME_PART_BITS = struct.calcsize("I") * BITS_PER_BYTE
WINDOWS_FILE_ATTRIBUTE_REPARSE_POINT = 0x400
WINDOWS_FIXED_DRIVE_TYPE = 3
WINDOWS_11_NT_MAJOR_VERSION = 10
WINDOWS_11_MIN_BUILD = 22000
WINDOWS_PER_MONITOR_AWARE_V2_CONTEXT = -4
WINDOWS_PROCESS_PER_MONITOR_DPI_AWARE = 2
WINDOWS_PROCESS_SYSTEM_DPI_AWARE = 1
WINDOWS_MESSAGEBOX_ICONERROR = 0x00000010
# Windows/RFC timeout facts used only as cold-start safety bounds, never as refresh cadence.
WINDOWS_DEFAULT_HUNG_APP_TIMEOUT_MILLISECONDS = 5000  # documented Windows HungAppTimeout default
WINDOWS_DEFAULT_TCP_DATA_RETRANSMISSIONS = 5  # documented TcpMaxDataRetransmissions default
RFC6298_INITIAL_RTO_SECONDS = float(_dt.timedelta(seconds=1).total_seconds())
RFC6298_MAX_RTO_SECONDS = float(_dt.timedelta(minutes=1).total_seconds())
RFC6298_BACKOFF_FACTOR = len(("original-transmission", "retransmission-copy"))
ADVANCED_ML_MIN_PYTHON = (3, 12)  # xgboost-cpu 3.4.1 Requires-Python contract
WHEEL_EXTENSION = ".whl"
WHEEL_FILENAME_FIELDS = ("distribution", "version", "python_tag", "abi_tag", "platform_tag")
WHEEL_RUNTIME_TAG_FIELDS = ("python_tag", "abi_tag", "platform_tag")
NVIDIA_SMI_FIELDS = ("index", "name", "memory.total", "memory.free", "utilization.gpu", "driver_version")
RETRYABLE_HTTP_STATUS_CODES = frozenset(
    {HTTPStatus.UNAUTHORIZED.value, HTTPStatus.FORBIDDEN.value, HTTPStatus.TOO_MANY_REQUESTS.value}
    | {status.value for status in HTTPStatus if status.value >= HTTPStatus.INTERNAL_SERVER_ERROR.value}
)
CHINA_UTC_OFFSET = _dt.timedelta(hours=8)
MARKET_MORNING_OPEN = _dt.time.fromisoformat("09:30")
MARKET_MORNING_CLOSE = _dt.time.fromisoformat("11:30")
MARKET_AFTERNOON_OPEN = _dt.time.fromisoformat("13:00")
MARKET_CLOSE = _dt.time.fromisoformat("15:00")
PERCENT_SCALE = 100.0  # percent is defined per hundred; independent of the Top100 product requirement
PROBABILITY_MIDPOINT = statistics.fmean((0.0, 1.0))
NUMERIC_TOLERANCE = math.sqrt(sys.float_info.epsilon)

# Objective numeric vocabulary.  These values are derived from product scale, platform/API
# contracts, data shape, or runtime resources instead of hand-tuned literals.
DATE_TEXT_LENGTH = len(_dt.date.min.isoformat())
DATE_YEAR_DIGITS = len(str(_dt.date.max.year))
FUND_CODE_DIGITS = len("000001")  # public fund-code contract
FUND_CODE_PATTERN = re.compile(rf"\d{{{FUND_CODE_DIGITS}}}")
FUND_CODE_SEARCH_PATTERN = re.compile(rf"(?<!\d)(\d{{{FUND_CODE_DIGITS}}})(?!\d)")

def _valid_fund_code(value) -> bool:
    return bool(FUND_CODE_PATTERN.fullmatch(str(value or "")))
FILE_IO_CHUNK_BYTES = io.DEFAULT_BUFFER_SIZE
CATALOG_CACHE_MIN_ROWS = MODEL_SELECTION_SIZE
CONTRACT_CROSSCHECK_SIZE = DISPLAY_TOP_N
FLOAT_SERIALIZATION_DIGITS = sys.float_info.dig

def _phase_progress_value(phases, phase, within: float = 0.0) -> float:
    """Map named work phases to percent by observed phase count, never by hand-picked percentages."""
    ordered = tuple(phases)
    if not ordered:
        return 0.0
    index = ordered.index(phase)
    fraction = _clamp(_finite(within), 0.0, 1.0)
    return PERCENT_SCALE * (index + fraction) / len(ordered)

def _nested_progress(progress, phases, phase):
    return lambda text, pct: progress(
        text, _phase_progress_value(phases, phase, _clamp(_finite(pct), 0.0, PERCENT_SCALE) / PERCENT_SCALE)
    )

_RUNTIME_LOCAL_WORK_UNIT_SECONDS: float | None = None

def _runtime_local_work_unit_seconds() -> float:
    """Measure the local scheduler yield only after the user-selected runtime folder is bound."""
    global _RUNTIME_LOCAL_WORK_UNIT_SECONDS
    resolution = time.get_clock_info("monotonic").resolution
    scheduler_tick = max(resolution, sys.getswitchinterval())
    if _RUNTIME_LOCAL_WORK_UNIT_SECONDS is not None:
        return _RUNTIME_LOCAL_WORK_UNIT_SECONDS
    if not RUNTIME_FOLDER_BOUND:
        # Import and multiprocessing-spawn re-import must stay measurement/side-effect free.
        return scheduler_tick
    started = time.monotonic()
    time.sleep(0)
    measured = max(0.0, time.monotonic() - started)
    _RUNTIME_LOCAL_WORK_UNIT_SECONDS = max(scheduler_tick, measured)
    return _RUNTIME_LOCAL_WORK_UNIT_SECONDS

def _objective_work_timeout(work_items: int = 1) -> float:
    """Scale the bound-runtime scheduler observation by the actual local work-item count."""
    items = max(1, int(work_items))
    return max(time.get_clock_info("monotonic").resolution, _runtime_local_work_unit_seconds() * items)

def _process_poll_seconds() -> float:
    """Cancellable-process polling cadence; evaluated lazily after runtime binding."""
    return max(
        time.get_clock_info("monotonic").resolution,
        _objective_work_timeout(1) / max(1, int(os.cpu_count() or 1)),
    )

def _windows_registry_number(root_name: str, subkey: str, value_name: str) -> int | None:
    """Read an integer-like Windows registry value without spawning a process or writing state."""
    if os.name != "nt":
        return None
    try:
        import winreg
        root = getattr(winreg, root_name)
        with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ) as handle:
            value, _kind = winreg.QueryValueEx(handle, value_name)
        return int(str(value).strip())
    except (AttributeError, OSError, TypeError, ValueError):
        return None

def _windows_hung_app_timeout_seconds() -> float:
    """Windows' configured GUI-hang boundary, used as a platform-derived child-process cold bound."""
    configured_ms = _windows_registry_number(
        "HKEY_CURRENT_USER", r"Control Panel\Desktop", "HungAppTimeout"
    )
    milliseconds = configured_ms if configured_ms and configured_ms > 0 else WINDOWS_DEFAULT_HUNG_APP_TIMEOUT_MILLISECONDS
    return max(time.get_clock_info("monotonic").resolution, milliseconds / MILLISECONDS_PER_SECOND)

def _windows_tcp_data_retransmissions() -> int:
    configured = _windows_registry_number(
        "HKEY_LOCAL_MACHINE", r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "TcpMaxDataRetransmissions"
    )
    return max(1, int(configured if configured and configured > 0 else WINDOWS_DEFAULT_TCP_DATA_RETRANSMISSIONS))

def _platform_network_inactivity_timeout_seconds() -> float:
    """Cold socket-inactivity bound from configured Windows TCP retransmissions + RFC 6298 RTO backoff."""
    retries = _windows_tcp_data_retransmissions()
    rto = RFC6298_INITIAL_RTO_SECONDS
    budget = 0.0
    for _attempt in range(retries + 1):
        budget += min(rto, RFC6298_MAX_RTO_SECONDS)
        rto = min(RFC6298_MAX_RTO_SECONDS, rto * RFC6298_BACKOFF_FACTOR)
    return max(time.get_clock_info("monotonic").resolution, budget)

def _platform_network_total_timeout_seconds() -> float:
    """Finite cold HTTP total bound covering each blocking protocol phase, including DNS and body transfer."""
    protocol_phases = ("dns", "tcp-connect", "tls-handshake", "response-headers", "response-body")
    return _platform_network_inactivity_timeout_seconds() * len(protocol_phases)

def _objective_external_operation_timeout(name: str, workload_units: int = 1) -> float:
    """Cold external-process bound from the Windows hang threshold and operation-shaped workload units."""
    units = max(1, int(workload_units))
    base = _windows_hung_app_timeout_seconds()
    if str(name) == "hardware_probe":
        units = max(units, len(("process-start", "hardware-provider", "serialization", "process-exit")))
    return base * units

def _objective_external_process_timeout(command: list[str]) -> float:
    """Defensive finite deadline for a child call site that omitted a more specific operation timeout."""
    args = [str(value) for value in (command or [])]
    package_units = max(1, sum("==" in value for value in args))
    joined = " ".join(args).lower()
    if "-m pip download" in joined:
        return _platform_network_total_timeout_seconds() * package_units
    if "-m pip install" in joined:
        return _objective_external_operation_timeout("dependency_install", package_units)
    return _objective_external_operation_timeout("external_process", len(("process-start", "operation", "process-exit")))

def _objective_stale_artifact_age_seconds(path: Path) -> float:
    """Staleness window from observed artifact size and this machine's measured local work unit."""
    try:
        if path.is_file():
            size = max(0, int(path.stat().st_size))
        else:
            size = sum(
                max(0, int((Path(root) / name).stat().st_size))
                for root, _dirs, names in os.walk(path, followlinks=False)
                for name in names
            )
    except OSError:
        size = 0
    work_units = max(1, math.ceil(size / max(1, FILE_IO_CHUNK_BYTES)))
    return _objective_work_timeout(work_units)

HTTP_IN_MEMORY_REPRESENTATIONS = len(("wire-bytes", "decoded-text", "parsed-object"))

def _objective_http_global_memory_budget() -> int:
    """Global in-flight HTTP byte budget from live RAM headroom and known response representations."""
    total, available = _portable_memory_status() if "_portable_memory_status" in globals() else (0, 0)
    basis = available or total
    if basis <= 0:
        return FILE_IO_CHUNK_BYTES
    return max(FILE_IO_CHUNK_BYTES, int(basis // HTTP_IN_MEMORY_REPRESENTATIONS))

def _objective_training_payload_memory_budget() -> int:
    """Training-payload admission is RAM-derived and independent from network response sizing."""
    total, available = _portable_memory_status() if "_portable_memory_status" in globals() else (0, 0)
    basis = available or total
    if basis <= 0:
        return FILE_IO_CHUNK_BYTES
    return max(FILE_IO_CHUNK_BYTES, int(basis // HTTP_IN_MEMORY_REPRESENTATIONS))

def _required_coverage(population: int, allowed_missing: int) -> float:
    population = max(1, int(population))
    return max(0.0, min(1.0, (population - min(population, max(0, int(allowed_missing)))) / population))

LATEST_ATTEMPTS = 1  # minimum one transport attempt per source; source fallback supplies redundancy
LATEST_TIMEOUT = 0.0  # sentinel: _http_text derives a finite per-host socket-inactivity timeout from observations
REFRESH_MIN_COVERAGE = _required_coverage(DISPLAY_TOP_N, allowed_missing=0)
RETURN_AGREEMENT_NUMERIC_TOLERANCE = NUMERIC_TOLERANCE

# Long-horizon policy is generated from actual history and walk-forward OOS evidence.
# A candidate horizon must fit once before the feature date and once after it for OOS labeling.
def _history_supported_target_years(item: dict) -> int:
    dates = item.get("dates") or []
    if len(dates) < 2:
        return 0
    try:
        first = _dt.date.fromisoformat(str(dates[0])[:DATE_TEXT_LENGTH])
        last = _dt.date.fromisoformat(str(dates[-1])[:DATE_TEXT_LENGTH])
    except ValueError:
        return 0
    span_years = max(0.0, (last - first).days / AVERAGE_GREGORIAN_DAYS_PER_YEAR)
    oos_required_spans = ("feature_lookback", "forward_label")
    return max(0, int(math.floor(span_years / len(oos_required_spans))))

def _candidate_target_specs(funds: list[dict]) -> tuple[dict, ...]:
    supported = sorted(
        (_history_supported_target_years(item) for item in funds if isinstance(item, dict)),
        reverse=True,
    )
    if len(supported) < DISPLAY_TOP_N:
        return ()
    max_common_years = supported[DISPLAY_TOP_N - 1]
    if max_common_years < MIN_LONG_TERM_HORIZON_YEARS:
        return ()
    return tuple(
        {"name": f"{years}y-data-supported-horizon", "horizon_years": years}
        for years in range(MIN_LONG_TERM_HORIZON_YEARS, max_common_years + 1)
    )

def _model_target_years(model: dict | None, fallback: int = MIN_LONG_TERM_HORIZON_YEARS) -> int:
    model = model if isinstance(model, dict) else {}
    spec = model.get("target_spec") if isinstance(model.get("target_spec"), dict) else {}
    value = spec.get("horizon_years", model.get("target_horizon_years", fallback))
    try:
        return max(MIN_LONG_TERM_HORIZON_YEARS, int(value))
    except (TypeError, ValueError):
        return max(MIN_LONG_TERM_HORIZON_YEARS, int(fallback))

UNIVERSE_EXPERT_ONLY_COVERAGE = MODEL_SELECTION_SIZE / DISPLAY_TOP_N
UNIVERSE_COMPLEX_ML_COVERAGE = REFRESH_MIN_COVERAGE
MIN_HISTORY_POINTS = 2  # mathematical minimum for an observed return interval; horizon completeness is date-validated later
# Formal model features require substantially denser evidence than the mathematical two-point minimum.
# These thresholds are intentionally simple, fixed release invariants rather than data-tuned parameters.
MIN_HISTORY_DENSITY = PROBABILITY_MIDPOINT
MIN_RECENT_HISTORY_DENSITY = PROBABILITY_MIDPOINT
MAX_CONSECUTIVE_MISSING_SESSIONS = MARKET_WEEKDAYS_PER_WEEK * 2
UNKNOWN_TRANSACTION_COST_FALLBACK = 1.0 / PERCENT_SCALE
# Provider-observed session gaps are only anomaly/cache hints; formal freshness uses OfficialChinaMarketCalendar.
MAX_OBSERVED_SESSION_GAP = 0
FINAL_FRESHNESS_COVERAGE = REFRESH_MIN_COVERAGE
FINAL_PUBLIC_METADATA_REFRESH_COVERAGE = REFRESH_MIN_COVERAGE
PIT_RATING_MIN_UNIVERSE_COVERAGE = UNIVERSE_EXPERT_ONLY_COVERAGE

# UI queue polling is computed from display refresh + observed event/handler timing at runtime.
# Dependency preparation is scheduled with Tk after_idle once a formal Top100 is painted.
UI_CLOCK_TICK_MILLISECONDS = MILLISECONDS_PER_SECOND
WINDOWS_VREFRESH_DEVICE_CAP = 116  # Win32 GetDeviceCaps(VREFRESH) index.

def _display_refresh_period_seconds() -> float:
    """Use the active Windows display refresh period as the GUI polling floor."""
    resolution = time.get_clock_info("monotonic").resolution
    if os.name == "nt":
        hdc = None
        try:
            user32 = ctypes.windll.user32
            gdi32 = ctypes.windll.gdi32
            hdc = user32.GetDC(None)
            if hdc:
                refresh_hz = int(gdi32.GetDeviceCaps(hdc, WINDOWS_VREFRESH_DEVICE_CAP))
                if refresh_hz > 1:
                    return max(resolution, 1.0 / refresh_hz)
        except (AttributeError, OSError, TypeError, ValueError):
            pass
        finally:
            if hdc:
                try:
                    ctypes.windll.user32.ReleaseDC(None, hdc)
                except Exception:
                    pass
    return max(resolution, sys.getswitchinterval())

def _path_size_if_file(path: Path) -> int:
    try:
        return max(0, int(path.stat().st_size)) if path.is_file() else 0
    except OSError:
        return 0

def _tree_size_if_directory(path: Path) -> int:
    try:
        if not path.exists() or not path.is_dir():
            return 0
    except OSError:
        return 0
    total = 0
    try:
        for current, dirs, names in os.walk(path, topdown=True, followlinks=False):
            current_path = Path(current)
            dirs[:] = [name for name in dirs if not _path_is_reparse_or_symlink(current_path / name)] if "_path_is_reparse_or_symlink" in globals() else dirs
            for name in names:
                total += _path_size_if_file(current_path / name)
    except OSError:
        return total
    return total

DISK_ATOMIC_SAFETY_MULTIPLIER = 3
DISK_GROWTH_SAMPLE_LIMIT = 8
_STORAGE_GROWTH_LOCK = threading.RLock()
_STORAGE_GROWTH_SAMPLES: list[int] = []

def _storage_growth_samples() -> list[int]:
    with _STORAGE_GROWTH_LOCK:
        return list(_STORAGE_GROWTH_SAMPLES[-DISK_GROWTH_SAMPLE_LIMIT:])

def _restore_storage_growth_samples(values) -> None:
    clean = []
    for value in list(values or [])[-DISK_GROWTH_SAMPLE_LIMIT:]:
        try:
            clean.append(max(0, int(value)))
        except (TypeError, ValueError):
            continue
    with _STORAGE_GROWTH_LOCK:
        _STORAGE_GROWTH_SAMPLES[:] = clean

def _storage_footprint_bytes() -> int:
    if not RUNTIME_FOLDER_BOUND or BASE_DIR is None:
        return 0
    paths = [path for path in (CACHE_PATH, CACHE_ROLLBACK_PATH, MODEL_PATH, MODEL_ROLLBACK_PATH) if isinstance(path, Path)]
    total = sum(_path_size_if_file(path) for path in paths)
    for path in (DEPS_DIR, DEPS_TMP_DIR, DEPS_BACKUP_DIR, RUNTIME_TMP_DIR):
        if isinstance(path, Path):
            total += _tree_size_if_directory(path)
    wheel_stage = BASE_DIR / "BestFunds_wheels.tmp"
    total += _tree_size_if_directory(wheel_stage)
    return total

def _record_storage_growth(before_bytes: int) -> None:
    growth = max(0, _storage_footprint_bytes() - max(0, int(before_bytes)))
    if growth <= 0:
        return
    with _STORAGE_GROWTH_LOCK:
        _STORAGE_GROWTH_SAMPLES.append(growth)
        del _STORAGE_GROWTH_SAMPLES[:-DISK_GROWTH_SAMPLE_LIMIT]

def _objective_low_disk_reserve_bytes(additional_bytes: int = 0) -> int:
    """Reserve a safety multiple of the largest real atomic write plus observed refresh growth."""
    if not RUNTIME_FOLDER_BOUND or BASE_DIR is None:
        return FILE_IO_CHUNK_BYTES
    db = _path_size_if_file(CACHE_PATH) if isinstance(CACHE_PATH, Path) else 0
    wal = _path_size_if_file(Path(str(CACHE_PATH) + "-wal")) if isinstance(CACHE_PATH, Path) else 0
    journal = _path_size_if_file(Path(str(CACHE_PATH) + "-journal")) if isinstance(CACHE_PATH, Path) else 0
    rollback_db = _path_size_if_file(CACHE_ROLLBACK_PATH) if isinstance(CACHE_ROLLBACK_PATH, Path) else 0
    # SQLite may need a second database-sized copy for VACUUM/rollback while WAL or journal is live.
    sqlite_atomic = max(FILE_IO_CHUNK_BYTES, db * 2, db + wal + journal, rollback_db + db)

    model_bytes = max(
        _path_size_if_file(MODEL_PATH) if isinstance(MODEL_PATH, Path) else 0,
        _path_size_if_file(MODEL_ROLLBACK_PATH) if isinstance(MODEL_ROLLBACK_PATH, Path) else 0,
    )
    model_atomic = max(FILE_IO_CHUNK_BYTES, model_bytes * 2)

    active_dependencies = _tree_size_if_directory(DEPS_DIR) if isinstance(DEPS_DIR, Path) else 0
    staged_dependencies = _tree_size_if_directory(DEPS_TMP_DIR) if isinstance(DEPS_TMP_DIR, Path) else 0
    backup_dependencies = _tree_size_if_directory(DEPS_BACKUP_DIR) if isinstance(DEPS_BACKUP_DIR, Path) else 0
    wheel_stage = _tree_size_if_directory(BASE_DIR / "BestFunds_wheels.tmp")
    dependency_atomic = max(
        FILE_IO_CHUNK_BYTES,
        staged_dependencies + active_dependencies,
        wheel_stage + staged_dependencies,
        backup_dependencies + active_dependencies,
    )
    training_atomic = max(
        FILE_IO_CHUNK_BYTES,
        _tree_size_if_directory(RUNTIME_TMP_DIR) if isinstance(RUNTIME_TMP_DIR, Path) else 0,
    )

    recent_growth = _storage_growth_samples()
    growth_headroom = FILE_IO_CHUNK_BYTES
    if recent_growth:
        growth_headroom = max(max(recent_growth), math.ceil(statistics.fmean(recent_growth) * 2.0))
    largest_atomic = max(sqlite_atomic, model_atomic, dependency_atomic, training_atomic)
    required = largest_atomic + growth_headroom + max(0, int(additional_bytes))
    return max(FILE_IO_CHUNK_BYTES, required * DISK_ATOMIC_SAFETY_MULTIPLIER)

def _require_storage_write_capacity(purpose: str, additional_bytes: int = 0) -> None:
    if _storage_survival_mode_active():
        raise StorageError(f"磁盘空间保护模式已启用：停止写入{purpose}，继续读取 last-known-good")
    if not _disk_capacity_allows(additional_bytes):
        _set_storage_survival_mode(True)
        raise StorageError(
            f"用户选择目录剩余空间低于长期安全余量：停止写入{purpose}，继续读取 last-known-good"
        )

def _selected_folder_free_bytes() -> int:
    try:
        return max(0, int(shutil.disk_usage(BASE_DIR).free))
    except (OSError, TypeError, AttributeError):
        return 0

def _disk_capacity_allows(additional_bytes: int = 0) -> bool:
    free = _selected_folder_free_bytes()
    return bool(free and free >= _objective_low_disk_reserve_bytes(additional_bytes))

def _objective_disk_pressure(free_disk_bytes: int) -> bool:
    """One shared low-disk predicate for live monitoring and unified storage GC."""
    free_bytes = max(0, int(_finite(free_disk_bytes, 0)))
    return free_bytes < _objective_low_disk_reserve_bytes()

_STORAGE_SURVIVAL_LOCK = threading.RLock()
_STORAGE_SURVIVAL_ACTIVE = False

def _set_storage_survival_mode(active: bool) -> None:
    global _STORAGE_SURVIVAL_ACTIVE
    with _STORAGE_SURVIVAL_LOCK:
        _STORAGE_SURVIVAL_ACTIVE = bool(active)

def _storage_survival_mode_active() -> bool:
    with _STORAGE_SURVIVAL_LOCK:
        return bool(_STORAGE_SURVIVAL_ACTIVE)

def _storage_survival_recheck() -> bool:
    """Exit read-only survival automatically once measured free space again satisfies the live reserve."""
    if not _storage_survival_mode_active():
        return False
    free = _selected_folder_free_bytes()
    if not _objective_disk_pressure(free):
        _set_storage_survival_mode(False)
        return False
    return True

def _objective_retry_delay(error_streak: int) -> float:
    """Cold-source retry pacing from protocol timeout; explicit Retry-After always wins."""
    streak = max(1, int(error_streak))
    retry_after = _server_retry_after_remaining() if "_server_retry_after_remaining" in globals() else 0.0
    if retry_after > 0.0:
        return retry_after
    return _platform_network_inactivity_timeout_seconds() * streak

PURCHASE_UNAVAILABLE_STATUSES = frozenset({"purchase_suspended", "closed", "confirmed_unavailable", "high_probability_unavailable", "unavailable"})
CURRENT_PURCHASE_EVIDENCE_FIELDS = (
    "availability_status", "availability_generated_at", "availability_note",
    "availability_evidence", "availability_public_signals",
    "availability_public_confirmations", "purchase_public_confirmations",
    "public_purchase_status", "public_purchase_status_secondary",
    "metadata_checked_at", "metadata_sources",
)
USER_AGENT = (
    "BestFunds "
    f"Python/{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} "
    f"({platform.system()} {platform.machine()})"
)

CHINA_TZ = _dt.timezone(CHINA_UTC_OFFSET)

EASTMONEY_REDIRECT_HOSTS = frozenset({
    "fund.eastmoney.com", "api.fund.eastmoney.com",
    "fundmobapi.eastmoney.com", "fundf10.eastmoney.com",
})
SINA_REDIRECT_HOSTS = frozenset({
    "vip.stock.finance.sina.com.cn", "stock.finance.sina.com.cn",
    "money.finance.sina.com.cn", "finance.sina.com.cn",
})


def _china_today() -> _dt.date:
    """Single China-market calendar date entry point; independent of the Windows local timezone."""
    return _dt.datetime.now(tz=CHINA_TZ).date()


def _human_seconds(seconds: float) -> str:
    seconds = max(0, int(math.ceil(seconds)))
    if seconds < SECONDS_PER_MINUTE:
        return f"{seconds}秒"
    minutes, seconds = divmod(seconds, SECONDS_PER_MINUTE)
    if minutes < SECONDS_PER_MINUTE:
        return f"{minutes}分{seconds:02d}秒" if seconds else f"{minutes}分钟"
    hours, minutes = divmod(minutes, SECONDS_PER_MINUTE)
    return f"{hours}小时{minutes:02d}分"


class SmartRefreshPolicy:
    """Market/source-driven cadence: observed source changes, NAV state, market boundaries and Retry-After."""

    def __init__(self):
        self.error_streak = 0
        self.low_coverage_streak = 0
        self.stable_streak = 0
        self.no_today_nav_streak = 0
        self.last_delay = 0.0
        self.last_reason = "等待首次分析"
        self._last_source_change_at: float | None = None
        self._source_interval_count = 0
        self._source_interval_mean = 0.0
        self._source_interval_m2 = 0.0
        self._source_interval_max = 0.0

    @staticmethod
    def _phase(now: _dt.datetime) -> str:
        now = now.astimezone(CHINA_TZ)
        if now.weekday() >= MARKET_WEEKDAYS_PER_WEEK:
            return "休市"
        local_time = now.time().replace(tzinfo=None)
        if MARKET_MORNING_OPEN <= local_time < MARKET_MORNING_CLOSE or MARKET_AFTERNOON_OPEN <= local_time < MARKET_CLOSE:
            return "交易时段"
        if MARKET_MORNING_CLOSE <= local_time < MARKET_AFTERNOON_OPEN:
            return "午间休市"
        if local_time >= MARKET_CLOSE:
            return "收盘后"
        return "开盘前"

    @staticmethod
    def _latest_by_market_context(results: list[dict] | None) -> dict[tuple[str, str], str]:
        latest: dict[tuple[str, str], str] = {}
        for raw in results or []:
            if not isinstance(raw, dict):
                continue
            day = str(raw.get("latest_date") or raw.get("display_nav_date") or "")[:DATE_TEXT_LENGTH]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                continue
            asset = _asset_bucket(str(raw.get("name") or ""), str(raw.get("type") or ""))
            sources = _market_session_sources(raw) or {"*"}
            for source in sources:
                key = (asset, source)
                latest[key] = max(latest.get(key, ""), day)
        return latest

    @classmethod
    def _nav_pending(cls, results: list[dict] | None, now: _dt.datetime) -> bool:
        now_cn = now.astimezone(CHINA_TZ)
        if now_cn.weekday() >= MARKET_WEEKDAYS_PER_WEEK or now_cn.time().replace(tzinfo=None) < MARKET_CLOSE:
            return False
        today = now_cn.date().isoformat()
        contexts = cls._latest_by_market_context(results)
        return bool(contexts) and any(day < today for day in contexts.values())

    @classmethod
    def _today_session_observed(cls, results: list[dict] | None, now: _dt.datetime) -> bool:
        now_cn = now.astimezone(CHINA_TZ)
        today = now_cn.date()
        contexts = cls._latest_by_market_context(results)
        if not contexts:
            return False
        yesterday = today - _dt.timedelta(days=1)
        with _OBSERVED_MARKET_SESSION_LOCK:
            for (asset, source), latest_day in contexts.items():
                if latest_day >= today.isoformat():
                    continue
                source_days = _OBSERVED_MARKET_SESSIONS_BY_CONTEXT.get((asset, source), set())
                if not source_days and source != "*":
                    source_days = _OBSERVED_MARKET_SESSIONS_BY_CONTEXT.get((asset, "*"), set())
                if not any(yesterday.isoformat() < day <= today.isoformat() for day in source_days):
                    return False
        return True

    @staticmethod
    def _next_weekday(day: _dt.date) -> _dt.date:
        candidate = day + _dt.timedelta(days=1)
        while candidate.weekday() >= MARKET_WEEKDAYS_PER_WEEK:
            candidate += _dt.timedelta(days=1)
        return candidate

    @classmethod
    def _next_market_event(cls, now: _dt.datetime) -> tuple[_dt.datetime, str]:
        now_cn = now.astimezone(CHINA_TZ)
        day = now_cn.date()
        local_time = now_cn.time().replace(tzinfo=None)
        combine = lambda date, clock: _dt.datetime.combine(date, clock, tzinfo=CHINA_TZ)
        if now_cn.weekday() >= MARKET_WEEKDAYS_PER_WEEK:
            candidate = day
            while candidate.weekday() >= MARKET_WEEKDAYS_PER_WEEK:
                candidate += _dt.timedelta(days=1)
            return combine(candidate, MARKET_MORNING_OPEN), "下一交易日开盘"
        if local_time < MARKET_MORNING_OPEN:
            return combine(day, MARKET_MORNING_OPEN), "开盘"
        if local_time < MARKET_MORNING_CLOSE:
            return combine(day, MARKET_MORNING_CLOSE), "午间休市"
        if local_time < MARKET_AFTERNOON_OPEN:
            return combine(day, MARKET_AFTERNOON_OPEN), "午后开盘"
        if local_time < MARKET_CLOSE:
            return combine(day, MARKET_CLOSE), "收盘"
        return combine(cls._next_weekday(day), MARKET_MORNING_OPEN), "下一交易日开盘"

    def _observed_source_interval(self) -> float | None:
        if self._source_interval_count <= 0 or self._source_interval_max <= 0.0:
            return None
        deviation = math.sqrt(self._source_interval_m2 / max(1, self._source_interval_count - 1)) if self._source_interval_count > 1 else 0.0
        return max(self._source_interval_max, self._source_interval_mean + deviation)

    def _record_source_change(self, changed: bool, at_monotonic: float) -> None:
        if not changed:
            return
        if self._last_source_change_at is not None:
            interval = max(time.get_clock_info("monotonic").resolution, at_monotonic - self._last_source_change_at)
            self._source_interval_count += 1
            delta = interval - self._source_interval_mean
            self._source_interval_mean += delta / self._source_interval_count
            self._source_interval_m2 += delta * (interval - self._source_interval_mean)
            self._source_interval_max = max(self._source_interval_max, interval)
        self._last_source_change_at = at_monotonic

    def _finish(self, seconds: float, reason: str) -> float:
        resolution = time.get_clock_info("monotonic").resolution
        self.last_delay = max(resolution, _finite(seconds, resolution))
        self.last_reason = reason
        return self.last_delay

    def _market_delay(self, results: list[dict] | None, now: _dt.datetime, elapsed: float = 0.0) -> tuple[float, str]:
        retry_after = _server_retry_after_remaining() if "_server_retry_after_remaining" in globals() else 0.0
        if retry_after > 0.0:
            return retry_after, "服务器 Retry-After"
        now_cn = now.astimezone(CHINA_TZ)
        phase = self._phase(now_cn)
        observed_interval = self._observed_source_interval()
        if phase == "交易时段" and observed_interval is not None:
            return observed_interval, "交易时段·按已观测源更新间隔"
        if phase == "收盘后" and self._today_session_observed(results, now_cn):
            event_at, event_name = self._next_market_event(now_cn)
            return max(0.0, (event_at - now_cn).total_seconds()), f"今日NAV已出现·等待{event_name}"
        if phase == "收盘后" and self._nav_pending(results, now_cn):
            close_at = _dt.datetime.combine(now_cn.date(), MARKET_CLOSE, tzinfo=CHINA_TZ)
            pending_age = max(0.0, (now_cn - close_at).total_seconds())
            candidates = [value for value in (observed_interval, max(0.0, _finite(elapsed))) if value is not None and value > 0.0]
            candidates.append(max(time.get_clock_info("monotonic").resolution, pending_age))
            return max(candidates), "收盘后·今日NAV尚未出现·按已观测等待时长降频"
        event_at, event_name = self._next_market_event(now_cn)
        return max(0.0, (event_at - now_cn).total_seconds()), f"{phase}·等待{event_name}"

    def initial_delay(self, results: list[dict] | None, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        delay, reason = self._market_delay(results, now, 0.0)
        return self._finish(delay, reason)

    def on_success(self, outcome: dict, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        self.error_streak = 0
        coverage = _finite(outcome.get("coverage"), 0.0)
        elapsed = max(0.0, _finite(outcome.get("elapsed_seconds"), 0.0))
        results = outcome.get("results") or []
        changed = int(outcome.get("updated_series") or 0)
        pool_changes = len(outcome.get("new_codes") or []) + len(outcome.get("removed_codes") or [])
        self._record_source_change(bool(changed or pool_changes), time.monotonic())
        after_close_pending = self._phase(now) == "收盘后" and not self._today_session_observed(results, now)
        self.no_today_nav_streak = self.no_today_nav_streak + 1 if after_close_pending else 0

        if coverage < REFRESH_MIN_COVERAGE or outcome.get("ranking_updated") is False:
            self.low_coverage_streak += 1
            self.stable_streak = 0
            retry_after = _server_retry_after_remaining() if "_server_retry_after_remaining" in globals() else 0.0
            base = max(retry_after, elapsed, _platform_network_inactivity_timeout_seconds())
            detail = "Top候选不完整" if outcome.get("priority_complete") is False else f"覆盖率{_format_unrounded_number(coverage, '%', scale=PERCENT_SCALE)}"
            return self._finish(base * self.low_coverage_streak, f"{detail}·按失败观测退避")

        self.low_coverage_streak = 0
        self.stable_streak = self.stable_streak + 1 if not (changed or pool_changes) else 0
        delay, reason = self._market_delay(results, now, elapsed)
        if pool_changes:
            reason = f"候选池变化{pool_changes}项·{reason}"
        elif changed:
            reason = f"发现{changed}个新净值·{reason}"
        return self._finish(delay, reason)

    def on_error(self, elapsed: float = 0.0) -> float:
        self.error_streak += 1
        self.low_coverage_streak = 0
        self.stable_streak = 0
        retry_after = _server_retry_after_remaining() if "_server_retry_after_remaining" in globals() else 0.0
        if retry_after > 0.0:
            return self._finish(retry_after, "服务器 Retry-After")
        observed_failure = max(0.0, _finite(elapsed, 0.0))
        base = observed_failure if observed_failure > 0.0 else _platform_network_inactivity_timeout_seconds()
        return self._finish(base * self.error_streak, f"网络/数据失败×{self.error_streak}·按实际失败耗时退避")



class DataError(RuntimeError):
    pass


class NetworkError(DataError):
    """Transient transport/HTTP failure; callers may retry or use a fallback source."""


class ContractError(DataError):
    """Remote payload shape/semantics no longer satisfy the adapter contract."""


class ParseError(DataError):
    """Received content could not be parsed according to the expected source format."""


class StorageError(DataError):
    """Local persistence or isolation failure."""


class ModelError(DataError):
    """Optional model backend/training failure."""


SOURCE_ADAPTER_ERRORS = (
    DataError, urllib.error.URLError, TimeoutError, ConnectionError, OSError,
    json.JSONDecodeError, UnicodeError, ValueError, KeyError, IndexError,
)


def _typed_source_error(exc: BaseException, context: str) -> DataError:
    """Map only known transport/payload failures; unknown programming errors must propagate."""
    if isinstance(exc, DataError):
        return exc
    if isinstance(exc, (urllib.error.URLError, TimeoutError, ConnectionError, OSError)):
        return NetworkError(f"{context}: {type(exc).__name__}: {exc}")
    if isinstance(exc, (json.JSONDecodeError, UnicodeError, ValueError, KeyError, IndexError)):
        return ParseError(f"{context}: {type(exc).__name__}: {exc}")
    raise exc


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _parse_iso(value: str | None) -> _dt.datetime | None:
    if not value:
        return None
    try:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        return _dt.datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def _finite(value, default=0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _published_decimal_places(value_text) -> int | None:
    text = str(value_text or "").strip()
    if not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", text):
        return None
    return len(text.partition(".")[2]) if "." in text else 0


def _format_published_number(value, decimals) -> str:
    number = _finite(value, float("nan"))
    if not math.isfinite(number):
        return "—"
    try:
        places = int(decimals)
    except (TypeError, ValueError):
        places = -1
    if places >= 0:
        return f"{number:.{places}f}"
    return repr(float(number))


def _format_unrounded_number(value, suffix: str = "", *, signed: bool = False, scale: float = 1.0) -> str:
    number = _finite(value, float("nan"))
    if not math.isfinite(number):
        return "—"
    number *= scale
    text = repr(float(number))
    if signed and number >= 0.0:
        text = "+" + text
    return text + suffix


def _published_navs_compatible(left_value, left_decimals, right_value, right_decimals) -> bool:
    """True when the two published rounded NAVs can represent at least one common real value."""
    try:
        ld = int(left_decimals); rd = int(right_decimals)
        if ld < 0 or rd < 0:
            return False
        left = Decimal(str(left_value)); right = Decimal(str(right_value))
        if not left.is_finite() or not right.is_finite() or left <= 0 or right <= 0:
            return False
        left_half = Decimal(1).scaleb(-ld) / Decimal(2)
        right_half = Decimal(1).scaleb(-rd) / Decimal(2)
        return max(left - left_half, right - right_half) <= min(left + left_half, right + right_half)
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        return False

def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _compound(values) -> float:
    total = 1.0
    return_floor = -1.0 + sys.float_info.epsilon
    for value in values:
        total *= 1.0 + max(return_floor, _finite(value))
    return total - 1.0


def _max_drawdown(values) -> float:
    wealth = 1.0
    peak = 1.0
    worst = 0.0
    return_floor = -1.0 + sys.float_info.epsilon
    for value in values:
        wealth *= 1.0 + max(return_floor, _finite(value))
        peak = max(peak, wealth)
        worst = min(worst, wealth / max(peak, sys.float_info.min) - 1.0)
    return worst


def _calendar_annualized_risk(
    returns, dates, start_return_index: int, finish_index: int
) -> tuple[float, float, list[float], float]:
    """Annualize irregular-period risk from actual calendar intervals, not observation counts."""
    finish_index = min(len(returns), len(dates), max(0, int(finish_index)))
    start_return_index = max(1, int(start_return_index))
    if start_return_index >= finish_index:
        return 0.0, 0.0, [], 0.0
    try:
        date_objects = [
            value if isinstance(value, _dt.date) else _dt.date.fromisoformat(str(value)[:DATE_TEXT_LENGTH])
            for value in dates[:finish_index]
        ]
    except ValueError:
        return 0.0, 0.0, [], 0.0
    increments: list[tuple[float, float]] = []
    for index in range(start_return_index, finish_index):
        days = (date_objects[index] - date_objects[index - 1]).days
        if days <= 0:
            continue
        elapsed_years = days / AVERAGE_GREGORIAN_DAYS_PER_YEAR
        value = max(-1.0 + sys.float_info.epsilon, _finite(returns[index]))
        increments.append((math.log1p(value), elapsed_years))
    total_years = sum(elapsed for _, elapsed in increments)
    if total_years <= 0.0:
        return 0.0, 0.0, [], 0.0
    drift = sum(log_return for log_return, _ in increments) / total_years
    variance_rate = sum(
        (log_return - drift * elapsed) ** 2
        for log_return, elapsed in increments
    ) / total_years
    downside_rate = sum(
        min(0.0, log_return) ** 2
        for log_return, _ in increments
    ) / total_years
    standardized = [
        log_return / math.sqrt(max(elapsed, sys.float_info.epsilon))
        for log_return, elapsed in increments
    ]
    return math.sqrt(max(0.0, variance_rate)), math.sqrt(max(0.0, downside_rate)), standardized, total_years


def _pearson(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 2:
        return 0.0
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = sum((x - mx) ** 2 for x in xs)
    dy = sum((y - my) ** 2 for y in ys)
    if dx <= NUMERIC_TOLERANCE or dy <= NUMERIC_TOLERANCE:
        return 0.0
    return numerator / math.sqrt(dx * dy)


def _spearman(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 2:
        return 0.0
    return _pearson(_rank_scale(xs), _rank_scale(ys))


def _median(values, default=0.0) -> float:
    clean = [_finite(v, float("nan")) for v in values]
    clean = [v for v in clean if math.isfinite(v)]
    return statistics.median(clean) if clean else default



def _rate(value, default=0.0) -> float:
    return max(0.0, _finite(value, default))


def _asset_bucket(name: str, fund_type: str) -> str:
    text = f"{name} {fund_type}".upper()
    if "QDII" in text or "海外" in text or any(word in text for word in ("纳斯达克", "标普", "全球", "恒生", "美国")):
        return "QDII/海外"
    if "FOF" in text or "基金中基金" in text:
        return "FOF"
    coarse = _coarse_type(fund_type)
    if coarse == "债券":
        return "债券"
    if coarse == "指数":
        return "指数"
    if coarse in ("股票", "混合"):
        return "主动权益"
    return "其他"



def _redemption_fee_for_holding_years(fees: dict | None, years: int) -> float | None:
    if not isinstance(fees, dict):
        return None
    schedule = fees.get("redemption_schedule")
    if not isinstance(schedule, list):
        return None
    holding_days = max(1, int(round(max(1, int(years)) * AVERAGE_GREGORIAN_DAYS_PER_YEAR)))
    matches = []
    for row in schedule:
        if not isinstance(row, dict):
            continue
        lower = _finite(row.get("lower_days"), 0.0)
        upper = _finite(row.get("upper_days"), float("inf"))
        rate = row.get("rate")
        if rate is not None and lower <= holding_days < upper:
            matches.append(_rate(rate))
    return min(matches) if matches else None


def _holding_costs(fees: dict | None, holding_years: int | None = None) -> dict:
    """Compute share-class cost for the runtime-selected model horizon only."""
    output = {
        "annual_cost": None, "embedded_annual_cost": None, "purchase_cost": None,
        "transaction_cost": None, "total_share_class_cost": None,
    }
    if not isinstance(fees, dict):
        return output

    def known_rate(key: str):
        value = fees.get(key)
        return None if value is None else _rate(value)

    purchase = known_rate("purchase_fee")
    embedded_parts = [known_rate(key) for key in (
        "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
    )]
    embedded_annual = sum(embedded_parts) if all(value is not None for value in embedded_parts) else None
    output.update({
        "annual_cost": embedded_annual,
        "embedded_annual_cost": embedded_annual,
        "purchase_cost": purchase,
    })
    if holding_years is None:
        return output
    years = _expected_holding_years(holding_years)
    redemption = _redemption_fee_for_holding_years(fees, years)
    transaction = purchase + redemption if purchase is not None and redemption is not None else None
    total = transaction + years * embedded_annual if transaction is not None and embedded_annual is not None else None
    output["transaction_cost"] = transaction
    output["total_share_class_cost"] = total
    return output


def _expected_holding_years(value=None, model: dict | None = None) -> int:
    if value is None:
        return _model_target_years(model)
    try:
        return max(MIN_LONG_TERM_HORIZON_YEARS, int(value))
    except (TypeError, ValueError):
        return _model_target_years(model)


def _transaction_cost_from_fees(fees: dict | None, years: int) -> float | None:
    costs = _holding_costs(fees, _expected_holding_years(years))
    value = costs.get("transaction_cost")
    if value is None:
        return None
    parsed = _finite(value, float("nan"))
    return max(0.0, parsed) if math.isfinite(parsed) else None


def _realized_net_holding_return(
    gross_return: float, fees: dict | None, years: int,
    unknown_transaction_cost: float | None = None,
) -> tuple[float, dict]:
    """Single source of truth for investor net return after purchase/redemption transaction fees.

    NAV already embeds management/custody/sales-service expenses, so those annual charges are
    deliberately not deducted again here.
    """
    years = _expected_holding_years(years)
    gross = max(-1.0 + sys.float_info.epsilon, _finite(gross_return))
    costs = _holding_costs(fees, years)
    purchase = costs.get("purchase_cost")
    redemption = _redemption_fee_for_holding_years(fees, years) if isinstance(fees, dict) else None
    fee_evidence_known = purchase is not None and redemption is not None
    if fee_evidence_known:
        purchase_rate = max(0.0, _finite(purchase))
        redemption_rate = _clamp(_finite(redemption), 0.0, 1.0)
        # Subscription fees reduce the amount that acquires units; redemption fees reduce proceeds.
        terminal_wealth = ((1.0 + gross) / (1.0 + purchase_rate)) * (1.0 - redemption_rate)
        source = "verified-purchase-and-redemption-fees"
        imputed_cost = None
    else:
        imputed = _finite(unknown_transaction_cost, float("nan"))
        if not math.isfinite(imputed):
            imputed = UNKNOWN_TRANSACTION_COST_FALLBACK
        imputed = _clamp(imputed, 0.0, 1.0)
        terminal_wealth = (1.0 + gross) * (1.0 - imputed)
        source = "conservative-unknown-fee-imputation"
        imputed_cost = imputed
    net_return = max(-1.0 + sys.float_info.epsilon, terminal_wealth - 1.0)
    zero_gross_terminal = ((1.0 / (1.0 + max(0.0, _finite(purchase)))) * (1.0 - _clamp(_finite(redemption), 0.0, 1.0))) if fee_evidence_known else (1.0 - imputed_cost)
    effective_transaction_cost = _clamp(1.0 - zero_gross_terminal, 0.0, 1.0)
    return net_return, {
        "fee_evidence_known": bool(fee_evidence_known),
        "cost_source": source,
        "purchase_fee": max(0.0, _finite(purchase)) if purchase is not None else None,
        "redemption_fee": max(0.0, _finite(redemption)) if redemption is not None else None,
        "imputed_transaction_cost": imputed_cost,
        "effective_transaction_cost": effective_transaction_cost,
    }


def _net_holding_return_path(
    returns: list[float], fees: dict | None, years: int,
    unknown_transaction_cost: float | None = None,
) -> tuple[list[float], dict]:
    """Return a path whose compounded terminal wealth equals _realized_net_holding_return()."""
    clean = [max(-1.0 + sys.float_info.epsilon, _finite(value)) for value in (returns or [])]
    if not clean:
        return [], {"fee_evidence_known": False, "effective_transaction_cost": None}
    gross = _compound(clean)
    net_total, evidence = _realized_net_holding_return(gross, fees, years, unknown_transaction_cost)
    prefix_total = _compound(clean[:-1]) if len(clean) > 1 else 0.0
    adjusted_last = (1.0 + net_total) / max(1.0 + prefix_total, sys.float_info.min) - 1.0
    clean[-1] = max(-1.0 + sys.float_info.epsilon, adjusted_last)
    return clean, evidence


def _share_class_cost(fund: dict, years: int) -> float:
    years = _expected_holding_years(years)
    if fund.get("fees_verified") is not True:
        return float("inf")
    fees = fund.get("fees") if isinstance(fund.get("fees"), dict) else {}
    costs = _holding_costs(fees, years)
    total = costs.get("total_share_class_cost")
    return float("inf") if total is None else max(0.0, _finite(total))


def _underlying_key(fund: dict) -> str:
    explicit = str(
        fund.get("underlying_fund_id") or fund.get("master_code")
        or fund.get("primary_code") or ""
    ).strip().casefold()
    if explicit:
        return explicit if explicit.startswith(("id:", "name:", "code:")) else "id:" + explicit
    base = _base_name(str(fund.get("name") or ""))
    wrapper = _wrapper_type(str(fund.get("type") or ""))
    return f"name:{base.casefold()}|{wrapper}" if base else "code:" + str(fund.get("code") or "")


def _validate_formal_results(results: list[dict]) -> list[dict]:
    rows = list(results or [])
    if not 1 <= len(rows) <= DISPLAY_TOP_N:
        raise DataError(f"正式结果必须为 1~{DISPLAY_TOP_N} 只，当前为 {len(rows)} 只")
    underlying = {_underlying_key(item) for item in rows}
    if "" in underlying or len(underlying) != len(rows):
        raise DataError(f"正式结果存在重复或缺失的底层基金标识")
    for item in rows:
        if item.get("absolute_investability") is not True:
            raise DataError(f"正式结果包含未通过绝对买入门控的基金：{item.get('code') or 'unknown'}")
        if str(item.get("availability_status") or "unknown") not in FORMAL_PURCHASABLE_STATUSES:
            raise DataError(f"正式结果包含当前不可确认申购的基金：{item.get('code') or 'unknown'}")
    # Explicit IDs are authoritative, but also fail closed on names that still look like
    # duplicate share classes (A/C/F/G/...; 类/份额) after normalization.
    suspicious = set()
    seen_signatures = set()
    for item in rows:
        base = _base_name(str(item.get("name") or "")).casefold()
        if not base:
            continue
        signature = (base, _wrapper_type(str(item.get("type") or "")))
        if signature in seen_signatures:
            suspicious.add(signature)
        seen_signatures.add(signature)
    if suspicious:
        raise DataError("正式结果存在疑似同底层基金的不同份额")
    return rows


def _formal_top_nav_verified(results: list[dict], fresh_codes) -> bool:
    rows = list(results or [])
    codes = {str(item.get("code") or "") for item in rows}
    return bool(
        1 <= len(rows) <= DISPLAY_TOP_N
        and len(codes) == len(rows)
        and "" not in codes
        and codes <= {str(code) for code in (fresh_codes or [])}
    )


def _add_years(day: _dt.date, years: int) -> _dt.date:
    target_year = day.year + years
    target_day = min(day.day, calendar.monthrange(target_year, day.month)[1])
    return day.replace(year=target_year, day=target_day)


def _years_before(day: _dt.date, years: int) -> _dt.date:
    return _add_years(day, -years)




# Public NAV dates are retained only as provider-scoped activity/gap evidence.
# They are never authoritative for the theoretically expected latest market session.
_OBSERVED_MARKET_SESSIONS_BY_CONTEXT: dict[tuple[str, str], set[str]] = {}
_OBSERVED_MARKET_SESSION_CONTEXT_COUNTS: dict[tuple[str, str, str], int] = {}
_OBSERVED_MARKET_SESSION_SORTED_CACHE: dict[tuple[str, str], tuple[str, ...]] = {}
_OBSERVED_MARKET_SESSION_LOCK = threading.RLock()


def _market_session_source_family(value: str) -> str:
    text = str(value or "").strip().casefold()
    if not text:
        return ""
    if "东方财富" in text or "eastmoney" in text:
        return "eastmoney"
    if "新浪" in text or "sina" in text:
        return "sina"
    if "本地历史缓存" in text or "persisted" in text or "sqlite" in text:
        return "persisted-history"
    return ""


def _market_session_sources(item: dict | None) -> set[str]:
    item = item if isinstance(item, dict) else {}
    sources: set[str] = set()
    raw_latest = item.get("latest_sources")
    if isinstance(raw_latest, (list, tuple, set, frozenset)):
        for value in raw_latest:
            family = _market_session_source_family(value)
            if family:
                sources.add(family)
    for key in ("source", "history_source", "fund_data_source"):
        text = str(item.get(key) or "")
        for token in ("东方财富", "新浪", "eastmoney", "sina", text):
            if token and token.casefold() in text.casefold():
                family = _market_session_source_family(token)
                if family:
                    sources.add(family)
    return sources


def _merge_observed_market_session_context_counts(counts: dict[tuple[str, str, str], int]) -> None:
    if not isinstance(counts, dict):
        return
    with _OBSERVED_MARKET_SESSION_LOCK:
        for key, raw_count in counts.items():
            if not isinstance(key, tuple) or len(key) != 3:
                continue
            asset_bucket, source_family, value = (str(part or "").strip() for part in key)
            day = value[:DATE_TEXT_LENGTH]
            if not asset_bucket or not source_family or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                continue
            count = max(0, int(_finite(raw_count, 0)))
            if count <= 0:
                continue
            context_key = (asset_bucket, source_family, day)
            previous = _OBSERVED_MARKET_SESSION_CONTEXT_COUNTS.get(context_key, 0)
            _OBSERVED_MARKET_SESSION_CONTEXT_COUNTS[context_key] = max(previous, count)
            session_key = (asset_bucket, source_family)
            sessions = _OBSERVED_MARKET_SESSIONS_BY_CONTEXT.setdefault(session_key, set())
            if day not in sessions:
                sessions.add(day)
                _OBSERVED_MARKET_SESSION_SORTED_CACHE.pop(session_key, None)


def _register_observed_market_rows(rows: dict[str, dict], fund_types: dict[str, str] | None = None) -> None:
    fund_types = fund_types or {}
    by_context_day: dict[tuple[str, str, str], set[str]] = {}
    for code, raw in (rows or {}).items():
        row = raw if isinstance(raw, dict) else {}
        day = str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            continue
        asset = _asset_bucket(str(row.get("name") or ""), str(fund_types.get(str(code)) or row.get("type") or ""))
        sources = _market_session_sources(row) or {"*"}
        for source in set(sources) | {"*"}:
            by_context_day.setdefault((asset, source, day), set()).add(str(code))
    if by_context_day:
        _merge_observed_market_session_context_counts({key: len(codes) for key, codes in by_context_day.items()})


def _register_observed_fund_histories(funds: list[dict]) -> None:
    by_context_day: dict[tuple[str, str, str], set[str]] = {}
    for item in funds or []:
        if not isinstance(item, dict):
            continue
        code = str(item.get("code") or "")
        if not code:
            continue
        asset = _asset_bucket(str(item.get("name") or ""), str(item.get("type") or ""))
        sources = _market_session_sources(item) or {"*"}
        for value in item.get("dates") or []:
            day = str(value)[:DATE_TEXT_LENGTH]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                continue
            for source in set(sources) | {"*"}:
                by_context_day.setdefault((asset, source, day), set()).add(code)
    if by_context_day:
        _merge_observed_market_session_context_counts({key: len(codes) for key, codes in by_context_day.items()})


def _observed_market_sessions_between(
    start_exclusive: _dt.date,
    finish_inclusive: _dt.date,
    *,
    fund_type: str = "",
    name: str = "",
    sources=None,
) -> int:
    """Count only sessions observed for the same asset class and, when known, the same source family."""
    if finish_inclusive <= start_exclusive:
        return 0
    asset = _asset_bucket(name, fund_type)
    requested_sources = {str(value or "").strip() for value in (sources or []) if str(value or "").strip()}
    start_text, finish_text = start_exclusive.isoformat(), finish_inclusive.isoformat()
    with _OBSERVED_MARKET_SESSION_LOCK:
        confirmed: set[str] = set()
        if requested_sources and requested_sources != {"*"}:
            for source in requested_sources:
                confirmed.update(_OBSERVED_MARKET_SESSIONS_BY_CONTEXT.get((asset, source), set()))
        if not confirmed:
            confirmed.update(_OBSERVED_MARKET_SESSIONS_BY_CONTEXT.get((asset, "*"), set()))
    return sum(start_text < day <= finish_text for day in confirmed)


def _observed_market_sessions_for_item(start_exclusive: _dt.date, finish_inclusive: _dt.date, item: dict | None) -> int:
    row = item if isinstance(item, dict) else {}
    return _observed_market_sessions_between(
        start_exclusive,
        finish_inclusive,
        fund_type=str(row.get("type") or ""),
        name=str(row.get("name") or ""),
        sources=_market_session_sources(row),
    )


def _observed_market_sessions_between_fast(
    start_exclusive: _dt.date, finish_inclusive: _dt.date, context: dict | None,
) -> int:
    """Bisect-count same-context observed sessions for feature-density hot paths."""
    if finish_inclusive <= start_exclusive:
        return 0
    row = context if isinstance(context, dict) else {}
    asset = _asset_bucket(str(row.get("name") or ""), str(row.get("type") or ""))
    sources = _market_session_sources(row)
    source = next(iter(sources)) if len(sources) == 1 else "*"
    key = (asset, source)
    with _OBSERVED_MARKET_SESSION_LOCK:
        ordered = _OBSERVED_MARKET_SESSION_SORTED_CACHE.get(key)
        if ordered is None:
            ordered = tuple(sorted(_OBSERVED_MARKET_SESSIONS_BY_CONTEXT.get(key, set())))
            _OBSERVED_MARKET_SESSION_SORTED_CACHE[key] = ordered
    return max(
        0,
        bisect.bisect_right(ordered, finish_inclusive.isoformat())
        - bisect.bisect_right(ordered, start_exclusive.isoformat()),
    )


def _weekday_session_count(start_inclusive: _dt.date, finish_inclusive: _dt.date) -> int:
    """Conservative no-network upper bound for expected weekday market observations."""
    if finish_inclusive < start_inclusive:
        return 0
    total_days = (finish_inclusive - start_inclusive).days + 1
    full_weeks, remainder = divmod(total_days, calendar.SUNDAY + 1)
    count = full_weeks * MARKET_WEEKDAYS_PER_WEEK
    for offset in range(remainder):
        if (start_inclusive.weekday() + offset) % (calendar.SUNDAY + 1) < MARKET_WEEKDAYS_PER_WEEK:
            count += 1
    return count


def _history_density_evidence(
    dates: list[str] | tuple[str, ...], target_years: int, context: dict | None = None,
) -> dict:
    """Fail-closed density/gap evidence for model-quality history, independent of span alone."""
    values = [str(value)[:DATE_TEXT_LENGTH] for value in (dates or [])]
    evidence = {
        "passed": False,
        "observed_sessions": len(values),
        "expected_sessions": 0,
        "missing_fraction": 1.0,
        "density": 0.0,
        "recent_observed_sessions": 0,
        "recent_expected_sessions": 0,
        "recent_density": 0.0,
        "max_missing_sessions_between_observations": 0,
        "large_gap_count": 0,
        "max_allowed_missing_sessions": MAX_CONSECUTIVE_MISSING_SESSIONS,
        "minimum_density": MIN_HISTORY_DENSITY,
        "minimum_recent_density": MIN_RECENT_HISTORY_DENSITY,
        "expected_session_basis": "weekday upper bound plus same-asset/provider observed-session evidence",
    }
    if len(values) < MIN_HISTORY_POINTS:
        return evidence
    try:
        days = [_dt.date.fromisoformat(value) for value in values]
    except ValueError:
        return evidence
    if any(right <= left for left, right in zip(days, days[1:])):
        return evidence

    first_day, last_day = days[0], days[-1]
    weekday_expected = _weekday_session_count(first_day, last_day)
    context_row = context if isinstance(context, dict) else {}
    observed_context_expected = _observed_market_sessions_between_fast(
        first_day - _dt.timedelta(days=1), last_day, context_row,
    ) if context_row else 0
    expected = max(weekday_expected, observed_context_expected, len(days))
    density = _clamp(len(days) / max(1, expected), 0.0, 1.0)

    missing_between = []
    for left, right in zip(days, days[1:]):
        possible = _weekday_session_count(left + _dt.timedelta(days=1), right)
        # The right endpoint is itself observed; all other possible weekday sessions are missing.
        missing_between.append(max(0, possible - int(right.weekday() < MARKET_WEEKDAYS_PER_WEEK)))
    max_missing = max(missing_between, default=0)
    large_gap_count = sum(value > MAX_CONSECUTIVE_MISSING_SESSIONS for value in missing_between)

    recent_start = max(first_day, _years_before(last_day, max(1, int(target_years))))
    recent_days = [day for day in days if day >= recent_start]
    recent_weekday_expected = _weekday_session_count(recent_start, last_day)
    recent_context_expected = _observed_market_sessions_between_fast(
        recent_start - _dt.timedelta(days=1), last_day, context_row,
    ) if context_row else 0
    recent_expected = max(recent_weekday_expected, recent_context_expected, len(recent_days))
    recent_density = _clamp(len(recent_days) / max(1, recent_expected), 0.0, 1.0)

    evidence.update({
        "observed_sessions": len(days),
        "expected_sessions": expected,
        "missing_fraction": _clamp(1.0 - density, 0.0, 1.0),
        "density": density,
        "recent_observed_sessions": len(recent_days),
        "recent_expected_sessions": recent_expected,
        "recent_density": recent_density,
        "max_missing_sessions_between_observations": max_missing,
        "large_gap_count": large_gap_count,
    })
    evidence["passed"] = bool(
        density >= MIN_HISTORY_DENSITY
        and recent_density >= MIN_RECENT_HISTORY_DENSITY
        and max_missing <= MAX_CONSECUTIVE_MISSING_SESSIONS
        and large_gap_count == 0
    )
    return evidence

def _rank_scale(values) -> list[float]:
    """Return tie-aware percentile ranks in [0, 1]; callers explicitly sign-scale when needed."""
    count = len(values)
    if count <= 1:
        return [PROBABILITY_MIDPOINT] * count
    order = sorted(range(count), key=lambda i: (_finite(values[i]), i))
    result = [PROBABILITY_MIDPOINT] * count
    start = 0
    while start < count:
        end = start + 1
        current = _finite(values[order[start]])
        while end < count and abs(_finite(values[order[end]]) - current) < NUMERIC_TOLERANCE:
            end += 1
        average_rank = (start + end - 1) / 2.0
        scaled = average_rank / (count - 1)
        for position in range(start, end):
            result[order[position]] = scaled
        start = end
    return result


def _path_is_reparse_or_symlink(path: Path) -> bool:
    """True for symlinks and Windows reparse points (including junctions)."""
    path = Path(path)
    try:
        if path.is_symlink():
            return True
        if not os.path.lexists(str(path)):
            return False
        attrs = int(getattr(os.lstat(path), "st_file_attributes", 0) or 0)
        return bool(attrs & WINDOWS_FILE_ATTRIBUTE_REPARSE_POINT)
    except (OSError, ValueError):
        # If an existing app-owned path cannot be inspected safely, fail closed at callers.
        return os.path.lexists(str(path))


def _require_runtime_folder() -> Path:
    """Fail closed until the user-selected writable root has been explicitly bound."""
    if not RUNTIME_FOLDER_BOUND or BASE_DIR is None:
        raise StorageError("尚未绑定用户选择的非系统盘目录")
    return BASE_DIR


def _assert_isolated_app_path(path: Path, base: Path | None = None) -> Path:
    """Resolve every existing component and reject any escape/reparse point under the app root."""
    root = Path(base).resolve() if base is not None else _require_runtime_folder().resolve()
    target = Path(os.path.abspath(str(path)))
    try:
        relative = target.relative_to(root)
    except ValueError as exc:
        raise StorageError(f"应用可写路径越出用户选择目录：{target}") from exc
    current = root
    for part in relative.parts:
        current = current / part
        if not os.path.lexists(str(current)):
            continue
        if _path_is_reparse_or_symlink(current):
            raise StorageError(f"拒绝使用符号链接/junction/reparse point 作为应用可写路径：{current}")
        try:
            resolved = current.resolve(strict=True)
        except OSError as exc:
            raise StorageError(f"无法安全解析应用可写路径：{current}: {exc}") from exc
        if resolved != root and root not in resolved.parents:
            raise StorageError(f"应用可写路径解析后越出用户选择目录：{current} -> {resolved}")
    return target


def _runtime_audit_path(value, *, operation: str) -> None:
    """Reject Python-layer filesystem mutations outside the bound application root."""
    if not RUNTIME_FOLDER_BOUND or BASE_DIR is None or isinstance(value, int) or value is None:
        return
    try:
        raw = os.fsdecode(os.fspath(value))
    except (TypeError, ValueError):
        return
    if not raw:
        return
    # Null devices do not persist bytes and are needed by subprocess implementations.
    null_names = {os.path.normcase(os.devnull)}
    if os.name == "nt":
        null_names.add("nul")
    if os.path.normcase(raw) in null_names:
        return
    if raw == ":memory:" and operation == "sqlite3.connect":
        return
    if operation == "sqlite3.connect" and raw.startswith("file:"):
        parsed = urllib.parse.urlparse(raw)
        raw = urllib.parse.unquote(parsed.path or "")
        if os.name == "nt" and re.match(r"^/[A-Za-z]:/", raw):
            raw = raw[1:]
    target = Path(raw)
    if not target.is_absolute():
        target = Path.cwd() / target
    _assert_isolated_app_path(target)


def _runtime_write_audit(event: str, args) -> None:
    """PEP 578 write barrier: writable Python APIs may only target BASE_DIR."""
    if not RUNTIME_FOLDER_BOUND:
        return
    if event == "open":
        path = args[0] if args else None
        mode = args[1] if len(args) > 1 else None
        flags = args[2] if len(args) > 2 else 0
        writing = False
        if isinstance(mode, str):
            writing = any(token in mode for token in ("w", "a", "x", "+"))
        try:
            flag_value = int(flags or 0)
        except (TypeError, ValueError):
            flag_value = 0
        write_flags = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND
        writing = writing or bool(flag_value & write_flags)
        if writing:
            _runtime_audit_path(path, operation=event)
        return

    one_path_events = {
        "os.mkdir", "os.remove", "os.rmdir", "os.truncate", "os.chmod", "os.utime", "os.chown",
        "shutil.rmtree",
    }
    if event in one_path_events and args:
        _runtime_audit_path(args[0], operation=event)
        return
    if event in {"os.rename", "os.link", "shutil.move"} and len(args) >= 2:
        _runtime_audit_path(args[0], operation=event)
        _runtime_audit_path(args[1], operation=event)
        return
    if event == "shutil.copyfile" and len(args) >= 2:
        _runtime_audit_path(args[1], operation=event)
        return
    if event == "os.symlink":
        # App-owned paths are never allowed to become reparse/symlink escape hatches.
        raise StorageError("运行时禁止创建符号链接/reparse 写入路径")
    if event == "sqlite3.connect" and args:
        _runtime_audit_path(args[0], operation=event)


def _install_runtime_write_audit() -> None:
    global _RUNTIME_WRITE_AUDIT_INSTALLED
    if _RUNTIME_WRITE_AUDIT_INSTALLED:
        return
    sys.addaudithook(_runtime_write_audit)
    _RUNTIME_WRITE_AUDIT_INSTALLED = True


def _ensure_isolated_app_dir(path: Path) -> Path:
    target = _assert_isolated_app_path(path)
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise StorageError(f"无法在用户选择目录创建应用文件夹：{target}: {exc}") from exc
    _assert_isolated_app_path(target)
    if not target.is_dir():
        raise StorageError(f"应用目录不是普通文件夹：{target}")
    return target


def _app_owned_paths() -> list[Path]:
    root = _require_runtime_folder()
    paths = [
        CACHE_PATH, CACHE_ROLLBACK_PATH,
        Path(str(CACHE_PATH) + "-wal"), Path(str(CACHE_PATH) + "-shm"), Path(str(CACHE_PATH) + "-journal"),
        Path(str(CACHE_ROLLBACK_PATH) + "-wal"), Path(str(CACHE_ROLLBACK_PATH) + "-shm"), Path(str(CACHE_ROLLBACK_PATH) + "-journal"),
        MODEL_PATH, MODEL_ROLLBACK_PATH,
        SETTINGS_PATH, DEPS_DIR, DEPS_TMP_DIR,
        DEPS_BACKUP_DIR, RUNTIME_TMP_DIR, root / ".BestFunds_cache",
        root / "BestFunds_wheels.tmp",
    ]
    try:
        paths.extend(root.glob(DEPS_DIR_PREFIX + "*"))
    except OSError:
        pass
    return list(dict.fromkeys(Path(value) for value in paths))


def _validate_app_path_isolation() -> None:
    for path in _app_owned_paths():
        _assert_isolated_app_path(path)


def _atomic_bytes(path: Path, data: bytes) -> None:
    path = _assert_isolated_app_path(Path(path))
    _assert_isolated_app_path(path.parent)
    descriptor, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        # Re-validate immediately before replacement so a concurrently introduced
        # junction/symlink cannot redirect the final write outside the selected root.
        _assert_isolated_app_path(path.parent)
        _assert_isolated_app_path(path)
        os.replace(temp, path)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def _write_json(path: Path, payload) -> None:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    _atomic_bytes(path, raw)


def _read_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return default


def _install_settings_defaults_payload() -> dict:
    logical = max(1, int(os.cpu_count() or 1))
    return {
        "install_mode": "adaptive",
        "lightgbm": False,
        "advanced_tree": False,
        "xgboost_distribution": "xgboost_cpu",
        "xgboost_device": "cpu",
        "cuda_failure_fingerprint": "",
        "cuda_failure_at": "",
        "cuda_failure_reason": "",
        "cuda_failure_kind": "",
        "cuda_failure_free_mib": 0,
        "cuda_failure_required_free_mib": 0,
        "cuda_backoff_active": False,
        "auto_update_model": True,
        "dependency_pins": dict(LOCAL_DEPENDENCY_PINS),
        "dependency_install_status": "not-configured",
        "active_dependency_dir": "",
        "pending_dependency_dir": "",
        "dependency_generation_manifests": {},
        "diagnostics": {},
        "configured_at": "",
        "hardware_fingerprint": "",
        "hardware_profile": {},
        "adaptive_tier": "unknown",
        "ml_threads": logical,
        "quick_start_representatives": DISPLAY_TOP_N,
        "http_transport_observations": {},
        "operation_duration_observations": {},
        "dependency_download_throughput": {},
        "dependency_wheel_read_throughput": {},
        "source_contract_probe_codes": [],
        "source_contract_state": {},
        "dependency_verified_signatures": {},
        "training_progress_observations": {},
    }


def _settings_schema_fingerprint() -> str:
    defaults = _install_settings_defaults_payload()
    field_definition = tuple(sorted((key, type(value).__name__) for key, value in defaults.items()))
    return _schema_fingerprint(field_definition)


def _default_install_settings() -> dict:
    payload = _install_settings_defaults_payload()
    payload["schema_fingerprint"] = _settings_schema_fingerprint()
    return payload


_SETTINGS_LOCK = threading.RLock()
_SETTINGS_BASELINE_KEY = "__bestalipayfunds_runtime_settings_baseline__"


def _normalize_install_settings(raw) -> dict:
    settings = _default_install_settings()
    if isinstance(raw, dict):
        # Schema evolution is field-driven: preserve only fields that still exist, then
        # stamp the fingerprint computed from today's definition. Legacy numeric versions
        # are deliberately ignored instead of being manually incremented.
        settings.update({
            k: v for k, v in raw.items()
            if k in settings and k not in {_SETTINGS_BASELINE_KEY, "schema_version", "schema_fingerprint"}
        })
    settings["schema_fingerprint"] = _settings_schema_fingerprint()
    return settings


def _load_install_settings() -> dict:
    with _SETTINGS_LOCK:
        settings = _normalize_install_settings(_read_json(SETTINGS_PATH, {}))
        settings[_SETTINGS_BASELINE_KEY] = copy.deepcopy(settings)
        return settings


def _save_install_settings(settings: dict) -> None:
    """Optimistic read-modify-write merge so stale snapshots do not clobber unrelated fields."""
    with _SETTINGS_LOCK:
        incoming = dict(settings or {})
        baseline = incoming.pop(_SETTINGS_BASELINE_KEY, None)
        if isinstance(baseline, dict):
            baseline = {k: v for k, v in baseline.items() if k != _SETTINGS_BASELINE_KEY}
            payload = _normalize_install_settings(_read_json(SETTINGS_PATH, {}))
            all_keys = set(incoming) | set(baseline)
            for key in all_keys:
                if key == _SETTINGS_BASELINE_KEY:
                    continue
                if key not in incoming and key in baseline:
                    payload.pop(key, None)
                elif key in incoming and (key not in baseline or incoming.get(key) != baseline.get(key)):
                    payload[key] = copy.deepcopy(incoming.get(key))
        else:
            payload = _normalize_install_settings(incoming)

        payload["schema_fingerprint"] = _settings_schema_fingerprint()
        payload.pop("schema_version", None)
        payload["install_mode"] = "adaptive"
        candidate_pins = payload.get("dependency_pins") if isinstance(payload.get("dependency_pins"), dict) else {}
        approved = _dependency_profiles_for_runtime()
        payload["dependency_pins"] = (
            dict(candidate_pins) if any(candidate_pins == profile for profile in approved)
            else (dict(LOCAL_DEPENDENCY_PINS) if approved else {})
        )
        manifests = payload.get("dependency_generation_manifests")
        payload["dependency_generation_manifests"] = dict(manifests) if isinstance(manifests, dict) else {}
        payload["configured_at"] = payload.get("configured_at") or _now_iso()
        _write_json(SETTINGS_PATH, payload)
        if isinstance(settings, dict):
            settings.clear()
            settings.update(copy.deepcopy(payload))
            settings[_SETTINGS_BASELINE_KEY] = copy.deepcopy(payload)


def _update_install_settings(mutator) -> dict:
    """Atomic in-process read-modify-write used by concurrent GUI workers."""
    with _SETTINGS_LOCK:
        settings = _normalize_install_settings(_read_json(SETTINGS_PATH, {}))
        mutator(settings)
        snapshot = dict(settings)
        _save_install_settings(snapshot)
        return snapshot


_OPERATION_OBSERVATION_LOCK = threading.RLock()
_OPERATION_RUNTIME_OBSERVATIONS: dict[str, dict] = {}

def _operation_observation_state(name: str) -> dict:
    key = str(name or "operation")
    with _OPERATION_OBSERVATION_LOCK:
        cached = _OPERATION_RUNTIME_OBSERVATIONS.get(key)
        if cached is not None:
            return cached
        persisted = _load_install_settings().get("operation_duration_observations") if RUNTIME_FOLDER_BOUND else {}
        raw = persisted.get(key) if isinstance(persisted, dict) else None
        state = {
            "count": max(0, int(_finite((raw or {}).get("count"), 0))),
            "mean": max(0.0, _finite((raw or {}).get("mean"), 0.0)),
            "m2": max(0.0, _finite((raw or {}).get("m2"), 0.0)),
            "max": max(0.0, _finite((raw or {}).get("max"), 0.0)),
        }
        _OPERATION_RUNTIME_OBSERVATIONS[key] = state
        return state

def _record_operation_duration(name: str, elapsed: float) -> None:
    value = max(0.0, float(elapsed))
    key = str(name or "operation")
    with _OPERATION_OBSERVATION_LOCK:
        state = _operation_observation_state(key)
        count = int(state.get("count") or 0) + 1
        mean = float(state.get("mean") or 0.0)
        delta = value - mean
        mean += delta / count
        m2 = float(state.get("m2") or 0.0) + delta * (value - mean)
        state.update({"count": count, "mean": mean, "m2": max(0.0, m2), "max": max(float(state.get("max") or 0.0), value)})
        snapshot = dict(state)
    if RUNTIME_FOLDER_BOUND and not _storage_survival_mode_active():
        def mutate(settings):
            rows = dict(settings.get("operation_duration_observations") or {})
            rows[key] = {**snapshot, "observed_at": _now_iso()}
            settings["operation_duration_observations"] = rows
        try:
            _update_install_settings(mutate)
        except Exception as exc:
            _record_diagnostic("operation-observation-persist", exc)

def _adaptive_operation_timeout(name: str) -> float:
    """Cold calls use a platform bound; successful same-operation observations then replace it adaptively."""
    with _OPERATION_OBSERVATION_LOCK:
        state = dict(_operation_observation_state(name))
    count = max(0, int(state.get("count") or 0))
    if count <= 0:
        return _objective_external_operation_timeout(name)
    variance = float(state.get("m2") or 0.0) / max(1, count - 1) if count > 1 else 0.0
    deviation = math.sqrt(max(0.0, variance))
    measurement_uncertainty = time.get_clock_info("monotonic").resolution
    return max(measurement_uncertainty, float(state.get("max") or 0.0) + max(deviation, measurement_uncertainty))

def _run_observed_process(command: list[str], operation_name: str, *, env=None) -> subprocess.CompletedProcess:
    started = time.monotonic()
    cwd = _isolated_subprocess_cwd() if env is not None and RUNTIME_FOLDER_BOUND else None
    completed = _run_process_cancellable(command, timeout=_adaptive_operation_timeout(operation_name), env=env, cwd=cwd)
    _record_operation_duration(operation_name, time.monotonic() - started)
    return completed


_HTTP_OBSERVATION_LOCK = threading.RLock()
_HTTP_RUNTIME_OBSERVATIONS: dict[str, dict] = {}

def _http_observation_key(url: str) -> str:
    return (urllib.parse.urlsplit(url).hostname or "unknown").lower()

def _http_observation_state(host: str) -> dict:
    with _HTTP_OBSERVATION_LOCK:
        cached = _HTTP_RUNTIME_OBSERVATIONS.get(host)
        if cached is not None:
            return cached
        persisted = _load_install_settings().get("http_transport_observations")
        raw = persisted.get(host) if isinstance(persisted, dict) else None
        state = {
            "success_count": max(0, int(_finite((raw or {}).get("success_count"), 0))),
            "mean_latency": max(0.0, _finite((raw or {}).get("mean_latency"), 0.0)),
            "m2_latency": max(0.0, _finite((raw or {}).get("m2_latency"), 0.0)),
            "max_latency": max(0.0, _finite((raw or {}).get("max_latency"), 0.0)),
            "inactivity_count": max(0, int(_finite((raw or {}).get("inactivity_count"), 0))),
            "mean_inactivity": max(0.0, _finite((raw or {}).get("mean_inactivity"), 0.0)),
            "m2_inactivity": max(0.0, _finite((raw or {}).get("m2_inactivity"), 0.0)),
            "max_inactivity": max(0.0, _finite((raw or {}).get("max_inactivity"), 0.0)),
            "max_response_bytes": max(0, int(_finite((raw or {}).get("max_response_bytes"), 0))),
            "failure_streak": max(0, int(_finite((raw or {}).get("failure_streak"), 0))),
            "failure_count": max(0, int(_finite((raw or {}).get("failure_count"), 0))),
            "mean_failure_elapsed": max(0.0, _finite((raw or {}).get("mean_failure_elapsed"), 0.0)),
            "m2_failure_elapsed": max(0.0, _finite((raw or {}).get("m2_failure_elapsed"), 0.0)),
            "max_failure_elapsed": max(0.0, _finite((raw or {}).get("max_failure_elapsed"), 0.0)),
            "adaptive_request_rate": max(0.0, _finite((raw or {}).get("adaptive_request_rate"), 0.0)),
            "adaptive_rate_successes": max(0, int(_finite((raw or {}).get("adaptive_rate_successes"), 0))),
        }
        _HTTP_RUNTIME_OBSERVATIONS[host] = state
        return state

def _persist_http_observation(host: str, state: dict) -> None:
    if _storage_survival_mode_active():
        return
    keys = (
        "success_count", "mean_latency", "m2_latency", "max_latency",
        "inactivity_count", "mean_inactivity", "m2_inactivity", "max_inactivity",
        "max_response_bytes", "failure_streak", "failure_count",
        "mean_failure_elapsed", "m2_failure_elapsed", "max_failure_elapsed",
        "adaptive_request_rate", "adaptive_rate_successes",
    )
    snapshot = {key: state.get(key, 0) for key in keys}
    snapshot["observed_at"] = _now_iso()
    def mutate(settings):
        observations = dict(settings.get("http_transport_observations") or {})
        observations[host] = snapshot
        settings["http_transport_observations"] = observations
    try:
        _update_install_settings(mutate)
    except Exception as exc:
        _record_diagnostic("http-observation-persist", exc)

def _welford_add(state: dict, count_key: str, mean_key: str, m2_key: str, max_key: str, value: float) -> None:
    value = max(0.0, float(value))
    count = int(state.get(count_key) or 0) + 1
    mean = float(state.get(mean_key) or 0.0)
    delta = value - mean
    mean += delta / count
    m2 = float(state.get(m2_key) or 0.0) + delta * (value - mean)
    state[count_key] = count
    state[mean_key] = mean
    state[m2_key] = max(0.0, m2)
    state[max_key] = max(float(state.get(max_key) or 0.0), value)

def _record_http_success(url: str, elapsed: float, response_bytes: int, inactivity_samples: list[float] | tuple[float, ...]) -> None:
    host = _http_observation_key(url)
    with _HTTP_OBSERVATION_LOCK:
        state = _http_observation_state(host)
        previous_failures = int(state.get("failure_streak") or 0)
        _welford_add(state, "success_count", "mean_latency", "m2_latency", "max_latency", elapsed)
        for sample in inactivity_samples:
            _welford_add(state, "inactivity_count", "mean_inactivity", "m2_inactivity", "max_inactivity", sample)
        state["max_response_bytes"] = max(int(state.get("max_response_bytes") or 0), max(0, int(response_bytes)))
        state["failure_streak"] = 0
        count = int(state.get("success_count") or 0)
        should_persist = previous_failures > 0 or (count & (count - 1) == 0)
        snapshot = dict(state)
    if should_persist:
        _persist_http_observation(host, snapshot)

def _record_http_failure(url: str, elapsed: float) -> None:
    host = _http_observation_key(url)
    with _HTTP_OBSERVATION_LOCK:
        state = _http_observation_state(host)
        state["failure_streak"] = int(state.get("failure_streak") or 0) + 1
        _welford_add(state, "failure_count", "mean_failure_elapsed", "m2_failure_elapsed", "max_failure_elapsed", elapsed)
        snapshot = dict(state)
    _persist_http_observation(host, snapshot)

def _adaptive_http_timeout(url: str) -> float:
    """Cold sockets use the platform/RFC bound; successful same-host inactivity observations then adapt it."""
    with _HTTP_OBSERVATION_LOCK:
        state = dict(_http_observation_state(_http_observation_key(url)))
    count = max(0, int(state.get("inactivity_count") or 0))
    if count <= 0:
        return _platform_network_inactivity_timeout_seconds()
    variance = float(state.get("m2_inactivity") or 0.0) / max(1, count - 1) if count > 1 else 0.0
    deviation = math.sqrt(max(0.0, variance))
    uncertainty = time.get_clock_info("monotonic").resolution
    return max(uncertainty, float(state.get("max_inactivity") or 0.0) + max(deviation, uncertainty))

def _adaptive_http_total_timeout(url: str) -> float:
    """Finite end-to-end deadline; cold use is platform/protocol bounded, warm use is same-host latency based."""
    with _HTTP_OBSERVATION_LOCK:
        state = dict(_http_observation_state(_http_observation_key(url)))
    count = max(0, int(state.get("success_count") or 0))
    socket_timeout = _adaptive_http_timeout(url)
    if count <= 0:
        return max(socket_timeout, _platform_network_total_timeout_seconds())
    variance = float(state.get("m2_latency") or 0.0) / max(1, count - 1) if count > 1 else 0.0
    deviation = math.sqrt(max(0.0, variance))
    uncertainty = time.get_clock_info("monotonic").resolution
    observed_total = float(state.get("max_latency") or 0.0) + max(deviation, uncertainty)
    return max(socket_timeout, observed_total, uncertainty)

def _retry_after_seconds(value: str | None) -> float | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return max(0.0, float(text))
    except ValueError:
        try:
            when = parsedate_to_datetime(text)
            if when.tzinfo is None:
                when = when.replace(tzinfo=_dt.timezone.utc)
            return max(0.0, (when - _dt.datetime.now(_dt.timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return None

_HTTP_SERVER_RETRY_LOCK = threading.Lock()
_HTTP_SERVER_RETRY_UNTIL = 0.0

def _record_server_retry_after(seconds: float | None) -> None:
    if seconds is None:
        return
    global _HTTP_SERVER_RETRY_UNTIL
    with _HTTP_SERVER_RETRY_LOCK:
        _HTTP_SERVER_RETRY_UNTIL = max(_HTTP_SERVER_RETRY_UNTIL, time.monotonic() + max(0.0, float(seconds)))

def _server_retry_after_remaining() -> float:
    with _HTTP_SERVER_RETRY_LOCK:
        return max(0.0, _HTTP_SERVER_RETRY_UNTIL - time.monotonic())

def _adaptive_http_retry_delay(url: str, server_delay: float | None = None) -> float:
    if server_delay is not None:
        return max(0.0, float(server_delay))
    with _HTTP_OBSERVATION_LOCK:
        state = dict(_http_observation_state(_http_observation_key(url)))
    count = max(0, int(state.get("failure_count") or 0))
    variance = float(state.get("m2_failure_elapsed") or 0.0) / max(1, count - 1) if count > 1 else 0.0
    deviation = math.sqrt(max(0.0, variance))
    observed = float(state.get("max_failure_elapsed") or 0.0) + deviation
    base = max(time.get_clock_info("monotonic").resolution, sys.getswitchinterval(), observed)
    return base * max(1, int(state.get("failure_streak") or 0))

def _adaptive_http_response_limit(url: str, fair_share: int) -> int | None:
    """Unknown first responses are disk-staged; memory ceilings exist only after endpoint size is observed."""
    state = _http_observation_state(_http_observation_key(url))
    observed = max(0, int(state.get("max_response_bytes") or 0))
    fair_share = max(1, int(fair_share))
    if observed <= 0:
        return None
    learned = observed + FILE_IO_CHUNK_BYTES
    return max(1, min(fair_share, learned))

class _HttpMemoryBudget:
    """Global in-flight byte accounting shared by every HTTP worker."""
    def __init__(self):
        self.lock = threading.RLock()
        self.active_requests = 0
        self.reserved_bytes = 0

    def begin(self) -> int:
        with self.lock:
            self.active_requests += 1
            capacity = _objective_http_global_memory_budget()
            return max(FILE_IO_CHUNK_BYTES, capacity // max(1, self.active_requests))

    def reserve(self, amount: int) -> None:
        amount = max(0, int(amount))
        if amount <= 0:
            return
        with self.lock:
            capacity = _objective_http_global_memory_budget()
            if self.reserved_bytes + amount > capacity:
                raise NetworkError(
                    f"并发网络响应需要 {self.reserved_bytes + amount} 字节，超过当前全局在途内存预算 {capacity} 字节"
                )
            self.reserved_bytes += amount

    def release(self, amount: int) -> None:
        with self.lock:
            self.reserved_bytes = max(0, self.reserved_bytes - max(0, int(amount)))

    def end(self, reserved: int) -> None:
        with self.lock:
            self.reserved_bytes = max(0, self.reserved_bytes - max(0, int(reserved)))
            self.active_requests = max(0, self.active_requests - 1)

_HTTP_MEMORY_BUDGET = _HttpMemoryBudget()

def _record_diagnostic(component: str, detail, error_type: str | None = None) -> None:
    """Persist diagnostics in the parent process without breaking the main workflow."""
    if _storage_survival_mode_active():
        return
    try:
        trace_text = ""
        if isinstance(detail, BaseException):
            error_type = error_type or type(detail).__name__
            message = str(detail)
            if detail.__traceback__ is not None:
                trace_text = "".join(traceback.format_exception(type(detail), detail, detail.__traceback__))[-12000:]
        else:
            message = str(detail)
        event = {
            "component": str(component),
            "at": _now_iso(),
            "type": str(error_type or "Info"),
            "message": message,
        }
        if trace_text:
            event["traceback"] = trace_text
        sink = _TRAINING_CHILD_EVENT_SINK
        if callable(sink):
            sink("diagnostic", event)
            return

        def mutate(settings):
            diagnostics = dict(settings.get("diagnostics") or {})
            diagnostics[event["component"]] = {
                "at": event["at"], "type": event["type"], "message": event["message"],
                **({"traceback": event["traceback"]} if event.get("traceback") else {}),
            }
            settings["diagnostics"] = diagnostics
        _update_install_settings(mutate)
    except Exception:
        pass


def _model_missed_dependency_ready(model: dict, dependency_ready_at: str | None, active_dir: Path | None) -> bool:
    """True when the persisted/current model cannot prove it trained against the dependency generation that just became ready."""
    if active_dir is None or not dependency_ready_at:
        return False
    ready_at = _parse_iso(dependency_ready_at)
    trained_at = _parse_iso(model.get("trained_at")) if isinstance(model, dict) else None
    if ready_at is None:
        return False
    if trained_at is None:
        return True
    if trained_at.tzinfo is None:
        trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
    if ready_at.tzinfo is None:
        ready_at = ready_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
    trained_dir = str((model or {}).get("training_dependency_dir") or "")
    if trained_dir == active_dir.name:
        return False
    return trained_at < ready_at or trained_dir != active_dir.name


def _windows_memory_status() -> tuple[int, int]:
    if os.name != "nt":
        return 0, 0
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]
    state = MEMORYSTATUSEX(); state.dwLength = ctypes.sizeof(state)
    try:
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
            return int(state.ullTotalPhys), int(state.ullAvailPhys)
    except Exception:
        pass
    return 0, 0


def _portable_memory_status() -> tuple[int, int]:
    total, available = _windows_memory_status()
    if total > 0:
        return total, available
    try:
        page = int(os.sysconf("SC_PAGE_SIZE")); pages = int(os.sysconf("SC_PHYS_PAGES"))
        avail_pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        return page * pages, page * avail_pages
    except (AttributeError, OSError, ValueError):
        return 0, 0


def _windows_gpu_summary() -> list[dict]:
    if os.name != "nt":
        return []
    command = [
        "powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
        "$ErrorActionPreference='SilentlyContinue'; "
        "Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress"
    ]
    try:
        completed = _run_observed_process(command, "hardware_probe", env=_isolated_subprocess_env() if RUNTIME_FOLDER_BOUND else None)
        if completed.returncode != 0 or not completed.stdout.strip():
            return []
        payload = json.loads(completed.stdout.lstrip("\ufeff"))
        rows = payload if isinstance(payload, list) else [payload]
        result = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            result.append({
                "name": str(row.get("Name") or ""),
                "adapter_ram_bytes": max(0, int(_finite(row.get("AdapterRAM"), 0))),
                "driver": str(row.get("DriverVersion") or ""),
            })
        return result
    except concurrent.futures.CancelledError:
        raise
    except Exception:
        return []


_NVIDIA_PROBE_CACHE_LOCK = threading.RLock()
_NVIDIA_PROBE_CACHE: dict = {}


def _remember_nvidia_cuda_probe(probe: dict) -> dict:
    snapshot = dict(probe or {})
    snapshot["gpus"] = [dict(row) for row in (snapshot.get("gpus") or []) if isinstance(row, dict)]
    with _NVIDIA_PROBE_CACHE_LOCK:
        _NVIDIA_PROBE_CACHE.clear()
        _NVIDIA_PROBE_CACHE.update(snapshot)
    return snapshot


def _cached_nvidia_cuda_probe() -> dict:
    """Return the last real NVIDIA probe without spawning nvidia-smi."""
    with _NVIDIA_PROBE_CACHE_LOCK:
        snapshot = dict(_NVIDIA_PROBE_CACHE)
        snapshot["gpus"] = [dict(row) for row in (_NVIDIA_PROBE_CACHE.get("gpus") or []) if isinstance(row, dict)]
    return snapshot


def _nvidia_cuda_probe() -> dict:
    """Read live NVIDIA capacity/pressure, including free VRAM, without importing CUDA libraries."""
    commands = [
        ["nvidia-smi.exe", "--query-gpu=index,name,memory.total,memory.free,utilization.gpu,driver_version", "--format=csv,noheader,nounits"],
        ["nvidia-smi", "--query-gpu=index,name,memory.total,memory.free,utilization.gpu,driver_version", "--format=csv,noheader,nounits"],
    ]
    for command in commands:
        try:
            completed = _run_observed_process(command, "hardware_probe", env=_isolated_subprocess_env() if RUNTIME_FOLDER_BOUND else None)
            if completed.returncode != 0:
                continue
            rows = []
            for line in completed.stdout.splitlines():
                parts = [part.strip() for part in line.split(",")]
                if len(parts) != len(NVIDIA_SMI_FIELDS):
                    continue
                values = dict(zip(NVIDIA_SMI_FIELDS, parts))
                def number(value, default=0):
                    try:
                        return max(0, int(float(value)))
                    except (TypeError, ValueError):
                        return default
                index = number(values["index"], len(rows))
                total_mib = number(values["memory.total"])
                observed_free_mib = number(values["memory.free"])
                free_mib = min(total_mib, observed_free_mib) if total_mib else observed_free_mib
                util_pct = min(PERCENT_SCALE, number(values["utilization.gpu"]))
                rows.append({
                    "index": index,
                    "name": values["name"],
                    "memory_mib": total_mib,  # compatibility alias for stable hardware fingerprinting
                    "memory_total_mib": total_mib,
                    "memory_free_mib": free_mib,
                    "utilization_gpu_pct": util_pct,
                    "driver": values["driver_version"],
                })
            if rows:
                return _remember_nvidia_cuda_probe({
                    "available": True,
                    "max_vram_mib": max(row["memory_total_mib"] for row in rows),
                    "max_free_vram_mib": max(row["memory_free_mib"] for row in rows),
                    "gpus": rows,
                })
        except concurrent.futures.CancelledError:
            raise
        except Exception:
            continue
    return _remember_nvidia_cuda_probe({"available": False, "max_vram_mib": 0, "max_free_vram_mib": 0, "gpus": []})


def _is_cuda_device(value) -> bool:
    return str(value or "").strip().lower().startswith("cuda")


def _select_cuda_training_device(required_free_mib: int | None = None, reserve_mib: int | None = None) -> dict:
    """Choose a GPU only when measured free VRAM covers the caller's measured working set."""
    probe = _nvidia_cuda_probe()
    threshold = max(0, int(required_free_mib or 0)) + max(0, int(reserve_mib or 0))
    candidates = [
        row for row in (probe.get("gpus") or [])
        if isinstance(row, dict) and int(_finite(row.get("memory_free_mib"), 0)) >= threshold
    ]
    if not candidates:
        return {"available": False, "device": "cpu", "required_free_mib": threshold, "probe": probe}
    selected = max(
        candidates,
        key=lambda row: (
            int(_finite(row.get("memory_free_mib"), 0)),
            -int(_finite(row.get("utilization_gpu_pct"), PERCENT_SCALE)),
        ),
    )
    index = max(0, int(_finite(selected.get("index"), 0)))
    return {
        "available": True,
        "device": f"cuda:{index}",
        "index": index,
        "name": str(selected.get("name") or ""),
        "free_mib": int(_finite(selected.get("memory_free_mib"), 0)),
        "total_mib": int(_finite(selected.get("memory_total_mib"), 0)),
        "utilization_gpu_pct": int(_finite(selected.get("utilization_gpu_pct"), 0)),
        "required_free_mib": threshold,
        "probe": probe,
    }


class RuntimeResourceController:
    """Continuous closed-loop resource controller.

    Worker admission is derived from measured CPU and RAM headroom instead of threshold
    buckets. Downward pressure is applied immediately; recovery is smoothed over elapsed
    observation time so the application does not oscillate between concurrency levels.
    """
    def __init__(self, interval: float | None = None):
        logical = max(1, int(os.cpu_count() or 1))
        self.interval = max(time.get_clock_info("monotonic").resolution, float(interval) if interval is not None else math.sqrt(logical))
        self._lock = threading.RLock()
        self._thread = None
        self._snapshot = {
            "sampled_at": "", "cpu_pct": 0.0, "ram_used_pct": 0.0,
            "cpu_headroom": 1.0, "ram_headroom": 1.0, "load_factor": 1.0,
            "free_disk_bytes": 0, "disk_pressure": False,
        }
        self._cpu_previous = None
        self._load_factor = 1.0
        self._last_sample_monotonic = 0.0
        # CPU/RAM remain high-frequency. GPU state is cache-only here; real nvidia-smi probes
        # are reserved for startup hardware discovery and training admission/diagnostics.

    @staticmethod
    def _windows_cpu_times():
        if os.name != "nt":
            return None
        class FILETIME(ctypes.Structure):
            _fields_ = [("dwLowDateTime", ctypes.c_ulong), ("dwHighDateTime", ctypes.c_ulong)]
        idle = FILETIME(); kernel = FILETIME(); user = FILETIME()
        try:
            if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
                return None
        except (AttributeError, OSError):
            return None
        def value(ft):
            return (int(ft.dwHighDateTime) << WINDOWS_FILETIME_PART_BITS) | int(ft.dwLowDateTime)
        return value(idle), value(kernel), value(user)

    def _cpu_usage(self) -> float:
        current = self._windows_cpu_times()
        if current is not None:
            previous = self._cpu_previous
            self._cpu_previous = current
            if previous is None:
                return float(self._snapshot.get("cpu_pct", 0.0))
            idle_delta = max(0, current[0] - previous[0])
            kernel_delta = max(0, current[1] - previous[1])
            user_delta = max(0, current[2] - previous[2])
            total = kernel_delta + user_delta
            if total > 0:
                return max(0.0, min(PERCENT_SCALE, PERCENT_SCALE * (total - idle_delta) / total))
        try:
            load1 = float(os.getloadavg()[0])
            return max(0.0, min(PERCENT_SCALE, load1 * PERCENT_SCALE / max(1, os.cpu_count() or 1)))
        except (AttributeError, OSError):
            return float(self._snapshot.get("cpu_pct", 0.0))

    @staticmethod
    def _continuous_headroom(cpu_pct: float, total_ram: int, available_ram: int) -> tuple[float, float, float]:
        cpu_headroom = _clamp(1.0 - _finite(cpu_pct) / PERCENT_SCALE, 0.0, 1.0)
        ram_headroom = _clamp(available_ram / total_ram, 0.0, 1.0) if total_ram > 0 else 1.0
        # Geometric mean makes either exhausted resource throttle the next wave while
        # preserving capacity when both resources have room. No bucket thresholds exist.
        factor = math.sqrt(max(0.0, cpu_headroom) * max(0.0, ram_headroom))
        return cpu_headroom, ram_headroom, _clamp(factor, 0.0, 1.0)

    def sample(self) -> dict:
        import shutil
        sampled_mono = time.monotonic()
        cpu_pct = self._cpu_usage()
        total_ram, available_ram = _portable_memory_status()
        ram_used_pct = (PERCENT_SCALE * (1.0 - available_ram / total_ram)) if total_ram > 0 else 0.0
        try:
            disk_free = int(shutil.disk_usage(BASE_DIR).free)
        except OSError:
            disk_free = 0
        # Ordinary network/refresh monitoring never spawns nvidia-smi. It consumes the most
        # recent real probe produced by startup discovery or an actual training decision.
        gpu = _cached_nvidia_cuda_probe() or {
            "available": False, "max_vram_mib": 0, "max_free_vram_mib": 0, "gpus": []
        }

        cpu_headroom, ram_headroom, observed_factor = self._continuous_headroom(
            cpu_pct, total_ram, available_ram,
        )
        with self._lock:
            elapsed = max(0.0, sampled_mono - self._last_sample_monotonic) if self._last_sample_monotonic else self.interval
            self._last_sample_monotonic = sampled_mono
            if observed_factor < self._load_factor:
                # Pressure must be respected immediately.
                self._load_factor = observed_factor
            else:
                # Recovery follows an elapsed-time exponential response instead of a
                # fixed number of healthy samples or a fixed step size.
                alpha = 1.0 - math.exp(-elapsed / max(self.interval, time.get_clock_info("monotonic").resolution))
                self._load_factor += (observed_factor - self._load_factor) * alpha
            self._load_factor = _clamp(self._load_factor, 0.0, 1.0)
            self._snapshot = {
                "sampled_at": _now_iso(),
                "cpu_pct": cpu_pct,
                "cpu_headroom": round(cpu_headroom, FLOAT_SERIALIZATION_DIGITS),
                "total_ram_bytes": int(total_ram),
                "available_ram_bytes": int(available_ram),
                "ram_used_pct": max(0.0, min(PERCENT_SCALE, ram_used_pct)),
                "ram_headroom": round(ram_headroom, FLOAT_SERIALIZATION_DIGITS),
                "free_disk_bytes": disk_free,
                "disk_pressure": _objective_disk_pressure(disk_free),
                "pressure": "adaptive-throttle" if self._load_factor < 1.0 else "normal",
                "load_factor": round(self._load_factor, FLOAT_SERIALIZATION_DIGITS),
                "gpu": gpu,
            }
            return dict(self._snapshot)

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self._snapshot)

    def recommended_workers(self, baseline: int) -> int:
        baseline = max(1, int(baseline))
        with self._lock:
            age = time.monotonic() - self._last_sample_monotonic if self._last_sample_monotonic else float("inf")
        if age >= self.interval and not _cancel_requested():
            try:
                self.sample()
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
                _record_diagnostic("resource-controller", exc, "ResourceMonitorError")
        with self._lock:
            factor = float(self._load_factor)
        admitted = int(math.ceil(baseline * factor))
        return max(1, min(baseline, admitted))

    def _run(self) -> None:
        while not _cancel_requested():
            try:
                self.sample()
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
                _record_diagnostic("resource-controller", exc, "ResourceMonitorError")
            # Monitoring must never accelerate merely because the machine is already under pressure.
            # Worker admission reacts to load; probe cadence stays at the objective base interval.
            delay = self.interval
            if _GLOBAL_STOP_EVENT.wait(delay):
                break

    def start(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._run, name="resource-controller", daemon=True)
            self._thread.start()


_RESOURCE_CONTROLLER = RuntimeResourceController()


def _runtime_resource_snapshot() -> dict:
    return _RESOURCE_CONTROLLER.snapshot()


def _detect_hardware_profile() -> dict:
    import shutil
    logical = max(1, int(os.cpu_count() or 1))
    total_ram, available_ram = _portable_memory_status()
    try:
        disk = shutil.disk_usage(BASE_DIR)
        free_disk = int(disk.free)
    except OSError:
        free_disk = 0
    # Prefer NVIDIA's own CLI on the target hardware; use CIM only as a fallback
    # when nvidia-smi is unavailable or reports no usable GPU.
    nvidia_cuda = _nvidia_cuda_probe()
    if nvidia_cuda.get("available") is True:
        gpus = [
            {
                "name": str(row.get("name") or ""),
                "adapter_ram_bytes": max(0, int(_finite(row.get("memory_mib"), 0))) * BYTES_PER_MIB,
                "driver": str(row.get("driver") or ""),
            }
            for row in (nvidia_cuda.get("gpus") or []) if isinstance(row, dict)
        ]
    else:
        gpus = _windows_gpu_summary()
    cpu_name = platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", "") or platform.machine()
    profile = {
        "detected_at": _now_iso(),
        "platform": platform.system(),
        "machine": platform.machine(),
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_bits": struct.calcsize("P") * BITS_PER_BYTE,
        "cpu_name": str(cpu_name),
        "logical_cpus": logical,
        "total_ram_bytes": int(total_ram),
        "available_ram_bytes": int(available_ram),
        "free_disk_bytes": int(free_disk),
        "gpus": gpus,
        "nvidia_cuda": nvidia_cuda,
    }
    stable = {
        "platform": profile["platform"], "machine": profile["machine"], "python": f"{sys.version_info.major}.{sys.version_info.minor}",
        "python_bits": profile["python_bits"], "cpu_name": profile["cpu_name"], "logical_cpus": logical,
        "total_ram_gib": total_ram / BYTES_PER_GIB if total_ram else 0.0,
        "gpu_names": [row.get("name", "") for row in gpus],
        "gpu_drivers": [row.get("driver", "") for row in gpus],
        "nvidia_cuda": bool(nvidia_cuda.get("available")),
        "nvidia_vram_mib": int(_finite(nvidia_cuda.get("max_vram_mib"), 0)),
        "nvidia_gpu_driver_fingerprint": [
            (row.get("name", ""), row.get("driver", ""), int(_finite(row.get("memory_mib"), 0)))
            for row in (nvidia_cuda.get("gpus") or []) if isinstance(row, dict)
        ],
    }
    profile["fingerprint"] = hashlib.sha256(json.dumps(stable, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return profile


def _adaptive_settings_for_hardware(profile: dict) -> dict:
    """Derive runtime capacity continuously from the machine observed at startup."""
    logical = max(1, int(_finite(profile.get("logical_cpus"), 1)))
    total_ram = max(0.0, _finite(profile.get("total_ram_bytes"), 0))
    available_ram = max(0.0, _finite(profile.get("available_ram_bytes"), 0))
    memory_headroom = _clamp(available_ram / total_ram, 0.0, 1.0) if total_ram > 0 else 1.0
    live_capacity = max(1, int(math.ceil(logical * math.sqrt(memory_headroom))))

    cuda_info = profile.get("nvidia_cuda") if isinstance(profile.get("nvidia_cuda"), dict) else {}
    cuda_rows = [row for row in (cuda_info.get("gpus") or []) if isinstance(row, dict)]
    best_gpu = max(
        cuda_rows,
        key=lambda row: int(_finite(row.get("memory_free_mib"), 0)),
        default=None,
    )
    free_vram = int(_finite((best_gpu or {}).get("memory_free_mib"), 0))
    total_vram = int(_finite((best_gpu or {}).get("memory_total_mib"), 0))
    gpu_headroom = _clamp(free_vram / total_vram, 0.0, 1.0) if total_vram > 0 else 0.0

    runtime_profiles = _dependency_profiles_for_runtime()
    native_profile_available = bool(runtime_profiles)
    lightgbm = native_profile_available
    # xgboost-cpu 3.4.1 has a Python >=3.12 contract; do not infer support from hardware.
    advanced_tree = bool(native_profile_available and sys.version_info >= ADVANCED_ML_MIN_PYTHON)
    cuda_capable = bool(advanced_tree and cuda_info.get("available") is True and best_gpu is not None)
    xgboost_distribution = "xgboost_gpu" if cuda_capable else "xgboost_cpu"
    xgboost_device = str(f"cuda:{int(_finite((best_gpu or {}).get('index'), 0))}") if cuda_capable and gpu_headroom > 0.0 else "cpu"

    # Model/worker capacity grows continuously with actually free memory and logical CPUs.
    ml_threads = live_capacity
    quick = DISPLAY_TOP_N
    return {
        "install_mode": "adaptive",
        "adaptive_tier": "continuous",
        "lightgbm": lightgbm,
        "advanced_tree": advanced_tree,
        "xgboost_distribution": xgboost_distribution,
        "xgboost_device": xgboost_device,
        "cuda_vram_gib": total_vram / MIB_PER_GIB,
        "cuda_free_vram_gib": free_vram / MIB_PER_GIB,
        "gpu_headroom": round(gpu_headroom, FLOAT_SERIALIZATION_DIGITS),
        "auto_update_model": True,
        "ml_threads": ml_threads,
        "quick_start_representatives": quick,
        "model_complexity": max(1, min(logical, live_capacity)),
        "memory_pressure_at_start": bool(memory_headroom < 1.0),
    }


def _adaptive_worker_count(kind: str, upper: int | None = None) -> int:
    if kind not in {"history", "network"}:
        raise ValueError(f"未知并发类型：{kind}")
    # Startup settings describe the machine, but they are not a permanent runtime ceiling.
    # Current CPU/RAM headroom is applied exactly once by ResourceController on every wave.
    capacity = _RESOURCE_CONTROLLER.recommended_workers(max(1, int(os.cpu_count() or 1)))
    if upper is not None:
        capacity = min(capacity, max(1, int(upper)))
    return max(1, capacity)


def _adaptive_ml_threads() -> int:
    return max(1, int(_finite(_load_install_settings().get("ml_threads"), 1)))



def _adaptive_model_complexity() -> int:
    return max(1, int(_finite(_load_install_settings().get("model_complexity"), 1)))


def _adaptive_boost_rounds(requested: int) -> int:
    # Scale requested work continuously with current admitted CPU capacity.
    logical = max(1, int(os.cpu_count() or 1))
    capacity = min(logical, _adaptive_model_complexity())
    factor = math.sqrt(capacity / logical) if logical else 1.0
    return max(1, int(round(max(1, int(requested)) * factor)))

def _runtime_python_abi() -> dict:
    return {
        "implementation": str(getattr(sys.implementation, "name", "python")),
        "cache_tag": str(getattr(sys.implementation, "cache_tag", "")),
        "major": int(sys.version_info.major),
        "minor": int(sys.version_info.minor),
        "pointer_bits": int(struct.calcsize("P") * BITS_PER_BYTE),
        "machine": str(platform.machine()).upper(),
    }


def _dependency_manifest_digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().lower()


def _dependency_tree_stat_signature(target: Path) -> tuple[int, int, int]:
    """Cheap invalidation fingerprint: file count, total bytes and newest file/dir mtime_ns."""
    root = _assert_isolated_app_path(Path(target))
    if _path_is_reparse_or_symlink(root) or not root.is_dir():
        raise StorageError(f"依赖代际目录不是普通文件夹：{root}")
    file_count = 0
    byte_count = 0
    latest_mtime_ns = int(root.stat().st_mtime_ns)
    for current_dir, dirnames, filenames in os.walk(root):
        current = Path(current_dir)
        _assert_isolated_app_path(current)
        if _path_is_reparse_or_symlink(current):
            raise StorageError(f"依赖目录包含 symlink/junction/reparse point：{current}")
        latest_mtime_ns = max(latest_mtime_ns, int(current.stat().st_mtime_ns))
        for dirname in dirnames:
            child_dir = current / dirname
            _assert_isolated_app_path(child_dir)
            if _path_is_reparse_or_symlink(child_dir):
                raise StorageError(f"依赖目录包含 symlink/junction/reparse point：{child_dir}")
        for filename in filenames:
            child = current / filename
            if child.name == DEPENDENCY_MANIFEST_FILENAME and child.parent == root:
                continue
            _assert_isolated_app_path(child)
            if _path_is_reparse_or_symlink(child) or not child.is_file():
                raise StorageError(f"依赖树包含非普通文件：{child}")
            stat = child.stat()
            file_count += 1
            byte_count += int(stat.st_size)
            latest_mtime_ns = max(latest_mtime_ns, int(stat.st_mtime_ns))
    return file_count, byte_count, latest_mtime_ns


def _dependency_installed_tree_fingerprint(target: Path) -> tuple[str, int, int]:
    """Hash the complete installed dependency tree except the self-referential manifest."""
    root = _assert_isolated_app_path(Path(target))
    if _path_is_reparse_or_symlink(root) or not root.is_dir():
        raise StorageError(f"依赖代际目录不是普通文件夹：{root}")
    aggregate = hashlib.sha256()
    file_count = 0
    byte_count = 0
    entries: list[Path] = []
    for current_root, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
        current = Path(current_root)
        for dirname in list(dirnames):
            child = current / dirname
            _assert_isolated_app_path(child)
            if _path_is_reparse_or_symlink(child):
                raise StorageError(f"依赖目录包含 symlink/junction/reparse point：{child}")
        for filename in filenames:
            child = current / filename
            if child.name == DEPENDENCY_MANIFEST_FILENAME and child.parent == root:
                continue
            entries.append(child)
    entries.sort(key=lambda path: path.relative_to(root).as_posix().casefold())
    for child in entries:
        _assert_isolated_app_path(child)
        if _path_is_reparse_or_symlink(child) or not child.is_file():
            raise StorageError(f"依赖树包含非普通文件：{child}")
        relative = child.relative_to(root).as_posix()
        digest = hashlib.sha256()
        size = 0
        with open(child, "rb") as handle:
            while True:
                block = handle.read(FILE_IO_CHUNK_BYTES)
                if not block:
                    break
                digest.update(block)
                size += len(block)
        aggregate.update(relative.encode("utf-8", "surrogatepass"))
        aggregate.update(b"\0")
        aggregate.update(str(size).encode("ascii"))
        aggregate.update(b"\0")
        aggregate.update(digest.hexdigest().encode("ascii"))
        aggregate.update(b"\n")
        file_count += 1
        byte_count += size
    return aggregate.hexdigest().lower(), file_count, byte_count


def _verify_dependency_generation(
    target: Path, settings: dict | None = None, *, require_import_probe: bool = False,
    force_tree_rehash: bool = False, force_import_probe: bool = False,
) -> tuple[bool, str, dict]:
    """Fail closed unless a generation is app-created, ABI-compatible and allowlisted in Settings."""
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    try:
        target = _assert_isolated_app_path(Path(target))
        if _path_is_reparse_or_symlink(target) or not target.is_dir():
            return False, "依赖代际目录不存在或不是普通文件夹", {}
    except (OSError, StorageError) as exc:
        return False, f"依赖代际路径隔离失败：{exc}", {}
    name = target.name
    if not (name.startswith(DEPS_DIR_PREFIX) and Path(name).name == name):
        return False, "依赖代际目录名不符合程序契约", {}
    manifest_path = target / DEPENDENCY_MANIFEST_FILENAME
    try:
        _assert_isolated_app_path(manifest_path)
        if _path_is_reparse_or_symlink(manifest_path) or not manifest_path.is_file():
            return False, "缺少程序生成的依赖 manifest", {}
        trusted = settings.get("dependency_generation_manifests")
        trusted = trusted if isinstance(trusted, dict) else {}
        expected_digest = str(trusted.get(name) or "").lower()
        actual_digest = _dependency_manifest_digest(manifest_path)
        if not re.fullmatch(r"[0-9a-f]{64}", expected_digest) or not hmac.compare_digest(actual_digest, expected_digest):
            return False, "依赖 manifest 未被当前安装设置信任", {}
        manifest = _read_json(manifest_path, {})
    except (OSError, StorageError) as exc:
        return False, f"读取依赖 manifest 失败：{exc}", {}
    if not isinstance(manifest, dict):
        return False, "依赖 manifest 格式非法", {}
    if str(manifest.get("schema_fingerprint") or "") != DEPENDENCY_MANIFEST_FINGERPRINT:
        return False, "依赖 manifest 字段指纹不兼容", manifest
    if str(manifest.get("generation") or "") != name or str(manifest.get("app") or "") != APP_NAME:
        return False, "依赖 manifest 代际标识不匹配", manifest
    if str(manifest.get("selection_rule") or "") != DEPENDENCY_SELECTION_RULE:
        return False, "依赖 manifest 版本选择规则与当前发布规则不匹配", manifest
    if manifest.get("python_abi") != _runtime_python_abi():
        return False, "依赖代际 Python ABI/架构与当前解释器不匹配", manifest
    specs = manifest.get("package_specs")
    if not isinstance(specs, list) or not specs or any("==" not in str(spec) for spec in specs):
        return False, "依赖 manifest 缺少固定包版本", manifest
    approved_sets = [set(profile.values()) for profile in _dependency_profiles_for_runtime()]
    if not approved_sets or not any(set(map(str, specs)).issubset(approved) for approved in approved_sets):
        return False, "依赖代际包版本不在当前 Python minor 的批准组合中", manifest
    hashes = manifest.get("wheel_sha256")
    if not isinstance(hashes, dict) or not hashes or any(not re.fullmatch(r"[0-9a-f]{64}", str(value).lower()) for value in hashes.values()):
        return False, "依赖 manifest 缺少已核验 wheel SHA-256", manifest
    sizes = manifest.get("wheel_size_bytes")
    if not isinstance(sizes, dict) or set(sizes) != set(hashes):
        return False, "依赖 manifest 缺少与 wheel 一一对应的发布大小", manifest
    for filename, digest in hashes.items():
        approved_digest = TRUSTED_WHEEL_SHA256.get(str(filename))
        if not approved_digest or not hmac.compare_digest(str(digest).lower(), approved_digest):
            return False, f"依赖 manifest wheel 不在代码内批准 SHA-256 清单：{filename}", manifest
        try:
            if int(sizes.get(filename)) <= 0:
                return False, f"依赖 manifest wheel 发布大小非法：{filename}", manifest
        except (TypeError, ValueError):
            return False, f"依赖 manifest wheel 发布大小非法：{filename}", manifest
    versions = manifest.get("import_versions")
    if not isinstance(versions, dict) or not versions:
        return False, "依赖 manifest 缺少导入版本信息", manifest
    expected_tree = str(manifest.get("installed_tree_sha256") or "").lower()
    expected_files = int(_finite(manifest.get("installed_tree_files"), -1))
    expected_bytes = int(_finite(manifest.get("installed_tree_bytes"), -1))
    if not re.fullmatch(r"[0-9a-f]{64}", expected_tree) or expected_files < 1 or expected_bytes < 1:
        return False, "依赖 manifest 缺少安装后文件树完整性摘要", manifest

    tree_cache_key = (str(target.resolve()), actual_digest)
    try:
        stat_signature = _dependency_tree_stat_signature(target)
    except (OSError, StorageError) as exc:
        return False, f"安装后依赖文件树状态检查失败：{exc}", manifest
    persisted_signatures = settings.get("dependency_verified_signatures")
    persisted_signatures = persisted_signatures if isinstance(persisted_signatures, dict) else {}
    persisted = persisted_signatures.get(name) if isinstance(persisted_signatures.get(name), dict) else {}
    persisted_signature = (
        int(_finite(persisted.get("file_count"), -1)),
        int(_finite(persisted.get("byte_count"), -1)),
        int(_finite(persisted.get("latest_mtime_ns"), -1)),
    )
    persisted_ok = bool(
        not force_tree_rehash
        and persisted_signature == stat_signature
        and hmac.compare_digest(str(persisted.get("manifest_digest") or "").lower(), actual_digest)
        and hmac.compare_digest(str(persisted.get("installed_tree_sha256") or "").lower(), expected_tree)
        and stat_signature[0] == expected_files
        and stat_signature[1] == expected_bytes
    )
    cached_tree = None if force_tree_rehash else _DEPENDENCY_TREE_VERIFY_CACHE.get(tree_cache_key)
    full_tree_verified = False
    if persisted_ok:
        tree_ok, tree_detail = True, "安装后依赖文件树快速签名与上次完整 SHA-256 验证一致"
        _DEPENDENCY_TREE_VERIFY_CACHE[tree_cache_key] = (stat_signature, True, tree_detail)
    elif cached_tree is not None and cached_tree[0] == stat_signature:
        _, tree_ok, tree_detail = cached_tree
    else:
        try:
            actual_tree, actual_files, actual_bytes = _dependency_installed_tree_fingerprint(target)
            tree_ok = (
                hmac.compare_digest(actual_tree, expected_tree)
                and actual_files == expected_files
                and actual_bytes == expected_bytes
            )
            tree_detail = "安装后依赖文件树 SHA-256 校验通过" if tree_ok else (
                f"安装后依赖文件树完整性不匹配：files {actual_files}/{expected_files}, "
                f"bytes {actual_bytes}/{expected_bytes}"
            )
            # Refresh the cheap signature after hashing in case the tree changed during the read.
            final_signature = _dependency_tree_stat_signature(target)
            if final_signature != stat_signature:
                tree_ok = False
                tree_detail = "依赖文件树在完整性校验期间发生变化，拒绝信任"
            stat_signature = final_signature
            full_tree_verified = bool(tree_ok)
        except (OSError, StorageError) as exc:
            tree_ok, tree_detail = False, f"安装后依赖文件树校验失败：{exc}"
        _DEPENDENCY_TREE_VERIFY_CACHE[tree_cache_key] = (stat_signature, tree_ok, tree_detail)
    if full_tree_verified and RUNTIME_FOLDER_BOUND and not _storage_survival_mode_active():
        try:
            verified_payload = {
                "manifest_digest": actual_digest, "installed_tree_sha256": expected_tree,
                "file_count": stat_signature[0], "byte_count": stat_signature[1],
                "latest_mtime_ns": stat_signature[2], "verified_at": _now_iso(),
            }
            def remember_verified_signature(current_settings):
                rows = dict(current_settings.get("dependency_verified_signatures") or {})
                rows[name] = verified_payload
                current_settings["dependency_verified_signatures"] = rows
            _update_install_settings(remember_verified_signature)
        except Exception as exc:
            _record_diagnostic("dependency-signature-persist", exc)
    if not tree_ok:
        return False, tree_detail, manifest

    if require_import_probe:
        import_cache_key = (str(target.resolve()), actual_digest, stat_signature)
        cached_probe = None if force_import_probe else _DEPENDENCY_IMPORT_VERIFY_CACHE.get(import_cache_key)
        if cached_probe is None:
            ok, detail = _dependency_import_probe(target, settings)
            _DEPENDENCY_IMPORT_VERIFY_CACHE[import_cache_key] = (ok, detail)
        else:
            ok, detail = cached_probe
        if not ok:
            return False, detail, manifest
        try:
            probed = json.loads(detail)
            probed_versions = probed.get("versions") if isinstance(probed, dict) else {}
        except (TypeError, json.JSONDecodeError):
            probed_versions = {}
        for module_name, expected_version in versions.items():
            if module_name in probed_versions and str(probed_versions.get(module_name)) != str(expected_version):
                return False, f"依赖导入版本与 manifest 不一致：{module_name}", manifest
    return True, "manifest/ABI/固定版本/安装后文件树校验通过", manifest


def _dependency_dir_from_name(
    name: str, settings: dict, *, require_import_probe: bool = False, safety_boundary: bool = False,
) -> Path | None:
    if not (name.startswith(DEPS_DIR_PREFIX) and Path(name).name == name):
        return None
    candidate = BASE_DIR / name
    ok, _, _ = _verify_dependency_generation(
        candidate, settings, require_import_probe=require_import_probe,
        force_tree_rehash=safety_boundary, force_import_probe=safety_boundary and require_import_probe,
    )
    return candidate if ok else None


def _active_dependency_dir(settings: dict | None = None) -> Path | None:
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    global _TRAINING_DEPENDENCY_OVERRIDE
    if _TRAINING_DEPENDENCY_OVERRIDE is not None:
        ok, _, _ = _verify_dependency_generation(_TRAINING_DEPENDENCY_OVERRIDE, settings)
        if ok:
            return _TRAINING_DEPENDENCY_OVERRIDE
    return _dependency_dir_from_name(str(settings.get("active_dependency_dir") or ""), settings)


def _activate_local_dependencies() -> Path | None:
    target = _active_dependency_dir()
    if target is None:
        return None
    text = str(target)
    if text not in sys.path:
        sys.path.insert(0, text)
    importlib.invalidate_caches()
    return target


def _pending_dependency_dir(
    settings: dict | None = None, *, require_import_probe: bool = False, safety_boundary: bool = False,
) -> Path | None:
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    return _dependency_dir_from_name(
        str(settings.get("pending_dependency_dir") or ""), settings,
        require_import_probe=require_import_probe, safety_boundary=safety_boundary,
    )


def _preferred_training_dependency_dir(
    settings: dict | None = None, *, require_import_probe: bool = False, safety_boundary: bool = False,
) -> Path | None:
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    pending = _pending_dependency_dir(
        settings, require_import_probe=require_import_probe, safety_boundary=safety_boundary,
    )
    if pending is not None:
        return pending
    active_name = str(settings.get("active_dependency_dir") or "")
    return _dependency_dir_from_name(
        active_name, settings, require_import_probe=require_import_probe, safety_boundary=safety_boundary,
    )


def _promote_pending_dependency_dir() -> bool:
    """Promote only a manifest/ABI/tree-verified generation; native import is revalidated at activation."""
    settings = _load_install_settings()
    pending = _pending_dependency_dir(settings, require_import_probe=False)
    if pending is None:
        if settings.get("pending_dependency_dir"):
            settings["dependency_install_status"] = "pending-verify-failed"
            settings["dependency_install_error"] = "pending dependency generation failed manifest/ABI/tree/import verification"
            settings["pending_dependency_dir"] = ""
            _save_install_settings(settings)
        return False
    previous = _active_dependency_dir(settings)
    settings["active_dependency_dir"] = pending.name
    settings["pending_dependency_dir"] = ""
    settings["dependency_install_status"] = "activated-on-process-start:manifest-abi-tree-verified"
    settings["dependency_activated_at"] = _now_iso()
    settings.pop("dependency_install_error", None)
    _save_install_settings(settings)
    _cleanup_stale_dependency_dirs(pending, (previous,) if previous is not None else ())
    return True


def _cleanup_stale_dependency_dirs(active: Path | None, protected: tuple[Path, ...] = ()) -> int:
    """Best-effort cleanup only for inactive dependency generations; return removed artifact count."""
    import shutil
    removed = 0
    keep = {Path(value).resolve() for value in protected if value is not None}
    if active is not None:
        keep.add(active.resolve())
    try:
        candidates = [path for path in BASE_DIR.glob(DEPS_DIR_PREFIX + "*") if path.is_dir() and not path.name.endswith(".tmp")]
    except OSError:
        candidates = []
    for path in candidates:
        try:
            _assert_isolated_app_path(path)
            if _path_is_reparse_or_symlink(path):
                _record_diagnostic("dependency-cleanup", f"refused reparse point: {path}", "StorageError")
                continue
            if path.resolve() in keep or str(path) in sys.path:
                continue
            shutil.rmtree(path)
            removed += 1
        except (OSError, StorageError):
            continue
    # Incomplete staging dirs are never active generations and are safe to reap when stale.
    now = time.time()
    for path in (DEPS_TMP_DIR, DEPS_BACKUP_DIR, BASE_DIR / "BestFunds_wheels.tmp"):
        try:
            safe = _assert_isolated_app_path(path)
            if not safe.exists() or _path_is_reparse_or_symlink(safe):
                continue
            age = now - safe.stat().st_mtime
            if age >= _objective_stale_artifact_age_seconds(safe):
                shutil.rmtree(safe)
                removed += 1
        except (OSError, StorageError):
            continue
    return removed


def _model_auto_update_enabled() -> bool:
    settings = _load_install_settings()
    return settings.get("auto_update_model") is not False


def _dependency_import_probe(target: Path, settings: dict) -> tuple[bool, str]:
    names = ["numpy"]
    if settings.get("lightgbm") is True:
        names.append("lightgbm")
    if settings.get("advanced_tree") is True:
        names.append("xgboost")
    probe = (
        "import importlib, json, pathlib, sys; "
        "sys.dont_write_bytecode=True; "
        f"target=pathlib.Path({str(target)!r}).resolve(); "
        f"names={names!r}; "
        "sys.path.insert(0, str(target)); "
        "mods=[importlib.import_module(n) for n in names]; "
        "paths={m.__name__:str(pathlib.Path(getattr(m,'__file__','')).resolve()) for m in mods}; "
        "bad=[n for n,p in paths.items() if target not in pathlib.Path(p).parents]; "
        "assert not bad, 'nonlocal imports: '+','.join(bad); "
        "print(json.dumps({'versions':{m.__name__:getattr(m,'__version__','unknown') for m in mods},'paths':paths}))"
    )
    completed = _run_process_cancellable(
        [sys.executable, "-I", "-S", "-c", probe],
        timeout=_objective_external_operation_timeout("dependency_import_probe", len(names)),
        env=_isolated_subprocess_env(), cwd=_isolated_subprocess_cwd(),
    )
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout or "import probe failed").strip()
    return True, completed.stdout.strip()


def _ensure_pip_available() -> tuple[bool, str]:
    """Probe pip only. Never run ensurepip because that can modify the user's Python installation."""
    try:
        probe = _run_process_cancellable(
            [sys.executable, "-m", "pip", "--version"],
            timeout=_objective_external_operation_timeout("pip_probe"),
            env=_isolated_subprocess_env(), cwd=_isolated_subprocess_cwd(),
        )
    except concurrent.futures.CancelledError:
        raise
    except (OSError, subprocess.SubprocessError, TimeoutError, RuntimeError) as exc:
        return False, f"pip probe failed without modifying global Python: {type(exc).__name__}: {exc}"
    if probe.returncode == 0:
        return True, (probe.stdout or "pip available").strip()
    detail = (probe.stderr or probe.stdout or "pip unavailable").strip()
    return False, "pip 不可用；按零全局修改策略使用标准库模型。" + (" " + detail if detail else "")


def _dependency_observed_bytes_per_second(settings: dict, key: str) -> float | None:
    observation = settings.get(key) if isinstance(settings, dict) else None
    observation = observation if isinstance(observation, dict) else {}
    rate = max(0.0, _finite(observation.get("minimum_bytes_per_second"), 0.0))
    return rate if rate > 0.0 else None

def _record_dependency_throughput(settings: dict, key: str, byte_count: int, elapsed: float) -> None:
    byte_count = max(0, int(byte_count))
    elapsed = max(0.0, _finite(elapsed, 0.0))
    if byte_count <= 0 or elapsed <= 0.0:
        return
    rate = byte_count / elapsed
    previous = settings.get(key) if isinstance(settings.get(key), dict) else {}
    count = max(0, int(_finite(previous.get("count"), 0))) + 1
    mean = max(0.0, _finite(previous.get("mean_bytes_per_second"), 0.0))
    delta = rate - mean
    mean += delta / count
    previous_min = max(0.0, _finite(previous.get("minimum_bytes_per_second"), 0.0))
    settings[key] = {
        "count": count,
        "mean_bytes_per_second": mean,
        "minimum_bytes_per_second": min(previous_min, rate) if previous_min > 0.0 else rate,
        "last_bytes": byte_count,
        "last_elapsed_seconds": elapsed,
        "observed_at": _now_iso(),
    }

def _dependency_download_timeout(expected_bytes: int, package_count: int, settings: dict) -> float:
    """Network cold bound first; later add transfer time using the slowest successful observed download rate."""
    packages = max(1, int(package_count))
    protocol_budget = _platform_network_total_timeout_seconds() * packages
    rate = _dependency_observed_bytes_per_second(settings, "dependency_download_throughput")
    transfer_budget = max(0, int(expected_bytes)) / rate if rate else 0.0
    return max(_platform_network_inactivity_timeout_seconds(), protocol_budget + transfer_budget)

def _dependency_install_timeout(uncompressed_bytes: int, package_count: int, measured_read_rate: float | None) -> float:
    process_budget = _objective_external_operation_timeout("dependency_install", max(1, int(package_count)))
    rate = max(0.0, _finite(measured_read_rate, 0.0))
    io_budget = max(0, int(uncompressed_bytes)) / rate if rate > 0.0 else 0.0
    return max(process_budget, process_budget + io_budget)

def _requires_python_allows_runtime(spec: str | None) -> bool:
    """Evaluate the simple PEP 440 Requires-Python forms used by pinned PyPI releases."""
    text = str(spec or "").strip()
    if not text:
        return True
    current = tuple((sys.version_info.major, sys.version_info.minor, sys.version_info.micro))

    def version_tuple(value: str) -> tuple[int, int, int]:
        parts = [int(part) for part in value.split(".") if part != ""][:3]
        return tuple((parts + [0, 0, 0])[:3])

    for raw_clause in text.split(","):
        clause = raw_clause.strip()
        match = re.fullmatch(r"(>=|<=|==|!=|~=|>|<)\s*(\d+(?:\.\d+){0,2})(\.\*)?", clause)
        if not match:
            return False  # fail closed; pip may support more, but native ML activation requires an auditable contract
        op, raw_version, wildcard = match.groups()
        target = version_tuple(raw_version)
        if wildcard:
            prefix = tuple(int(part) for part in raw_version.split("."))
            equal = current[:len(prefix)] == prefix
            if (op == "==" and not equal) or (op == "!=" and equal):
                return False
            if op not in {"==", "!="}:
                return False
            continue
        if op == ">=" and not (current >= target): return False
        if op == ">" and not (current > target): return False
        if op == "<=" and not (current <= target): return False
        if op == "<" and not (current < target): return False
        if op == "==" and not (current == target): return False
        if op == "!=" and not (current != target): return False
        if op == "~=":
            if current < target:
                return False
            components = raw_version.count(".") + 1
            upper = (target[0] + 1, 0, 0) if components <= 2 else (target[0], target[1] + 1, 0)
            if current >= upper:
                return False
    return True


def _wheel_tag_matches_runtime(filename: str) -> tuple[bool, str]:
    """On Windows, reject wheels that do not match CPython minor + win_amd64 before manifest trust."""
    if os.name != "nt":
        return True, "non-Windows validation host"
    if struct.calcsize("P") * BITS_PER_BYTE != X64_POINTER_BITS or platform.machine().upper() not in {"AMD64", "X86_64"}:
        return False, "当前运行时不是 Windows x64 / AMD64"
    if not str(filename).lower().endswith(WHEEL_EXTENSION):
        return False, "不是 wheel 文件"
    parts = str(filename)[:-len(WHEEL_EXTENSION)].split("-")
    if len(parts) < len(WHEEL_FILENAME_FIELDS):
        return False, "wheel 文件名 tag 格式非法"
    python_tag, abi_tag, platform_tag = parts[-len(WHEEL_RUNTIME_TAG_FIELDS):]
    platform_tags = set(platform_tag.lower().split("."))
    if "win_amd64" not in platform_tags:
        return False, f"platform tag 不匹配 Windows x64：{platform_tag}"

    major, minor = sys.version_info.major, sys.version_info.minor
    current_cp = f"cp{major}{minor}"
    python_tags = set(python_tag.lower().split("."))
    abi_tags = set(abi_tag.lower().split("."))
    if current_cp in python_tags:
        if current_cp in abi_tags or "abi3" in abi_tags or "none" in abi_tags:
            return True, "exact CPython minor + win_amd64"
        return False, f"ABI tag 不匹配当前 {current_cp}：{abi_tag}"
    if ("py3" in python_tags or f"py{major}" in python_tags) and "none" in abi_tags:
        return True, "Python 3 universal + win_amd64"
    if "abi3" in abi_tags:
        for tag in python_tags:
            match = re.fullmatch(r"cp(\d)(\d{1,2})", tag)
            if match and int(match.group(1)) == major and int(match.group(2)) <= minor:
                return True, "compatible abi3 + win_amd64"
    return False, f"Python tag 不匹配当前 {current_cp}：{python_tag}-{abi_tag}"


def _approved_release_wheel_metadata(packages: list[str]) -> tuple[bool, str, dict[str, dict]]:
    """Resolve exact approved wheel filename/hash/size from PyPI before any wheel bytes are downloaded."""
    approved: dict[str, dict] = {}
    for spec in packages:
        if "==" not in spec:
            return False, f"依赖未固定版本：{spec}", {}
        raw_name, version = spec.split("==", 1)
        project = re.sub(r"[-_.]+", "-", raw_name).lower()
        url = f"https://pypi.org/pypi/{urllib.parse.quote(project)}/{urllib.parse.quote(version)}/json"
        try:
            payload = _http_json(
                url, referer="https://pypi.org/", xhr=False, accept="application/json", attempts=LATEST_ATTEMPTS,
            )
        except (NetworkError, ParseError, ContractError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            return False, f"无法取得 {project}=={version} 的 PyPI wheel 大小元数据：{type(exc).__name__}: {exc}", {}
        requires_python = str((payload.get("info") or {}).get("requires_python") or "")
        if requires_python and not _requires_python_allows_runtime(requires_python):
            return False, f"批准依赖与当前 Python 不兼容：{project}=={version} requires {requires_python}", {}
        matches = []
        for row in payload.get("urls") or []:
            filename = str(row.get("filename") or "")
            expected_hash = TRUSTED_WHEEL_SHA256.get(filename)
            if not expected_hash:
                continue
            tag_ok, _ = _wheel_tag_matches_runtime(filename)
            if not tag_ok:
                continue
            fields = filename[:-len(WHEEL_EXTENSION)].split("-") if filename.endswith(WHEEL_EXTENSION) else []
            if len(fields) < len(WHEEL_FILENAME_FIELDS):
                continue
            wheel_project = re.sub(r"[-_.]+", "-", fields[0]).lower()
            if wheel_project != project or fields[1] != version:
                continue
            published_hash = str((row.get("digests") or {}).get("sha256") or "").lower()
            try:
                size = int(row.get("size"))
            except (TypeError, ValueError):
                continue
            if size <= 0 or not re.fullmatch(r"[0-9a-f]{64}", published_hash):
                continue
            if not hmac.compare_digest(published_hash, expected_hash):
                return False, f"PyPI 发布哈希与代码内批准 SHA-256 冲突：{filename}", {}
            matches.append({
                "filename": filename, "sha256": expected_hash, "size": size,
                "project": project, "version": version,
            })
        if len(matches) != 1:
            return False, f"无法唯一确定当前 Python/Windows x64 的批准 wheel：{project}=={version}", {}
        record = matches[0]
        approved[record["filename"]] = record
    if len(approved) != len(packages):
        return False, "批准 wheel 发布清单与固定依赖数量不一致", {}
    return True, f"已从 PyPI 复核 {len(approved)} 个批准 wheel 的 filename/SHA-256/size", approved


def _wheel_uncompressed_bytes(wheel_dir: Path) -> int:
    """Exact ZIP member payload size for the downloaded approved wheels."""
    total = 0
    for wheel in sorted(wheel_dir.glob("*.whl")):
        with zipfile.ZipFile(wheel, "r") as archive:
            total += sum(max(0, int(member.file_size)) for member in archive.infolist())
    return total


def _verify_downloaded_wheels_against_allowlist(
    wheel_dir: Path, packages: list[str], release_metadata: dict[str, dict],
) -> tuple[bool, str, dict[str, str], dict[str, int]]:
    """Authenticate downloaded wheel identity, bytes and exact published size against the approved release manifest."""
    requested: dict[str, str] = {}
    for spec in packages:
        if "==" not in spec:
            return False, f"依赖未固定版本：{spec}", {}, {}
        name, version = spec.split("==", 1)
        requested[re.sub(r"[-_.]+", "-", name).lower()] = version

    wheels = sorted(wheel_dir.glob("*.whl"))
    if len(wheels) != len(requested):
        return False, f"wheel 数量与固定依赖不一致：{len(wheels)} != {len(requested)}", {}, {}

    verified_hashes: dict[str, str] = {}
    verified_sizes: dict[str, int] = {}
    represented: set[str] = set()
    for wheel in wheels:
        filename = wheel.name
        tag_ok, tag_detail = _wheel_tag_matches_runtime(filename)
        if not tag_ok:
            return False, f"wheel 与当前 Python/Windows x64 不兼容：{filename}（{tag_detail}）", {}, {}
        release = release_metadata.get(filename) if isinstance(release_metadata, dict) else None
        expected_hash = TRUSTED_WHEEL_SHA256.get(filename)
        if not expected_hash or not isinstance(release, dict):
            return False, f"wheel 不在批准 filename/hash/size 发布清单：{filename}", {}, {}
        fields = filename[:-len(WHEEL_EXTENSION)].split("-")
        if len(fields) < len(WHEEL_FILENAME_FIELDS):
            return False, f"wheel 文件名无法识别：{filename}", {}, {}
        project = re.sub(r"[-_.]+", "-", fields[0]).lower()
        version = fields[1]
        if requested.get(project) != version or release.get("project") != project or release.get("version") != version:
            return False, f"wheel 身份不属于当前固定依赖 profile：{filename}", {}, {}
        try:
            expected_size = int(release.get("size"))
            actual_size = int(wheel.stat().st_size)
        except (OSError, TypeError, ValueError) as exc:
            return False, f"无法核验 wheel 大小：{filename}: {exc}", {}, {}
        if expected_size <= 0 or actual_size != expected_size:
            return False, f"wheel 大小与发布清单不一致：{filename} {actual_size}/{expected_size}", {}, {}
        digest = hashlib.sha256()
        with wheel.open("rb") as handle:
            while True:
                chunk = handle.read(FILE_IO_CHUNK_BYTES)
                if not chunk:
                    break
                digest.update(chunk)
        actual_hash = digest.hexdigest().lower()
        published_hash = str(release.get("sha256") or "").lower()
        if not hmac.compare_digest(actual_hash, expected_hash) or not hmac.compare_digest(actual_hash, published_hash):
            return False, f"批准 wheel SHA-256 校验失败：{filename}", {}, {}
        verified_hashes[filename] = actual_hash
        verified_sizes[filename] = actual_size
        represented.add(project)

    missing = sorted(set(requested) - represented)
    if missing:
        return False, "固定依赖未全部下载/校验：" + ",".join(missing), {}, {}
    return True, f"已核验 {len(verified_hashes)} 个批准 wheel 的 filename/SHA-256/size 与运行时 tag", verified_hashes, verified_sizes


def _install_local_dependencies(settings: dict, status_callback=None) -> tuple[bool, str]:
    with _DEPENDENCY_INSTALL_LOCK:
        return _install_local_dependencies_locked(settings, status_callback=status_callback)


def _install_local_dependencies_locked(settings: dict, status_callback=None) -> tuple[bool, str]:
    runtime_root = _require_runtime_folder()
    if not _native_ml_runtime_supported():
        settings["lightgbm"] = False
        settings["advanced_tree"] = False
        settings["dependency_install_status"] = "unsupported-python-runtime-native-ml-disabled"
        _save_install_settings(settings)
        return False, f"当前 CPython minor 没有 wheel/hash 验证的 native profile（已验证：{_native_python_profile_text()}）；已自动使用纯 Python 模型。"
    approved_profiles = list(_dependency_profiles_for_runtime())
    pins = settings.get("dependency_pins") if isinstance(settings.get("dependency_pins"), dict) else {}
    if not any(pins == profile for profile in approved_profiles):
        pins = dict(approved_profiles[0])
        settings["dependency_pins"] = dict(pins)
    packages = []
    if settings.get("lightgbm") is True:
        packages.extend((pins["numpy"], pins["scipy"], pins["lightgbm"]))
    if settings.get("advanced_tree") is True:
        if sys.version_info < ADVANCED_ML_MIN_PYTHON:
            settings["advanced_tree"] = False
        else:
            xgb_key = str(settings.get("xgboost_distribution") or "xgboost_cpu")
            if xgb_key not in {"xgboost_cpu", "xgboost_gpu"}:
                xgb_key = "xgboost_cpu"
            packages.extend((pins["numpy"], pins["scipy"], pins[xgb_key]))
    packages = list(dict.fromkeys(packages))
    if not packages:
        settings["dependency_install_status"] = "minimal-standard-library-only"
        _save_install_settings(settings)
        return True, "硬件自适应：当前采用标准库轻量后端"

    pip_ok, pip_detail = _ensure_pip_available()
    if not pip_ok:
        settings["dependency_install_status"] = "pip-unavailable-fallback-minimal"
        settings["dependency_install_error"] = pip_detail
        settings["lightgbm"] = False
        settings["advanced_tree"] = False
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", pip_detail, "PipUnavailable")
        return False, "pip 不可用；未运行 ensurepip、未修改全局 Python，已自动使用标准库模型。"

    metadata_ok, metadata_detail, release_metadata = _approved_release_wheel_metadata(packages)
    if not metadata_ok:
        settings["dependency_install_status"] = "release-metadata-preflight-failed"
        settings["dependency_install_error"] = metadata_detail
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", metadata_detail, "ReleaseMetadataFailed")
        return False, "无法在下载前确认批准 wheel 的 filename/SHA-256/size；已拒绝 native 安装并自动降级。"
    release_download_bytes = sum(int(row["size"]) for row in release_metadata.values())

    wheel_dir = runtime_root / "BestFunds_wheels.tmp"
    previous_active = _active_dependency_dir(settings)
    install_seed = json.dumps({
        "packages": packages, "python": list(sys.version_info[:3]), "machine": platform.machine(),
        "xgboost_device": settings.get("xgboost_device"), "nonce": time.time_ns(),
    }, sort_keys=True, ensure_ascii=True)
    install_id = hashlib.sha256(install_seed.encode("utf-8")).hexdigest()
    final_dir = runtime_root / f"{DEPS_DIR_PREFIX}{install_id}"
    for safe_path in (DEPS_TMP_DIR, wheel_dir, final_dir):
        _assert_isolated_app_path(safe_path)

    for path in (DEPS_TMP_DIR, wheel_dir):
        try:
            if path.exists():
                shutil.rmtree(path)
        except OSError as exc:
            settings["dependency_install_status"] = f"prepare-failed:{type(exc).__name__}"
            settings["dependency_install_error"] = str(exc)
            _save_install_settings(settings)
            _record_diagnostic("dependency-install", exc)
            return False, f"无法准备本地 AI 临时目录：{exc}"
    if not _disk_capacity_allows(release_download_bytes):
        detail = (
            f"下载前磁盘预检失败：free={_selected_folder_free_bytes()}, "
            f"required={_objective_low_disk_reserve_bytes(release_download_bytes)}; {metadata_detail}"
        )
        settings["dependency_install_status"] = "disk-preflight-failed"
        settings["dependency_install_error"] = detail
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", detail, "LowDisk")
        return False, "用户选择目录的实际可用空间不足以容纳已批准 wheel 下载；已在下载前停止并自动降级。"
    try:
        DEPS_TMP_DIR.mkdir(parents=True, exist_ok=False)
        wheel_dir.mkdir(parents=True, exist_ok=False)
    except OSError as exc:
        settings["dependency_install_status"] = f"deps-dir-failed:{type(exc).__name__}"
        settings["dependency_install_error"] = str(exc)
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", exc)
        return False, f"无法创建本地 AI 临时目录：{exc}"

    package_names = [value.split("==",1)[0] for value in packages]
    if status_callback:
        status_callback(metadata_detail + "；后台下载已批准固定版本 wheel：" + " / ".join(package_names) + "…")
    download_timeout = _dependency_download_timeout(release_download_bytes, len(packages), settings)
    pip_socket_timeout = max(time.get_clock_info("monotonic").resolution, _platform_network_inactivity_timeout_seconds())
    download_command = [
        sys.executable, "-m", "pip", "download", "--disable-pip-version-check", "--quiet",
        "--timeout", str(int(math.ceil(pip_socket_timeout))),
        "--only-binary=:all:", "--no-deps", "--no-cache-dir", "--dest", str(wheel_dir), *packages,
    ]
    try:
        download_started = time.monotonic()
        downloaded = _run_process_cancellable(
            download_command, timeout=download_timeout, env=_isolated_subprocess_env(), cwd=_isolated_subprocess_cwd()
        )
        download_elapsed = max(time.get_clock_info("monotonic").resolution, time.monotonic() - download_started)
        if downloaded.returncode != 0:
            detail = (downloaded.stderr or downloaded.stdout or "pip download failed").strip()
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            settings["dependency_install_status"] = "download-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "DownloadFailed")
            return False, "当前 Python 对应的批准固定 wheel profile 不可用；程序将自动使用原有依赖或纯 Python 模型。"
        verify_started = time.monotonic()
        ok_hash, hash_detail, verified_hashes, verified_sizes = _verify_downloaded_wheels_against_allowlist(wheel_dir, packages, release_metadata)
        verify_elapsed = max(time.get_clock_info("monotonic").resolution, time.monotonic() - verify_started)
        if not ok_hash:
            settings["dependency_install_status"] = "sha256-verify-failed"
            settings["dependency_install_error"] = hash_detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", hash_detail, "HashVerifyFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "本地 AI wheel 的 SHA-256 校验失败或无法确认；已拒绝安装并自动降级。"
        verified_download_bytes = sum(max(0, int(value)) for value in verified_sizes.values())
        _record_dependency_throughput(settings, "dependency_download_throughput", verified_download_bytes, download_elapsed)
        measured_wheel_read_rate = verified_download_bytes / verify_elapsed if verified_download_bytes > 0 and verify_elapsed > 0.0 else None
        _record_dependency_throughput(settings, "dependency_wheel_read_throughput", verified_download_bytes, verify_elapsed)
        try:
            _save_install_settings(settings)
        except Exception as exc:
            _record_diagnostic("dependency-throughput-observation", exc)
        path_ok, path_detail = _verify_wheel_member_path_budget(wheel_dir, DEPS_TMP_DIR)
        if not path_ok:
            settings["dependency_install_status"] = "dependency-path-too-deep"
            settings["dependency_install_error"] = path_detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", path_detail, "PathTooDeep")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "所选目录对批准 native wheel 的实际解包路径过深；已拒绝安装并自动使用纯 Python 模型。"
        try:
            uncompressed_bytes = _wheel_uncompressed_bytes(wheel_dir)
        except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
            detail = f"无法读取批准 wheel ZIP 成员大小：{type(exc).__name__}: {exc}"
            settings["dependency_install_status"] = "wheel-zip-size-check-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "WheelZipFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "无法在安装前确认 wheel 实际解压大小；已拒绝安装并自动降级。"
        if not _disk_capacity_allows(uncompressed_bytes):
            detail = (
                f"解压前磁盘预检失败：free={_selected_folder_free_bytes()}, "
                f"required={_objective_low_disk_reserve_bytes(uncompressed_bytes)}, unzip={uncompressed_bytes}"
            )
            settings["dependency_install_status"] = "disk-unpack-preflight-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "LowDisk")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "用户选择目录的实际可用空间不足以解压批准 wheel；已在安装前停止并自动降级。"
        if status_callback:
            status_callback(hash_detail + "；" + path_detail + "；ZIP 实际解压容量预检通过；正在离线安装到用户选择的文件夹内版本化目录…")
        install_command = [
            sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--quiet",
            "--no-index", "--no-cache-dir", "--no-compile", "--find-links", str(wheel_dir), "--target", str(DEPS_TMP_DIR), *packages,
        ]
        install_timeout = _dependency_install_timeout(uncompressed_bytes, len(packages), measured_wheel_read_rate)
        installed = _run_process_cancellable(
            install_command, timeout=install_timeout, env=_isolated_subprocess_env(), cwd=_isolated_subprocess_cwd()
        )
        if installed.returncode != 0:
            detail = (installed.stderr or installed.stdout or "pip install failed").strip()
            settings["dependency_install_status"] = "install-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "InstallFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "校验后的本地 AI 依赖安装失败；程序将自动使用原有依赖或纯 Python 模型。"
        if status_callback:
            status_callback("安装完成；正在隔离验证 NumPy / SciPy / LightGBM / XGBoost…")
        ok, detail = _dependency_import_probe(DEPS_TMP_DIR, settings)
        if not ok:
            settings["dependency_install_status"] = "verify-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "ImportVerifyFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "本地 AI 依赖验证失败；未触碰当前激活目录，程序会自动降级。"
        try:
            probe_payload = json.loads(detail)
        except (TypeError, json.JSONDecodeError):
            probe_payload = {}
        import_versions = probe_payload.get("versions") if isinstance(probe_payload, dict) else {}
        installed_tree_sha256, installed_tree_files, installed_tree_bytes = _dependency_installed_tree_fingerprint(DEPS_TMP_DIR)
        manifest = {
            "schema_fingerprint": DEPENDENCY_MANIFEST_FINGERPRINT,
            "app": APP_NAME,
            "generation": final_dir.name,
            "created_at": _now_iso(),
            "selection_rule": DEPENDENCY_SELECTION_RULE,
            "python_abi": _runtime_python_abi(),
            "package_specs": list(packages),
            "import_versions": dict(import_versions) if isinstance(import_versions, dict) else {},
            "wheel_sha256": dict(verified_hashes),
            "wheel_size_bytes": dict(verified_sizes),
            "installed_tree_sha256": installed_tree_sha256,
            "installed_tree_files": installed_tree_files,
            "installed_tree_bytes": installed_tree_bytes,
        }
        manifest_path = DEPS_TMP_DIR / DEPENDENCY_MANIFEST_FILENAME
        _write_json(manifest_path, manifest)
        manifest_digest = _dependency_manifest_digest(manifest_path)
        if status_callback:
            status_callback("验证通过；已写入批准 wheel filename/SHA-256/size + 安装后文件树 SHA-256 manifest。当前 GUI 不热切 native DLL，新训练进程可直接使用这一代依赖…")
        os.replace(DEPS_TMP_DIR, final_dir)
        _assert_isolated_app_path(final_dir)
        settings = _load_install_settings() | settings
        trusted_manifests = dict(settings.get("dependency_generation_manifests") or {})
        trusted_manifests[final_dir.name] = manifest_digest
        settings["dependency_generation_manifests"] = trusted_manifests
        settings["pending_dependency_dir"] = final_dir.name
        settings["dependency_install_status"] = "installed-pending-training-ready-wheel+tree-sha256-manifest:" + detail
        settings["dependency_wheel_sha256"] = verified_hashes
        settings["dependency_wheel_size_bytes"] = verified_sizes
        settings["dependency_staged_at"] = _now_iso()
        settings.pop("dependency_install_error", None)
        _save_install_settings(settings)
        # Never prepend the newly installed native stack to the GUI process. A fresh training
        # child may use this verified pending generation immediately; normal startup promotes it.
        _cleanup_stale_dependency_dirs(previous_active, (final_dir,))
        shutil.rmtree(wheel_dir, ignore_errors=True)
        return True, "本地 AI 依赖已核验并暂存；本次运行后续训练可自动使用，下次启动再正式激活到 GUI 进程。"
    except (OSError, StorageError, subprocess.SubprocessError, TimeoutError) as exc:
        shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
        settings["dependency_install_status"] = f"operational-error:{type(exc).__name__}"
        settings["dependency_install_error"] = str(exc)
        _save_install_settings(settings); _record_diagnostic("dependency-install", exc, "RetryableDependencyError")
        return False, "本地 AI 安装遇到可恢复的系统/文件错误；当前激活目录未被替换，程序将自动降级继续运行。"


def _configure_hardware_adaptive(force: bool = False, status_callback=None, allow_install: bool = True) -> dict:
    """Zero-interaction hardware adaptation. No installation choice is ever shown to the user."""
    profile = _detect_hardware_profile()
    desired = _adaptive_settings_for_hardware(profile)
    current = _load_install_settings()
    fingerprint_changed = current.get("hardware_fingerprint") != profile.get("fingerprint")
    failure_kind = str(current.get("cuda_failure_kind") or _classify_cuda_failure_reason(current.get("cuda_failure_reason")))
    deterministic_failure_same_hardware = bool(
        failure_kind == "deterministic-incompatibility"
        and current.get("cuda_failure_fingerprint")
        and current.get("cuda_failure_fingerprint") == profile.get("fingerprint")
    )
    transient_failure_pending = bool(
        not fingerprint_changed
        and str(failure_kind).startswith("transient-")
        and current.get("cuda_backoff_active") is True
    )
    if _is_cuda_device(desired.get("xgboost_device")) and (deterministic_failure_same_hardware or transient_failure_pending):
        if deterministic_failure_same_hardware or _cuda_backoff_blocks(current, profile.get("nvidia_cuda") or {}):
            desired["xgboost_device"] = "cpu"
            desired["cuda_backoff_active"] = True
        else:
            # A transient CUDA failure is retriable once live free VRAM is objectively better
            # than it was at failure time.
            desired["cuda_backoff_active"] = False
    else:
        desired["cuda_backoff_active"] = False
    dependency_selection_changed = any(
        current.get(key) != desired.get(key) for key in ("lightgbm", "advanced_tree", "xgboost_distribution")
    )
    current_pins = current.get("dependency_pins") if isinstance(current.get("dependency_pins"), dict) else {}
    pins_changed = not any(current_pins == profile for profile in _dependency_profiles_for_runtime())

    settings = dict(current)
    if fingerprint_changed:
        for key in (
            "cuda_failure_fingerprint", "cuda_failure_at", "cuda_failure_reason", "cuda_failure_kind",
            "cuda_failure_free_mib", "cuda_failure_required_free_mib", "cuda_backoff_active",
        ):
            settings.pop(key, None)
    settings.update(desired)
    settings["hardware_profile"] = profile
    settings["hardware_fingerprint"] = profile.get("fingerprint", "")
    settings["last_hardware_scan_at"] = _now_iso()
    _save_install_settings(settings)
    active_target = _activate_local_dependencies()
    pending_target = _pending_dependency_dir(settings)
    # Never remove a verified pending generation that may be used by an isolated training process.
    _cleanup_stale_dependency_dirs(active_target, (pending_target,) if pending_target is not None else ())

    required = []
    if settings.get("lightgbm") is True:
        required.append("lightgbm")
    if settings.get("advanced_tree") is True:
        required.append("xgboost")
    deps_ok = True
    if required:
        active_target = _active_dependency_dir(settings)
        deps_ok, _detail = _dependency_import_probe(active_target, settings) if active_target is not None else (False, "local dependency directory missing")

    status_text = str(current.get("dependency_install_status") or "")
    failed_before = any(token in status_text for token in ("failed", "unavailable", "exception"))
    retry_due = True
    dependency_error_streak = max(1, int(_finite(current.get("dependency_error_streak"), 1)))
    if failed_before and not (force or fingerprint_changed or pins_changed):
        try:
            attempted = _parse_iso(str(current.get("last_dependency_attempt_at") or ""))
            retry_delay = _objective_retry_delay(dependency_error_streak)
            retry_due = not attempted or (_dt.datetime.now(tz=CHINA_TZ) - attempted.astimezone(CHINA_TZ)).total_seconds() >= retry_delay
        except (TypeError, ValueError, OverflowError):
            retry_due = True

    need_install = bool(allow_install and required and pending_target is None and (force or dependency_selection_changed or pins_changed or not deps_ok) and retry_due)
    if need_install:
        settings["last_dependency_attempt_at"] = _now_iso()
        _save_install_settings(settings)
        if status_callback:
            status_callback(f"硬件自适应：{settings['adaptive_tier']}，正在自动准备本地 AI 依赖…")
        ok, message = _install_local_dependencies(settings, status_callback=status_callback)
        settings = _load_install_settings()
        settings["last_adaptive_install_ok"] = bool(ok)
        settings["last_adaptive_install_message"] = str(message)
        previous_streak = max(0, int(_finite(settings.get("dependency_error_streak"), 0)))
        settings["dependency_error_streak"] = 0 if ok else previous_streak + 1
        _save_install_settings(settings)
    elif required and pending_target is not None:
        settings["dependency_install_status"] = "installed-pending-training-ready"
        settings["dependency_install_error"] = "新 native AI 依赖已核验并暂存；当前 GUI 不热切 DLL，但独立训练进程可立即使用；下次启动再正式激活。"
        _save_install_settings(settings)
    elif required and not deps_ok and not allow_install:
        settings["dependency_install_status"] = "deferred-background-install"
        settings["dependency_install_error"] = "GUI 已先启动；高级 AI 依赖将在应用工作线程中自动准备。若本轮训练先完成，会在依赖就绪后自动补训。"
        _save_install_settings(settings)
    elif required and not deps_ok and not retry_due:
        settings["lightgbm"] = False
        settings["advanced_tree"] = False
        settings["dependency_install_status"] = "adaptive-backoff-after-failed-install"
        settings["dependency_install_error"] = "上一轮本地 AI 依赖安装失败；达到自适应重试条件前使用纯 Python AI。"
        _save_install_settings(settings)
    elif not required:
        settings["dependency_install_status"] = "adaptive-standard-library-fallback"
        _save_install_settings(settings)
    else:
        settings["dependency_install_status"] = settings.get("dependency_install_status") or "adaptive-local-dependencies-ready"
        _save_install_settings(settings)

    _activate_local_dependencies()
    return _load_install_settings()


def _classify_cuda_failure_reason(reason) -> str:
    """Only known incompatibility signatures become hardware-sticky; unknown failures remain retriable."""
    text = str(reason or "").casefold()
    deterministic_markers = (
        "not compiled with cuda",
        "cuda support is not enabled",
        "cuda is not enabled",
        "no kernel image is available for execution on the device",
        "unsupported gpu architecture",
        "unsupported cuda",
        "driver version is insufficient for cuda runtime version",
        "cuda driver version is insufficient",
        "invalid device function",
        "invalid device ordinal",
    )
    if any(marker in text for marker in deterministic_markers):
        return "deterministic-incompatibility"
    resource_markers = (
        "out of memory", "memory allocation", "device is busy", "device busy",
        "device unavailable", "resource unavailable", "initialization error", "device reset",
    )
    return "transient-resource" if any(marker in text for marker in resource_markers) else "transient-unknown"


def _cuda_backoff_blocks(settings: dict, probe: dict) -> bool:
    """Return whether a recorded CUDA failure still objectively blocks a retry now."""
    if settings.get("cuda_backoff_active") is not True:
        return False
    kind = str(settings.get("cuda_failure_kind") or _classify_cuda_failure_reason(settings.get("cuda_failure_reason")))
    if kind == "deterministic-incompatibility":
        return True
    current_free = max(0, int(_finite((probe or {}).get("max_free_vram_mib"), 0)))
    failure_free = max(0, int(_finite(settings.get("cuda_failure_free_mib"), 0)))
    required_floor = max(0, int(_finite(settings.get("cuda_failure_required_free_mib"), 0)))
    recovered = current_free > failure_free and current_free >= required_floor
    return not recovered


def _record_cuda_failure_payload(payload: dict) -> None:
    """Persist a classified CUDA fallback event in the parent process only."""
    reason = str((payload or {}).get("reason") or "CUDA training failure")
    at = str((payload or {}).get("at") or _now_iso())
    kind = str((payload or {}).get("kind") or _classify_cuda_failure_reason(reason))
    free_mib = max(0, int(_finite((payload or {}).get("free_mib_at_failure"), 0)))
    required_mib = max(0, int(_finite((payload or {}).get("required_free_mib"), 0)))
    device = str((payload or {}).get("device") or "")

    def mutate(settings):
        settings["cuda_failure_fingerprint"] = (
            str(settings.get("hardware_fingerprint") or "") if kind == "deterministic-incompatibility" else ""
        )
        settings["cuda_failure_at"] = at
        settings["cuda_failure_reason"] = reason
        settings["cuda_failure_kind"] = kind
        settings["cuda_failure_free_mib"] = free_mib
        settings["cuda_failure_required_free_mib"] = required_mib
        settings["cuda_backoff_active"] = True
        settings["xgboost_device"] = "cpu"
    _update_install_settings(mutate)
    _record_diagnostic(
        "xgboost-cuda",
        f"{kind}: {reason}; device={device}; free_mib={free_mib}; required_floor_mib={required_mib}",
        "ModelError",
    )


def _record_cuda_success_payload(payload: dict) -> None:
    """Clear transient CUDA backoff after an objectively successful GPU training call."""
    device = str((payload or {}).get("device") or "")
    current = _load_install_settings()
    if current.get("cuda_backoff_active") is not True and (not _is_cuda_device(device) or current.get("xgboost_device") == device):
        return
    def mutate(settings):
        settings["cuda_backoff_active"] = False
        if _is_cuda_device(device):
            settings["xgboost_device"] = device
    _update_install_settings(mutate)


def _record_cuda_success(selection: dict) -> None:
    try:
        payload = {"at": _now_iso(), "device": str((selection or {}).get("device") or "")}
        sink = _TRAINING_CHILD_EVENT_SINK
        if callable(sink):
            sink("cuda_success", payload)
            return
        _record_cuda_success_payload(payload)
    except Exception:
        pass


def _record_cuda_failure(
    exc: BaseException, *, device: str = "", required_free_mib: int = 0, selection: dict | None = None,
) -> None:
    """Report CUDA fallback with failure type and live VRAM; child trainers notify the parent."""
    try:
        reason = f"{type(exc).__name__}: {exc}"
        probe = _nvidia_cuda_probe()
        selected_index = None
        match = re.search(r"cuda:(\d+)", str(device or "").casefold())
        if match:
            selected_index = int(match.group(1))
        rows = [row for row in (probe.get("gpus") or []) if isinstance(row, dict)]
        selected_row = next((row for row in rows if selected_index is not None and int(_finite(row.get("index"), -1)) == selected_index), None)
        free_mib = int(_finite((selected_row or {}).get("memory_free_mib"), 0))
        if free_mib <= 0:
            free_mib = int(_finite(probe.get("max_free_vram_mib"), 0))
        if free_mib <= 0 and isinstance(selection, dict):
            free_mib = int(_finite(selection.get("free_mib"), 0))
        payload = {
            "at": _now_iso(),
            "reason": reason,
            "kind": _classify_cuda_failure_reason(reason),
            "device": str(device or (selection or {}).get("device") or ""),
            "free_mib_at_failure": max(0, free_mib),
            "required_free_mib": max(0, int(required_free_mib)),
            "fallback": "cpu",
        }
        sink = _TRAINING_CHILD_EVENT_SINK
        if callable(sink):
            sink("cuda_failure", payload)
            return
        _record_cuda_failure_payload(payload)
    except Exception:
        pass


def _decode_response(raw: bytes, charset: str | None) -> str:
    candidates = [charset, "utf-8-sig", "utf-8", "gb18030"]
    for candidate in candidates:
        if not candidate:
            continue
        try:
            return raw.decode(candidate)
        except (LookupError, UnicodeDecodeError):
            pass
    return raw.decode("utf-8", errors="replace")


def _read_response_limited(response, limit: int, *, deadline_at: float) -> tuple[bytes, int, list[float]]:
    """Read incrementally with both size and end-to-end deadlines; report blocking-read evidence."""
    limit = max(1, int(limit))
    try:
        content_length = int(response.headers.get("Content-Length") or 0)
    except (TypeError, ValueError):
        content_length = 0
    if content_length > limit:
        raise NetworkError(f"网络响应声明大小 {content_length} 字节，超过当前请求预算 {limit} 字节")
    reserved = 0
    if content_length > 0:
        _HTTP_MEMORY_BUDGET.reserve(content_length)
        reserved = content_length
    chunks = []
    received = 0
    inactivity_samples: list[float] = []
    try:
        while True:
            if _cancel_requested():
                raise concurrent.futures.CancelledError("程序正在退出")
            if time.monotonic() >= deadline_at:
                raise TimeoutError("HTTP 总截止时间已到")
            read_started = time.monotonic()
            block = response.read(min(FILE_IO_CHUNK_BYTES, limit - received + 1))
            inactivity_samples.append(max(0.0, time.monotonic() - read_started))
            if not block:
                break
            if content_length <= 0:
                _HTTP_MEMORY_BUDGET.reserve(len(block))
                reserved += len(block)
            chunks.append(block)
            received += len(block)
            if received > limit:
                raise NetworkError(f"网络响应超过当前请求预算 {limit} 字节")
        return b"".join(chunks), reserved, inactivity_samples
    except BaseException:
        _HTTP_MEMORY_BUDGET.release(reserved)
        raise


def _safe_gzip_decompress(raw: bytes, limit: int) -> tuple[bytes, int]:
    limit = max(len(raw), int(limit))
    chunks = []
    decoded_size = 0
    reserved = 0
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode="rb") as handle:
            while True:
                block = handle.read(min(FILE_IO_CHUNK_BYTES, limit - decoded_size + 1))
                if not block:
                    break
                _HTTP_MEMORY_BUDGET.reserve(len(block))
                reserved += len(block)
                chunks.append(block)
                decoded_size += len(block)
                if decoded_size > limit:
                    raise ParseError(f"gzip 解压结果超过当前请求预算 {limit} 字节")
    except (OSError, EOFError) as exc:
        _HTTP_MEMORY_BUDGET.release(reserved)
        raise ParseError(f"gzip 响应损坏：{exc}") from exc
    except BaseException:
        _HTTP_MEMORY_BUDGET.release(reserved)
        raise
    return b"".join(chunks), reserved


class _DomainTokenBucket:
    """Per-domain AIMD limiter learned from remote behavior, never from local CPU core count."""
    def __init__(self, host: str):
        self.host = str(host or "unknown").lower()
        clock = time.get_clock_info("monotonic").resolution
        state = _http_observation_state(self.host)
        learned = max(0.0, _finite(state.get("adaptive_request_rate"), 0.0))
        mean_latency = max(0.0, _finite(state.get("mean_latency"), 0.0))
        # Cold start is intentionally one request/second. Warm starts restore the last stable
        # host-specific rate; observed latency provides only a remote-behavior-derived ceiling.
        self.rate = max(clock, learned if learned > 0.0 else 1.0)
        self.capacity = max(1.0, min(self.rate, 1.0 + self.rate * max(mean_latency, clock)))
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self.penalty_until = 0.0
        self.successes = max(0, int(_finite(state.get("adaptive_rate_successes"), 0)))
        self.lock = threading.Lock()

    def _remember(self) -> None:
        with _HTTP_OBSERVATION_LOCK:
            state = _http_observation_state(self.host)
            state["adaptive_request_rate"] = float(self.rate)
            state["adaptive_rate_successes"] = int(self.successes)
            snapshot = dict(state)
        # Persist sparsely: after failures and at power-of-two success counts.
        if self.successes == 0 or (self.successes & (self.successes - 1) == 0):
            _persist_http_observation(self.host, snapshot)

    def acquire(self) -> None:
        while True:
            with self.lock:
                now = time.monotonic()
                if now < self.penalty_until:
                    wait = self.penalty_until - now
                else:
                    effective_rate = max(time.get_clock_info("monotonic").resolution, self.rate)
                    self.tokens = min(self.capacity, self.tokens + (now - self.updated) * effective_rate)
                    self.updated = now
                    if self.tokens >= 1.0:
                        self.tokens -= 1.0
                        return
                    wait = (1.0 - self.tokens) / effective_rate
            if _sleep_interruptible(wait):
                raise concurrent.futures.CancelledError("程序正在退出")

    def mark_success(self, elapsed: float = 0.0) -> None:
        remember = False
        with self.lock:
            if time.monotonic() < self.penalty_until:
                return
            self.successes += 1
            # Additive increase becomes progressively smaller, while the latency-derived ceiling
            # prevents a fast workstation from teaching the remote server an arbitrarily high rate.
            latency = max(time.get_clock_info("monotonic").resolution, float(elapsed or 0.0))
            remote_ceiling = max(1.0, 2.0 / latency)
            increment = 1.0 / max(2.0, math.sqrt(float(self.successes) + 1.0))
            self.rate = min(remote_ceiling, self.rate + increment)
            self.capacity = max(1.0, min(self.rate, 1.0 + self.rate * latency))
            self.tokens = min(self.tokens, self.capacity)
            remember = self.successes == 1 or (self.successes & (self.successes - 1) == 0)
        if remember:
            self._remember()

    def penalize(self, seconds: float, *, severe: bool = False) -> None:
        with self.lock:
            divisor = 4.0 if severe else 2.0
            self.rate = max(time.get_clock_info("monotonic").resolution, self.rate / divisor)
            self.capacity = max(1.0, min(self.capacity, self.rate))
            self.tokens = min(self.tokens, self.capacity)
            self.penalty_until = max(self.penalty_until, time.monotonic() + max(0.0, float(seconds)))
            self.successes = 0
        self._remember()


_DOMAIN_BUCKETS: dict[str, _DomainTokenBucket] = {}
_DOMAIN_BUCKETS_LOCK = threading.Lock()


def _domain_bucket(url: str) -> _DomainTokenBucket:
    host = (urllib.parse.urlsplit(url).hostname or "unknown").lower()
    with _DOMAIN_BUCKETS_LOCK:
        bucket = _DOMAIN_BUCKETS.get(host)
        if bucket is None:
            bucket = _DOMAIN_BUCKETS[host] = _DomainTokenBucket(host)
        return bucket


class _PinnedRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, allowed_hosts: set[str] | frozenset[str]):
        super().__init__()
        self.allowed_hosts = {str(host).strip().lower() for host in allowed_hosts if str(host).strip()}

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        host = (parsed.hostname or "").lower()
        if parsed.scheme.lower() != "https" or host not in self.allowed_hosts:
            raise urllib.error.HTTPError(
                req.full_url, code,
                f"已阻止携带受信请求头跳转到白名单外地址：{newurl}", headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class _FirstHttpAttemptStatusError(Exception):
    def __init__(self, code: int, message: str, retry_after: str | None = None, elapsed: float = 0.0):
        super().__init__(message)
        self.code = int(code)
        self.retry_after = retry_after
        self.elapsed = max(0.0, float(elapsed))

def _first_http_attempt_worker(
    url: str, encoded: bytes | None, headers: dict, allowed_hosts: tuple[str, ...],
    socket_timeout: float, total_timeout: float, explicit_limit: int | None,
    stage_path_text: str, disk_reserve_bytes: int, result_queue,
) -> None:
    """Cold HTTP attempt: finite socket/total deadlines and disk staging instead of unbounded RAM growth."""
    started = time.monotonic()
    stage_path = Path(stage_path_text)
    deadline_at = started + max(time.get_clock_info("monotonic").resolution, float(total_timeout))
    try:
        request = urllib.request.Request(url, data=encoded, headers=headers)
        opener = urllib.request.build_opener(_PinnedRedirectHandler(frozenset(allowed_hosts)))
        open_started = time.monotonic()
        response_context = opener.open(request, timeout=max(time.get_clock_info("monotonic").resolution, float(socket_timeout)))
        header_wait = max(0.0, time.monotonic() - open_started)
        with response_context as response:
            try:
                content_length = int(response.headers.get("Content-Length") or 0)
            except (TypeError, ValueError):
                content_length = 0
            if explicit_limit is not None and content_length > int(explicit_limit):
                raise NetworkError(f"网络响应声明大小 {content_length} 字节，超过调用方明确预算 {int(explicit_limit)} 字节")
            if content_length > 0:
                free = int(shutil.disk_usage(stage_path.parent).free)
                if free < max(0, int(disk_reserve_bytes)) + content_length:
                    raise NetworkError("首次网络响应声明大小超过用户所选磁盘当前安全可用空间")
            received = 0
            inactivity = [header_wait]
            with open(stage_path, "wb") as handle:
                while True:
                    if time.monotonic() >= deadline_at:
                        raise TimeoutError("首次 HTTP 总截止时间已到")
                    remaining_limit = None if explicit_limit is None else int(explicit_limit) - received
                    read_size = FILE_IO_CHUNK_BYTES if remaining_limit is None else min(FILE_IO_CHUNK_BYTES, remaining_limit + 1)
                    read_started = time.monotonic()
                    block = response.read(max(1, read_size))
                    inactivity.append(max(0.0, time.monotonic() - read_started))
                    if not block:
                        break
                    if explicit_limit is not None and received + len(block) > int(explicit_limit):
                        raise NetworkError(f"网络响应超过调用方明确预算 {int(explicit_limit)} 字节")
                    free = int(shutil.disk_usage(stage_path.parent).free)
                    if free < max(0, int(disk_reserve_bytes)) + len(block):
                        raise NetworkError("首次未知长度网络响应已触及用户所选磁盘安全余量")
                    handle.write(block)
                    received += len(block)
            result_queue.put((
                "ok-file", received, response.headers.get_content_charset(),
                response.headers.get("Content-Encoding", ""), inactivity,
                max(0.0, time.monotonic() - started),
            ))
    except urllib.error.HTTPError as exc:
        result_queue.put((
            "http-error", int(exc.code), str(exc),
            exc.headers.get("Retry-After") if exc.headers else None,
            max(0.0, time.monotonic() - started),
        ))
    except BaseException as exc:
        try:
            result_queue.put(("error", type(exc).__name__, str(exc), max(0.0, time.monotonic() - started)))
        except Exception:
            pass


def _cancellable_first_http_attempt(
    url: str, encoded: bytes | None, headers: dict, allowed_hosts: frozenset[str],
    socket_timeout: float, total_timeout: float, explicit_limit: int | None, memory_limit: int,
) -> tuple[bytes, str | None, str, list[float], float, int]:
    """Run the cold attempt in a killable process; stage bytes on selected-disk before exact-size RAM admission."""
    _require_runtime_folder()
    generation = _current_http_generation()
    context = mp.get_context("spawn")
    result_queue = context.Queue(maxsize=1)
    stage_dir = _ensure_isolated_app_dir(RUNTIME_TMP_DIR)
    descriptor, stage_name = tempfile.mkstemp(prefix="http-first-", suffix=".response", dir=str(stage_dir))
    os.close(descriptor)
    stage_path = _assert_isolated_app_path(Path(stage_name))
    disk_reserve = _objective_low_disk_reserve_bytes()
    process = context.Process(
        target=_first_http_attempt_worker,
        args=(
            url, encoded, dict(headers), tuple(sorted(allowed_hosts)), float(socket_timeout), float(total_timeout),
            None if explicit_limit is None else int(explicit_limit), str(stage_path), int(disk_reserve), result_queue,
        ),
        name="best-alipay-funds-http-first-sample", daemon=True,
    )
    started = time.monotonic()
    deadline_at = started + max(time.get_clock_info("monotonic").resolution, float(total_timeout))
    process.start()
    poll_base = max(time.get_clock_info("monotonic").resolution, sys.getswitchinterval())
    reserved = 0
    try:
        while True:
            if _cancel_requested() or generation != _current_http_generation():
                if process.is_alive():
                    process.terminate()
                process.join(timeout=poll_base)
                if _cancel_requested():
                    raise concurrent.futures.CancelledError("程序正在退出")
                raise concurrent.futures.CancelledError("网络刷新代际已更新；终止旧一代首次采样")
            remaining = deadline_at - time.monotonic()
            if remaining <= 0:
                if process.is_alive():
                    process.terminate()
                process.join(timeout=poll_base)
                raise TimeoutError(f"首次网络采样超过客观总截止时间 {_human_seconds(total_timeout)}")
            try:
                message = result_queue.get(timeout=min(poll_base, remaining))
                break
            except queue.Empty:
                if not process.is_alive():
                    try:
                        message = result_queue.get_nowait()
                        break
                    except queue.Empty:
                        raise NetworkError(f"首次网络采样进程异常退出，exitcode={process.exitcode}")
        process.join(timeout=poll_base)
        kind = message[0] if isinstance(message, tuple) and message else "error"
        if kind == "ok-file":
            response_bytes = max(0, int(message[1]))
            actual_size = int(stage_path.stat().st_size)
            if actual_size != response_bytes:
                raise NetworkError(f"首次网络响应临时文件大小不一致：{actual_size}/{response_bytes}")
            if actual_size > max(1, int(memory_limit)):
                raise NetworkError(
                    f"首次网络响应已安全落盘，但其实际大小 {actual_size} 字节超过当前可用内存准入 {int(memory_limit)} 字节"
                )
            _HTTP_MEMORY_BUDGET.reserve(actual_size)
            reserved = actual_size
            raw = stage_path.read_bytes()
            if len(raw) != actual_size:
                raise NetworkError("首次网络响应落盘后读取不完整")
            return raw, message[2], str(message[3] or ""), list(message[4] or []), float(message[5]), reserved
        if kind == "http-error":
            raise _FirstHttpAttemptStatusError(message[1], message[2], message[3], message[4])
        if kind == "error":
            raise NetworkError(f"{message[1]}: {message[2]}")
        raise NetworkError("首次网络采样返回非法结果")
    except BaseException:
        if reserved:
            _HTTP_MEMORY_BUDGET.release(reserved)
        raise
    finally:
        if process.is_alive():
            process.terminate()
            process.join(timeout=poll_base)
        try:
            result_queue.close()
        except Exception:
            pass
        try:
            stage_path.unlink(missing_ok=True)
        except OSError:
            pass


# ===== HTTP / 限流 =====

def _http_text(
    url: str,
    *,
    data: dict | None = None,
    referer: str = "https://fund.eastmoney.com/",
    timeout: float | None = None,
    attempts: int | None = None,
    xhr: bool = False,
    accept: str | None = None,
    headers_extra: dict | None = None,
    allowed_redirect_hosts: set[str] | frozenset[str] | None = None,
    max_response_bytes: int | None = None,
) -> str:
    host_state = dict(_http_observation_state(_http_observation_key(url)))
    cold_transport = max(0, int(host_state.get("success_count") or 0)) <= 0
    if timeout is None or float(timeout) <= 0:
        timeout = _adaptive_http_timeout(url)
    else:
        timeout = max(time.get_clock_info("monotonic").resolution, float(timeout))
    total_timeout = max(timeout, _adaptive_http_total_timeout(url))
    attempts = max(1, int(attempts if attempts is not None else LATEST_ATTEMPTS))
    parsed_url = urllib.parse.urlsplit(url)
    initial_host = (parsed_url.hostname or "").lower()
    if parsed_url.scheme.lower() != "https" or not initial_host:
        raise NetworkError(f"金融数据源必须使用有效 HTTPS 地址：{url}")
    if allowed_redirect_hosts is None:
        if initial_host in EASTMONEY_REDIRECT_HOSTS:
            allowed_redirect_hosts = EASTMONEY_REDIRECT_HOSTS
        elif initial_host in SINA_REDIRECT_HOSTS:
            allowed_redirect_hosts = SINA_REDIRECT_HOSTS
        else:
            allowed_redirect_hosts = frozenset({initial_host})
    else:
        allowed_redirect_hosts = frozenset(str(host).strip().lower() for host in allowed_redirect_hosts if str(host).strip())
        if initial_host not in allowed_redirect_hosts:
            raise NetworkError(f"金融数据源初始域名 {initial_host} 不在固定白名单")
    encoded = None
    if data is not None:
        encoded = urllib.parse.urlencode(data).encode("utf-8")
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": accept or "*/*",
        "Accept-Encoding": "gzip",
        "Referer": referer,
        "Cache-Control": "no-cache",
    }
    if xhr:
        headers["X-Requested-With"] = "XMLHttpRequest"
    if encoded is not None:
        headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    if headers_extra:
        headers.update({str(k): str(v) for k, v in headers_extra.items() if v is not None})
    last_error = None
    bucket = _domain_bucket(url)
    for attempt in range(attempts):
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        try:
            bucket.acquire()
            started_request = time.monotonic()
            request = urllib.request.Request(url, data=encoded, headers=headers)
            opener = urllib.request.build_opener(_PinnedRedirectHandler(allowed_redirect_hosts))
            fair_share = _HTTP_MEMORY_BUDGET.begin()
            reserved = 0
            adaptive_limit = _adaptive_http_response_limit(url, fair_share)
            explicit_limit = max(1, int(max_response_bytes)) if max_response_bytes is not None else None
            if adaptive_limit is None:
                request_limit = explicit_limit
            elif explicit_limit is None:
                request_limit = adaptive_limit
            else:
                request_limit = min(adaptive_limit, explicit_limit)
            try:
                inactivity_samples: list[float] = []
                if cold_transport:
                    raw, charset, content_encoding, inactivity_samples, elapsed, raw_reserved = _cancellable_first_http_attempt(
                        url, encoded, headers, frozenset(allowed_redirect_hosts), timeout, total_timeout, request_limit, fair_share,
                    )
                    reserved += raw_reserved
                else:
                    warm_limit = max(1, int(request_limit if request_limit is not None else fair_share))
                    open_started = time.monotonic()
                    response_context = opener.open(request, timeout=timeout)
                    inactivity_samples.append(max(0.0, time.monotonic() - open_started))
                    with response_context as response:
                        raw, raw_reserved, read_samples = _read_response_limited(
                            response, warm_limit, deadline_at=started_request + total_timeout,
                        )
                        reserved += raw_reserved
                        inactivity_samples.extend(read_samples)
                        charset = response.headers.get_content_charset()
                        content_encoding = response.headers.get("Content-Encoding", "")
                    elapsed = max(0.0, time.monotonic() - started_request)
                decode_limit = max(1, int(request_limit if request_limit is not None else fair_share))
                if str(content_encoding or "").lower() == "gzip":
                    decoded, decoded_reserved = _safe_gzip_decompress(raw, decode_limit)
                    reserved += decoded_reserved
                    raw = decoded
                text = _decode_response(raw, charset)
                _record_http_success(url, elapsed, len(raw), inactivity_samples)
                bucket.mark_success(elapsed)
                return text
            finally:
                _HTTP_MEMORY_BUDGET.end(reserved)
        except _FirstHttpAttemptStatusError as exc:
            last_error = exc
            failure_elapsed = exc.elapsed or max(0.0, time.monotonic() - started_request)
            _record_http_failure(url, failure_elapsed)
            server_retry = _retry_after_seconds(exc.retry_after)
            _record_server_retry_after(server_retry)
            delay = _adaptive_http_retry_delay(url, server_retry)
            if exc.code in RETRYABLE_HTTP_STATUS_CODES:
                bucket.penalize(delay, severe=exc.code in {403, 429})
            if attempt + 1 < attempts and _sleep_interruptible(delay):
                raise concurrent.futures.CancelledError("程序正在退出")
        except urllib.error.HTTPError as exc:
            last_error = exc
            _record_http_failure(url, max(0.0, time.monotonic() - started_request))
            retry_after = exc.headers.get("Retry-After") if exc.headers else None
            server_retry = _retry_after_seconds(retry_after)
            _record_server_retry_after(server_retry)
            delay = _adaptive_http_retry_delay(url, server_retry)
            if exc.code in RETRYABLE_HTTP_STATUS_CODES:
                bucket.penalize(delay, severe=exc.code in {403, 429})
            if attempt + 1 < attempts and _sleep_interruptible(delay):
                raise concurrent.futures.CancelledError("程序正在退出")
        except (OSError, urllib.error.URLError, TimeoutError, NetworkError) as exc:
            last_error = exc
            _record_http_failure(url, max(0.0, time.monotonic() - started_request))
            delay = _adaptive_http_retry_delay(url)
            bucket.penalize(delay)
            if attempt + 1 < attempts and _sleep_interruptible(delay):
                raise concurrent.futures.CancelledError("程序正在退出")
    raise NetworkError(f"网络请求失败：{last_error}")


def _http_json(url: str, **kwargs):
    kwargs.setdefault("xhr", True)
    kwargs.setdefault("accept", "application/json,text/plain,*/*")
    text = _http_text(url, **kwargs)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        decoder = json.JSONDecoder()
        for match in re.finditer(r"\{", text):
            try:
                payload, _end = decoder.raw_decode(text[match.start():])
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                return payload
        raise ParseError(f"数据格式无法识别：{exc}") from exc


def _wrapper_type(value: str) -> str:
    text = (value or "").upper()
    if "QDII" in text or "海外" in text:
        return "QDII"
    if "FOF" in text or "基金中基金" in text:
        return "FOF"
    return "普通"


def _coarse_type(value: str) -> str:
    text = value or "其他"
    if "债" in text:
        return "债券"
    if "指数" in text or "ETF" in text.upper():
        return "指数"
    if "股票" in text:
        return "股票"
    if "混合" in text:
        return "混合"
    if _wrapper_type(text) == "FOF":
        return "混合"
    if _wrapper_type(text) == "QDII":
        return "指数" if "指数" in text else "股票"
    return "其他"


def _base_name(name: str) -> str:
    value = re.sub(r"[（(](人民币|前端|后端|场外)[）)]", "", name or "")
    value = re.sub(r"(?:ETF)?联接基金?(?:[A-IY](?:类)?(?:份额)?)?$", "联接", value, flags=re.I)
    value = re.sub(r"(?:人民币)?[A-IY](?:类)?(?:份额)?$", "", value, flags=re.I)
    value = re.sub(r"[\s·\-_（）()]", "", value)
    return value


def _share_preference(name: str) -> int:
    compact = re.sub(r"\s+", "", (name or "").strip().upper())
    suffix = r"(?:类)?(?:份额)?$"
    # Only ordering matters to callers. Derive the ordinal from the declared preference order
    # instead of embedding arbitrary score magnitudes.
    preference_order = ("other_share_class", "preferred_or_unlabeled", "class_a")
    if re.search(r"A" + suffix, compact):
        group = "class_a"
    elif re.search(r"C" + suffix, compact):
        group = "preferred_or_unlabeled"
    elif re.search(r"[B-IY]" + suffix, compact):
        group = "other_share_class"
    else:
        group = "preferred_or_unlabeled"
    return preference_order.index(group)


def _theme(name: str) -> str:
    groups = {
        "医药医疗": ("医药", "医疗", "生物", "创新药"),
        "科技半导体": ("科技", "半导体", "芯片", "软件", "计算机", "人工智能", "机器人"),
        "新能源": ("新能源", "光伏", "电池", "汽车"),
        "消费": ("消费", "白酒", "食品", "家电"),
        "周期资源": ("煤炭", "有色", "钢铁", "资源", "化工", "黄金"),
        "军工": ("军工", "国防", "航天"),
        "金融地产": ("金融", "银行", "证券", "地产"),
        "海外": ("全球", "海外", "美国", "纳斯达克", "标普", "港股", "恒生"),
    }
    for label, words in groups.items():
        if any(word in (name or "") for word in words):
            return label
    return "宽基/全市场"


def _candidate_allowed(name: str) -> bool:
    """Catalog-stage eligibility is structural only; comparability/data/purchase gates act later."""
    return bool(str(name or "").strip())


def _parse_purchase_status(status_text: str, termination_date: str = "") -> str:
    """Classify the purchase side only; never treat a generic “开放” or redemption state as purchasable."""
    text = re.sub(r"\s+", "", str(status_text or ""))
    if termination_date or any(word in text for word in ("基金清盘", "清盘", "终止运作", "基金终止")):
        return "closed"
    # Large-purchase limits contain “暂停申购” in common source wording, so check them first.
    if any(word in text for word in ("暂停大额申购", "限制大额申购", "大额申购上限", "限购")):
        return "limited_purchasable"
    if any(word in text for word in ("暂停申购", "终止申购")):
        return "purchase_suspended"
    if any(word in text for word in ("封闭期", "暂停交易")):
        return "closed"
    if any(word in text for word in ("开放申购", "正常申购", "可申购", "申购开放")):
        return "public_open"
    if "暂停赎回" in text:
        return "redemption_suspended"
    return "unknown"


def _redemption_state(status_text: str) -> str:
    text = re.sub(r"\s+", "", str(status_text or ""))
    if any(word in text for word in ("暂停赎回", "终止赎回")):
        return "suspended"
    if any(word in text for word in ("开放赎回", "正常赎回", "可赎回", "赎回开放")):
        return "open"
    return "unknown"


def _public_availability_signals(item: dict) -> set[str]:
    signals = {str(value) for value in (item.get("availability_public_signals") or []) if str(value)}
    # Recompute purchase/latest confirmation signals from current evidence so legacy cached
    # generalized “开放” or source-count-only confirmations cannot survive a refresh.
    signals.difference_update({"public-purchase-open", "public-purchase-limited", "multi-source-latest-nav"})
    purchase_text = " ".join(filter(None, (
        str(item.get("public_purchase_status") or ""),
        str(item.get("public_purchase_status_secondary") or ""),
    )))
    purchase_state = _parse_purchase_status(
        purchase_text,
        str(item.get("termination_date") or ""),
    )
    if purchase_state == "public_open":
        signals.add("public-purchase-open")
    elif purchase_state == "limited_purchasable":
        signals.add("public-purchase-limited")
    catalog_sources = {str(value) for value in (item.get("catalog_sources") or []) if str(value)}
    if len(catalog_sources) >= PUBLIC_SOURCE_COUNT or int(_finite(item.get("public_catalog_confirmations"), 0)) >= PUBLIC_SOURCE_COUNT:
        signals.add("multi-public-catalog")
    # Two sources returning rows is only source coverage. Cross-source confirmation is earned only
    # when the same NAV date and a tight NAV tolerance have already been verified.
    if item.get("latest_cross_source_verified") is True:
        signals.add("multi-source-latest-nav")
    latest_text = str(item.get("latest_date") or item.get("display_nav_date") or "")[:DATE_TEXT_LENGTH]
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", latest_text):
        try:
            if _observed_market_sessions_for_item(_dt.date.fromisoformat(latest_text), _china_today(), item) <= MAX_OBSERVED_SESSION_GAP:
                signals.add("observed-nav-activity")
        except ValueError:
            pass
    return signals


def _valuation_entry_signal(item: dict) -> float:
    """Current-entry signal from public valuation percentiles; no signal means neutral zero."""
    if _asset_bucket(item.get("name", ""), item.get("type", "")) not in {"指数", "QDII/海外"}:
        return 0.0
    features = item.get("product_features") if isinstance(item.get("product_features"), dict) else {}
    values = []
    for key in ("pe_percentile", "pb_percentile"):
        value = _finite(features.get(key), float("nan"))
        if math.isfinite(value):
            values.append(1.0 - 2.0 * _clamp(value, 0.0, 1.0))
    for key in ("dividend_yield_percentile", "equity_risk_premium_percentile"):
        value = _finite(features.get(key), float("nan"))
        if math.isfinite(value):
            values.append(2.0 * _clamp(value, 0.0, 1.0) - 1.0)
    return _clamp(statistics.fmean(values), -1.0, 1.0) if values else 0.0


def _product_integrity_score(item: dict) -> float:
    """Equal-weight completeness percentage across observable public product fields."""
    checks = (
        item.get("fees_verified") is True,
        bool(str(item.get("fund_company") or "").strip()),
        bool(str(item.get("benchmark") or item.get("index_code") or "").strip()),
        bool(item.get("product_features")),
        bool(str(item.get("fund_manager") or "").strip()),
        bool(str(item.get("metadata_checked_at") or "").strip()),
    )
    return PERCENT_SCALE * statistics.fmean(1.0 if value else 0.0 for value in checks)


def _model_evidence_factor(model: dict, item: dict) -> tuple[float, dict]:
    """Confidence is the geometric mean of directly observed evidence dimensions."""
    universe_cov = _clamp(_finite(model.get("historical_universe_known_coverage"), 0.0), 0.0, 1.0)
    availability_cov = _clamp(_finite(model.get("historical_availability_coverage"), 0.0), 0.0, 1.0)
    metrics = model.get("full_pipeline_oos") or model.get("untouched_test_oos") or model.get("validation_metrics") or {}
    windows = max(0, int(_finite(metrics.get("windows"), 0)))
    windows_factor = 1.0 if windows > 0 else 0.0
    dispersion = abs(_finite(metrics.get("rank_ic_std"), float("nan")))
    if not math.isfinite(dispersion):
        median = _finite(metrics.get("rank_ic_median"), 0.0)
        lower = _finite(metrics.get("rank_ic_p25"), median)
        dispersion = abs(median - lower)
    dispersion_factor = 1.0 / (1.0 + dispersion)
    # Current NAV freshness is deliberately excluded here.  It is a formal-output gate backed by
    # OfficialChinaMarketCalendar, not a candidate-set/model-confidence feature inferred from providers.
    # Coverage completeness is reported separately and is not an arbitrary numeric confidence weight.
    # Per-row point-in-time purchase eligibility still participates in historical OOS admission/selection.
    factors = (universe_cov, windows_factor, dispersion_factor)
    # Geometric mean makes any missing evidence materially lower confidence without author weights.
    factor = math.prod(max(sys.float_info.min, value) for value in factors) ** (1.0 / len(factors))
    if any(value <= 0.0 for value in factors):
        factor = 0.0
    details = {
        "historical_universe_known_coverage": universe_cov,
        "historical_availability_coverage": availability_cov,
        "oos_windows": windows,
        "rank_ic_dispersion": dispersion,
        "current_nav_freshness_basis": "formal-independent-calendar-gate",
        "factor": factor,
    }
    return factor, details


# ===== 公开基金元数据兼容逻辑 =====



# ===== 数据源适配器 =====

class _FundHTMLStructure(HTMLParser):
    """Structure-aware extractor for public fund pages; no character-distance windows."""
    BLOCK_TAGS = frozenset(("p", "div", "li", "dt", "dd", "section", "article", "h1", "h2", "h3", "h4", "h5", "h6", "caption"))
    CELL_TAGS = frozenset(("td", "th"))

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self.blocks: list[str] = []
        self.events: list[tuple[str, object]] = []
        self._row: list[str] | None = None
        self._cell_parts: list[str] | None = None
        self._block_parts: list[str] = []
        self._skip_depth = 0

    @staticmethod
    def _clean(parts) -> str:
        return re.sub(r"\s+", " ", html.unescape(" ".join(str(part) for part in parts if str(part).strip()))).strip()

    def _flush_block(self) -> None:
        value = self._clean(self._block_parts)
        self._block_parts.clear()
        if value and (not self.blocks or self.blocks[-1] != value):
            self.blocks.append(value)
            self.events.append(("block", value))

    def handle_starttag(self, tag, attrs):
        tag = str(tag).lower()
        if tag in ("script", "style"):
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag == "tr":
            self._row = []
        elif tag in self.CELL_TAGS:
            self._cell_parts = []

    def handle_endtag(self, tag):
        tag = str(tag).lower()
        if tag in ("script", "style"):
            if self._skip_depth:
                self._skip_depth -= 1
            return
        if self._skip_depth:
            return
        if tag in self.CELL_TAGS and self._cell_parts is not None:
            value = self._clean(self._cell_parts)
            if self._row is not None:
                self._row.append(value)
            self._cell_parts = None
        elif tag == "tr" and self._row is not None:
            row = list(self._row)
            self._row = None
            if any(row):
                self.rows.append(row)
                self.events.append(("row", row))
        if tag in self.BLOCK_TAGS:
            self._flush_block()

    def handle_data(self, data):
        if self._skip_depth:
            return
        text = str(data or "").strip()
        if not text:
            return
        self._block_parts.append(text)
        if self._cell_parts is not None:
            self._cell_parts.append(text)

    def close(self):
        super().close()
        self._flush_block()

    @classmethod
    def parse(cls, text: str) -> "_FundHTMLStructure":
        parser = cls()
        parser.feed(text or "")
        parser.close()
        return parser

    def value(self, *labels: str) -> str:
        wanted = tuple(str(label).strip() for label in labels if str(label).strip())
        for row in self.rows:
            for index, cell in enumerate(row):
                if cell in wanted and index + 1 < len(row) and row[index + 1]:
                    return row[index + 1]
        for index, block in enumerate(self.blocks):
            for label in wanted:
                if block == label and index + 1 < len(self.blocks):
                    return self.blocks[index + 1]
                if block.startswith(label):
                    suffix = block[len(label):].lstrip(" ：:")
                    if suffix:
                        return suffix
        return ""

    def section_rows(self, label: str) -> list[str]:
        active = False
        rows: list[str] = []
        for kind, value in self.events:
            if kind == "block":
                block = str(value)
                if label in block:
                    active = True
                    continue
                if active and "费率" in block and label not in block:
                    break
            elif kind == "row" and active:
                row_text = self._clean(value if isinstance(value, list) else [value])
                if row_text:
                    rows.append(row_text)
        return rows

    def blocks_matching(self, *needles: str) -> list[str]:
        wanted = tuple(str(value) for value in needles if str(value))
        return [block for block in self.blocks if all(value in block for value in wanted)]


class EastMoneySource:
    LIST_URL = "https://fund.eastmoney.com/js/fundcode_search.js"
    HISTORY_URL = "https://api.fund.eastmoney.com/f10/lsjz"
    PING_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
    MOBILE_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"
    SINA_VERIFY_URL = "https://money.finance.sina.com.cn/fund/go.php/vAkFundInfo_JJGLR/q/{code}.phtml"
    BASIC_URL = "https://fundf10.eastmoney.com/jbgk_{code}.html"
    FEE_URL = "https://fundf10.eastmoney.com/jjfl_{code}.html"

    def all_funds(self) -> list[dict]:
        text = _http_text(self.LIST_URL)
        start, end = text.find("["), text.rfind("]")
        if start < 0 or end <= start:
            raise ContractError("基金清单接口返回异常")
        try:
            rows = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise ParseError("基金清单解析失败") from exc
        funds = []
        for row in rows:
            if not isinstance(row, list) or len(row) < 4 or not _valid_fund_code(row[0]):
                continue
            funds.append({"code": str(row[0]), "name": str(row[2]), "type": str(row[3])})
        return funds

    def public_fallback_universe(self, limit: int | None = None) -> dict[str, dict]:
                                                                                            
                                                                                                   
        chosen = sorted(
            (row for row in self.all_funds() if _candidate_allowed(row.get("name", ""))),
            key=lambda row: int(row.get("code") or int("9" * FUND_CODE_DIGITS)),
        )
        observed = _now_iso()
        output = {}
        for row in chosen:
            code = row["code"]
            output[code] = {
                **row,
                "availability_status": "unknown",
                "availability_generated_at": observed,
                "availability_source": "东方财富基金公开基金清单",
                "availability_source_id": "eastmoney-public-fallback",
                "availability_evidence": "公开基金目录存在性信息",
                "availability_note": "公开基金目录与状态元数据，仅用于数据完整性记录",
                "fund_data_source": "东方财富基金公开基金清单/历史净值",
                "fees_verified": False, "fees": {}, "fees_history": [],
                "available_from": "", "available_to": "", "availability_history": [],
                "share_class": "", "product_features": {}, "product_features_history": [],
                "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
                **_holding_costs({}),
            }
        if len(output) < DISPLAY_TOP_N:
            raise DataError(f"公开基金候选池仅 {len(output)} 个，无法进行长期分析")
        return output

    @staticmethod
    def structural_prefilter(availability: dict[str, dict], limit: int | None = None) -> dict[str, dict]:
        rows = []
        for code, row in availability.items():
            name = str(row.get("name") or "")
            fund_type = str(row.get("type") or "")
            if not _candidate_allowed(name):
                continue
            if row.get("termination_date"):
                continue
            rows.append((code, row))
        rows.sort(key=lambda pair: pair[0])
        if limit is not None:
            rows = rows[:max(0, int(limit))]
        return dict(rows)

    @staticmethod
    def _strip_html(value: str) -> str:
        value = re.sub(r"<script[\s\S]*?</script>|<style[\s\S]*?</style>", " ", value or "", flags=re.I)
        value = re.sub(r"<[^>]+>", " ", value)
        return re.sub(r"\s+", " ", html.unescape(value)).strip()

    @classmethod
    def _parse_basic_metadata(cls, text: str) -> dict:
        document = _FundHTMLStructure.parse(text or "")
        cell = document.value

        company = cell("基金管理人", "管理人")
        benchmark = cell("业绩比较基准")
        tracking = cell("跟踪标的", "标的指数")
        inception_raw = cell("成立日期/规模", "成立日期")
        termination_raw = cell("终止日期", "清盘日期")
        size_raw = cell("基金规模") or inception_raw
        purchase_status = cell("申购状态", "申购赎回状态")
        tracking_error_raw = cell("跟踪误差", "年化跟踪误差")
        manager_raw = cell("基金经理", "现任基金经理")
        manager_tenure_raw = cell("任职时间", "任职年限")
        objective = cell("投资目标", "投资方向")
        inception_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", inception_raw)
        termination_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", termination_raw)

        def normalized_date(match) -> str:
            if not match:
                return ""
            value = match.group(0).replace("年", "-").replace("月", "-").replace("日", "")
            try:
                return _dt.date.fromisoformat("-".join(f"{int(x):02d}" if i else x for i, x in enumerate(value.split("-")))).isoformat()
            except ValueError:
                return ""

        no_tracking = any(word in tracking for word in ("无跟踪标的", "不适用", "--", "暂无"))
        index_code = "" if no_tracking else tracking
        public_theme = _theme(" ".join(value for value in (tracking, objective) if value))
        if public_theme == "宽基/全市场":
            public_theme = ""
        size_match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*亿元", size_raw)
        te_match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*%", tracking_error_raw)
        product_features = {}
        if size_match:
            product_features["fund_size_billion"] = float(size_match.group(1))
        if te_match:
            product_features["tracking_error_annual"] = _rate(float(te_match.group(1)) / PERCENT_SCALE)

        evidence_blocks = [manager_tenure_raw, manager_raw, objective, *document.blocks]
        for block in evidence_blocks:
            if not block or not any(label in block for label in ("任职时间", "任职年限", "任职以来")):
                continue
            tenure_match = re.search(r"(?:任职时间|任职年限|任职以来)[^0-9]*([0-9]+(?:\.[0-9]+)?)\s*年", block)
            if tenure_match:
                product_features["manager_tenure_years"] = max(0.0, float(tenure_match.group(1)))
                break

        manager_names = []
        for value in re.findall(r"[\u4e00-\u9fa5·]+", manager_raw):
            if value and value not in manager_names:
                manager_names.append(value)
        if manager_raw:
            product_features["manager_name"] = manager_raw
        if manager_names:
            product_features["manager_count_current"] = len(manager_names)
        if public_theme:
            product_features["style_label"] = public_theme

        valuation_labels = {
            "pe_percentile": ("PE", "市盈率"),
            "pb_percentile": ("PB", "市净率"),
            "dividend_yield_percentile": ("股息率", "股息"),
            "equity_risk_premium_percentile": ("风险溢价", "ERP"),
        }
        for key, labels in valuation_labels.items():
            for block in document.blocks:
                if "百分位" not in block or not any(label.lower() in block.lower() for label in labels):
                    continue
                match = re.search(r"百分位[^0-9]*([0-9]+(?:\.[0-9]+)?)\s*%", block, flags=re.I)
                if match:
                    product_features[key] = _clamp(float(match.group(1)) / PERCENT_SCALE, 0.0, 1.0)
                    break

        for block in [objective, *document.blocks]:
            if not block or not any(word in block for word in ("股票", "权益")):
                continue
            if not any(word in block for word in ("占基金资产", "仓位", "比例")):
                continue
            equity_match = re.search(r"(?:占基金资产|仓位|比例)[^0-9%]*([0-9]+(?:\.[0-9]+)?)\s*%", block)
            if equity_match:
                product_features["equity_exposure"] = _clamp(float(equity_match.group(1)) / PERCENT_SCALE, 0.0, 1.0)
                break
        return {
            "fund_company": company,
            "benchmark": benchmark,
            "index_code": index_code,
            "theme": public_theme,
            "inception_date": normalized_date(inception_match),
            "termination_date": normalized_date(termination_match),
            "public_purchase_status": purchase_status,
            "fund_manager": manager_raw,
            "product_features": product_features,
            "metadata_source": "东方财富基金档案公开结构化页面",
            "metadata_checked_at": _now_iso(),
        }

    @classmethod
    def _parse_fee_schedule(cls, text: str) -> dict:
        document = _FundHTMLStructure.parse(text or "")

        def labelled_rate(label: str) -> float | None:
            candidates = [document.value(label), *document.blocks_matching(label)]
            for value in candidates:
                if not value:
                    continue
                match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*%", value)
                if match:
                    return _rate(float(match.group(1)) / PERCENT_SCALE)
                if any(word in value for word in ("不收取", "免收", "免费")):
                    return 0.0
            return None

        purchase = None
        purchase_channel_estimate = None
        purchase_rows = document.section_rows("申购费率")
        if not purchase_rows:
            purchase_rows = [" ".join(row) for row in document.rows if any("申购" in cell for cell in row)]
        for row_text in purchase_rows:
            rates = [float(value) / PERCENT_SCALE for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if rates and any(word in row_text for word in ("小于", "以下", "万元", "申购")):
                purchase = max(rates)
                purchase_channel_estimate = min(rates)
                break
        if purchase is None:
            for value in [document.value("申购费率"), *document.blocks_matching("申购费率")]:
                if value and any(word in value for word in ("不收取", "免收", "免费", "0%", "0.0%")):
                    purchase = 0.0
                    purchase_channel_estimate = 0.0
                    break

        def duration_bounds(row_text: str) -> tuple[float, float]:
            lower, upper = 0.0, float("inf")
            units = {"天":1.0, "日":1.0, "月":AVERAGE_GREGORIAN_DAYS_PER_MONTH, "年":AVERAGE_GREGORIAN_DAYS_PER_YEAR}
            for pattern, kind in (
                (r"(?:大于等于|不少于|≥)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "lower"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:及|或)?以上", "lower"),
                (r"(?:小于|少于|<)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "upper"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:以内|以下)", "upper"),
            ):
                for value, unit in re.findall(pattern, row_text):
                    days = float(value) * units[unit]
                    if kind == "lower":
                        lower = max(lower, days)
                    else:
                        upper = min(upper, days)
            return lower, upper

        redemption_rows = []
        section_rows = document.section_rows("赎回费率")
        if not section_rows:
            section_rows = [" ".join(row) for row in document.rows if any("赎回" in cell for cell in row)]
        for row_text in section_rows:
            rates = [float(value) / PERCENT_SCALE for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if not rates and any(word in row_text for word in ("不收取", "免收")):
                rates = [0.0]
            if not rates or not any(unit in row_text for unit in ("天", "日", "月", "年", "以上", "以下")):
                continue
            lower, upper = duration_bounds(row_text)
            redemption_rows.append((lower, upper, min(rates)))

        fees = {
            "purchase_fee": purchase,
            "purchase_fee_standard": purchase,
            "purchase_fee_channel_estimate": purchase_channel_estimate,
            "management_fee_annual": labelled_rate("管理费率"),
            "custody_fee_annual": labelled_rate("托管费率"),
            "sales_service_fee_annual": labelled_rate("销售服务费率"),
            "redemption_schedule": [
                {"lower_days": lower, "upper_days": upper, "rate": rate}
                for lower, upper, rate in redemption_rows
            ],
        }
        required = (
            "purchase_fee", "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
        )
        verified_fields = {key: fees.get(key) is not None for key in required}
        verified_fields["redemption_schedule"] = bool(redemption_rows)
        complete = all(verified_fields.values())
        normalized = {
            key: (
                [{"lower_days": _finite(row.get("lower_days")), "upper_days": _finite(row.get("upper_days"), float("inf")), "rate": _rate(row.get("rate"))} for row in value]
                if key == "redemption_schedule" and isinstance(value, list)
                else (None if value is None else _rate(value))
            )
            for key, value in fees.items()
        }
        return {
            "fees": normalized,
            "fees_verified": complete,
            "fee_schedule_complete": complete,
            "fee_field_verified": verified_fields,
            "fees_source": "东方财富公开费率表",
            **_holding_costs(normalized if complete else None),
        }


    def basic_metadata(self, code: str) -> dict:
        text = _http_text(
            self.BASIC_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
        )
        result = self._parse_basic_metadata(text)
        try:
            fee_text = _http_text(
                self.FEE_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
            )
            result.update(self._parse_fee_schedule(fee_text))
        except DataError:
            pass
        return result

    def metadata_many(self, funds: list[dict]) -> dict[str, dict]:
        targets = [fund for fund in funds if _valid_fund_code(fund.get("code"))]
        output = {}
        if not targets:
            return output
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", len(targets)), thread_name_prefix="fund-meta") as pool:
            future_map = {pool.submit(self.basic_metadata, str(fund["code"])): str(fund["code"]) for fund in targets}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    output[code] = future.result()
                except (DataError, OSError, TimeoutError, ValueError, RuntimeError):
                    output[code] = {"metadata_source": "公开基金档案暂不可用", "metadata_checked_at": _now_iso()}
        return output


    @staticmethod
    def _history_rows(payload) -> tuple[list[dict], int]:
        if not isinstance(payload, dict):
            return [], 0

        data = payload.get("Data")
        if isinstance(data, dict):
            rows = data.get("LSJZList")
            if not isinstance(rows, list):
                rows = []
            total_raw = payload.get(
                "TotalCount",
                data.get("TotalCount", len(rows)),
            )
        else:
            rows = payload.get("Datas")
            if not isinstance(rows, list):
                rows = []
            total_raw = payload.get("TotalCount", len(rows))

        try:
            total = max(0, int(float(total_raw)))
        except (TypeError, ValueError):
            total = len(rows)
        return rows, total

    @staticmethod
    def _history_row_date(row: dict) -> str:
        return str((row or {}).get("FSRQ") or (row or {}).get("PDATE") or "")[:DATE_TEXT_LENGTH]

    def _mobile_history_pages(self, code: str, start: _dt.date) -> list[dict]:
        """Fetch mobile history page-by-page until the requested horizon or TotalCount is exhausted."""
        collected: dict[str, dict] = {}
        total_hint = None
        observed_page_width = None
        start_text = start.isoformat()
        page = 1
        while not _cancel_requested():
            before = len(collected)
            params = {
                "FCODE": code, "pageIndex": page, "plat": "Android",
                "appType": "ttjj", "product": "EFund", "version": "6.2.4",
                "deviceid": "best-alipay-funds-local",
            }
            payload = _http_json(f"{self.MOBILE_BASE}/FundMNHisNetList?" + urllib.parse.urlencode(params), attempts=1)
            if not isinstance(payload, dict) or not (isinstance(payload.get("Datas"), list) or isinstance(payload.get("Data"), dict)):
                raise ContractError(f"{code} 东方财富移动历史 payload 契约异常")
            rows, total = self._history_rows(payload)
            if total > 0:
                total_hint = max(int(total_hint or 0), int(total))
            if not rows:
                break
            if observed_page_width is None:
                observed_page_width = len(rows)
            valid_page_dates = []
            for index, row in enumerate(rows):
                if not isinstance(row, dict):
                    continue
                day = self._history_row_date(row)
                if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                    collected[day] = row
                    valid_page_dates.append(day)
                else:
                    collected[f"page:{page}:row:{index}"] = row
            if valid_page_dates and min(valid_page_dates) <= start_text:
                break
            valid_count = sum(
                1 for key in collected
                if not key.startswith("page:")
            )
            if total_hint and valid_count >= total_hint:
                break
            if observed_page_width and len(rows) < observed_page_width and not total_hint:
                break
            if len(collected) == before:
                break
            page += 1
        return [row for key, row in collected.items() if not key.startswith("page:") or isinstance(row, dict)]

    def _web_history_pages(self, code: str, start: _dt.date, end: _dt.date) -> list[dict]:
        """Fetch EastMoney f10 history without assuming one huge page is accepted forever."""
        collected: dict[str, dict] = {}
        total_hint = None
        observed_page_width = None
        page = 1
        while not _cancel_requested():
            params = {
                "fundCode": code, "pageIndex": page,
                "startDate": start.isoformat(), "endDate": end.isoformat(), "_": int(time.time() * MILLISECONDS_PER_SECOND),
            }
            payload = _http_json(
                self.HISTORY_URL + "?" + urllib.parse.urlencode(params),
                referer=f"https://fundf10.eastmoney.com/jjjz_{code}.html", attempts=1,
            )
            if not isinstance(payload, dict) or not isinstance(payload.get("Data"), dict):
                raise ContractError(f"{code} 东方财富 F10 历史 payload 契约异常")
            rows, total = self._history_rows(payload)
            if total > 0:
                total_hint = max(int(total_hint or 0), int(total))
            if not rows:
                break
            if observed_page_width is None:
                observed_page_width = len(rows)
            before = len(collected)
            for index, row in enumerate(rows):
                if not isinstance(row, dict):
                    continue
                day = self._history_row_date(row)
                key = day if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day) else f"page:{page}:row:{index}"
                collected[key] = row
            if total_hint and len([key for key in collected if not key.startswith("page:")]) >= total_hint:
                break
            if observed_page_width and len(rows) < observed_page_width and not total_hint:
                break
            if len(collected) == before:
                break
            page += 1
        return list(collected.values())

    @staticmethod
    def _normalize_history(rows: list[dict]) -> dict:
        clean = []
        for row in rows:
            date = str(row.get("FSRQ") or "")[:DATE_TEXT_LENGTH]
            nav = _finite(row.get("DWJZ"), float("nan"))
            accumulated = _finite(row.get("LJJZ"), float("nan"))
            event = str(row.get("FHFCZ") or row.get("unitMoney") or "").strip()
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or not math.isfinite(nav) or nav <= 0:
                continue
            change_raw = row.get("JZZZL")
            change = None if change_raw in (None, "", "--") else _finite(change_raw) / PERCENT_SCALE
            clean.append((date, nav, accumulated if math.isfinite(accumulated) and accumulated > 0 else None, change, event))
        clean.sort(key=lambda item: item[0])
        clean = list({item[0]: item for item in clean}.values())
        dates, returns = [], []
        previous_nav = None
        previous_accumulated = None
        provider_fallbacks = corporate_actions = accumulated_confirmations = 0

        def cash_dividend(text: str) -> float:
            if not text:
                return 0.0
                                                                 
            match = re.search(r"每\s*(\d+)?\s*份[^0-9]*(?:派|分红|现金)[^0-9]*([0-9]+(?:\.[0-9]+)?)", text)
            if match:
                amount = _finite(match.group(2), 0.0)
                return amount / max(1, int(match.group(1))) if match.group(1) else amount
            match = re.search(r"(?:派现金|现金分红)[^0-9]*([0-9]+(?:\.[0-9]+)?)", text)
            return _finite(match.group(1), 0.0) if match else 0.0

        for date, nav, accumulated, reported, event in clean:
            dates.append(date)
            if previous_nav is None:
                value = 0.0
            else:
                mechanical = nav / previous_nav - 1.0
                accumulated_move = None
                if accumulated is not None and previous_accumulated is not None and previous_accumulated > 0:
                    accumulated_move = accumulated / previous_accumulated - 1.0
                dividend = cash_dividend(event)
                event_flag = bool(event and event not in ("--", "暂无分红"))
                reported_valid = reported is not None and math.isfinite(reported) and reported > -1.0
                agreement_tolerance = RETURN_AGREEMENT_NUMERIC_TOLERANCE
                lggj_support = (
                    reported_valid and accumulated_move is not None
                    and abs(reported - accumulated_move) <= agreement_tolerance
                    and abs(reported - mechanical) > agreement_tolerance
                )
                if dividend > 0:
                    value = (nav + dividend) / previous_nav - 1.0
                    corporate_actions += 1
                    if reported_valid and abs(value - reported) <= agreement_tolerance:
                        accumulated_confirmations += int(accumulated_move is not None)
                elif reported_valid and abs(reported - mechanical) <= agreement_tolerance:
                    value = mechanical
                elif reported_valid and (event_flag or lggj_support):
                                                                                                     
                                                                                                   
                                                                                       
                    value = reported
                    corporate_actions += 1
                    provider_fallbacks += 1
                    accumulated_confirmations += int(lggj_support)
                else:
                    value = mechanical
            returns.append(max(-1.0 + sys.float_info.epsilon, _finite(value)))
            previous_nav = nav
            if accumulated is not None:
                previous_accumulated = accumulated
        return {
            "dates": dates, "returns": returns,
            "latest_nav": clean[-1][1] if clean else None,
            "latest_date": clean[-1][0] if clean else "",
            "return_basis": "adjusted-unit-nav+explicit-corporate-actions",
            "return_provider_fallbacks": provider_fallbacks,
            "return_corporate_actions": corporate_actions,
            "return_accumulated_confirmations": accumulated_confirmations,
        }

    def _ping_history(self, code: str, start: _dt.date) -> dict:
        params = urllib.parse.urlencode({"v": int(time.time() * MILLISECONDS_PER_SECOND)})
        text = _http_text(
            self.PING_URL.format(code=code) + "?" + params,
            referer=f"https://fund.eastmoney.com/{code}.html", attempts=1,
        )
        match = re.search(r"var\s+Data_netWorthTrend\s*=\s*(\[[\s\S]*?\])\s*;", text)
        if not match:
            raise ParseError(f"{code} 走势图数据结构缺失")
        try:
            source_rows = json.loads(match.group(1))
        except json.JSONDecodeError:
            source_rows = []
            for object_text in re.findall(r"\{[^{}]*\}", match.group(1)):
                x_match = re.search(r'["\']?x["\']?\s*:\s*(\d+)', object_text)
                y_match = re.search(r'["\']?y["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                r_match = re.search(r'["\']?equityReturn["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                if x_match and y_match:
                    source_rows.append({
                        "x": int(x_match.group(1)), "y": float(y_match.group(1)),
                        "equityReturn": float(r_match.group(1)) if r_match else None,
                        "unitMoney": "",
                    })
        rows = []
        for row in source_rows:
            try:
                day = _dt.datetime.fromtimestamp(float(row.get("x")) / MILLISECONDS_PER_SECOND, tz=CHINA_TZ).date()
            except (TypeError, ValueError, OSError, OverflowError):
                continue
            if day < start:
                continue
            rows.append({"FSRQ": day.isoformat(), "DWJZ": row.get("y"), "JZZZL": row.get("equityReturn"), "FHFCZ": row.get("unitMoney")})
        result = self._normalize_history(rows)
        if len(result["dates"]) < MIN_HISTORY_POINTS:
            raise DataError(f"{code} 走势图历史不足 {MIN_HISTORY_POINTS} 条")
        name_match = re.search(r"var\s+fS_name\s*=\s*['\"]([^'\"]+)['\"]", text)
        if name_match:
            result["name"] = name_match.group(1).strip()
        return result

    def history(self, code: str) -> dict:
        today = _china_today()
        start = _dt.date.min
        errors = []
        try:
            return self._ping_history(code, start)
        except DataError as exc:
            errors.append(str(exc))
        try:
            rows = self._mobile_history_pages(code, start)
            rows = [row for row in rows if not self._history_row_date(row) or self._history_row_date(row) >= start.isoformat()]
            result = self._normalize_history(rows)
            if len(result["dates"]) >= MIN_HISTORY_POINTS:
                return result
            errors.append(f"移动历史仅 {len(result['dates'])} 条")
        except DataError as exc:
            errors.append(str(exc))
        try:
            rows = self._web_history_pages(code, start, today)
            result = self._normalize_history(rows)
            if len(result["dates"]) >= MIN_HISTORY_POINTS:
                return result
            errors.append(f"F10历史仅 {len(result['dates'])} 条")
        except DataError as exc:
            errors.append(str(exc))
        raise DataError(f"{code} 历史净值不足或暂不可用：{'；'.join(errors[-max(1, PUBLIC_SOURCE_COUNT):]) or '数据不足'}")

    def update_history(self, code: str, cached: dict) -> dict:
        dates = [str(day)[:DATE_TEXT_LENGTH] for day in (cached.get("dates") or [])]
        returns = list(cached.get("returns") or [])
        if len(dates) < MIN_HISTORY_POINTS or len(dates) != len(returns):
            return self.history(code)
        try:
            parsed_dates = [_dt.date.fromisoformat(day) for day in dates]
        except ValueError:
            return self.history(code)
        if parsed_dates != sorted(parsed_dates):
            return self.history(code)

        today = _china_today()
        # Re-read the complete retained history range.  Without a provider revision contract,
        # any finite look-back window would be an invented correctness threshold.  The first
        # cached observation is kept as the normalization anchor.
        revision_start = parsed_dates[0]
        try:
            rows = self._web_history_pages(code, revision_start, today)
            incremental = self._normalize_history(rows)
            inc_dates = list(incremental.get("dates") or [])
            inc_returns = list(incremental.get("returns") or [])
            if len(inc_dates) < 2 or len(inc_dates) != len(inc_returns):
                raise ParseError(f"{code} 修订窗口历史不足，无法安全覆盖缓存")

            merged = dict(zip(dates, returns))
            replace_from = inc_dates[1]
            # Replace the overlap, rather than append-only. This also removes a stale date
            # if the provider later retracts/corrects an erroneous observation in the window.
            replace_to = inc_dates[-1]
            for day in [value for value in merged if replace_from <= value <= replace_to]:
                merged.pop(day, None)
            for day, value in zip(inc_dates[1:], inc_returns[1:]):
                merged[day] = value

            ordered_dates = sorted(merged)
            latest_date = str(incremental.get("latest_date") or ordered_dates[-1])[:DATE_TEXT_LENGTH]
            latest_nav = (
                incremental.get("latest_nav")
                if incremental.get("latest_date") == latest_date
                else cached.get("latest_nav")
            )
            result = {
                "dates": ordered_dates,
                "returns": [merged[day] for day in ordered_dates],
                "latest_nav": latest_nav,
                "latest_date": latest_date,
                "return_basis": incremental.get("return_basis") or cached.get("return_basis"),
                "return_provider_fallbacks": incremental.get("return_provider_fallbacks", cached.get("return_provider_fallbacks", 0)),
                "return_corporate_actions": incremental.get("return_corporate_actions", cached.get("return_corporate_actions", 0)),
                "return_accumulated_confirmations": incremental.get("return_accumulated_confirmations", cached.get("return_accumulated_confirmations", 0)),
            }
            return result
        except NetworkError:
            # A transient window request may still be recoverable via ping/mobile/full-history fallbacks.
            return self.history(code)

    def latest(self, codes: list[str], *, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS) -> dict[str, dict]:
        if not codes:
            return {}
        last_error: BaseException | None = None
        for version in ("1", "6.2.4"):
            params = {
                "pageIndex": 1, "plat": "Android",
                "appType": "ttjj", "product": "EFund", "Version": version,
                "deviceid": "best-alipay-funds-local", "Fcodes": ",".join(codes),
            }
            try:
                payload = _http_json(
                    f"{self.MOBILE_BASE}/FundMNFInfo?" + urllib.parse.urlencode(params),
                    attempts=attempts, timeout=timeout,
                )
                if not isinstance(payload, dict) or not isinstance(payload.get("Datas"), list):
                    raise ContractError(f"东方财富最新净值 payload 缺少 Datas 数组（Version={version}）")
                output = {}
                for row in payload.get("Datas") or []:
                    if not isinstance(row, dict):
                        continue
                    code = str(row.get("FCODE") or "")
                    if code not in codes:
                        continue
                    nav_text = str(row.get("NAV") or "").strip()
                    nav = _finite(nav_text, float("nan"))
                    nav_date = str(row.get("PDATE") or "")[:DATE_TEXT_LENGTH]
                    nav_decimals = _published_decimal_places(nav_text)
                    if not math.isfinite(nav) or nav <= 0 or nav_decimals is None or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", nav_date):
                        continue
                    output[code] = {
                        "code": code, "name": str(row.get("SHORTNAME") or "").strip(),
                        "nav": nav, "nav_text": nav_text, "nav_decimals": nav_decimals,
                        "day_change": _finite(row.get("NAVCHGRT"), float("nan")),
                        "nav_date": nav_date,
                    }
                if output:
                    return output
                last_error = ContractError(f"东方财富最新净值 Version={version} 未解析出请求基金")
            except (DataError, ParseError, ContractError, NetworkError) as exc:
                last_error = exc
                continue
        if isinstance(last_error, NetworkError):
            raise last_error
        if len(codes) >= 2 and last_error is not None:
            raise last_error
        return {}

    def latest_many(self, codes: list[str], progress=lambda *_: None) -> dict:
        """Fetch the real request set once, then retry unresolved funds at the one-code protocol unit."""
        codes = list(dict.fromkeys(str(code) for code in codes if _valid_fund_code(code)))
        if not codes:
            progress("东方财富最新净值 0/0", PERCENT_SCALE)
            return {"rows": {}, "requested": 0, "received": 0, "failed_codes": [], "errors": []}

        output: dict[str, dict] = {}
        errors: list[str] = []
        progress(f"东方财富最新净值 0/{len(codes)}", 0)

        # First ask for exactly the caller's observed workload. If the provider or transport
        # rejects it, or returns only part of it, the fallback unit is one fund code: the
        # indivisible API key rather than a designer-selected batch size.
        try:
            output.update(self.latest(codes, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS))
        except (DataError, ParseError, ContractError, NetworkError) as exc:
            errors.append(str(exc))

        unresolved = [code for code in codes if code not in output]
        completed = len(codes) - len(unresolved)
        progress(
            f"东方财富最新净值 {completed}/{len(codes)} · 已取得 {len(output)}",
            PERCENT_SCALE * completed / max(1, len(codes)),
        )
        if unresolved and not _cancel_requested():
            workers = _adaptive_worker_count("network", len(unresolved))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="latest") as pool:
                future_map = {
                    pool.submit(self.latest, [code], timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS): code
                    for code in unresolved
                }
                for future in concurrent.futures.as_completed(future_map):
                    code = future_map[future]
                    try:
                        output.update(future.result())
                    except (DataError, ParseError, ContractError, NetworkError) as exc:
                        errors.append(f"{code}: {exc}")
                    finally:
                        completed += 1
                        progress(
                            f"东方财富最新净值 {min(completed, len(codes))}/{len(codes)} · 已取得 {len(output)}",
                            PERCENT_SCALE * min(completed, len(codes)) / max(1, len(codes)),
                        )

        failed_codes = [code for code in codes if code not in output]
        return {
            "rows": output,
            "requested": len(codes),
            "received": len(output),
            "failed_codes": failed_codes,
            "errors": errors,
        }


    def _sina_verify_one(self, item: dict) -> dict:
        code = str(item.get("code") or "")
        if not _valid_fund_code(code):
            return {"ok": False, "reason": "invalid-code"}
        try:
            text = _http_text(
                self.SINA_VERIFY_URL.format(code=code), referer="https://finance.sina.com.cn/fund/",
            )
            normalized = re.sub(r"\s+", " ", text)
            code_ok = code in normalized
            name = str(item.get("name") or "").strip()
                                                                                                
                                                                           
            stem = re.sub(r"[A-HI-ZＡ-Ｚ]$", "", name, flags=re.I).strip()
            stem = re.sub(r"[（）()\s·•]", "", stem)
            name_ok = (not stem) or stem in re.sub(r"[（）()\s·•]", "", normalized)
            company = re.sub(r"基金管理有限公司$|基金管理$|基金$", "", str(item.get("fund_company") or "")).strip()
            company_ok = (not company) or company in normalized
            nav_match = re.search(r"(?:最新净值|昨日净值)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)", normalized)
            sina_nav_text = nav_match.group(1) if nav_match else ""
            sina_nav = _finite(sina_nav_text, float("nan")) if nav_match else float("nan")
            sina_decimals = _published_decimal_places(sina_nav_text) if nav_match else None
            local_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
            local_decimals = item.get("display_nav_decimals", item.get("latest_nav_decimals"))
            nav_ratio = abs(sina_nav / local_nav - 1.0) if math.isfinite(sina_nav) and math.isfinite(local_nav) and local_nav > 0 else None
            nav_ok = nav_ratio is not None and _published_navs_compatible(local_nav, local_decimals, sina_nav, sina_decimals)
            return {
                "ok": bool(code_ok and name_ok and nav_ok and company_ok), "code_ok": bool(code_ok), "name_ok": bool(name_ok),
                "company_ok": bool(company_ok),
                "nav_ok": bool(nav_ok), "sina_nav": sina_nav if math.isfinite(sina_nav) else None,
                "nav_relative_diff": nav_ratio, "source": "新浪财经基金中心",
                "url_kind": "money.finance.sina.com.cn/fund",
            }
        except SOURCE_ADAPTER_ERRORS as exc:
            return {"ok": False, "reason": str(exc), "source": "新浪财经基金中心"}

    def cross_verify_top100(self, items: list[dict]) -> dict:
        rows = list(items[:DISPLAY_TOP_N])
        if not rows:
            return {"verified": 0, "requested": 0, "source": "新浪财经基金中心"}
        verified = 0; details = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", len(rows)), thread_name_prefix="sina-verify") as pool:
            future_map = {pool.submit(self._sina_verify_one, item): item for item in rows}
            for future in concurrent.futures.as_completed(future_map):
                item = future_map[future]
                try:
                    result = future.result()
                except SOURCE_ADAPTER_ERRORS as exc:
                    result = {"ok": False, "reason": str(exc), "source": "新浪财经基金中心"}
                details[item["code"]] = result
                if result.get("ok"):
                    verified += 1
        for item in rows:
            result = details.get(item["code"], {})
            item["independent_source_verified"] = result.get("ok") is True
            item["metadata_cross_verified"] = result.get("company_ok") is True
            item["independent_source"] = "新浪财经基金中心"
            item["independent_source_nav"] = result.get("sina_nav")
            item["independent_source_note"] = result.get("reason") or ("代码/名称/净值证据一致" if result.get("ok") else "交叉核验不完整")
        return {"verified": verified, "requested": len(rows), "source": "新浪财经基金中心", "details": details}


class SecondarySource:
    """Sina public-fund adapter. It is a real fallback path, not just a final Top100 evidence."""
    CATALOG_URL = "https://vip.stock.finance.sina.com.cn/fund_center/data/jsonp.php/IO.XSRV2.CallbackList['best']/NetValueReturn_Service.NetValueReturnOpen"
    HISTORY_URL = "https://stock.finance.sina.com.cn/fundInfo/view/FundInfo_LSJZ.php?symbol={code}&page={page}"
    INFO_URL = "https://stock.finance.sina.com.cn/fundInfo/view/FundInfo_XGFG.php?symbol={code}"

    @staticmethod
    def _walk_dicts(value):
        if isinstance(value, dict):
            yield value
            for child in value.values():
                yield from SecondarySource._walk_dicts(child)
        elif isinstance(value, list):
            for child in value:
                yield from SecondarySource._walk_dicts(child)

    @staticmethod
    def _fund_from_row(row: dict) -> dict | None:
        code = ""
        for key in ("symbol", "code", "fundcode", "fcode", "scode"):
            value = str(row.get(key) or "")
            match = FUND_CODE_SEARCH_PATTERN.search(value)
            if match:
                code = match.group(1); break
        if not code:
            return None
        name = next((str(row.get(key) or "").strip() for key in ("name", "sname", "fundname", "shortname") if str(row.get(key) or "").strip()), "")
        if not name:
            return None
        fund_type = next((str(row.get(key) or "").strip() for key in ("type", "typename", "fundtype", "type2") if str(row.get(key) or "").strip()), "公开基金")
        return {"code": code, "name": name, "type": fund_type}

    @staticmethod
    def _catalog_total_hint(payload) -> int | None:
        candidates = []
        for row in SecondarySource._walk_dicts(payload):
            for key in ("total", "totalcount", "totalCount", "TotalCount", "recordcount", "recordCount"):
                if key not in row:
                    continue
                try:
                    value = int(float(row.get(key)))
                except (TypeError, ValueError):
                    continue
                if value > 0:
                    candidates.append(value)
        return max(candidates) if candidates else None

    def all_funds(self) -> list[dict]:
        output = {}
        page = 1
        while not _cancel_requested():
            before = len(output)
            params = {"page": page, "sort": "form_year", "asc": 0, "ccode": "", "type2": 0, "type3": ""}
            payload = _http_json(
                self.CATALOG_URL + "?" + urllib.parse.urlencode(params),
                referer="https://vip.stock.finance.sina.com.cn/fund_center/",
            )
            page_codes = set()
            for row in self._walk_dicts(payload):
                item = self._fund_from_row(row)
                if item:
                    output[item["code"]] = item
                    page_codes.add(item["code"])
            total_hint = self._catalog_total_hint(payload)
            if total_hint and len(output) >= total_hint:
                break
            if not page_codes or len(output) == before:
                break
            page += 1
        if len(output) < DISPLAY_TOP_N:
            raise ContractError(f"新浪公开基金目录仅解析到 {len(output)} 个基金")
        return sorted(output.values(), key=lambda row: row["code"])

    @staticmethod
    def _history_rows_from_html(text: str) -> list[tuple[str, float, float | None]]:
        rows = []
        for block in re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", text or "", flags=re.I):
            plain = EastMoneySource._strip_html(block)
            match = re.search(r"(20\d{2}|19\d{2})[/-](\d{1,2})[/-](\d{1,2})\s+([0-9]+(?:\.[0-9]+)?)\s+([0-9]+(?:\.[0-9]+)?)\s+([+-]?[0-9]+(?:\.[0-9]+)?)\s*%", plain)
            if not match:
                continue
            day = f"{int(match.group(1)):04d}-{int(match.group(2)):02d}-{int(match.group(3)):02d}"
            rows.append((day, float(match.group(4)), float(match.group(6)) / PERCENT_SCALE))
        return rows

    def history(self, code: str) -> dict:
        collected = {}
        page = 1
        while not _cancel_requested():
            text = _http_text(self.HISTORY_URL.format(code=code, page=page), referer="https://finance.sina.com.cn/fund/")
            rows = self._history_rows_from_html(text)
            if not rows:
                if page == 1:
                    raise ParseError(f"新浪历史净值页面未解析到 {code}")
                break
            before = len(collected)
            for day, nav, growth in rows:
                collected[day] = (nav, growth)
            if len(collected) == before:
                break
            page += 1
        if len(collected) < MIN_HISTORY_POINTS:
            raise DataError(f"新浪历史净值 {code} 仅 {len(collected)} 条，低于长期分析门槛")
        dates = sorted(collected)
        returns = []
        prev_nav = None
        for day in dates:
            nav, growth = collected[day]
            value = growth if growth is not None else (nav / prev_nav - 1.0 if prev_nav and prev_nav > 0 else 0.0)
            returns.append(max(-1.0 + sys.float_info.epsilon, _finite(value)))
            prev_nav = nav
        latest_day = dates[-1]
        latest_nav = collected[latest_day][0]
        return {"dates": dates, "returns": returns, "latest_nav": latest_nav, "latest_date": latest_day, "history_source": "新浪财经基金历史净值"}

    def latest_one(self, code: str) -> dict | None:
        text = _http_text(self.INFO_URL.format(code=code), referer="https://finance.sina.com.cn/fund/")
        plain = EastMoneySource._strip_html(text)
        date_match = re.search(r"截止日期[：:]?\s*(20\d{2})[/-](\d{1,2})[/-](\d{1,2})", plain)
        nav_match = re.search(r"单位净值[：:]?\s*([0-9]+(?:\.[0-9]+)?)", plain)
        if not date_match or not nav_match:
            raise ParseError(f"新浪最新净值页面字段未匹配：{code}")
        day = f"{int(date_match.group(1)):04d}-{int(date_match.group(2)):02d}-{int(date_match.group(3)):02d}"
        change_match = re.search(r"净值增长率[：:]?\s*([+-]?[0-9]+(?:\.[0-9]+)?)\s*%", plain)
        nav_text = nav_match.group(1)
        return {"code": code, "nav": float(nav_text), "nav_text": nav_text, "nav_decimals": _published_decimal_places(nav_text), "nav_date": day, "day_change": (_finite(change_match.group(1)) if change_match else float("nan")), "source": "新浪财经基金中心"}

    def latest_many(self, codes: list[str], limit: int | None = None, progress=lambda *_: None) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if _valid_fund_code(code)))
        if limit is not None:
            codes = codes[:max(0, int(limit))]
        output, errors, fatal_contract_errors = {}, [], []
        if not codes:
            progress("新浪最新净值 0/0", PERCENT_SCALE)
            return {"rows": {}, "requested": 0, "received": 0, "failed_codes": [], "errors": []}
        workers = _adaptive_worker_count("network", len(codes))
        completed = 0
        progress(f"新浪最新净值 0/{len(codes)}", 0)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="sina-latest") as pool:
            future_map = {pool.submit(self.latest_one, code): code for code in codes}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    row = future.result()
                    if row:
                        output[code] = row
                except SOURCE_ADAPTER_ERRORS as exc:
                    errors.append(f"{code}:{exc}")
                    if isinstance(exc, (ParseError, ContractError)):
                        fatal_contract_errors.append(exc)
                finally:
                    completed += 1
                    progress(
                        f"新浪最新净值 {completed}/{len(codes)} · 已取得 {len(output)}",
                        PERCENT_SCALE * completed / max(1, len(codes)),
                    )
        if fatal_contract_errors and not output:
            raise fatal_contract_errors[0]
        missing = [code for code in codes if code not in output]
        return {"rows": output, "requested": len(codes), "received": len(output), "failed_codes": missing, "errors": errors}

    def basic_metadata(self, code: str) -> dict:
        text = _http_text(self.INFO_URL.format(code=code), referer="https://finance.sina.com.cn/fund/")
        structure = _FundHTMLStructure.parse(text)
        purchase = structure.value("申购状态", "交易状态")
        company = structure.value("基金管理人", "基金管理公司", "管理人")
        manager = structure.value("基金经理")
        if not any((purchase, company, manager)):
            raise ParseError(f"新浪基金档案关键字段未解析：{code}")
        return {"fund_company": company, "fund_manager": manager, "public_purchase_status": purchase, "metadata_source_secondary": "新浪财经基金中心", "metadata_checked_at_secondary": _now_iso()}


class FundDataSource:
    """Two-adapter facade with capability-scoped degradation and independent public evidence."""
    _parse_fee_schedule = staticmethod(EastMoneySource._parse_fee_schedule)
    _history_rows = staticmethod(EastMoneySource._history_rows)
    _normalize_history = staticmethod(EastMoneySource._normalize_history)
    _strip_html = staticmethod(EastMoneySource._strip_html)
    _CAPABILITIES = ("catalog", "latest", "history", "metadata")
    _CORE_CAPABILITIES = ("catalog", "latest")

    def __init__(self):
        self.primary = EastMoneySource()
        self.secondary = SecondarySource()
        self.source_health = {
            source: {capability: 1.0 for capability in self._CAPABILITIES}
            for source in ("primary", "secondary")
        }
        self.source_degraded = {
            source: {capability: False for capability in self._CAPABILITIES}
            for source in ("primary", "secondary")
        }
        persisted_contract = _load_install_settings().get("source_contract_state") if RUNTIME_FOLDER_BOUND else {}
        persisted_contract = dict(persisted_contract) if isinstance(persisted_contract, dict) else {}
        self.source_contract = persisted_contract or {"checked": False, "details": {}}
        self.source_circuit = {
            source: {
                capability: {
                    "state": "CLOSED", "parse_failures": 0, "opened_at": 0.0,
                    "next_probe_at": 0.0, "last_error": "", "open_count": 0, "health_penalties": 0,
                }
                for capability in self._CAPABILITIES
            }
            for source in ("primary", "secondary")
        }
        self._catalog_cache: list[dict] | None = None

    def __getattr__(self, name):
        return getattr(self.primary, name)

    @classmethod
    def _contract_fingerprint(cls) -> str:
        adapters = []
        for adapter_cls in (EastMoneySource, SecondarySource):
            endpoints = sorted(
                (name, str(value))
                for name, value in vars(adapter_cls).items()
                if name.endswith("_URL") and isinstance(value, str)
            )
            adapters.append((adapter_cls.__name__, tuple(endpoints)))
        return _schema_fingerprint((cls._CAPABILITIES, cls._CORE_CAPABILITIES, tuple(adapters)))

    def next_contract_recheck_at(self) -> _dt.datetime:
        checked_at = _parse_iso(self.source_contract.get("checked_at"))
        if checked_at is None:
            return _dt.datetime.now(tz=CHINA_TZ)
        if checked_at.tzinfo is None:
            checked_at = checked_at.replace(tzinfo=CHINA_TZ)
        return checked_at.astimezone(CHINA_TZ) + _dt.timedelta(days=AVERAGE_GREGORIAN_DAYS_PER_MONTH)

    @staticmethod
    def _contract_row_valid(row: dict) -> bool:
        code = str(row.get("code") or "")
        name = str(row.get("name") or "").strip()
        return bool(_valid_fund_code(code) and name)

    def _capability_degraded(self, key: str, capability: str) -> bool:
        return bool((self.source_degraded.get(key) or {}).get(capability))

    def _penalize_health(self, key: str, capability: str) -> None:
        state = self.source_circuit[key][capability]
        penalties = int(state.get("health_penalties") or 0) + 1
        state["health_penalties"] = penalties
        self.source_health[key][capability] = 1.0 / (1.0 + penalties)

    @staticmethod
    def _circuit_delay_seconds(open_count: int) -> float:
        count = max(1, int(open_count))
        # Re-probe delay is driven only by the observed consecutive failure streak.
        return _objective_retry_delay(count)

    def _open_source_circuit(self, key: str, capability: str, reason: str) -> None:
        now = time.monotonic()
        state = self.source_circuit[key][capability]
        open_count = int(state.get("open_count") or 0) + 1
        state.update({
            "state": "OPEN",
            "opened_at": now,
            "next_probe_at": now + self._circuit_delay_seconds(open_count),
            "last_error": str(reason),
            "open_count": open_count,
        })
        self.source_degraded[key][capability] = True
        self.source_health[key][capability] = 0.0
        if capability == "catalog":
            self._catalog_cache = None
        _record_diagnostic(f"source-circuit-{key}-{capability}", reason, "ContractError")

    def _close_source_circuit(self, key: str, capability: str) -> None:
        state = self.source_circuit[key][capability]
        state.update({"state": "CLOSED", "parse_failures": 0, "opened_at": 0.0, "next_probe_at": 0.0, "last_error": "", "open_count": 0, "health_penalties": 0})
        self.source_degraded[key][capability] = False
        self.source_health[key][capability] = 1.0

    def _note_source_failure(self, key: str, capability: str, exc: BaseException) -> None:
        if not isinstance(exc, (ParseError, ContractError)):
            return
        state = self.source_circuit[key][capability]
        if state.get("state") == "OPEN":
            return
        state["parse_failures"] = int(state.get("parse_failures") or 0) + 1
        state["last_error"] = f"{type(exc).__name__}: {exc}"
        _record_diagnostic(f"source-parse-{key}-{capability}", exc)
        # A Contract/Parse failure is direct evidence that this adapter is unsafe now.
        self._open_source_circuit(
            key, capability,
            f"{capability} Contract/Parse 失败：{state['last_error']}",
        )

    def _note_source_success(self, key: str, capability: str) -> None:
        state = self.source_circuit[key][capability]
        if state.get("state") == "HALF_OPEN":
            self._close_source_circuit(key, capability)
        elif state.get("state") == "CLOSED":
            state["parse_failures"] = 0
            state["last_error"] = ""

    def _probe_allowed(self, key: str, capability: str, now: float, force: bool) -> bool:
        state = self.source_circuit[key][capability]
        if state.get("state") != "OPEN":
            return True
        if force or now >= float(state.get("next_probe_at") or 0.0):
            state["state"] = "HALF_OPEN"
            return True
        return False

    def _network_probe_failed(self, key: str, capability: str, now: float) -> None:
        state = self.source_circuit[key][capability]
        if state.get("state") == "HALF_OPEN":
            state["state"] = "OPEN"
            open_count = int(state.get("open_count") or 0) + 1
            state["open_count"] = open_count
            state["next_probe_at"] = now + self._circuit_delay_seconds(open_count)
            self.source_degraded[key][capability] = True

    @staticmethod
    def _contract_probe_codes(catalog: list[dict] | None, limit: int | None = None, preferred: list[str] | None = None) -> list[str]:
        limit = max(PUBLIC_SOURCE_COUNT, len(FundDataSource._CORE_CAPABILITIES)) if limit is None else max(1, int(limit))
        valid = [
            row for row in (catalog or [])
            if isinstance(row, dict) and _valid_fund_code(row.get("code")) and str(row.get("name") or "").strip()
        ]
        if not valid:
            return []
        by_code = {str(row.get("code")): row for row in valid}
        chosen = [code for code in (preferred or []) if code in by_code][:limit]
        seen_types = set()
        for code in chosen:
            row = by_code[code]
            fund_type = re.sub(r"\s+", "", str(row.get("type") or "未知")).upper()
            seen_types.add("QDII" if "QDII" in fund_type or "海外" in fund_type else ("FOF" if "FOF" in fund_type else fund_type))
        for row in valid:
            code = str(row.get("code"))
            if code in chosen:
                continue
            fund_type = re.sub(r"\s+", "", str(row.get("type") or "未知")).upper()
            bucket = "QDII" if "QDII" in fund_type or "海外" in fund_type else ("FOF" if "FOF" in fund_type else fund_type)
            if bucket in seen_types:
                continue
            chosen.append(code); seen_types.add(bucket)
            if len(chosen) >= limit:
                return chosen
        for row in valid:
            code = str(row.get("code"))
            if code not in chosen:
                chosen.append(code)
                if len(chosen) >= limit:
                    break
        return chosen[:limit]

    def startup_contract_test(self, force: bool = False, progress=lambda *_: None) -> dict:
        now = time.monotonic()
        states = [
            state
            for source_states in self.source_circuit.values()
            for state in source_states.values()
        ]
        checked_at = _parse_iso(self.source_contract.get("checked_at"))
        if checked_at is not None and checked_at.tzinfo is None:
            checked_at = checked_at.replace(tzinfo=CHINA_TZ)
        contract_fingerprint = self._contract_fingerprint()
        periodic_due = bool(
            not self.source_contract.get("checked")
            or self.source_contract.get("core_ok") is False
            or str(self.source_contract.get("contract_fingerprint") or "") != contract_fingerprint
            or checked_at is None
            or (_dt.datetime.now(tz=CHINA_TZ) - checked_at.astimezone(CHINA_TZ)).total_seconds()
               >= AVERAGE_GREGORIAN_DAYS_PER_MONTH * SECONDS_PER_DAY
        )
        half_open_due = any(
            state.get("state") == "OPEN" and now >= float(state.get("next_probe_at") or 0.0)
            for state in states
        )
        parse_triggered = any(
            int(state.get("parse_failures") or 0) > 0
            for state in states
        )
        if not (force or periodic_due or half_open_due or parse_triggered):
            if self.source_contract.get("core_ok") is False:
                raise ContractError(str(self.source_contract.get("core_error") or "核心数据能力仍不可用"))
            progress("数据源检查已使用近期安全结果", PERCENT_SCALE)
            return dict(self.source_contract)

        details = {}
        validated_catalogs = []
        available = {capability: set() for capability in self._CORE_CAPABILITIES}
        contract_samples = {"catalog_counts": {}, "latest": {}, "metadata": {}}
        source_pairs = (("primary", self.primary, "东方财富"), ("secondary", self.secondary, "新浪"))
        probed_capabilities = ("catalog", "latest", "metadata")
        probe_settings = _load_install_settings()
        prior_probe_codes = [
            str(code) for code in (probe_settings.get("source_contract_probe_codes") or [])
            if _valid_fund_code(code)
        ]

        def contract_progress(source_index: int, capability: str, within: float = 0.0) -> float:
            completed_units = source_index * len(probed_capabilities) + probed_capabilities.index(capability)
            completed_units += _clamp(_finite(within), 0.0, 1.0)
            return PERCENT_SCALE * completed_units / max(1, len(source_pairs) * len(probed_capabilities))

        for source_index, (key, adapter, source_label) in enumerate(source_pairs):
            notes = {capability: [] for capability in self._CAPABILITIES}
            outcomes = {capability: False for capability in self._CAPABILITIES}
            catalog = None
            candidate_catalog = []
            probe_codes = list(prior_probe_codes)

            # Catalog is a core capability, but its failure must not disable latest/history/metadata.
            progress(f"检查{source_label}基金目录", contract_progress(source_index, "catalog"))
            if self._probe_allowed(key, "catalog", now, force):
                try:
                    catalog = adapter.all_funds()
                    valid = [row for row in catalog if isinstance(row, dict) and self._contract_row_valid(row)]
                    if len(valid) < DISPLAY_TOP_N:
                        raise ContractError(f"目录契约异常 valid={len(valid)}")
                    candidate_catalog = valid
                    contract_samples["catalog_counts"][key] = len(valid)
                    if validated_catalogs:
                        common_codes = set(str(row.get("code")) for row in valid)
                        for _previous_key, previous_rows in validated_catalogs:
                            common_codes &= {str(row.get("code")) for row in previous_rows if isinstance(row, dict)}
                        common_rows = [row for row in valid if str(row.get("code")) in common_codes]
                        if common_rows:
                            candidate_catalog = common_rows
                    probe_codes = self._contract_probe_codes(candidate_catalog, preferred=prior_probe_codes)
                    outcomes["catalog"] = True
                    available["catalog"].add(key)
                    self._close_source_circuit(key, "catalog")
                    validated_catalogs.append((key, valid))
                    notes["catalog"].append("契约通过")
                except (ParseError, ContractError) as exc:
                    self._note_source_failure(key, "catalog", exc)
                    self._penalize_health(key, "catalog")
                    notes["catalog"].append(f"契约异常:{type(exc).__name__}")
                except (NetworkError, OSError) as exc:
                    self._network_probe_failed(key, "catalog", now)
                    notes["catalog"].append(f"暂不可达:{type(exc).__name__}")
            else:
                state = self.source_circuit[key]["catalog"]
                remaining = max(0, int(float(state.get("next_probe_at") or 0.0) - now))
                notes["catalog"].append(f"熔断中，约 {remaining // SECONDS_PER_MINUTE} 分钟后复探")

            # Latest is independently probed even when catalog parsing is broken.
            progress(f"检查{source_label}最新净值字段", contract_progress(source_index, "latest"))
            if self._probe_allowed(key, "latest", now, force) and probe_codes:
                try:
                    latest = adapter.latest_many(
                        probe_codes,
                        progress=lambda text, pct, index=source_index: progress(
                            text, contract_progress(index, "latest", _clamp(_finite(pct), 0.0, PERCENT_SCALE) / PERCENT_SCALE)
                        ),
                    )
                    rows = latest.get("rows") or {}
                    requested = set(probe_codes)
                    observed = {str(code): row for code, row in rows.items() if str(code) in requested and isinstance(row, dict)}
                    if not observed:
                        raise ContractError("最新净值契约没有成功观测")
                    invalid = []
                    probe_catalog = {
                        str(item.get("code") or ""): item
                        for item in candidate_catalog
                        if isinstance(item, dict) and str(item.get("code") or "")
                    }
                    for code, row in observed.items():
                        nav = _finite(row.get("nav"), float("nan"))
                        day = str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH]
                        catalog_item = probe_catalog.get(str(code), {})
                        freshness_row = {**catalog_item, **row}
                        fund_type = str(catalog_item.get("type") or freshness_row.get("type") or "")
                        valid = bool(
                            math.isfinite(nav) and nav > 0
                            and re.fullmatch(r"\d{4}-\d{2}-\d{2}", day)
                            and FreshnessGate.is_fresh(freshness_row, _china_today(), fund_type)
                        )
                        if not valid:
                            invalid.append(code)
                    if invalid:
                        raise ContractError(f"最新净值契约返回了无效观测: {','.join(sorted(invalid))}")
                    contract_samples["latest"][key] = {
                        code: {
                            "nav": _finite(row.get("nav")),
                            "nav_date": str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH],
                            "nav_decimals": row.get("nav_decimals"),
                            "name": str((probe_catalog.get(code) or {}).get("name") or ""),
                        }
                        for code, row in observed.items()
                    }
                    notes["latest"].append(f"成功观测 {len(observed)}/{len(probe_codes)}；逐条契约通过")
                    outcomes["latest"] = True
                    available["latest"].add(key)
                    self._close_source_circuit(key, "latest")
                    if not notes["latest"]:
                        notes["latest"].append("契约通过")
                except (ParseError, ContractError) as exc:
                    self._note_source_failure(key, "latest", exc)
                    self._penalize_health(key, "latest")
                    notes["latest"].append(f"契约异常:{type(exc).__name__}")
                except (NetworkError, OSError) as exc:
                    self._network_probe_failed(key, "latest", now)
                    notes["latest"].append(f"暂不可达:{type(exc).__name__}")
            else:
                if not probe_codes:
                    notes["latest"].append("本轮没有双方目录共同/近期成功的动态探针，跳过主动熔断")
                else:
                    state = self.source_circuit[key]["latest"]
                    remaining = max(0, int(float(state.get("next_probe_at") or 0.0) - now))
                    notes["latest"].append(f"熔断中，约 {remaining // SECONDS_PER_MINUTE} 分钟后复探")

            # Metadata is enhancement-only. Failure disables only metadata for this source.
            progress(f"检查{source_label}基金信息字段", contract_progress(source_index, "metadata"))
            if self._probe_allowed(key, "metadata", now, force) and probe_codes:
                try:
                    meta = adapter.basic_metadata(probe_codes[0])
                    metadata_stamp = isinstance(meta, dict) and (meta.get("metadata_checked_at") or meta.get("metadata_checked_at_secondary"))
                    metadata_signal = isinstance(meta, dict) and any(
                        meta.get(field) for field in ("fund_company", "fund_manager", "public_purchase_status", "benchmark", "inception_date")
                    )
                    if not metadata_stamp or not metadata_signal:
                        raise ContractError("元数据契约异常")
                    outcomes["metadata"] = True
                    contract_samples["metadata"][key] = {
                        "code": str(probe_codes[0]),
                        "fund_company": str(meta.get("fund_company") or ""),
                        "fund_manager": str(meta.get("fund_manager") or ""),
                        "benchmark": str(meta.get("benchmark") or ""),
                        "inception_date": str(meta.get("inception_date") or "")[:DATE_TEXT_LENGTH],
                    }
                    self._close_source_circuit(key, "metadata")
                    notes["metadata"].append("契约通过")
                except (ParseError, ContractError) as exc:
                    self._note_source_failure(key, "metadata", exc)
                    self._penalize_health(key, "metadata")
                    notes["metadata"].append(f"契约异常:{type(exc).__name__}")
                except (NetworkError, OSError) as exc:
                    self._network_probe_failed(key, "metadata", now)
                    notes["metadata"].append(f"暂不可达:{type(exc).__name__}")
            else:
                if not probe_codes:
                    notes["metadata"].append("本轮没有可用动态探针，跳过主动熔断")
                else:
                    state = self.source_circuit[key]["metadata"]
                    remaining = max(0, int(float(state.get("next_probe_at") or 0.0) - now))
                    notes["metadata"].append(f"熔断中，约 {remaining // SECONDS_PER_MINUTE} 分钟后复探")

            capabilities = {}
            for capability in self._CAPABILITIES:
                state = self.source_circuit[key][capability]
                capabilities[capability] = {
                    "available": (not self._capability_degraded(key, capability)) if capability == "history" else outcomes.get(capability, False),
                    "degraded": self._capability_degraded(key, capability),
                    "state": state.get("state"),
                    "parse_failures": int(state.get("parse_failures") or 0),
                    "note": "；".join(notes[capability]) or "未在启动阶段探测",
                }
            details[key] = {
                "degraded": all(self._capability_degraded(key, capability) for capability in self._CORE_CAPABILITIES),
                "state": "DEGRADED" if any(self._capability_degraded(key, capability) for capability in self._CAPABILITIES) else "CLOSED",
                "capabilities": capabilities,
                "note": "；".join(
                    f"{capability}:{capabilities[capability]['note']}"
                    for capability in ("catalog", "latest", "metadata")
                ),
            }
            core_ok = outcomes["catalog"] or outcomes["latest"]
            progress(
                f"{source_label}核心数据检查" + ("可用" if core_ok else "需备用源接管"),
                contract_progress(source_index, "metadata", 1.0),
            )

        if validated_catalogs:
            merged = {}
            source_labels = {"primary": "东方财富", "secondary": "新浪财经"}
            common_codes = None
            common_rows_lookup = {}
            for _key, rows in validated_catalogs:
                codes = {str(row.get("code")) for row in rows if isinstance(row, dict) and _valid_fund_code(row.get("code"))}
                common_codes = codes if common_codes is None else common_codes & codes
                for row in rows:
                    if isinstance(row, dict):
                        common_rows_lookup.setdefault(str(row.get("code") or ""), row)
            if common_codes:
                common_rows = [common_rows_lookup[code] for code in sorted(common_codes) if code in common_rows_lookup]
                dynamic_probes = self._contract_probe_codes(common_rows, preferred=prior_probe_codes)
                if dynamic_probes:
                    def remember_probes(settings):
                        settings["source_contract_probe_codes"] = list(dynamic_probes)
                    _update_install_settings(remember_probes)
            for key, rows in validated_catalogs:
                source_name = source_labels.get(key, key)
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    code = str(row.get("code") or "")
                    if not _valid_fund_code(code):
                        continue
                    item = merged.setdefault(code, {"code": code, "name": "", "type": ""})
                    if not item.get("name") and row.get("name"):
                        item["name"] = row.get("name")
                    if not item.get("type") and row.get("type"):
                        item["type"] = row.get("type")
                    sources = set(item.get("catalog_sources") or [])
                    sources.add(source_name)
                    item["catalog_sources"] = sorted(sources)
            snapshot_sources = sorted({source_labels.get(key, key) for key, _rows in validated_catalogs})
            for item in merged.values():
                item["public_catalog_confirmations"] = len(item.get("catalog_sources") or [])
                item["availability_public_signals"] = (["multi-public-catalog"] if item["public_catalog_confirmations"] >= PUBLIC_SOURCE_COUNT else [])
                # Snapshot-wide provenance is transient evidence used by candidate-pool deletion.
                # It is copied onto every row so structural filtering cannot erase the fact that
                # all configured catalogs did (or did not) participate in this same observation.
                item["catalog_snapshot_sources"] = list(snapshot_sources)
            if len(merged) >= CATALOG_CACHE_MIN_ROWS:
                self._catalog_cache = [dict(row) for row in sorted(merged.values(), key=lambda row: row["code"])]

        semantic_mismatches = []
        primary_latest = contract_samples["latest"].get("primary") or {}
        secondary_latest = contract_samples["latest"].get("secondary") or {}
        for code in sorted(set(primary_latest) & set(secondary_latest)):
            left = primary_latest[code]
            right = secondary_latest[code]
            if left.get("nav_date") != right.get("nav_date"):
                continue
            left_nav = _finite(left.get("nav"), float("nan"))
            right_nav = _finite(right.get("nav"), float("nan"))
            decimals_available = left.get("nav_decimals") is not None and right.get("nav_decimals") is not None
            compatible = (
                _published_navs_compatible(left_nav, left.get("nav_decimals"), right_nav, right.get("nav_decimals"))
                if decimals_available else
                abs(left_nav / right_nav - 1.0) <= RETURN_AGREEMENT_NUMERIC_TOLERANCE * max(1.0, abs(left_nav), abs(right_nav))
            )
            if not (math.isfinite(left_nav) and math.isfinite(right_nav) and compatible):
                semantic_mismatches.append(code)
        if semantic_mismatches:
            message = f"双源同日期净值语义契约不一致: {','.join(semantic_mismatches)}"
            details["cross_source_semantics"] = {"state": "DEGRADED", "note": message}
            self.source_contract = {
                "checked": True, "details": details, "checked_at": _now_iso(),
                "core_ok": False, "latest_ok": False, "core_error": message,
                "contract_fingerprint": contract_fingerprint,
                "sample_codes": sorted(set(primary_latest) | set(secondary_latest)),
                "sample_values": contract_samples,
            }
            def remember_failed_contract(settings):
                settings["source_contract_state"] = dict(self.source_contract)
            _update_install_settings(remember_failed_contract)
            raise ContractError(message)

        build_ok = bool(available["catalog"])
        latest_ok = bool(available["latest"])
        core_error = "" if build_ok else "当前基金目录暂不可用；程序将自动重试/使用可用备用能力"
        self.source_contract = {
            "checked": True, "details": details, "checked_at": _now_iso(),
            "core_ok": build_ok, "latest_ok": latest_ok, "core_error": core_error,
            "contract_fingerprint": contract_fingerprint,
            "sample_codes": sorted({
                code for rows in contract_samples["latest"].values() for code in (rows or {})
            }),
            "sample_values": contract_samples,
        }
        def remember_contract(settings):
            settings["source_contract_state"] = dict(self.source_contract)
        _update_install_settings(remember_contract)
        if not build_ok:
            raise ContractError(core_error)
        progress("数据源检查完成", PERCENT_SCALE)
        return dict(self.source_contract)

    @staticmethod
    def structural_prefilter(availability: dict[str, dict], limit: int | None = None) -> dict[str, dict]:
        return EastMoneySource.structural_prefilter(availability, limit)

    def all_funds(self) -> list[dict]:
        if self._catalog_cache is not None:
            rows = [dict(row) for row in self._catalog_cache]
            self._catalog_cache = None
            return rows
        primary_rows = secondary_rows = []
        errors = []
        try:
            if self._capability_degraded("primary", "catalog"):
                raise ContractError("东方财富目录能力已因格式契约异常熔断")
            primary_rows = self.primary.all_funds()
            self._note_source_success("primary", "catalog")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, "东方财富目录")
            if exc is not raw_exc: _record_diagnostic("source-primary-catalog", exc)
            self._note_source_failure("primary", "catalog", exc)
            self._penalize_health("primary", "catalog"); errors.append(f"东方财富目录:{exc}")
        try:
            if self._capability_degraded("secondary", "catalog"):
                raise ContractError("新浪目录能力已因格式契约异常熔断")
            secondary_rows = self.secondary.all_funds()
            self._note_source_success("secondary", "catalog")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, "新浪目录")
            if exc is not raw_exc: _record_diagnostic("source-secondary-catalog", exc)
            self._note_source_failure("secondary", "catalog", exc)
            self._penalize_health("secondary", "catalog"); errors.append(f"新浪目录:{exc}")
        if not primary_rows and not secondary_rows:
            raise DataError("双基金目录均不可用：" + "；".join(errors))
        merged = {}
        snapshot_sources = [
            source_name
            for source_name, rows in (("东方财富", primary_rows), ("新浪财经", secondary_rows))
            if rows
        ]
        for source_name, rows in (("东方财富", primary_rows), ("新浪财经", secondary_rows)):
            for row in rows:
                code = str(row.get("code") or "")
                if not _valid_fund_code(code):
                    continue
                item = merged.setdefault(code, {"code": code, "name": "", "type": ""})
                if not item.get("name") and row.get("name"):
                    item["name"] = row.get("name")
                if not item.get("type") and row.get("type"):
                    item["type"] = row.get("type")
                sources = set(item.get("catalog_sources") or [])
                sources.add(source_name); item["catalog_sources"] = sorted(sources)
        for item in merged.values():
            item["public_catalog_confirmations"] = len(item.get("catalog_sources") or [])
            item["availability_public_signals"] = (["multi-public-catalog"] if item["public_catalog_confirmations"] >= PUBLIC_SOURCE_COUNT else [])
            item["catalog_snapshot_sources"] = list(snapshot_sources)
        if len(merged) < DISPLAY_TOP_N:
            raise DataError(f"双源合并基金目录仅 {len(merged)} 个")
        result = sorted(merged.values(), key=lambda row: row["code"])
        return result

    def public_fallback_universe(self, limit: int | None = None) -> dict[str, dict]:
        chosen = sorted((row for row in self.all_funds() if _candidate_allowed(row.get("name", ""))), key=lambda row: int(row.get("code") or int("9" * FUND_CODE_DIGITS)))
        if limit is not None:
            chosen = chosen[:max(0, int(limit))]
        observed = _now_iso(); output = {}
        for row in chosen:
            code = row["code"]
            output[code] = {**row, "availability_status": "unknown", "availability_generated_at": observed, "availability_source": "公开基金多源元数据", "availability_source_id": "public-multisignal-inference", "availability_evidence": "东方财富与新浪公开目录及基金状态元数据", "availability_note": "公开基金多源状态元数据", "fund_data_source": "东方财富 + 新浪财经公开基金数据", "fees_verified": False, "fees": {}, "fees_history": [], "available_from": "", "available_to": "", "availability_history": [], "share_class": "", "product_features": {}, "product_features_history": [], "benchmark": "", "index_code": "", "fund_company": "", "theme": "", **_holding_costs({})}
        if len(output) < DISPLAY_TOP_N:
            raise DataError(f"公开基金候选池仅 {len(output)} 个，无法进行长期分析")
        return output

    @staticmethod
    def _validate_history_result(code: str, result: dict, source_name: str) -> dict:
        dates = list((result or {}).get("dates") or [])
        returns = list((result or {}).get("returns") or [])
        if len(dates) != len(returns):
            raise DataError(f"{code} {source_name}历史日期/收益长度不一致")
        if len(dates) < MIN_HISTORY_POINTS:
            raise DataError(
                f"{code} {source_name}历史仅 {len(dates)} 条，低于正式分析最低 {MIN_HISTORY_POINTS} 条"
            )
        return result

    def history(self, code: str) -> dict:
        try:
            if self._capability_degraded("primary", "history"):
                raise ContractError("东方财富历史能力已熔断")
            result = self._validate_history_result(code, self.primary.history(code), "东方财富")
            self._note_source_success("primary", "history")
            result["history_source"] = "东方财富基金历史净值"
            return result
        except SOURCE_ADAPTER_ERRORS as raw_primary_exc:
            primary_exc = _typed_source_error(raw_primary_exc, f"{code} 东方财富历史")
            if primary_exc is not raw_primary_exc: _record_diagnostic("source-primary-history", primary_exc)
            self._note_source_failure("primary", "history", primary_exc)
            self._penalize_health("primary", "history")
            try:
                if self._capability_degraded("secondary", "history"):
                    raise ContractError("新浪历史能力已熔断")
                result = self._validate_history_result(code, self.secondary.history(code), "新浪")
                self._note_source_success("secondary", "history")
                result["history_fallback_reason"] = str(primary_exc)
                return result
            except SOURCE_ADAPTER_ERRORS as raw_secondary_exc:
                secondary_exc = _typed_source_error(raw_secondary_exc, f"{code} 新浪历史")
                if secondary_exc is not raw_secondary_exc: _record_diagnostic("source-secondary-history", secondary_exc)
                self._note_source_failure("secondary", "history", secondary_exc)
                self._penalize_health("secondary", "history")
                raise DataError(f"{code} 双历史源失败：东方财富={primary_exc}；新浪={secondary_exc}") from raw_secondary_exc

    @staticmethod
    def _merge_history_revision(cached: dict, revision: dict) -> dict:
        dates = [str(day)[:DATE_TEXT_LENGTH] for day in (cached.get("dates") or [])]
        returns = list(cached.get("returns") or [])
        inc_dates = [str(day)[:DATE_TEXT_LENGTH] for day in (revision.get("dates") or [])]
        inc_returns = list(revision.get("returns") or [])
        if len(dates) != len(returns) or len(inc_dates) < 2 or len(inc_dates) != len(inc_returns):
            raise ParseError("备用历史修订窗口无法安全合并")
        merged = dict(zip(dates, returns))
        replace_from = inc_dates[1]
        replace_to = inc_dates[-1]
        for day in [value for value in merged if replace_from <= value <= replace_to]:
            merged.pop(day, None)
        for day, value in zip(inc_dates[1:], inc_returns[1:]):
            merged[day] = value
        ordered = sorted(merged)
        cached_latest = str(cached.get("latest_date") or (dates[-1] if dates else ""))[:DATE_TEXT_LENGTH]
        revision_latest = str(revision.get("latest_date") or inc_dates[-1])[:DATE_TEXT_LENGTH]
        latest_date = max(cached_latest, revision_latest)
        latest_nav = revision.get("latest_nav") if revision_latest >= cached_latest else cached.get("latest_nav")
        return {
            "dates": ordered,
            "returns": [merged[day] for day in ordered],
            "latest_date": latest_date,
            "latest_nav": latest_nav,
        }

    def update_history(
        self, code: str, cached: dict, *, latest_row: dict | None = None, latest_checked: bool = False,
    ) -> dict:
        """Update a valid cached series from the latest quote whenever that is objectively safe.

        Full retained-history reads are reserved for observable anomalies: malformed cache, same-day
        NAV revision, a gap spanning more than one observed market session, or disagreement between
        the published daily move and the move implied by adjacent NAVs. A missing online quote keeps
        the local series intact and lets the formal freshness gate decide whether it may be promoted.
        """
        dates = [str(day)[:DATE_TEXT_LENGTH] for day in (cached.get("dates") or [])]
        returns = list(cached.get("returns") or [])
        cache_usable = bool(
            len(dates) >= MIN_HISTORY_POINTS and len(dates) == len(returns)
            and all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", day) for day in dates)
            and dates == sorted(dates)
        )

        row = dict(latest_row or {}) if isinstance(latest_row, dict) else {}
        if cache_usable and not latest_checked:
            try:
                report = self.latest_many([code])
                row = dict((report.get("rows") or {}).get(code) or {})
                latest_checked = True
            except SOURCE_ADAPTER_ERRORS as exc:
                _record_diagnostic("history-latest-prefetch", exc)
                latest_checked = True

        if cache_usable and latest_checked:
            if not row:
                result = dict(cached)
                result["dates"] = dates
                result["returns"] = returns
                result["history_source"] = "本地历史缓存（最新净值暂不可得）"
                result["history_incremental_deferred"] = True
                return result

            old_date = dates[-1]
            new_date = str(row.get("nav_date") or row.get("date") or "")[:DATE_TEXT_LENGTH]
            old_nav = _finite(cached.get("latest_nav"), float("nan"))
            new_nav = _finite(row.get("nav"), float("nan"))
            valid_new = bool(
                re.fullmatch(r"\d{4}-\d{2}-\d{2}", new_date)
                and math.isfinite(new_nav) and new_nav > 0
            )
            if valid_new and new_date == old_date and math.isfinite(old_nav) and old_nav > 0:
                if _published_navs_compatible(
                    old_nav, cached.get("latest_nav_decimals"),
                    new_nav, row.get("nav_decimals"),
                ):
                    result = dict(cached)
                    result["dates"] = dates
                    result["returns"] = returns
                    result["latest_nav"] = new_nav
                    result["latest_date"] = new_date
                    if row.get("nav_decimals") is not None:
                        result["latest_nav_decimals"] = int(row.get("nav_decimals"))
                    result["history_source"] = "本地历史缓存 + 批量最新净值"
                    result["history_incremental_deferred"] = False
                    return result
                # Same-period published NAV changed: only a full revision read can safely resolve it.
            elif valid_new and new_date > old_date and math.isfinite(old_nav) and old_nav > 0:
                try:
                    old_day = _dt.date.fromisoformat(old_date)
                    new_day = _dt.date.fromisoformat(new_date)
                    session_context = {**cached, **row}
                    session_context["type"] = cached.get("type") or row.get("type") or ""
                    market_sessions = _observed_market_sessions_for_item(old_day, new_day, session_context)
                except ValueError:
                    market_sessions = None
                nav_return = new_nav / old_nav - 1.0
                source_day = _finite(row.get("day_change"), float("nan"))
                source_return = source_day / PERCENT_SCALE if math.isfinite(source_day) else float("nan")
                agreed = bool(
                    math.isfinite(source_return)
                    and abs(source_return - nav_return)
                    <= RETURN_AGREEMENT_NUMERIC_TOLERANCE * max(1.0, abs(source_return))
                )
                # A matching published daily move is sufficient for the normal incremental path
                # unless the process has positively observed more than one intervening market session.
                if market_sessions is not None and market_sessions <= 1 and agreed:
                    result = dict(cached)
                    result["dates"] = dates + [new_date]
                    result["returns"] = returns + [max(-1.0 + sys.float_info.epsilon, nav_return)]
                    result["latest_nav"] = new_nav
                    result["latest_date"] = new_date
                    if row.get("nav_decimals") is not None:
                        result["latest_nav_decimals"] = int(row.get("nav_decimals"))
                    result["return_pending_adjustment"] = False
                    result["history_source"] = "本地历史缓存 + 批量最新净值增量"
                    result["history_incremental_deferred"] = False
                    return result
                # Multi-session gaps and disagreement are objective reasons to rebuild the series.
            elif valid_new and new_date < old_date:
                # The online source is behind the locally retained truth; do not erase newer local data.
                result = dict(cached)
                result["dates"] = dates
                result["returns"] = returns
                result["history_source"] = "本地历史缓存（在线净值日期落后）"
                result["history_incremental_deferred"] = True
                return result

        # Cache is unusable or an objective revision/corporate-action condition was observed.
        try:
            if self._capability_degraded("primary", "history"):
                raise ContractError("东方财富历史能力已熔断")
            result = self.primary.update_history(code, cached) if cache_usable else self.primary.history(code)
            self._note_source_success("primary", "history")
            result["history_source"] = "东方财富基金历史净值"
            return result
        except SOURCE_ADAPTER_ERRORS as raw_primary_exc:
            primary_exc = _typed_source_error(raw_primary_exc, f"{code} 东方财富历史校正")
            if primary_exc is not raw_primary_exc:
                _record_diagnostic("source-primary-update-history", primary_exc)
            self._note_source_failure("primary", "history", primary_exc)
            self._penalize_health("primary", "history")
            if self._capability_degraded("secondary", "history"):
                raise DataError(f"{code} 历史主源失败且备用源已熔断：{primary_exc}") from primary_exc
            try:
                secondary_history = self.secondary.history(code)
                self._note_source_success("secondary", "history")
                result = self._merge_history_revision(cached, secondary_history) if cache_usable else secondary_history
                result["history_source"] = "新浪财经基金历史净值（异常校正）"
                result["history_fallback_reason"] = str(primary_exc)
                return result
            except SOURCE_ADAPTER_ERRORS as raw_secondary_exc:
                secondary_exc = _typed_source_error(raw_secondary_exc, f"{code} 新浪历史校正")
                if secondary_exc is not raw_secondary_exc:
                    _record_diagnostic("source-secondary-update-history", secondary_exc)
                self._note_source_failure("secondary", "history", secondary_exc)
                raise DataError(f"{code} 历史双源失败：东方财富={primary_exc}；新浪={secondary_exc}") from raw_secondary_exc

    @staticmethod
    def _merge_latest_rows(primary: dict, secondary: dict) -> dict:
        output = dict(primary or secondary or {})
        sources = []
        if primary:
            sources.append("东方财富")
        if secondary:
            sources.append("新浪财经")
        output["latest_sources"] = sources
        output["latest_source_count"] = len(sources)
        # A single valid source is one observation. Two source rows count as two confirmations
        # only after same-period date and NAV consistency checks pass.
        output["latest_public_confirmations"] = 1 if sources else 0
        output["latest_cross_source_verified"] = False
        if primary and secondary:
            pdate = str(primary.get("nav_date") or primary.get("date") or "")[:DATE_TEXT_LENGTH]
            sdate = str(secondary.get("nav_date") or secondary.get("date") or "")[:DATE_TEXT_LENGTH]
            output["latest_primary_date"] = pdate
            output["latest_secondary_date"] = sdate
            pnav = _finite(primary.get("nav"), float("nan"))
            snav = _finite(secondary.get("nav"), float("nan"))
            valid_navs = math.isfinite(pnav) and math.isfinite(snav) and pnav > 0 and snav > 0
            relative_diff = abs(snav / pnav - 1.0) if valid_navs else float("inf")
            if math.isfinite(relative_diff):
                output["latest_cross_source_relative_diff"] = relative_diff
            same_date = bool(
                re.fullmatch(r"\d{4}-\d{2}-\d{2}", pdate)
                and re.fullmatch(r"\d{4}-\d{2}-\d{2}", sdate)
                and pdate == sdate
            )
            precision_match = _published_navs_compatible(
                pnav, primary.get("nav_decimals"), snav, secondary.get("nav_decimals")
            )
            verified = bool(valid_navs and same_date and precision_match)
            output["latest_cross_source_verified"] = verified
            output["latest_public_confirmations"] = PUBLIC_SOURCE_COUNT if verified else 1
            output["latest_cross_source_note"] = (
                "同一期双源净值一致" if verified else
                "双源日期不一致，未计为同一期确认" if pdate != sdate else
                "双源净值差异超阈值，未计为确认"
            )
        return output

    def latest_many(self, codes: list[str], progress=lambda *_: None) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if _valid_fund_code(code)))
        source_phases = ("primary", "secondary")
        progress(f"获取最新净值 0/{len(codes)}", 0.0)
        try:
            if self._capability_degraded("primary", "latest"):
                raise ContractError("东方财富最新净值能力已熔断")
            primary_result = self.primary.latest_many(
                codes, progress=_nested_progress(progress, source_phases, "primary"),
            )
            self._note_source_success("primary", "latest")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, "东方财富最新净值")
            if exc is not raw_exc: _record_diagnostic("source-primary-latest", exc)
            self._note_source_failure("primary", "latest", exc)
            primary_result = {"rows": {}, "requested": len(codes), "received": 0, "failed_codes": codes, "errors": [str(exc)]}
            progress("主要净值源暂不可用，正在切换备用源", _phase_progress_value(source_phases, "secondary"))
        primary_rows = primary_result.get("rows") or {}
        # Missing primary rows are all eligible for secondary takeover; only already-successful rows are bounded cross-checks.
        missing = [code for code in codes if code not in primary_rows]
        crosscheck = [code for code in codes[:CONTRACT_CROSSCHECK_SIZE] if code not in missing]
        secondary_targets = list(dict.fromkeys(missing + crosscheck))
        try:
            if self._capability_degraded("secondary", "latest"):
                raise ContractError("新浪最新净值能力已熔断")
            secondary_result = self.secondary.latest_many(
                secondary_targets, progress=_nested_progress(progress, source_phases, "secondary"),
            )
            self._note_source_success("secondary", "latest")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, "新浪最新净值")
            if exc is not raw_exc: _record_diagnostic("source-secondary-latest", exc)
            self._note_source_failure("secondary", "latest", exc)
            secondary_result = {"rows": {}, "requested": len(secondary_targets), "received": 0, "failed_codes": secondary_targets, "errors": [str(exc)]}
        secondary_rows = secondary_result.get("rows") or {}
        merged = {}
        for code in codes:
            if code in primary_rows or code in secondary_rows:
                merged[code] = self._merge_latest_rows(primary_rows.get(code), secondary_rows.get(code))
        failed = [code for code in codes if code not in merged]
        progress(f"最新净值已取得 {len(merged)}/{len(codes)}", PERCENT_SCALE)
        return {"rows": merged, "requested": len(codes), "received": len(merged), "failed_codes": failed, "errors": list(primary_result.get("errors") or []) + list(secondary_result.get("errors") or [])}

    def latest(self, codes: list[str], **_kwargs) -> dict[str, dict]:
        return self.latest_many(codes)["rows"]

    def basic_metadata(self, code: str) -> dict:
        primary = secondary = {}
        try:
            if self._capability_degraded("primary", "metadata"):
                raise ContractError("东方财富元数据能力已熔断")
            primary = self.primary.basic_metadata(code)
            self._note_source_success("primary", "metadata")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, f"{code} 东方财富元数据")
            if exc is not raw_exc: _record_diagnostic("source-primary-metadata", exc)
            self._note_source_failure("primary", "metadata", exc); self._penalize_health("primary", "metadata")
        try:
            if self._capability_degraded("secondary", "metadata"):
                raise ContractError("新浪元数据能力已熔断")
            secondary = self.secondary.basic_metadata(code)
            self._note_source_success("secondary", "metadata")
        except SOURCE_ADAPTER_ERRORS as raw_exc:
            exc = _typed_source_error(raw_exc, f"{code} 新浪元数据")
            if exc is not raw_exc: _record_diagnostic("source-secondary-metadata", exc)
            self._note_source_failure("secondary", "metadata", exc); self._penalize_health("secondary", "metadata")
        if not primary and not secondary:
            raise DataError(f"{code} 双元数据源均不可用")
        output = dict(primary or {})
        for key, value in secondary.items():
            if value and not output.get(key): output[key] = value
        statuses = [str(value.get("public_purchase_status") or "") for value in (primary, secondary) if value]
        parsed_states = [_parse_purchase_status(text) for text in statuses]
        open_count = sum(state == "public_open" for state in parsed_states)
        limited_count = sum(state == "limited_purchasable" for state in parsed_states)
        suspended_count = sum(state in PURCHASE_UNAVAILABLE_STATUSES for state in parsed_states)
        signals = set(output.get("availability_public_signals") or [])
        if open_count:
            signals.add("public-purchase-open")
        if limited_count:
            signals.add("public-purchase-limited")
        if len(statuses) >= 2:
            signals.add("multi-public-metadata")
        output["availability_public_signals"] = sorted(signals)
        # Only purchase-side agreement contributes to purchase confirmations. Metadata source
        # count is tracked separately and cannot lift a fund into a purchasable evidence tier.
        output["purchase_public_confirmations"] = max(open_count, limited_count, suspended_count)
        output["availability_public_confirmations"] = output["purchase_public_confirmations"]
        output["metadata_sources"] = [name for name, value in (("东方财富", primary), ("新浪财经", secondary)) if value]
        output["public_purchase_status_secondary"] = str(secondary.get("public_purchase_status") or "")
        return output

    def metadata_many(self, funds: list[dict]) -> dict[str, dict]:
        targets = [fund for fund in funds if _valid_fund_code(fund.get("code"))]
        output = {}
        failures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", max(1, len(targets))), thread_name_prefix="dual-fund-meta") as pool:
            future_map = {pool.submit(self.basic_metadata, str(fund["code"])): str(fund["code"]) for fund in targets}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    output[code] = future.result()
                except SOURCE_ADAPTER_ERRORS as exc:
                    failures.append(f"{code}:{type(exc).__name__}:{exc}")
        if failures:
            _record_diagnostic("metadata-many", f"{len(failures)} failures; last={failures[-1]}", "MetadataBatchError")
        return output

    def cross_verify_top100(self, items: list[dict]) -> dict:
        rows = list(items[:DISPLAY_TOP_N]); details = {}; verified = 0
        if self._capability_degraded("secondary", "latest"):
            for item in rows:
                item["independent_source_verified"] = False
                item["independent_source"] = "新浪财经基金中心"
                item["independent_source_note"] = "新浪最新净值能力已熔断，本轮不使用其交叉证据"
            return {"verified": 0, "requested": len(rows), "source": "新浪财经基金中心（最新净值能力已熔断）", "details": {}}
        secondary = self.secondary.latest_many([item["code"] for item in rows]) if rows else {"rows": {}}
        sec_rows = secondary.get("rows") or {}
        for item in rows:
            sec = sec_rows.get(item["code"])
            ok = False
            if sec:
                local_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
                snav = _finite(sec.get("nav"), float("nan"))
                local_date = str(item.get("display_nav_date") or item.get("latest_date") or "")[:DATE_TEXT_LENGTH]
                secondary_date = str(sec.get("nav_date") or sec.get("date") or "")[:DATE_TEXT_LENGTH]
                valid_navs = math.isfinite(local_nav) and math.isfinite(snav) and local_nav > 0 and snav > 0
                relative_diff = abs(snav / local_nav - 1.0) if valid_navs else float("inf")
                same_date = bool(
                    re.fullmatch(r"\d{4}-\d{2}-\d{2}", local_date)
                    and re.fullmatch(r"\d{4}-\d{2}-\d{2}", secondary_date)
                    and local_date == secondary_date
                )
                ok = bool(valid_navs and same_date and _published_navs_compatible(
                    local_nav, item.get("display_nav_decimals", item.get("latest_nav_decimals")),
                    snav, sec.get("nav_decimals"),
                ))
                sources = set(item.get("latest_sources") or [])
                sources.add("新浪财经")
                item["latest_sources"] = sorted(sources)
                item["latest_source_count"] = len(sources)
                item["latest_cross_source_verified"] = ok
                item["latest_public_confirmations"] = PUBLIC_SOURCE_COUNT if ok and len(sources) >= PUBLIC_SOURCE_COUNT else 1
                if math.isfinite(relative_diff):
                    item["latest_cross_source_relative_diff"] = relative_diff
                item["latest_secondary_date"] = secondary_date
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
            item["independent_source_verified"] = ok
            item["independent_source"] = "新浪财经基金中心"
            item["independent_source_nav"] = sec.get("nav") if sec else None
            item["independent_source_note"] = (
                "同一期最新净值交叉证据一致" if ok else
                "新浪净值日期与当前展示期不同，未计为同一期确认" if sec and str(sec.get("nav_date") or sec.get("date") or "")[:DATE_TEXT_LENGTH] != str(item.get("display_nav_date") or item.get("latest_date") or "")[:DATE_TEXT_LENGTH] else
                "新浪最新净值交叉证据未通过严格一致性校验"
            )
            details[item["code"]] = {
                "ok": ok, "source": "新浪财经基金中心",
                "sina_nav": sec.get("nav") if sec else None,
                "sina_date": str(sec.get("nav_date") or sec.get("date") or "")[:DATE_TEXT_LENGTH] if sec else "",
            }
            verified += int(ok)
        return {"verified": verified, "requested": len(rows), "source": "新浪财经基金中心", "details": details}



# ===== 本地存储 =====


CACHE_SCHEMA_FIELDS = {
    "runtime_state": ("key", "value_json"),
    "fund_master": ("code", "payload_json"),
    "nav_returns": ("code", "nav_date", "daily_return"),
    "market_session_context": ("asset_bucket", "source_family", "session_date", "observation_count"),
    "metadata": ("code", "payload_json"),
    "availability_history": ("code", "span_from", "span_to", "purchasable", "payload_json"),
    "formal_ranking": ("holding_years", "rank", "fund_code", "model_version", "validated_at", "validation_json", "payload_json"),
    "ranking_predictions": ("prediction_date", "fund_code", "holding_years", "predicted_rank", "raw_score", "model_version", "model_trained_at", "feature_snapshot_hash", "anchor_nav_date", "representative_history_code", "payload_json"),
    "prediction_outcomes": ("prediction_date", "fund_code", "holding_years", "evaluated_at", "target_return", "target_drawdown", "target_relative_return", "payload_json"),
    "prediction_long_term_summary": ("cohort_year", "holding_years", "asset_class", "sample_count", "payload_json", "updated_at"),
    "prediction_cohort_archive": ("prediction_date", "holding_years", "model_version", "model_trained_at", "sample_count", "payload_json", "archived_at"),
}
CACHE_SCHEMA_FINGERPRINT = _sqlite_schema_fingerprint(_schema_fingerprint(CACHE_SCHEMA_FIELDS))

CACHE_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS runtime_state (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fund_master (
    code TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS nav_returns (
    code TEXT NOT NULL,
    nav_date TEXT NOT NULL,
    daily_return REAL NOT NULL,
    PRIMARY KEY (code, nav_date)
);
CREATE INDEX IF NOT EXISTS idx_nav_returns_code_date ON nav_returns(code, nav_date);
CREATE TABLE IF NOT EXISTS market_session_context (
    asset_bucket TEXT NOT NULL,
    source_family TEXT NOT NULL,
    session_date TEXT NOT NULL,
    observation_count INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (asset_bucket, source_family, session_date)
);
CREATE INDEX IF NOT EXISTS idx_market_session_context_date
    ON market_session_context(asset_bucket, source_family, session_date);
CREATE TABLE IF NOT EXISTS metadata (
    code TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS availability_history (
    code TEXT NOT NULL,
    span_from TEXT NOT NULL,
    span_to TEXT NOT NULL DEFAULT '',
    purchasable INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (code, span_from, span_to, purchasable)
);
CREATE TABLE IF NOT EXISTS formal_ranking (
    holding_years INTEGER NOT NULL,
    rank INTEGER NOT NULL,
    fund_code TEXT NOT NULL,
    model_version INTEGER NOT NULL,
    validated_at TEXT NOT NULL,
    validation_json TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (holding_years, rank),
    UNIQUE (holding_years, fund_code)
);
CREATE INDEX IF NOT EXISTS idx_formal_ranking_validated
    ON formal_ranking(holding_years, validated_at);
CREATE TABLE IF NOT EXISTS ranking_predictions (
    prediction_date TEXT NOT NULL,
    fund_code TEXT NOT NULL,
    holding_years INTEGER NOT NULL,
    predicted_rank INTEGER NOT NULL,
    raw_score REAL NOT NULL,
    model_version INTEGER NOT NULL,
    model_trained_at TEXT NOT NULL DEFAULT '',
    feature_snapshot_hash TEXT NOT NULL,
    anchor_nav_date TEXT NOT NULL DEFAULT '',
    representative_history_code TEXT NOT NULL DEFAULT '',
    payload_json TEXT NOT NULL,
    PRIMARY KEY (prediction_date, fund_code, holding_years)
);
CREATE INDEX IF NOT EXISTS idx_ranking_predictions_maturity
    ON ranking_predictions(prediction_date, holding_years);
CREATE TABLE IF NOT EXISTS prediction_outcomes (
    prediction_date TEXT NOT NULL,
    fund_code TEXT NOT NULL,
    holding_years INTEGER NOT NULL,
    evaluated_at TEXT NOT NULL,
    target_return REAL,
    target_drawdown REAL,
    target_relative_return REAL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (prediction_date, fund_code, holding_years)
);
CREATE INDEX IF NOT EXISTS idx_prediction_outcomes_eval
    ON prediction_outcomes(evaluated_at, prediction_date);
CREATE TABLE IF NOT EXISTS prediction_long_term_summary (
    cohort_year TEXT NOT NULL,
    holding_years INTEGER NOT NULL,
    asset_class TEXT NOT NULL,
    sample_count INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (cohort_year, holding_years, asset_class)
);
CREATE TABLE IF NOT EXISTS prediction_cohort_archive (
    prediction_date TEXT NOT NULL,
    holding_years INTEGER NOT NULL,
    model_version INTEGER NOT NULL,
    model_trained_at TEXT NOT NULL DEFAULT '',
    sample_count INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    archived_at TEXT NOT NULL,
    PRIMARY KEY (prediction_date, holding_years)
);
CREATE INDEX IF NOT EXISTS idx_prediction_cohort_archive_years
    ON prediction_cohort_archive(holding_years, prediction_date);
"""


def _migrate_retired_ranking_profile_dimension(connection: sqlite3.Connection) -> None:
    """Collapse the retired no-op ranking profile dimension while preserving the neutral legacy cohort."""
    tables = {
        "formal_ranking": (
            "holding_years,rank,fund_code,model_version,validated_at,validation_json,payload_json",
            "holding_years,rank,fund_code,model_version,validated_at,validation_json,payload_json",
        ),
        "ranking_predictions": (
            "prediction_date,fund_code,holding_years,predicted_rank,raw_score,model_version,model_trained_at,feature_snapshot_hash,anchor_nav_date,representative_history_code,payload_json",
            "prediction_date,fund_code,holding_years,predicted_rank,raw_score,model_version,model_trained_at,feature_snapshot_hash,anchor_nav_date,representative_history_code,payload_json",
        ),
        "prediction_outcomes": (
            "prediction_date,fund_code,holding_years,evaluated_at,target_return,target_drawdown,target_relative_return,payload_json",
            "prediction_date,fund_code,holding_years,evaluated_at,target_return,target_drawdown,target_relative_return,payload_json",
        ),
        "prediction_long_term_summary": (
            "cohort_year,holding_years,asset_class,sample_count,payload_json,updated_at",
            "cohort_year,holding_years,asset_class,sample_count,payload_json,updated_at",
        ),
        "prediction_cohort_archive": (
            "prediction_date,holding_years,model_version,model_trained_at,sample_count,payload_json,archived_at",
            "prediction_date,holding_years,model_version,model_trained_at,sample_count,payload_json,archived_at",
        ),
    }
    columns_by_table = {}
    for table in tables:
        columns_by_table[table] = {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})")}
    # Some much older caches predate outcome target columns.  Add only the historical nullable
    # compatibility fields before collapsing the retired profile key so migration remains monotonic.
    if "profile" in columns_by_table.get("prediction_outcomes", set()):
        for column in ("target_return", "target_drawdown", "target_relative_return"):
            if column not in columns_by_table["prediction_outcomes"]:
                connection.execute(f"ALTER TABLE prediction_outcomes ADD COLUMN {column} REAL")
                columns_by_table["prediction_outcomes"].add(column)
    legacy_tables = [table for table, columns in columns_by_table.items() if "profile" in columns]
    if not legacy_tables:
        return
    savepoint = "retire_ranking_profile"
    connection.execute(f"SAVEPOINT {savepoint}")
    try:
        for index_name in (
            "idx_formal_ranking_validated", "idx_ranking_predictions_maturity",
            "idx_prediction_outcomes_eval", "idx_prediction_cohort_archive_years",
        ):
            connection.execute(f"DROP INDEX IF EXISTS {index_name}")
        creation_sql = {
            "formal_ranking": "CREATE TABLE formal_ranking (holding_years INTEGER NOT NULL,rank INTEGER NOT NULL,fund_code TEXT NOT NULL,model_version INTEGER NOT NULL,validated_at TEXT NOT NULL,validation_json TEXT NOT NULL,payload_json TEXT NOT NULL,PRIMARY KEY (holding_years,rank),UNIQUE (holding_years,fund_code))",
            "ranking_predictions": "CREATE TABLE ranking_predictions (prediction_date TEXT NOT NULL,fund_code TEXT NOT NULL,holding_years INTEGER NOT NULL,predicted_rank INTEGER NOT NULL,raw_score REAL NOT NULL,model_version INTEGER NOT NULL,model_trained_at TEXT NOT NULL DEFAULT '',feature_snapshot_hash TEXT NOT NULL,anchor_nav_date TEXT NOT NULL DEFAULT '',representative_history_code TEXT NOT NULL DEFAULT '',payload_json TEXT NOT NULL,PRIMARY KEY (prediction_date,fund_code,holding_years))",
            "prediction_outcomes": "CREATE TABLE prediction_outcomes (prediction_date TEXT NOT NULL,fund_code TEXT NOT NULL,holding_years INTEGER NOT NULL,evaluated_at TEXT NOT NULL,target_return REAL,target_drawdown REAL,target_relative_return REAL,payload_json TEXT NOT NULL,PRIMARY KEY (prediction_date,fund_code,holding_years))",
            "prediction_long_term_summary": "CREATE TABLE prediction_long_term_summary (cohort_year TEXT NOT NULL,holding_years INTEGER NOT NULL,asset_class TEXT NOT NULL,sample_count INTEGER NOT NULL,payload_json TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY (cohort_year,holding_years,asset_class))",
            "prediction_cohort_archive": "CREATE TABLE prediction_cohort_archive (prediction_date TEXT NOT NULL,holding_years INTEGER NOT NULL,model_version INTEGER NOT NULL,model_trained_at TEXT NOT NULL DEFAULT '',sample_count INTEGER NOT NULL,payload_json TEXT NOT NULL,archived_at TEXT NOT NULL,PRIMARY KEY (prediction_date,holding_years))",
        }
        for table in legacy_tables:
            legacy = f"{table}__profile_legacy"
            connection.execute(f"DROP TABLE IF EXISTS {legacy}")
            connection.execute(f"ALTER TABLE {table} RENAME TO {legacy}")
            connection.execute(creation_sql[table])
            target_cols, source_cols = tables[table]
            # INSERT OR REPLACE makes any historical non-neutral duplicate harmless; the old
            # neutral profile is ordered last and therefore wins if such duplicates exist.
            connection.execute(
                f"INSERT OR REPLACE INTO {table}({target_cols}) SELECT {source_cols} FROM {legacy} "
                "ORDER BY CASE WHEN profile='均衡' THEN 1 ELSE 0 END"
            )
            connection.execute(f"DROP TABLE {legacy}")
        connection.execute(f"RELEASE SAVEPOINT {savepoint}")
    except sqlite3.Error:
        connection.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
        connection.execute(f"RELEASE SAVEPOINT {savepoint}")
        raise


def _ensure_cache_schema(connection: sqlite3.Connection) -> None:
    """Create/extend the current schema; compatibility upgrades are idempotent, never ordinal."""
    try:
        table_count = int(connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0])
        if table_count == 0:
            connection.execute("PRAGMA auto_vacuum=INCREMENTAL")
    except (sqlite3.Error, TypeError, ValueError):
        pass
    _migrate_retired_ranking_profile_dimension(connection)
    connection.executescript(CACHE_SCHEMA_SQL)
    required_additions = {
        "prediction_outcomes": {
            "target_return": "REAL", "target_drawdown": "REAL", "target_relative_return": "REAL",
        },
    }
    for table, additions in required_additions.items():
        columns = {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})")}
        for column, declaration in additions.items():
            if column not in columns:
                connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")


def _cache_persisted_fingerprint(connection: sqlite3.Connection) -> int:
    row = connection.execute("SELECT value_json FROM runtime_state WHERE key='schema_fingerprint'").fetchone()
    try:
        state_value = int(json.loads(row[0])) if row else 0
    except (TypeError, ValueError, json.JSONDecodeError):
        state_value = 0
    pragma_value = int(connection.execute("PRAGMA user_version").fetchone()[0])
    return state_value if state_value > 0 else pragma_value


def _set_cache_fingerprint(connection: sqlite3.Connection) -> None:
    connection.execute(f"PRAGMA user_version={CACHE_SCHEMA_FINGERPRINT}")
    connection.execute(
        "INSERT INTO runtime_state(key,value_json) VALUES('schema_fingerprint',?) "
        "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
        (json.dumps(CACHE_SCHEMA_FINGERPRINT),),
    )
    connection.execute("DELETE FROM runtime_state WHERE key='version'")


def _migrate_legacy_cache_payloads(connection: sqlite3.Connection) -> None:
    """Idempotently remove retired private-source claims; schema identity is field-derived."""
    private_keys = {
        "availability_declared", "availability_declared_at", "availability_expires_at",
        "availability_sequence", "availability_signature_alg", "availability_schema_version",
    }
    rows = list(connection.execute("SELECT code,payload_json FROM metadata"))
    rewritten = []
    for code, payload_json in rows:
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except json.JSONDecodeError:
            continue
        if not isinstance(payload, dict):
            continue
        changed = False
        for key in private_keys:
            if key in payload:
                payload.pop(key, None)
                changed = True
        if str(payload.get("availability_status") or "") == "confirmed_purchasable":
            payload["availability_status"] = "unknown"
            payload["availability_note"] = "旧版私有源状态已退役；等待公开多源证据重新判定"
            changed = True
        if changed:
            rewritten.append((json.dumps(payload, ensure_ascii=False, separators=(",", ":")), str(code)))
    if rewritten:
        connection.executemany("UPDATE metadata SET payload_json=? WHERE code=?", rewritten)

    history_rows = list(connection.execute(
        "SELECT code,span_from,span_to,purchasable,payload_json FROM availability_history"
    ))
    history_rewritten = []
    for code, span_from, span_to, purchasable, payload_json in history_rows:
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except json.JSONDecodeError:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        evidence = str(payload.get("evidence") or "")
        if "signed" in evidence.lower() or "manifest" in evidence.lower():
            payload["evidence"] = "legacy-availability-observation"
            history_rewritten.append((
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                str(code), str(span_from), str(span_to), int(purchasable),
            ))
    if history_rewritten:
        connection.executemany(
            "UPDATE availability_history SET payload_json=? WHERE code=? AND span_from=? AND span_to=? AND purchasable=?",
            history_rewritten,
        )


def migrate_cache(connection: sqlite3.Connection) -> None:
    """Normalize any older compatible cache to the field-derived current schema fingerprint."""
    with connection:
        _ensure_cache_schema(connection)
        _migrate_legacy_cache_payloads(connection)
        _set_cache_fingerprint(connection)

def _configure_sqlite_connection(connection: sqlite3.Connection, *, durable: bool = False) -> None:
    journal = SQLITE_JOURNAL_MODE if SQLITE_JOURNAL_MODE in {"WAL", "DELETE"} else "DELETE"
    synchronous = "FULL" if durable or SQLITE_NORMAL_SYNCHRONOUS == "FULL" else "NORMAL"
    connection.execute(f"PRAGMA journal_mode={journal}")
    connection.execute(f"PRAGMA synchronous={synchronous}")


class LocalStore:
    def __init__(self):
        self.read_only_survival_bootstrap = _storage_survival_mode_active()
        if self.read_only_survival_bootstrap:
            self.cache = {
                "schema_fingerprint": CACHE_SCHEMA_FINGERPRINT, "updated_at": None,
                "last_full_nav_refresh_at": None, "funds": {}, "fund_master": {},
            }
            self.model = self._load_model_read_only()
        else:
            self.cache = self._load_cache()
            self.model = self._load_model()

    @staticmethod
    def _quarantine_cache(reason: str) -> None:
        """Atomically move only a proven-corrupt SQLite database aside inside the selected folder."""
        with _STORAGE_COMMIT_LOCK:
            _assert_isolated_app_path(CACHE_PATH)
            _assert_isolated_app_path(CACHE_ROLLBACK_PATH)
            pairs = [
                (CACHE_PATH, CACHE_ROLLBACK_PATH),
                (Path(str(CACHE_PATH) + "-wal"), Path(str(CACHE_ROLLBACK_PATH) + "-wal")),
                (Path(str(CACHE_PATH) + "-shm"), Path(str(CACHE_ROLLBACK_PATH) + "-shm")),
                (Path(str(CACHE_PATH) + "-journal"), Path(str(CACHE_ROLLBACK_PATH) + "-journal")),
            ]
            for source, target in pairs:
                _assert_isolated_app_path(source)
                _assert_isolated_app_path(target)
                if not os.path.lexists(str(source)):
                    continue
                try:
                    if os.path.lexists(str(target)):
                        if _path_is_reparse_or_symlink(target):
                            raise StorageError(f"SQLite rollback 路径不是普通文件：{target}")
                        target.unlink()
                    os.replace(source, target)
                except (OSError, StorageError) as exc:
                    raise StorageError(f"SQLite 损坏库隔离失败：{source} -> {target}: {exc}") from exc
            _record_diagnostic("sqlite-recovery", reason, "StorageError")

    @staticmethod
    def _open_checked_cache(*, quick_check: bool = True) -> sqlite3.Connection:
        """Open SQLite with cancellable lock waiting measured in SQLite lock-duration units."""
        _require_runtime_folder()
        last_error = None
        lock_started = None
        lock_streak = 0
        corruption_recovery_used = False
        while True:
            if _cancel_requested():
                raise concurrent.futures.CancelledError("程序正在退出")
            connection = None
            try:
                _assert_isolated_app_path(CACHE_PATH)
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-wal"))
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-shm"))
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-journal"))
                # A zero SQLite busy timeout keeps the C call non-blocking; lock waiting happens
                # in this Python loop so the global stop event can interrupt it.
                connection = sqlite3.connect(CACHE_PATH, timeout=0.0)
                try:
                    table_count = int(connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0])
                    if table_count == 0:
                        connection.execute("PRAGMA auto_vacuum=INCREMENTAL")
                except (sqlite3.Error, TypeError, ValueError):
                    pass
                connection.execute("PRAGMA temp_store=MEMORY")
                if quick_check:
                    rows = connection.execute("PRAGMA quick_check").fetchall()
                    messages = [str(row[0]) for row in rows if row]
                    if not messages or any(message.lower() != "ok" for message in messages):
                        raise sqlite3.DatabaseError("PRAGMA quick_check: " + "; ".join(messages))
                if lock_started is not None:
                    _record_operation_duration("sqlite_lock_wait", time.monotonic() - lock_started)
                return connection
            except sqlite3.OperationalError as exc:
                last_error = exc
                if connection is not None:
                    try:
                        connection.close()
                    except sqlite3.Error:
                        pass
                text = str(exc).lower()
                if "locked" in text or "busy" in text:
                    if lock_started is None:
                        lock_started = time.monotonic()
                    lock_streak += 1
                    observed = _adaptive_operation_timeout("sqlite_lock_wait")
                    scheduler_tick = max(time.get_clock_info("monotonic").resolution, sys.getswitchinterval())
                    delay = min(scheduler_tick * max(1, lock_streak), observed)
                    if _sleep_interruptible(delay):
                        raise concurrent.futures.CancelledError("程序正在退出")
                    continue
                corruption_markers = (
                    "malformed", "disk image is malformed", "file is not a database",
                    "database corruption", "database schema is corrupt",
                )
                if any(marker in text for marker in corruption_markers) and not corruption_recovery_used and os.path.lexists(str(CACHE_PATH)):
                    corruption_recovery_used = True
                    LocalStore._quarantine_cache(f"{type(exc).__name__}: {exc}")
                    continue
                break
            except sqlite3.DatabaseError as exc:
                last_error = exc
                if connection is not None:
                    try:
                        connection.close()
                    except sqlite3.Error:
                        pass
                text = str(exc).lower()
                corruption_markers = (
                    "pragma quick_check:", "malformed", "disk image is malformed",
                    "file is not a database", "database corruption", "database schema is corrupt",
                )
                if any(marker in text for marker in corruption_markers) and not corruption_recovery_used and os.path.lexists(str(CACHE_PATH)):
                    corruption_recovery_used = True
                    LocalStore._quarantine_cache(f"{type(exc).__name__}: {exc}")
                    continue
                break
            except (OSError, StorageError) as exc:
                last_error = exc
                if connection is not None:
                    try:
                        connection.close()
                    except sqlite3.Error:
                        pass
                break
        raise StorageError(f"SQLite 自检/恢复失败：{CACHE_PATH}: {last_error}") from last_error

    @staticmethod
    def _load_cache() -> dict:
        empty = {"schema_fingerprint": CACHE_SCHEMA_FINGERPRINT, "updated_at": None, "last_full_nav_refresh_at": None, "funds": {}, "fund_master": {}}
        try:
            connection = LocalStore._open_checked_cache(quick_check=False)
            connection.row_factory = sqlite3.Row
            try:
                _configure_sqlite_connection(connection)
                _ensure_cache_schema(connection)
                persisted_version = _cache_persisted_fingerprint(connection)
                if persisted_version != CACHE_SCHEMA_FINGERPRINT:
                    migrate_cache(connection)
                state = {}
                for row in connection.execute("SELECT key, value_json FROM runtime_state"):
                    try:
                        state[row["key"]] = json.loads(row["value_json"])
                    except (TypeError, json.JSONDecodeError):
                        pass
                _restore_storage_growth_samples(state.get("storage_growth_samples"))
                funds = {}
                for row in connection.execute("SELECT code, payload_json FROM metadata"):
                    try:
                        payload = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    funds[row["code"]] = payload if isinstance(payload, dict) else {}
                persisted_context_counts = {
                    (str(row[0]), str(row[1]), str(row[2])): int(row[3])
                    for row in connection.execute(
                        "SELECT asset_bucket, source_family, session_date, observation_count "
                        "FROM market_session_context ORDER BY asset_bucket, source_family, session_date"
                    )
                }
                _merge_observed_market_session_context_counts(persisted_context_counts)
                # Historical NAV rows stay normalized in SQLite. They are hydrated in bounded
                # code batches only when ranking/training actually needs them.
                for row in connection.execute(
                    "SELECT code, payload_json FROM availability_history ORDER BY code, span_from, span_to"
                ):
                    try:
                        span = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    funds.setdefault(row["code"], {})
                    funds[row["code"]].setdefault("availability_history", []).append(span)
                master = {}
                for row in connection.execute("SELECT code, payload_json FROM fund_master"):
                    try:
                        payload = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    if isinstance(payload, dict):
                        master[row["code"]] = payload
                return {
                    "schema_fingerprint": CACHE_SCHEMA_FINGERPRINT,
                    "updated_at": state.get("updated_at"),
                    "last_full_nav_refresh_at": state.get("last_full_nav_refresh_at"),
                    "funds": funds,
                    "fund_master": master,
                }
            finally:
                connection.close()
        except StorageError:
            raise
        except (OSError, sqlite3.Error, ValueError, TypeError) as exc:
            _record_diagnostic("sqlite-load", exc)
            return empty

    def load_history_for_codes(self, codes, start_date: str | None = None) -> dict[str, dict]:
        """Load normalized NAV history only for requested codes; SQLite remains the historical truth source."""
        normalized = sorted({str(code) for code in (codes or []) if _valid_fund_code(code)})
        if not normalized:
            return {}
        output: dict[str, dict] = {}
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            start_date_text = str(start_date)[:DATE_TEXT_LENGTH] if start_date else ""
            valid_start_date = bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", start_date_text))
            try:
                sqlite_variable_limit = int(connection.getlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER))
            except (AttributeError, sqlite3.Error, TypeError, ValueError):
                sqlite_variable_limit = 1
            batch_size = max(1, sqlite_variable_limit - int(valid_start_date))
            for offset in range(0, len(normalized), batch_size):
                batch = normalized[offset:offset + batch_size]
                placeholders = ",".join("?" for _ in batch)
                params: list = list(batch)
                where = f"code IN ({placeholders})"
                if valid_start_date:
                    where += " AND nav_date >= ?"
                    params.append(start_date_text)
                for code, nav_date, daily_return in connection.execute(
                    f"SELECT code,nav_date,daily_return FROM nav_returns WHERE {where} ORDER BY code,nav_date",
                    tuple(params),
                ):
                    row = output.setdefault(str(code), {"dates": [], "returns": []})
                    row["dates"].append(str(nav_date))
                    row["returns"].append(float(daily_return))
        finally:
            connection.close()
        return output

    def commit_latest_rows(self, latest: dict[str, dict], codes: set[str] | None = None) -> dict:
        """Append validated latest NAV returns directly to SQLite without hydrating full histories."""
        allowed = None if codes is None else {str(code) for code in codes}
        rows = {
            str(code): row for code, row in (latest or {}).items()
            if isinstance(row, dict) and _valid_fund_code(code)
            and (allowed is None or str(code) in allowed)
        }
        if not rows:
            return {"updated_series": 0, "same_day_updates": 0, "pending_adjustments": 0}
        _require_storage_write_capacity("最新净值缓存")
        before_storage = _storage_footprint_bytes()
        funds = self.cache.get("funds") if isinstance(self.cache.get("funds"), dict) else {}
        updated_series = 0
        same_day_updates = 0
        pending_adjustments = 0
        with _STORAGE_COMMIT_LOCK:
            connection = self._open_checked_cache(quick_check=False)
            try:
                _ensure_cache_schema(connection)
                with connection:
                    for code, row in rows.items():
                        cached = funds.get(code) if isinstance(funds.get(code), dict) else None
                        if cached is None:
                            continue
                        old_date = str(cached.get("latest_date") or "")[:DATE_TEXT_LENGTH]
                        old_nav = _finite(cached.get("latest_nav"), float("nan"))
                        new_date = str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH]
                        new_nav = _finite(row.get("nav"), float("nan"))
                        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", new_date) or not math.isfinite(new_nav) or new_nav <= 0:
                            continue

                        cached["display_nav"] = new_nav
                        cached["display_nav_date"] = new_date
                        if row.get("nav_decimals") is not None:
                            cached["display_nav_decimals"] = int(row.get("nav_decimals"))
                        if new_date > old_date and math.isfinite(old_nav) and old_nav > 0:
                            nav_return = new_nav / old_nav - 1.0
                            source_day = _finite(row.get("day_change"), float("nan"))
                            source_return = source_day / PERCENT_SCALE if math.isfinite(source_day) else float("nan")
                            agreed = math.isfinite(source_return) and abs(source_return - nav_return) <= RETURN_AGREEMENT_NUMERIC_TOLERANCE * max(1.0, abs(source_return))
                            if agreed:
                                connection.execute(
                                    "INSERT INTO nav_returns(code,nav_date,daily_return) VALUES(?,?,?) "
                                    "ON CONFLICT(code,nav_date) DO UPDATE SET daily_return=excluded.daily_return",
                                    (code, new_date, float(max(-1.0 + sys.float_info.epsilon, nav_return))),
                                )
                                cached["latest_nav"] = new_nav
                                cached["latest_date"] = new_date
                                if row.get("nav_decimals") is not None:
                                    cached["latest_nav_decimals"] = int(row.get("nav_decimals"))
                                cached["return_pending_adjustment"] = False
                                cached["updated_at"] = _now_iso()
                                cached["_nav_series_count"] = int(_finite(cached.get("_nav_series_count"), 0)) + 1
                                updated_series += 1
                            else:
                                cached["return_pending_adjustment"] = True
                                pending_adjustments += 1
                        elif new_date == old_date:
                            cached["latest_nav"] = new_nav
                            if row.get("nav_decimals") is not None:
                                cached["latest_nav_decimals"] = int(row.get("nav_decimals"))
                            same_day_updates += 1

                        metadata = {
                            key: value for key, value in cached.items()
                            if key not in ("dates", "returns", "availability_history")
                        }
                        connection.execute(
                            "INSERT INTO metadata(code,payload_json) VALUES(?,?) "
                            "ON CONFLICT(code) DO UPDATE SET payload_json=excluded.payload_json",
                            (code, json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))),
                        )
            finally:
                connection.close()
        _record_storage_growth(before_storage)
        return {
            "updated_series": updated_series,
            "same_day_updates": same_day_updates,
            "pending_adjustments": pending_adjustments,
        }

    def load_working_set_codes(self, holding_years: int) -> list[str]:
        """Restore the last data-driven ranked foreground cohort without inventing a fixed rank cap."""
        years = _expected_holding_years(holding_years)
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            latest = connection.execute(
                "SELECT MAX(prediction_date) FROM ranking_predictions WHERE holding_years=?",
                (years,),
            ).fetchone()
            prediction_date = str(latest[0] or "") if latest else ""
            rows = []
            if prediction_date:
                rows = list(connection.execute(
                    "SELECT fund_code FROM ranking_predictions "
                    "WHERE prediction_date=? AND holding_years=? "
                    "ORDER BY predicted_rank",
                    (prediction_date, years),
                ))
            if len(rows) < DISPLAY_TOP_N:
                rows = list(connection.execute(
                    "SELECT fund_code FROM formal_ranking WHERE holding_years=? ORDER BY rank",
                    (years,),
                ))
        finally:
            connection.close()
        return [str(row[0]) for row in rows if _valid_fund_code(row[0])]



    @staticmethod
    def check_cache_fast_integrity() -> None:
        """Startup gate: verify SQLite can open its schema without scanning every database page."""
        connection = LocalStore._open_checked_cache(quick_check=False)
        try:
            connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()
            connection.execute("PRAGMA schema_version").fetchone()
            connection.execute("PRAGMA user_version").fetchone()
        finally:
            connection.close()

    @staticmethod
    def check_cache_integrity() -> None:
        connection = LocalStore._open_checked_cache(quick_check=True)
        connection.close()

    def load_history_rebuild_checkpoint(self) -> dict:
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            row = connection.execute(
                "SELECT value_json FROM runtime_state WHERE key='history_rebuild_checkpoint'"
            ).fetchone()
        finally:
            connection.close()
        if not row:
            return {}
        try:
            payload = json.loads(row[0])
        except (TypeError, json.JSONDecodeError):
            return {}
        return dict(payload) if isinstance(payload, dict) else {}

    def save_history_rebuild_checkpoint(self, payload: dict | None) -> None:
        _require_storage_write_capacity("历史扫描检查点")
        with _STORAGE_COMMIT_LOCK:
            connection = self._open_checked_cache(quick_check=False)
            try:
                _configure_sqlite_connection(connection)
                _ensure_cache_schema(connection)
                with connection:
                    if payload:
                        connection.execute(
                            "INSERT INTO runtime_state(key,value_json) VALUES('history_rebuild_checkpoint',?) "
                            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
                            (json.dumps(dict(payload), ensure_ascii=False, separators=(",", ":"), default=str),),
                        )
                    else:
                        connection.execute("DELETE FROM runtime_state WHERE key='history_rebuild_checkpoint'")
            finally:
                connection.close()

    def next_prediction_maturity_at(self, now: _dt.datetime | None = None) -> _dt.datetime | None:
        """Return the earliest future cohort maturity at the factual market-close boundary."""
        now_cn = (now or _dt.datetime.now(tz=CHINA_TZ)).astimezone(CHINA_TZ)
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            rows = list(connection.execute(
                "SELECT DISTINCT p.anchor_nav_date,p.holding_years "
                "FROM ranking_predictions p LEFT JOIN prediction_outcomes o "
                "ON p.prediction_date=o.prediction_date AND p.fund_code=o.fund_code "
                "AND p.holding_years=o.holding_years "
                "WHERE o.target_return IS NULL"
            ))
        finally:
            connection.close()
        candidates = []
        for anchor_text, holding_years in rows:
            text = str(anchor_text or "")[:DATE_TEXT_LENGTH]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
                continue
            try:
                anchor_day = _dt.date.fromisoformat(text)
            except ValueError:
                continue
            maturity_day = _add_years(anchor_day, _expected_holding_years(holding_years))
            maturity_at = _dt.datetime.combine(maturity_day, MARKET_CLOSE, tzinfo=CHINA_TZ)
            if maturity_at > now_cn:
                candidates.append(maturity_at)
        return min(candidates) if candidates else None

    def maintain_prediction_retention(self) -> dict:
        """Archive fully mature cohorts after two-model absorption or one extra target horizon."""
        connection = self._open_checked_cache(quick_check=False)
        archived = 0
        deleted_predictions = 0
        deleted_outcomes = 0
        try:
            _ensure_cache_schema(connection)
            current_seen = set(self.model.get("feedback_cohorts_seen") or []) if isinstance(self.model, dict) else set()
            rollback_model = _read_json(MODEL_ROLLBACK_PATH, {}) if MODEL_ROLLBACK_PATH.exists() else {}
            rollback_seen = set(rollback_model.get("feedback_cohorts_seen") or []) if isinstance(rollback_model, dict) else set()
            doubly_absorbed = current_seen & rollback_seen

            cohorts = []
            for prediction_date, years in connection.execute(
                "SELECT p.prediction_date,p.holding_years "
                "FROM ranking_predictions p LEFT JOIN prediction_outcomes o "
                "USING(prediction_date,fund_code,holding_years) "
                "GROUP BY p.prediction_date,p.holding_years "
                "HAVING COUNT(*) > 0 AND SUM(CASE WHEN o.target_return IS NOT NULL THEN 1 ELSE 0 END)=COUNT(*)"
            ):
                date_text, years = str(prediction_date), int(years)
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_text):
                    continue
                cohort_id = json.dumps([date_text, years], ensure_ascii=False, separators=(",", ":"))
                absorbed = cohort_id in doubly_absorbed
                try:
                    old_enough = _china_today() >= _add_years(_add_years(_dt.date.fromisoformat(date_text), years), years)
                except ValueError:
                    old_enough = False
                if absorbed or old_enough:
                    cohorts.append((date_text, years, cohort_id))

            with _STORAGE_COMMIT_LOCK, connection:
                for prediction_date, years, cohort_id in sorted(cohorts):
                    counts = connection.execute(
                        "SELECT COUNT(*),SUM(CASE WHEN o.target_return IS NOT NULL THEN 1 ELSE 0 END) "
                        "FROM ranking_predictions p LEFT JOIN prediction_outcomes o "
                        "USING(prediction_date,fund_code,holding_years) "
                        "WHERE p.prediction_date=? AND p.holding_years=?",
                        (prediction_date, years),
                    ).fetchone()
                    total = int((counts or [0])[0] or 0)
                    mature = int((counts or [0, 0])[1] or 0)
                    if total <= 0 or mature != total:
                        continue
                    rows = list(connection.execute(
                        "SELECT p.predicted_rank,p.raw_score,p.feature_snapshot_hash,p.payload_json,"
                        "p.model_version,p.model_trained_at,o.target_return,o.target_drawdown,o.target_relative_return,o.payload_json "
                        "FROM ranking_predictions p JOIN prediction_outcomes o "
                        "USING(prediction_date,fund_code,holding_years) "
                        "WHERE p.prediction_date=? AND p.holding_years=?",
                        (prediction_date, years),
                    ))
                    if not rows:
                        continue

                    parsed = []
                    feature_hashes = []
                    for row in rows:
                        try:
                            prediction_payload = json.loads(row[3]) if row[3] else {}
                        except json.JSONDecodeError:
                            prediction_payload = {}
                        try:
                            outcome_payload = json.loads(row[9]) if row[9] else {}
                        except json.JSONDecodeError:
                            outcome_payload = {}
                        prediction_payload = prediction_payload if isinstance(prediction_payload, dict) else {}
                        outcome_payload = outcome_payload if isinstance(outcome_payload, dict) else {}
                        feature_hashes.append(str(row[2] or ""))
                        parsed.append({
                            "rank": int(row[0]), "raw": _finite(row[1]), "payload": prediction_payload,
                            "role": str(prediction_payload.get("sample_role") or "legacy_display"),
                            "target": _finite(row[6]), "drawdown": _finite(row[7], float("nan")),
                            "relative": _finite(row[8], float("nan")),
                            "outcome_history_code": str(outcome_payload.get("outcome_history_code") or ""),
                        })

                    def cohort_ic(getter) -> tuple[float, int]:
                        pairs = []
                        for item in parsed:
                            signal = _finite(getter(item), float("nan"))
                            target = _finite(item.get("target"), float("nan"))
                            if math.isfinite(signal) and math.isfinite(target):
                                pairs.append((signal, target))
                        if len(pairs) < MIN_HISTORY_POINTS:
                            return 0.0, 0
                        xs, ys = zip(*pairs)
                        return _pearson(_rank_scale(xs), _rank_scale(ys)), len(pairs)

                    rank_ic, samples = cohort_ic(lambda item: item["raw"])
                    long_ic, _long_samples = cohort_ic(lambda item: _finite((item.get("payload") or {}).get("long_raw_score"), float("nan")))
                    component_ic = {}
                    for name in ("expert", "linear", "nonlinear", "external", "tree2"):
                        ic, component_samples = cohort_ic(
                            lambda item, n=name: _finite(((item.get("payload") or {}).get("component_scores") or {}).get(n), float("nan"))
                        )
                        if component_samples:
                            component_ic[name] = {"rank_ic": ic, "samples": component_samples, "cohorts": 1}

                    displayed = sorted((item for item in parsed if item["role"] == "display_top100"), key=lambda item: item["rank"])
                    controls = [item for item in parsed if item["role"] == "control"]
                    top100_return = statistics.fmean(item["target"] for item in displayed[:DISPLAY_TOP_N]) if len(displayed) >= DISPLAY_TOP_N else None
                    benchmark_return = statistics.fmean(item["target"] for item in controls[:DISPLAY_TOP_N]) if len(controls) >= DISPLAY_TOP_N else None
                    display_excess = (top100_return - benchmark_return) if top100_return is not None and benchmark_return is not None else None
                    drawdowns = [item["drawdown"] for item in displayed[:DISPLAY_TOP_N] if math.isfinite(item["drawdown"])]
                    outcome_codes = sorted({item["outcome_history_code"] for item in parsed if _valid_fund_code(item["outcome_history_code"])})
                    payload = {
                        "prediction_date": prediction_date, "holding_years": years,
                        "feedback": {
                            "samples": samples, "cohorts": 1, "rank_ic": rank_ic,
                            "long_signal_ic": long_ic, "long_samples": _long_samples, "display_excess": display_excess,
                            "component_ic": component_ic, "mature_cohort_id": cohort_id,
                        },
                        "top100_return": top100_return, "benchmark_return": benchmark_return,
                        "drawdown": statistics.fmean(drawdowns) if drawdowns else None,
                        "sample_count": total,
                        "feature_distribution_digest": hashlib.sha256(
                            "\n".join(sorted(feature_hashes)).encode("ascii", "ignore")
                        ).hexdigest(),
                        "outcome_history_code_digest": hashlib.sha256(
                            "\n".join(outcome_codes).encode("ascii", "ignore")
                        ).hexdigest(),
                        "retention_policy": "raw-through-maturity; archive after champion+rollback absorption or one additional target horizon",
                    }
                    model_version = int(rows[0][4])
                    model_trained_at = str(rows[0][5] or "")
                    connection.execute(
                        "INSERT INTO prediction_cohort_archive("
                        "prediction_date,holding_years,model_version,model_trained_at,sample_count,payload_json,archived_at) "
                        "VALUES(?,?,?,?,?,?,?) ON CONFLICT(prediction_date,holding_years) DO UPDATE SET "
                        "model_version=excluded.model_version,model_trained_at=excluded.model_trained_at,"
                        "sample_count=excluded.sample_count,payload_json=excluded.payload_json,archived_at=excluded.archived_at",
                        (prediction_date, years, model_version, model_trained_at, total,
                         json.dumps(payload, ensure_ascii=False, separators=(",", ":")), _now_iso()),
                    )
                    deleted_outcomes += connection.execute(
                        "DELETE FROM prediction_outcomes WHERE prediction_date=? AND holding_years=?",
                        (prediction_date, years),
                    ).rowcount
                    deleted_predictions += connection.execute(
                        "DELETE FROM ranking_predictions WHERE prediction_date=? AND holding_years=?",
                        (prediction_date, years),
                    ).rowcount
                    archived += 1

            prediction_count = int(connection.execute("SELECT COUNT(*) FROM ranking_predictions").fetchone()[0])
            outcome_count = int(connection.execute("SELECT COUNT(*) FROM prediction_outcomes").fetchone()[0])
            archive_count = int(connection.execute("SELECT COUNT(*) FROM prediction_cohort_archive").fetchone()[0])
            try:
                connection.execute("PRAGMA incremental_vacuum")
                connection.execute("PRAGMA optimize")
            except sqlite3.Error as exc:
                _record_diagnostic("prediction-retention-optimize", exc, "SQLiteMaintenanceError")
            return {
                "policy": "raw-through-maturity; archive after champion+rollback absorption or one additional target horizon",
                "prediction_rows": prediction_count, "outcome_rows": outcome_count,
                "archived_cohorts": archive_count, "archived_this_run": archived,
                "deleted_predictions": deleted_predictions, "deleted_outcomes": deleted_outcomes,
            }
        finally:
            connection.close()

    def maintain_history_storage(self) -> dict:
        """Preserve all observed NAV history; report storage health and reclaim only already-free pages."""
        import shutil
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            try:
                connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                connection.execute("PRAGMA optimize")
            except sqlite3.Error:
                pass
            try:
                page_count = int(connection.execute("PRAGMA page_count").fetchone()[0])
                freelist_count = int(connection.execute("PRAGMA freelist_count").fetchone()[0])
                page_size = int(connection.execute("PRAGMA page_size").fetchone()[0])
                nav_rows = int(connection.execute("SELECT COUNT(*) FROM nav_returns").fetchone()[0])
            except (sqlite3.Error, TypeError, ValueError):
                page_count = freelist_count = page_size = nav_rows = 0
        finally:
            connection.close()
        try:
            db_bytes = CACHE_PATH.stat().st_size if CACHE_PATH.exists() else 0
        except OSError:
            db_bytes = 0
        try:
            wal_path = Path(str(CACHE_PATH) + "-wal")
            wal_bytes = wal_path.stat().st_size if wal_path.exists() else 0
        except OSError:
            wal_bytes = 0
        try:
            free_disk_bytes = int(shutil.disk_usage(BASE_DIR).free)
        except OSError:
            free_disk_bytes = 0
        return {
            "retention_policy": "nav=all-observed-history; predictions=raw-through-maturity+cohort-archive",
            "nav_rows": nav_rows, "db_bytes": db_bytes, "wal_bytes": wal_bytes,
            "free_disk_bytes": free_disk_bytes, "freelist_bytes": freelist_count * page_size,
            "page_count": page_count,
            "low_disk": _objective_disk_pressure(free_disk_bytes),
        }


    def compact_cache_database(self, *, disk_pressure: bool = False) -> dict:
        """Release SQLite free pages safely; convert legacy DBs to incremental vacuum only when scratch space permits."""
        import shutil
        result = {"attempted": False, "method": "none", "released_bytes": 0, "reason": "not-needed"}
        with _STORAGE_COMMIT_LOCK:
            connection = self._open_checked_cache(quick_check=False)
            try:
                _ensure_cache_schema(connection)
                try:
                    connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                except sqlite3.Error:
                    pass
                try:
                    connection.execute("PRAGMA optimize")
                except sqlite3.Error:
                    pass
                page_count = int(connection.execute("PRAGMA page_count").fetchone()[0])
                freelist_count = int(connection.execute("PRAGMA freelist_count").fetchone()[0])
                page_size = int(connection.execute("PRAGMA page_size").fetchone()[0])
                auto_vacuum = int(connection.execute("PRAGMA auto_vacuum").fetchone()[0])
                freelist_bytes = max(0, freelist_count * page_size)
                db_bytes_before = CACHE_PATH.stat().st_size if CACHE_PATH.exists() else page_count * page_size
                ratio = freelist_count / max(1, page_count)
                # Reclaim when free pages are material relative to the database itself; under
                # measured disk pressure, any reclaimable page is useful.
                should_compact = bool(
                    freelist_count > 0
                    and (disk_pressure or freelist_count >= max(1, math.isqrt(max(1, page_count))))
                )
                result.update({
                    "db_bytes_before": db_bytes_before,
                    "freelist_bytes_before": freelist_bytes,
                    "freelist_ratio_before": ratio,
                    "auto_vacuum_before": auto_vacuum,
                })
                if not should_compact or freelist_count <= 0:
                    return result
                result["attempted"] = True
                if auto_vacuum == 2:
                    # Incremental mode releases end-of-file free pages without requiring a second full DB copy.
                    pages = freelist_count
                    connection.execute(f"PRAGMA incremental_vacuum({max(1, int(pages))})")
                    result["method"] = "incremental_vacuum"
                    result["reason"] = "disk-pressure" if disk_pressure else "freelist-threshold"
                else:
                    try:
                        free_disk = int(shutil.disk_usage(BASE_DIR).free)
                    except OSError:
                        free_disk = 0
                    # SQLite VACUUM rebuilds the database; require room for one additional full copy.
                    scratch_required = db_bytes_before * 2
                    if free_disk and free_disk >= scratch_required:
                        # Setting auto_vacuum on a populated legacy database only takes effect after VACUUM.
                        connection.execute("PRAGMA auto_vacuum=INCREMENTAL")
                        connection.execute("VACUUM")
                        result["method"] = "full_vacuum_enable_incremental"
                        result["reason"] = "legacy-auto-vacuum-conversion"
                    else:
                        result["method"] = "skipped-full-vacuum"
                        result["reason"] = "insufficient-scratch-space"
                try:
                    connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                except sqlite3.Error:
                    pass
                try:
                    db_bytes_after = CACHE_PATH.stat().st_size if CACHE_PATH.exists() else 0
                except OSError:
                    db_bytes_after = 0
                result["db_bytes_after"] = db_bytes_after
                result["released_bytes"] = max(0, db_bytes_before - db_bytes_after)
                result["auto_vacuum_after"] = int(connection.execute("PRAGMA auto_vacuum").fetchone()[0])
                return result
            except sqlite3.Error as exc:
                result["reason"] = f"sqlite-error:{type(exc).__name__}"
                _record_diagnostic("sqlite-compact", exc, "StorageError")
                return result
            finally:
                connection.close()

    def save_formal_ranking(self, results: list[dict], holding_years: int, model: dict, gate: dict) -> None:
        """Atomically replace the last-known-good Top100 snapshot for one holding horizon."""
        rows = _validate_formal_results(list(results or []))
        years = _expected_holding_years(holding_years, model)
        validated_at = str((gate or {}).get("checked_at") or _now_iso())
        validation_json = json.dumps(dict(gate or {}), ensure_ascii=False, separators=(",", ":"), default=str)
        payloads = []
        for rank, item in enumerate(rows, 1):
            code = str(item.get("code") or "")
            if not _valid_fund_code(code):
                raise StorageError(f"正式排名包含非法基金代码：{code!r}")
            # Formal snapshots are UI/rollback state, not a second copy of historical NAV arrays.
            # Keep all ranking/detail fields while excluding bulk histories already persisted in normalized tables.
            bulk_keys = {
                "dates", "returns", "availability_history", "catalog_history",
                "product_features_history", "fees_history", "return_corporate_actions",
                "return_provider_fallbacks", "feature_vector", "scaled", "model_evidence_inputs",
            }
            payload = {key: value for key, value in item.items() if key not in bulk_keys}
            payload["ranking_rank"] = rank
            payloads.append((
                years, rank, code, int(model.get("schema_fingerprint") or MODEL_SCHEMA_FINGERPRINT),
                validated_at, validation_json,
                json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str),
            ))
        _require_storage_write_capacity("正式排名快照")
        before_storage = _storage_footprint_bytes()
        with _STORAGE_COMMIT_LOCK:
            connection = self._open_checked_cache(quick_check=False)
            try:
                # formal_ranking is last-known-good state, so make this rare commit more durable than normal NAV checkpoints.
                _configure_sqlite_connection(connection, durable=True)
                _ensure_cache_schema(connection)
                with connection:
                    connection.execute(
                        "DELETE FROM formal_ranking WHERE holding_years=?",
                        (years,),
                    )
                    connection.executemany(
                        "INSERT INTO formal_ranking(holding_years,rank,fund_code,model_version,validated_at,validation_json,payload_json) "
                        "VALUES(?,?,?,?,?,?,?)",
                        payloads,
                    )
                try:
                    checkpoint = connection.execute("PRAGMA wal_checkpoint(FULL)").fetchone()
                    if checkpoint and int(checkpoint[0] or 0) != 0:
                        _record_diagnostic("formal-ranking-checkpoint", f"WAL checkpoint busy: {tuple(checkpoint)}", "SQLiteBusy")
                except sqlite3.Error as exc:
                    _record_diagnostic("formal-ranking-checkpoint", exc)
            finally:
                connection.close()
        _record_storage_growth(before_storage)

    def load_formal_ranking(self, holding_years: int) -> dict | None:
        """Load an immutable last-known-good snapshot instead of recomputing from mutable candidates."""
        years = _expected_holding_years(holding_years)
        read_only = _storage_survival_mode_active()
        if read_only:
            try:
                if not CACHE_PATH.exists():
                    return None
                connection = sqlite3.connect(CACHE_PATH.resolve().as_uri() + "?mode=ro", uri=True, timeout=0.0)
            except (OSError, sqlite3.Error):
                return None
        else:
            connection = self._open_checked_cache(quick_check=False)
        try:
            if not read_only:
                _ensure_cache_schema(connection)
            rows = list(connection.execute(
                "SELECT rank,fund_code,model_version,validated_at,validation_json,payload_json FROM formal_ranking "
                "WHERE holding_years=? ORDER BY rank",
                (years,),
            ))
        except sqlite3.Error:
            return None
        finally:
            connection.close()
        if not 1 <= len(rows) <= DISPLAY_TOP_N or [int(row[0]) for row in rows] != list(range(1, len(rows) + 1)):
            return None
        if any(int(_finite(row[2], -1)) != MODEL_SCHEMA_FINGERPRINT for row in rows):
            # Keep the historical SQLite row intact, but never display a formal snapshot produced by older ranking semantics.
            return None
        decoded = []
        for rank, code, _model_version, _validated_at, _validation_json, payload_json in rows:
            try:
                payload = json.loads(payload_json)
            except (TypeError, json.JSONDecodeError):
                return None
            if not isinstance(payload, dict) or str(payload.get("code") or "") != str(code):
                return None
            payload["ranking_rank"] = int(rank)
            decoded.append(payload)
        try:
            gate = json.loads(rows[0][4]) if rows[0][4] else {}
        except (TypeError, json.JSONDecodeError):
            gate = {}
        gate = dict(gate) if isinstance(gate, dict) else {}
        gate.setdefault("checked_at", str(rows[0][3] or ""))
        return {"rows": _validate_formal_results(decoded), "gate": gate}

    def record_ranking_predictions(self, results: list[dict], holding_years: int, model: dict) -> int:
        """Persist the displayed Top100 plus data-driven boundary challengers as one daily cohort."""
        if not results or _cancel_requested():
            return 0
        prediction_date = _china_today().isoformat()
        rows = []
        for rank, item in enumerate(results, 1):
            code = str(item.get("code") or "")
            if not _valid_fund_code(code):
                continue
            feature_vector = item.get("feature_vector") if isinstance(item.get("feature_vector"), list) else []
            feature_hash = hashlib.sha256(json.dumps(
                [round(_finite(value), FLOAT_SERIALIZATION_DIGITS) for value in feature_vector], separators=(",", ":"), ensure_ascii=True,
            ).encode("utf-8")).hexdigest()
            payload = {
                "long_raw_score": _finite(item.get("long_raw_score")),
                "component_scores": dict(item.get("model_component_scores") or {}),
                "long_term_blend": _finite(model.get("long_term_blend"), PROBABILITY_MIDPOINT),
                "component_weights": dict(model.get("component_weights") or {}),
                "model_status": str(model.get("model_status") or ""),
                "asset_class": str(item.get("asset_class") or ""),
                "sample_role": str(item.get("prediction_sample_role") or "display_top100"),
            }
            anchor_nav_date = str(item.get("latest_date") or item.get("display_nav_date") or "")[:DATE_TEXT_LENGTH]
            representative = str(item.get("representative_history_code") or code)
            rows.append((
                prediction_date, code, int(holding_years), int(item.get("ranking_rank") or rank),
                float(_finite(item.get("raw_score"))), int(model.get("schema_fingerprint") or MODEL_SCHEMA_FINGERPRINT),
                str(model.get("trained_at") or ""), feature_hash, anchor_nav_date, representative,
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            ))
        if not rows:
            return 0
        _require_storage_write_capacity("排名预测快照")
        before_storage = _storage_footprint_bytes()
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            with _STORAGE_COMMIT_LOCK, connection:
                # Replace the whole same-day cohort atomically so stale boundary challengers or
                # superseded rankings cannot survive a later refresh on the same day.
                connection.execute(
                    "DELETE FROM ranking_predictions WHERE prediction_date=? AND holding_years=?",
                    (prediction_date, int(holding_years)),
                )
                connection.execute(
                    "DELETE FROM prediction_outcomes WHERE prediction_date=? AND holding_years=?",
                    (prediction_date, int(holding_years)),
                )
                connection.executemany(
                    "INSERT INTO ranking_predictions("
                    "prediction_date,fund_code,holding_years,predicted_rank,raw_score,model_version,model_trained_at,"
                    "feature_snapshot_hash,anchor_nav_date,representative_history_code,payload_json) VALUES(?,?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(prediction_date,fund_code,holding_years) DO UPDATE SET "
                    "predicted_rank=excluded.predicted_rank,raw_score=excluded.raw_score,model_version=excluded.model_version,"
                    "model_trained_at=excluded.model_trained_at,feature_snapshot_hash=excluded.feature_snapshot_hash,"
                    "anchor_nav_date=excluded.anchor_nav_date,representative_history_code=excluded.representative_history_code,"
                    "payload_json=excluded.payload_json",
                    rows,
                )
            _record_storage_growth(before_storage)
            return len(rows)
        finally:
            connection.close()

    @staticmethod
    def _prediction_path_outcomes(item: dict, anchor_nav_date: str, holding_years: int) -> dict:
        """Evaluate only the exact deployed target horizon from later persisted NAV."""
        dates = [str(value)[:DATE_TEXT_LENGTH] for value in (item.get("dates") or [])]
        returns = [_finite(value) for value in (item.get("returns") or [])]
        if len(dates) != len(returns) or not dates or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", anchor_nav_date or ""):
            return {}
        try:
            anchor = _dt.date.fromisoformat(anchor_nav_date)
            latest = _dt.date.fromisoformat(dates[-1])
        except ValueError:
            return {}
        target = _add_years(anchor, _expected_holding_years(holding_years))
        if latest < target:
            return {"target_return": None, "target_drawdown": None}
        start_index = bisect.bisect_right(dates, anchor_nav_date)
        end_index = bisect.bisect_right(dates, target.isoformat())
        values = returns[start_index:end_index]
        if len(values) < MIN_HISTORY_POINTS:
            return {"target_return": None, "target_drawdown": None}
        wealth = peak = 1.0
        worst = 0.0
        for value in values:
            value = max(-1.0 + sys.float_info.epsilon, _finite(value))
            wealth *= 1.0 + value
            peak = max(peak, wealth)
            worst = min(worst, wealth / max(peak, sys.float_info.min) - 1.0)
        return {"target_return": wealth - 1.0, "target_drawdown": worst}

    def update_prediction_outcomes(self, funds: list[dict]) -> int:
        """Backfill only the objective matured label matching each prediction's deployed target horizon."""
        if not funds or _cancel_requested():
            return 0
        by_code = {str(item.get("code") or ""): item for item in funds if isinstance(item, dict) and item.get("code")}
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            predictions = list(connection.execute(
                "SELECT prediction_date,fund_code,holding_years,anchor_nav_date,representative_history_code,payload_json "
                "FROM ranking_predictions"
            ))
            previously_mature = {
                (str(row[0]), str(row[1]), int(row[2]))
                for row in connection.execute(
                    "SELECT prediction_date,fund_code,holding_years FROM prediction_outcomes WHERE target_return IS NOT NULL"
                )
            }
            computed = []
            target_cohorts: dict[tuple[str, int], list[int]] = {}
            for row in predictions:
                prediction_date, code, years, anchor_date, representative, payload_json = row
                representative_code = str(representative or "")
                display_code = str(code or "")
                item = None
                outcome_history_code = ""
                if _valid_fund_code(representative_code):
                    item = by_code.get(representative_code)
                    if item is not None:
                        outcome_history_code = representative_code
                if item is None and _valid_fund_code(display_code):
                    item = by_code.get(display_code)
                    if item is not None:
                        outcome_history_code = display_code
                if not item:
                    continue
                years = _expected_holding_years(years)
                values = self._prediction_path_outcomes(item, str(anchor_date or ""), years)
                if not values or all(value is None for value in values.values()):
                    continue
                try:
                    prediction_payload = json.loads(payload_json) if payload_json else {}
                except json.JSONDecodeError:
                    prediction_payload = {}
                record = {
                    "prediction_date": str(prediction_date), "fund_code": str(code),
                    "holding_years": years, **values, "target_relative_return": None,
                    "prediction_payload": prediction_payload if isinstance(prediction_payload, dict) else {},
                    "outcome_history_code": outcome_history_code,
                }
                computed.append(record)
                if values.get("target_return") is not None:
                    target_cohorts.setdefault((str(prediction_date), years), []).append(len(computed) - 1)

            # A target benchmark is valid only when the hidden control set itself reaches the product's Top100 size.
            for indexes in target_cohorts.values():
                control_indexes = [
                    index for index in indexes
                    if str((computed[index].get("prediction_payload") or {}).get("sample_role") or "") == "control"
                ]
                benchmark_indexes = control_indexes if len(control_indexes) >= DISPLAY_TOP_N else indexes
                if not benchmark_indexes:
                    continue
                benchmark = statistics.fmean(_finite(computed[index]["target_return"]) for index in benchmark_indexes)
                for index in indexes:
                    computed[index]["target_relative_return"] = _finite(computed[index]["target_return"]) - benchmark
            if not computed:
                return 0

            now = _now_iso()
            rows = []
            for record in computed:
                payload = {
                    "target_horizon_years": record["holding_years"],
                    "target_mature": record.get("target_return") is not None,
                    "source": "subsequent-persisted-nav-history",
                    "outcome_history_code": str(record.get("outcome_history_code") or ""),
                }
                rows.append((
                    record["prediction_date"], record["fund_code"], record["holding_years"], now,
                    record.get("target_return"), record.get("target_drawdown"), record.get("target_relative_return"),
                    json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                ))
            newly_matured = sum(
                1 for record in computed
                if record.get("target_return") is not None
                and (
                    record["prediction_date"], record["fund_code"], record["holding_years"]
                ) not in previously_mature
            )
            _require_storage_write_capacity("预测结果反馈")
            before_storage = _storage_footprint_bytes()
            with _STORAGE_COMMIT_LOCK, connection:
                connection.executemany(
                    "INSERT INTO prediction_outcomes("
                    "prediction_date,fund_code,holding_years,evaluated_at,target_return,target_drawdown,target_relative_return,payload_json) "
                    "VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(prediction_date,fund_code,holding_years) DO UPDATE SET "
                    "evaluated_at=excluded.evaluated_at,target_return=excluded.target_return,target_drawdown=excluded.target_drawdown,"
                    "target_relative_return=excluded.target_relative_return,payload_json=excluded.payload_json",
                    rows,
                )
            _record_storage_growth(before_storage)
            return newly_matured
        finally:
            connection.close()

    def prediction_feedback_summary(self) -> dict:
        """Summarize target-matched feedback from raw and compressed cohorts with the same dynamic purge policy."""
        connection = self._open_checked_cache(quick_check=False)
        try:
            _ensure_cache_schema(connection)
            rows = list(connection.execute(
                "SELECT p.prediction_date,p.holding_years,p.predicted_rank,p.raw_score,p.payload_json,"
                "o.target_return,o.target_relative_return "
                "FROM ranking_predictions p JOIN prediction_outcomes o USING(prediction_date,fund_code,holding_years) "
                "WHERE o.target_return IS NOT NULL"
            ))
            archived_rows = list(connection.execute(
                "SELECT prediction_date,holding_years,payload_json FROM prediction_cohort_archive"
            ))
        finally:
            connection.close()
        if not rows and not archived_rows:
            return {"target_feedback_by_years": {}, "status": "no-mature-outcomes", "evaluated_at": _now_iso()}

        raw_groups: dict[tuple[str, int], list[dict]] = {}
        for row in rows:
            try:
                payload = json.loads(row[4]) if row[4] else {}
            except json.JSONDecodeError:
                payload = {}
            payload = payload if isinstance(payload, dict) else {}
            cohort = (str(row[0])[:DATE_TEXT_LENGTH], int(row[1]))
            raw_groups.setdefault(cohort, []).append({
                "rank": int(row[2]), "raw": _finite(row[3]), "payload": payload,
                "role": str(payload.get("sample_role") or "legacy_display"),
                "target": _finite(row[5], float("nan")),
                "target_relative": _finite(row[6], float("nan")),
            })

        def metric_for_group(cohort: tuple[str, int], group: list[dict]) -> dict | None:
            date_text, years = cohort
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_text):
                return None

            def cohort_ic(getter) -> tuple[float, int]:
                pairs = []
                for item in group:
                    signal = _finite(getter(item), float("nan"))
                    outcome = _finite(item.get("target"), float("nan"))
                    if math.isfinite(signal) and math.isfinite(outcome):
                        pairs.append((signal, outcome))
                if len(pairs) < MIN_HISTORY_POINTS:
                    return 0.0, 0
                xs, ys = zip(*pairs)
                ic = _pearson(_rank_scale(xs), _rank_scale(ys))
                return (ic if math.isfinite(ic) else 0.0), len(pairs)

            rank_ic, samples = cohort_ic(lambda item: item["raw"])
            long_ic, long_samples = cohort_ic(
                lambda item: _finite((item.get("payload") or {}).get("long_raw_score"), float("nan"))
            )
            component_ic = {}
            for name in ("expert", "linear", "nonlinear", "external", "tree2"):
                ic, component_samples = cohort_ic(
                    lambda item, n=name: _finite(((item.get("payload") or {}).get("component_scores") or {}).get(n), float("nan"))
                )
                if component_samples:
                    component_ic[name] = {"rank_ic": ic, "samples": component_samples, "cohorts": 1}

            displayed = sorted([item for item in group if item["role"] == "display_top100"], key=lambda item: item["rank"])
            controls = [item for item in group if item["role"] == "control"]
            display_excess = None
            if len(displayed) >= DISPLAY_TOP_N and len(controls) >= DISPLAY_TOP_N:
                display_return = statistics.fmean(_finite(item["target"]) for item in displayed[:DISPLAY_TOP_N])
                control_return = statistics.fmean(_finite(item["target"]) for item in controls[:DISPLAY_TOP_N])
                display_excess = display_return - control_return
            return {
                "cohort": cohort, "date": date_text, "years": years,
                "samples": samples, "cohorts": 1 if samples else 0, "rank_ic": rank_ic,
                "long_signal_ic": long_ic, "long_samples": long_samples,
                "display_excess": display_excess, "component_ic": component_ic,
                "mature_cohort_id": json.dumps(list(cohort), ensure_ascii=False, separators=(",", ":")),
                "storage": "raw",
            }

        cohort_metrics: dict[tuple[str, int], dict] = {}
        for cohort, group in raw_groups.items():
            metric = metric_for_group(cohort, group)
            if metric is not None:
                cohort_metrics[cohort] = metric

        for prediction_date, years, payload_json in archived_rows:
            cohort = (str(prediction_date)[:DATE_TEXT_LENGTH], int(years))
            if cohort in cohort_metrics:
                continue
            try:
                payload = json.loads(payload_json) if payload_json else {}
            except json.JSONDecodeError:
                payload = {}
            feedback_row = payload.get("feedback") if isinstance(payload, dict) else None
            if not isinstance(feedback_row, dict) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", cohort[0]):
                continue
            metric = dict(feedback_row)
            metric.update({
                "cohort": cohort, "date": cohort[0], "years": cohort[1],
                "mature_cohort_id": str(metric.get("mature_cohort_id") or json.dumps(list(cohort), ensure_ascii=False, separators=(",", ":"))),
                "storage": "archive",
            })
            cohort_metrics[cohort] = metric

        by_policy: dict[int, list[dict]] = {}
        for metric in cohort_metrics.values():
            by_policy.setdefault(int(metric["years"]), []).append(metric)

        selected_metrics = []
        for years, metrics in by_policy.items():
            next_feature_start = None
            for metric in sorted(metrics, key=lambda item: item["date"], reverse=True):
                day = _dt.date.fromisoformat(metric["date"])
                mature_day = _add_years(day, years)
                if next_feature_start is None or mature_day <= next_feature_start:
                    selected_metrics.append(metric)
                    next_feature_start = day

        target_feedback_by_years = {}
        for years in sorted({int(item["years"]) for item in selected_metrics}):
            subset = [item for item in selected_metrics if int(item["years"]) == years]
            rank_rows = [item for item in subset if int(_finite(item.get("samples"), 0)) > 0]
            samples = sum(int(_finite(item.get("samples"), 0)) for item in rank_rows)
            cohorts = len(rank_rows)
            rank_ic = statistics.fmean(_finite(item.get("rank_ic"), 0.0) for item in rank_rows) if rank_rows else 0.0
            long_rows = [item for item in subset if int(_finite(item.get("long_samples"), 0)) > 0]
            long_ic = statistics.fmean(_finite(item.get("long_signal_ic"), 0.0) for item in long_rows) if long_rows else 0.0
            excess_rows = [item for item in subset if item.get("display_excess") is not None]
            mature_ids = [str(item.get("mature_cohort_id") or "") for item in excess_rows if item.get("mature_cohort_id")]

            component_ic = {}
            component_names = set()
            for item in subset:
                if isinstance(item.get("component_ic"), dict):
                    component_names.update(item["component_ic"])
            for name in component_names:
                rows_for_component = []
                for item in subset:
                    component = (item.get("component_ic") or {}).get(name) if isinstance(item.get("component_ic"), dict) else None
                    if isinstance(component, dict) and int(_finite(component.get("samples"), 0)) > 0:
                        rows_for_component.append(component)
                if rows_for_component:
                    component_ic[name] = {
                        "rank_ic": statistics.fmean(_finite(row.get("rank_ic"), 0.0) for row in rows_for_component),
                        "samples": sum(int(_finite(row.get("samples"), 0)) for row in rows_for_component),
                        "cohorts": len(rows_for_component),
                    }
            strength = min(1.0, samples / max(1, cohorts * DISPLAY_TOP_N)) if cohorts else 0.0
            target_feedback_by_years[str(years)] = {
                "target_horizon_years": years, "samples": samples, "cohorts": cohorts,
                "rank_ic": rank_ic, "long_signal_ic": long_ic,
                "display_excess": statistics.fmean(_finite(item.get("display_excess"), 0.0) for item in excess_rows) if excess_rows else 0.0,
                "control_cohorts": len(excess_rows), "mature_cohort_ids": mature_ids,
                "component_ic": component_ic, "strength": strength,
                "status": "mature-feedback" if cohorts else "no-mature-target-outcomes",
                "archived_selected_cohorts": sum(item.get("storage") == "archive" for item in subset),
            }

        return {
            "target_feedback_by_years": target_feedback_by_years,
            "status": "target-mature" if target_feedback_by_years else "no-mature-outcomes",
            "feedback_sampling": "target-maturity-non-overlapping-anchors+hidden-controls; raw+cohort-archive same purge",
            "evaluated_at": _now_iso(),
        }

    @staticmethod
    def default_model() -> dict:
            return {
                "schema_fingerprint": MODEL_SCHEMA_FINGERPRINT,
                "trained_at": None,
                "feature_names": AdaptiveRanker.FEATURE_NAMES,
                "linear_weights": [0.0] * len(AdaptiveRanker.FEATURE_NAMES),
                "nonlinear_models": [],
                "asset_models": {},
                "asset_model_policy": "asset-specific-if-trained-else-global",
                "feedback_cohorts_seen": [],
                "last_feedback_cohort": "",
                "component_weights": {"expert": 1.0, "linear": 0.0, "nonlinear": 0.0, "external": 0.0, "tree2": 0.0},
                "optional_ml": None,
                "optional_tree2": None,
                "optional_ml_status": "not-trained",
                "optional_tree2_status": "not-trained",
                "validation_ic": 0.0,
                "model_quality": 0.0,
                "validation_metrics": {},
                "full_pipeline_oos": {},
                "untouched_test_oos": {},
                "candidate_deployment_oos": {},
                "baseline_deployment_oos": {},
                "deployment_gate": {"passed": False, "reason": "not-trained", "prediction_feedback_passed": True, "production_passed": False},
                "prediction_feedback": {"target_feedback_by_years": {}, "status": "no-mature-outcomes"},
                "prediction_feedback_gate": {"evaluated": False, "passed": True, "reason": "no mature realized prediction outcomes"},
                "expert_development_oos": {},
                "training_samples": 0,
                "tuning_samples": 0,
                "deployment_validation_samples": 0,
                "universe_size": 0,
                "historical_availability_coverage": 0.0,
                "historical_universe_known_coverage": 0.0,
                "historical_availability_used_for_model_selection": False,
                "ai_enabled": False,
                "model_status": "expert-fallback",
                "baseline_mode": "expert",
                "baseline_metrics": {},
                "split_boundaries": {},
                "universe_codes": [],
                "selection_dataset": "development selects; independent deployment validation gates; non-overlapping untouched audit may only exercise a fixed catastrophic veto; production refit after freeze",
                "evaluation_model": {},
                "production_model": {},
                "survivorship_bias": True,
                "survivor_conditioned": False,
                "shadow_model": False,
                "shadow_candidate_available": False,
                "shadow_candidate_trained_at": "",
                "shadow_candidate_model": {},
                "strict_pit_production": False,
                "production_model_role": "expert-fallback",
                "long_term_blend": PROBABILITY_MIDPOINT,
                "target_spec": {},
                "engine": "anchored walk-forward long-horizon target search + LongTermQuality/EntryTiming + one production Top100 ranking policy",
            }


    @staticmethod
    def _model_payload_valid(model) -> bool:
        return bool(
            isinstance(model, dict)
            and model.get("schema_fingerprint") == MODEL_SCHEMA_FINGERPRINT
            and model.get("feature_names") == AdaptiveRanker.FEATURE_NAMES
            and len(model.get("linear_weights") or []) == len(AdaptiveRanker.FEATURE_NAMES)
        )

    def _load_model_read_only(self) -> dict:
        """Load primary/rollback/default model without repairing or creating files."""
        _assert_isolated_app_path(MODEL_PATH)
        _assert_isolated_app_path(MODEL_ROLLBACK_PATH)
        primary = _read_json(MODEL_PATH, None) if MODEL_PATH.exists() else None
        if self._model_payload_valid(primary):
            return primary
        rollback = _read_json(MODEL_ROLLBACK_PATH, None) if MODEL_ROLLBACK_PATH.exists() else None
        if self._model_payload_valid(rollback):
            return dict(rollback)
        return self.default_model()

    def _load_model(self) -> dict:
        _assert_isolated_app_path(MODEL_PATH)
        _assert_isolated_app_path(MODEL_ROLLBACK_PATH)
        primary = _read_json(MODEL_PATH, None) if MODEL_PATH.exists() else None
        if self._model_payload_valid(primary):
            return primary

        rollback = _read_json(MODEL_ROLLBACK_PATH, None) if MODEL_ROLLBACK_PATH.exists() else None
        if self._model_payload_valid(rollback):
            model = dict(rollback)
            model["force_retrain_reason"] = "model-primary-recovered-from-last-known-good"
            try:
                _write_json(MODEL_PATH, model)
            except (OSError, StorageError) as exc:
                raise StorageError(f"无法从 last-known-good 恢复 AI：{MODEL_PATH}\n{exc}") from exc
            _record_diagnostic("model-recovery", "primary model invalid; restored last-known-good", "ModelRecovery")
            return model

        model = self.default_model()
        if MODEL_PATH.exists() or MODEL_ROLLBACK_PATH.exists():
            model["force_retrain_reason"] = "model-schema-or-json-invalid"
        try:
            _write_json(MODEL_PATH, model)
        except (OSError, StorageError) as exc:
            raise StorageError(f"无法在用户选择目录创建默认 AI：{MODEL_PATH}\n{exc}") from exc
        return model

    def _cache_save_scope(self, connection: sqlite3.Connection, selected_codes: set[str] | None):
        cache_funds = self.cache.get("funds") or {}
        history_cutoff = _dt.date.min.isoformat()
        if selected_codes is None:
            target_codes = set(cache_funds)
            nav_rows = connection.execute("SELECT code, COUNT(*), MAX(nav_date) FROM nav_returns GROUP BY code")
            metadata_rows = connection.execute("SELECT code,payload_json FROM metadata")
        else:
            target_codes = set(selected_codes) & set(cache_funds)
            if target_codes:
                placeholders = ",".join("?" for _ in target_codes)
                params = tuple(sorted(target_codes))
                nav_rows = connection.execute(
                    f"SELECT code, COUNT(*), MAX(nav_date) FROM nav_returns WHERE code IN ({placeholders}) GROUP BY code",
                    params,
                )
                metadata_rows = connection.execute(
                    f"SELECT code,payload_json FROM metadata WHERE code IN ({placeholders})",
                    params,
                )
            else:
                nav_rows = []
                metadata_rows = []
        nav_state = {row[0]: {"count": int(row[1]), "max_date": str(row[2] or "")} for row in nav_rows}
        existing_metadata = {}
        for row in metadata_rows:
            try:
                payload = json.loads(row[1])
                existing_metadata[row[0]] = payload if isinstance(payload, dict) else {}
            except (TypeError, json.JSONDecodeError):
                existing_metadata[row[0]] = {}
        return cache_funds, history_cutoff, target_codes, nav_state, existing_metadata

    @staticmethod
    def _trim_history_for_persistence(item: dict, history_cutoff: str):
        history_loaded = "dates" in item and "returns" in item
        dates = list(item.get("dates") or []) if history_loaded else []
        returns = list(item.get("returns") or []) if history_loaded else []
        if history_loaded and len(dates) == len(returns) and dates:
            normalized_dates = [str(day)[:DATE_TEXT_LENGTH] for day in dates]
            keep_from = bisect.bisect_left(normalized_dates, history_cutoff)
            if keep_from > 0:
                dates = dates[keep_from:]
                returns = returns[keep_from:]
        return history_loaded, dates, returns

    @staticmethod
    def _nav_structure_signature(item: dict, previous: dict, history_loaded: bool) -> str:
        if not history_loaded:
            return str(previous.get("_nav_structure_signature") or "")
        payload = {
            "return_basis": item.get("return_basis"),
            "corporate_actions": item.get("return_corporate_actions"),
            "accumulated_confirmations": item.get("return_accumulated_confirmations"),
            "provider_fallbacks": item.get("return_provider_fallbacks"),
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
        ).hexdigest()

    @staticmethod
    def _nav_series_signature(dates: list, returns: list) -> str:
        if len(dates) != len(returns):
            return ""
        payload = [
            (str(day)[:DATE_TEXT_LENGTH], round(float(ret), FLOAT_SERIALIZATION_DIGITS))
            for day, ret in zip(dates, returns)
        ]
        return hashlib.sha256(
            json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
        ).hexdigest()

    def _persist_nav_series(self, connection, code: str, dates: list, returns: list, previous: dict, db_state: dict) -> str:
        """Persist the complete retained series iff its content hash changed."""
        if not (len(dates) == len(returns) and dates):
            return ""
        series_signature = self._nav_series_signature(dates, returns)
        previous_signature = str(previous.get("_nav_series_signature") or "")
        unchanged = bool(
            db_state.get("count") == len(dates)
            and str(db_state.get("max_date") or "") == str(dates[-1])[:DATE_TEXT_LENGTH]
            and previous_signature
            and hmac.compare_digest(previous_signature, series_signature)
        )
        if unchanged:
            return series_signature
        if db_state.get("count"):
            connection.execute("DELETE FROM nav_returns WHERE code=?", (code,))
        connection.executemany(
            "INSERT INTO nav_returns(code,nav_date,daily_return) VALUES(?,?,?) "
            "ON CONFLICT(code,nav_date) DO UPDATE SET daily_return=excluded.daily_return",
            [(code, str(day)[:DATE_TEXT_LENGTH], float(ret)) for day, ret in zip(dates, returns)],
        )
        return series_signature

    @staticmethod
    def _cache_metadata_payload(item: dict, previous: dict, db_state: dict, history_loaded: bool, dates: list, returns: list, nav_structure_signature: str, nav_series_signature: str) -> dict:
        metadata = {key: value for key, value in item.items() if key not in ("dates", "returns", "availability_history", "_nav_anchor_date", "_nav_anchor_signature")}
        if history_loaded:
            metadata["_nav_structure_signature"] = nav_structure_signature
            metadata["_nav_series_signature"] = nav_series_signature
            metadata["_nav_series_count"] = len(dates) if len(dates) == len(returns) else 0
        else:
            metadata["_nav_structure_signature"] = str(previous.get("_nav_structure_signature") or "")
            metadata["_nav_series_signature"] = str(previous.get("_nav_series_signature") or "")
            metadata["_nav_series_count"] = int(db_state.get("count") or previous.get("_nav_series_count") or 0)
        return metadata

    @staticmethod
    def _persist_availability_history(connection, code: str, item: dict) -> None:
        for span in item.get("availability_history") or []:
            if not isinstance(span, dict):
                continue
            start_date = str(span.get("from") or "")[:DATE_TEXT_LENGTH]
            finish_date = str(span.get("to") or "")[:DATE_TEXT_LENGTH]
            if not start_date:
                continue
            connection.execute(
                "INSERT OR REPLACE INTO availability_history"
                "(code,span_from,span_to,purchasable,payload_json) VALUES(?,?,?,?,?)",
                (
                    code, start_date, finish_date,
                    1 if span.get("purchasable", True) is True else 0,
                    json.dumps(span, ensure_ascii=False, separators=(",", ":")),
                ),
            )

    def _persist_cache_fund(self, connection, code: str, item: dict, previous: dict, db_state: dict, history_cutoff: str) -> None:
        history_loaded, dates, returns = self._trim_history_for_persistence(item, history_cutoff)
        nav_signature = self._nav_structure_signature(item, previous, history_loaded)
        nav_series_signature = (
            self._persist_nav_series(connection, code, dates, returns, previous, db_state)
            if history_loaded else str(previous.get("_nav_series_signature") or "")
        )
        metadata = self._cache_metadata_payload(
            item, previous, db_state, history_loaded, dates, returns, nav_signature, nav_series_signature
        )
        connection.execute(
            "INSERT INTO metadata(code,payload_json) VALUES(?,?) "
            "ON CONFLICT(code) DO UPDATE SET payload_json=excluded.payload_json",
            (code, json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))),
        )
        self._persist_availability_history(connection, code, item)

    def _persist_cache_runtime_state(self, connection) -> None:
        connection.execute(f"PRAGMA user_version={CACHE_SCHEMA_FINGERPRINT}")
        connection.executemany(
            "INSERT INTO runtime_state(key,value_json) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
            [
                ("schema_fingerprint", json.dumps(CACHE_SCHEMA_FINGERPRINT)),
                ("updated_at", json.dumps(self.cache.get("updated_at"))),
                ("last_full_nav_refresh_at", json.dumps(self.cache.get("last_full_nav_refresh_at"))),
                ("storage_growth_samples", json.dumps(_storage_growth_samples())),
            ],
        )
        with _OBSERVED_MARKET_SESSION_LOCK:
            observed_context_counts = dict(_OBSERVED_MARKET_SESSION_CONTEXT_COUNTS)
        if observed_context_counts:
            connection.executemany(
                "INSERT INTO market_session_context(asset_bucket,source_family,session_date,observation_count) VALUES(?,?,?,?) "
                "ON CONFLICT(asset_bucket,source_family,session_date) DO UPDATE SET "
                "observation_count=MAX(observation_count,excluded.observation_count)",
                sorted((asset, source, day, count) for (asset, source, day), count in observed_context_counts.items()),
            )

    def _persist_fund_master_rows(self, connection, selected_codes: set[str] | None) -> None:
        master_rows = self.cache.get("fund_master") or {}
        master_codes = set(master_rows) if selected_codes is None else (set(selected_codes) & set(master_rows))
        for code in sorted(master_codes):
            item = master_rows.get(code)
            if isinstance(item, dict):
                connection.execute(
                    "INSERT INTO fund_master(code,payload_json) VALUES(?,?) "
                    "ON CONFLICT(code) DO UPDATE SET payload_json=excluded.payload_json",
                    (code, json.dumps(item, ensure_ascii=False, separators=(",", ":"))),
                )

    @staticmethod
    def _maintain_cache_after_full_save(connection, history_cutoff: str) -> None:
        try:
            with connection:
                connection.execute("DELETE FROM nav_returns WHERE nav_date < ?", (history_cutoff,))
                connection.execute("DELETE FROM market_session_context WHERE session_date < ?", (history_cutoff,))
        except sqlite3.Error as exc:
            _record_diagnostic("sqlite-retention", exc, "SQLiteMaintenanceError")
        try:
            connection.execute("PRAGMA wal_checkpoint(PASSIVE)")
            connection.execute("PRAGMA optimize")
        except sqlite3.Error as exc:
            _record_diagnostic("sqlite-optimize", exc, "SQLiteMaintenanceError")

    def save_cache(self, dirty_codes: set[str] | None = None) -> None:
        """Persist the whole cache or only changed fund codes using small transaction helpers."""
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        selected_codes = None if dirty_codes is None else {str(code) for code in dirty_codes if str(code)}
        _require_storage_write_capacity("SQLite 缓存")
        before_storage = _storage_footprint_bytes()
        with _STORAGE_COMMIT_LOCK:
            try:
                connection = LocalStore._open_checked_cache(quick_check=False)
                try:
                    _configure_sqlite_connection(connection)
                    _ensure_cache_schema(connection)
                    persisted_version = _cache_persisted_fingerprint(connection)
                    if persisted_version != CACHE_SCHEMA_FINGERPRINT:
                        migrate_cache(connection)
                    cache_funds, history_cutoff, target_codes, nav_state, existing_metadata = self._cache_save_scope(connection, selected_codes)
                    with connection:
                        if _cancel_requested():
                            raise concurrent.futures.CancelledError("程序正在退出")
                        self._persist_cache_runtime_state(connection)
                        for code in sorted(target_codes):
                            item = cache_funds.get(code)
                            if not isinstance(item, dict):
                                continue
                            self._persist_cache_fund(
                                connection, code, item, existing_metadata.get(code) or {},
                                nav_state.get(code) or {"count": 0, "max_date": ""}, history_cutoff,
                            )
                        self._persist_fund_master_rows(connection, selected_codes)
                    if selected_codes is None:
                        self._maintain_cache_after_full_save(connection, history_cutoff)
                finally:
                    connection.close()
            except (OSError, sqlite3.Error, StorageError) as exc:
                raise StorageError(f"无法在用户选择目录写入 SQLite 缓存：{CACHE_PATH}\n{exc}") from exc
        _record_storage_growth(before_storage)


    def save_model(self, model: dict) -> None:
        if not self._model_payload_valid(model):
            raise ModelError("拒绝保存不满足当前模型契约的 AI payload")
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        _require_storage_write_capacity("AI 模型")
        before_storage = _storage_footprint_bytes()
        try:
            _assert_isolated_app_path(MODEL_PATH)
            _assert_isolated_app_path(MODEL_ROLLBACK_PATH)
            with _STORAGE_COMMIT_LOCK:
                if _cancel_requested():
                    raise concurrent.futures.CancelledError("程序正在退出")
                current = _read_json(MODEL_PATH, None) if MODEL_PATH.exists() else None
                if self._model_payload_valid(current):
                    _atomic_bytes(MODEL_ROLLBACK_PATH, MODEL_PATH.read_bytes())
                _write_json(MODEL_PATH, model)
        except (OSError, StorageError) as exc:
            raise StorageError(f"无法在用户选择目录写入 AI：{MODEL_PATH}\n{exc}") from exc
        _record_storage_growth(before_storage)
        self.model = model


def _safe_tree_size_bytes(root: Path) -> int:
    try:
        root = _assert_isolated_app_path(root)
        if not root.exists() or _path_is_reparse_or_symlink(root):
            return 0
    except (OSError, StorageError):
        return 0
    total = 0
    try:
        for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
            current_path = Path(current)
            safe_dirs = []
            for name in dirs:
                path = current_path / name
                try:
                    if not _path_is_reparse_or_symlink(path):
                        safe_dirs.append(name)
                except OSError:
                    continue
            dirs[:] = safe_dirs
            for name in files:
                path = current_path / name
                try:
                    if _path_is_reparse_or_symlink(path):
                        continue
                    total += max(0, path.stat().st_size)
                except OSError:
                    continue
    except OSError:
        pass
    return total


def _prune_rebuildable_cache(root: Path, target_bytes: int) -> dict:
    """Delete oldest ordinary cache files until a bounded target is reached; never follow links/reparse points."""
    root = _assert_isolated_app_path(root)
    target = max(0, int(target_bytes))
    before = _safe_tree_size_bytes(root)
    if before <= target or not root.exists():
        return {"before": before, "after": before, "removed_files": 0}
    files = []
    try:
        for current, dirs, names in os.walk(root, topdown=True, followlinks=False):
            current_path = Path(current)
            dirs[:] = [name for name in dirs if not _path_is_reparse_or_symlink(current_path / name)]
            for name in names:
                path = current_path / name
                try:
                    safe = _assert_isolated_app_path(path)
                    if _path_is_reparse_or_symlink(safe) or not safe.is_file():
                        continue
                    stat = safe.stat()
                    files.append((float(stat.st_mtime), int(stat.st_size), safe))
                except (OSError, StorageError):
                    continue
    except (OSError, StorageError):
        return {"before": before, "after": _safe_tree_size_bytes(root), "removed_files": 0}
    current_bytes = before
    removed = 0
    for _mtime, size, path in sorted(files, key=lambda row: row[0]):
        if current_bytes <= target:
            break
        try:
            path.unlink()
            current_bytes = max(0, current_bytes - max(0, size))
            removed += 1
        except OSError:
            continue
    # Empty cache directories are harmless but removing them keeps the bound folder tidy.
    try:
        dirs = [Path(current) for current, _subdirs, _files in os.walk(root, topdown=False, followlinks=False)]
        for directory in dirs:
            if directory == root:
                continue
            try:
                directory.rmdir()
            except OSError:
                pass
    except OSError:
        pass
    return {"before": before, "after": _safe_tree_size_bytes(root), "removed_files": removed}


def _run_unified_storage_gc(store: LocalStore) -> dict:
    """Ordered GC: stale runtime -> CUDA/Numba/rebuildable cache -> inactive deps -> SQLite compact."""
    import shutil
    try:
        free_before = int(shutil.disk_usage(BASE_DIR).free)
    except OSError:
        free_before = 0
    app_footprint = _safe_tree_size_bytes(BASE_DIR)
    # Live monitoring and maintenance intentionally share this exact low-disk predicate.
    disk_pressure = _objective_disk_pressure(free_before)
    actions = []

    runtime_removed = _cleanup_stale_runtime_files(0 if disk_pressure else None)
    actions.append({"stage": "stale-runtime", "removed": runtime_removed})

    cache_root = BASE_DIR / ".BestFunds_cache"
    cuda_root = cache_root / "cuda"
    numba_root = cache_root / "numba"
    # Rebuildable caches are left untouched while space is sufficient; under measured pressure
    # they can be removed completely because their contents are reproducible.
    if disk_pressure:
        cuda_gc = _prune_rebuildable_cache(cuda_root, 0)
        numba_gc = _prune_rebuildable_cache(numba_root, 0)
        cache_total = _safe_tree_size_bytes(cache_root)
        whole_cache_gc = _prune_rebuildable_cache(cache_root, 0)
        overall_target = 0
    else:
        cache_total = _safe_tree_size_bytes(cache_root)
        cuda_gc = {"before": _safe_tree_size_bytes(cuda_root), "after": _safe_tree_size_bytes(cuda_root), "removed_files": 0}
        numba_gc = {"before": _safe_tree_size_bytes(numba_root), "after": _safe_tree_size_bytes(numba_root), "removed_files": 0}
        whole_cache_gc = {"before": cache_total, "after": cache_total, "removed_files": 0}
        overall_target = cache_total
    actions.append({
        "stage": "cuda-numba-rebuildable-cache",
        "cuda": cuda_gc, "numba": numba_gc, "overall": whole_cache_gc,
        "limit_bytes": overall_target,
    })

    settings = _load_install_settings()
    active = _active_dependency_dir(settings)
    pending = _pending_dependency_dir(settings)
    dependency_removed = _cleanup_stale_dependency_dirs(active, (pending,) if pending is not None else ())
    actions.append({"stage": "inactive-dependency", "removed": dependency_removed})

    try:
        sqlite_gc = store.compact_cache_database(disk_pressure=disk_pressure)
    except (sqlite3.Error, StorageError, OSError, DataError, ValueError) as exc:
        sqlite_gc = {"attempted": True, "method": "failed", "reason": f"{type(exc).__name__}: {exc}"}
    actions.append({"stage": "sqlite-compact", **sqlite_gc})
    try:
        free_after = int(shutil.disk_usage(BASE_DIR).free)
    except OSError:
        free_after = 0
    pressure_after = _objective_disk_pressure(free_after)
    if disk_pressure and pressure_after:
        _set_storage_survival_mode(True)
    elif _storage_survival_mode_active() and not pressure_after:
        _set_storage_survival_mode(False)
    return {
        "disk_pressure": disk_pressure,
        "disk_pressure_after": pressure_after,
        "survival_mode": _storage_survival_mode_active(),
        "free_disk_before": free_before,
        "free_disk_after": free_after,
        "reclaimed_disk_bytes": max(0, free_after - free_before) if free_before and free_after else 0,
        "rebuildable_cache_limit_bytes": overall_target,
        "app_footprint_bytes": app_footprint,
        "actions": actions,
        "checked_at": _now_iso(),
    }


# ===== 排名器 / AI =====

def _loaded_modules_are_local(active_dir: Path, names: tuple[str, ...]) -> bool:
    """Refuse a native stack if a top-level module was already loaded from outside the active local generation."""
    try:
        root = active_dir.resolve()
    except OSError:
        return False
    for name in names:
        module = sys.modules.get(name)
        if module is None:
            continue
        path_text = str(getattr(module, "__file__", "") or "")
        if not path_text:
            return False
        try:
            if root not in Path(path_text).resolve().parents:
                return False
        except OSError:
            return False
    return True



def _target_feedback_for_model(feedback: dict | None, model: dict | None) -> dict:
    feedback = feedback if isinstance(feedback, dict) else {}
    by_years = feedback.get("target_feedback_by_years") if isinstance(feedback.get("target_feedback_by_years"), dict) else {}
    return dict(by_years.get(str(_model_target_years(model))) or {})


def _prediction_feedback_adjusted_model(model: dict, feedback: dict | None) -> tuple[dict, dict]:
    """Move production weights only from target-matched mature realized outcomes."""
    feedback = dict(feedback or {})
    adjusted = dict(model or {})

    target_feedback = _target_feedback_for_model(feedback, adjusted)
    samples = int(_finite(target_feedback.get("samples"), 0))
    cohorts = int(_finite(target_feedback.get("cohorts"), 0))
    strength = _clamp(_finite(target_feedback.get("strength"), 0.0), 0.0, 1.0)
    rank_ic = _finite(target_feedback.get("rank_ic"), 0.0)
    display_excess = _finite(target_feedback.get("display_excess"), 0.0)
    evaluated = str(target_feedback.get("status") or "") == "mature-feedback"
    gate_passed = not evaluated or (rank_ic >= 0.0 and display_excess >= 0.0)

    # Long-quality components are allowed to learn only from labels whose maturity equals this model's target horizon.
    if evaluated and strength > 0.0 and adjusted:
        components = dict(adjusted.get("component_weights") or {})
        component_feedback = target_feedback.get("component_ic") if isinstance(target_feedback.get("component_ic"), dict) else {}
        learned_weights = {}
        for name, weight in components.items():
            component_row = component_feedback.get(name) if isinstance(component_feedback.get(name), dict) else {}
            ic = _clamp(_finite(component_row.get("rank_ic"), 0.0), -1.0, 1.0)
            learned_weights[name] = max(0.0, _finite(weight) * (1.0 + strength * ic))
        total = sum(learned_weights.values())
        if total > sys.float_info.epsilon:
            adjusted["component_weights"] = {name: value / total for name, value in learned_weights.items()}

    target_years = _model_target_years(adjusted)
    gate_reason = (
        f"{target_years}y target feedback not mature; production weights remain unchanged"
        if not evaluated else
        f"{target_years}y realized target feedback Pareto guardrail passed; candidate still requires deployment validation"
        if gate_passed else
        f"{target_years}y realized target feedback Pareto guardrail failed: RankIC {_format_unrounded_number(rank_ic, signed=True)}, display-group excess {_format_unrounded_number(display_excess, '%', signed=True, scale=PERCENT_SCALE)}"
    )
    gate = {
        "evaluated": evaluated, "passed": gate_passed, "reason": gate_reason,
        "target_horizon_years": target_years, "samples": samples, "cohorts": cohorts,
        "strength": round(strength, FLOAT_SERIALIZATION_DIGITS),
    }
    adjusted["prediction_feedback"] = feedback
    adjusted["prediction_feedback_gate"] = dict(gate)
    return adjusted, gate


BASE_MODEL_FEATURE_NAMES = (
    "entry_return_latest", "return_target_ann", "zero_baseline_return_volatility_target",
    "zero_baseline_downside_ratio_target", "calmar_target", "drawdown_quality",
    "volatility_quality", "worst_period", "positive_months", "trend_quality",
    "stability_quality", "recovery_quality",
    "transaction_cost_target_quality", "rolling_target_worst", "recovery_time_quality",
    "ulcer_quality", "bear_stress_quality", "long_evidence_strength", "fee_evidence_known",
)
MODEL_ASSET_BUCKETS = ("主动权益", "指数", "债券", "FOF", "QDII/海外", "其他")
MODEL_ASSET_FEATURE_NAMES = (
    "asset_class_active_equity", "asset_class_index", "asset_class_bond",
    "asset_class_fof", "asset_class_qdii_overseas", "asset_class_other",
)
MODEL_WITHIN_ASSET_FEATURE_NAMES = tuple(
    f"within_asset_percentile_{name}" for name in BASE_MODEL_FEATURE_NAMES
)
MODEL_FEATURE_NAMES = BASE_MODEL_FEATURE_NAMES + MODEL_WITHIN_ASSET_FEATURE_NAMES + MODEL_ASSET_FEATURE_NAMES


class AdaptiveRanker:
    BASE_FEATURE_NAMES = list(BASE_MODEL_FEATURE_NAMES)
    FEATURE_NAMES = list(MODEL_FEATURE_NAMES)
    # Equal-weight fallback is the neutral prior.  Any non-equal weighting must be learned
    # from walk-forward data and pass the deployment/untouched gates below.
    EXPERT_WEIGHTS = [1.0 / len(FEATURE_NAMES)] * len(FEATURE_NAMES)
    NONLINEAR_SEEDS = tuple(
        int.from_bytes(hashlib.sha256(f"{APP_NAME}:{name}".encode("utf-8")).digest()[:struct.calcsize("I")], "big")
        for name in FEATURE_NAMES
    )

    @classmethod
    def _adaptive_nonlinear_seeds(cls):
        count = min(len(cls.NONLINEAR_SEEDS), max(1, _adaptive_model_complexity()))
        return cls.NONLINEAR_SEEDS[:count]

    @classmethod
    def _adaptive_lightgbm_grid(cls):
        # Empty means the release-pinned LightGBM defaults. Any future non-default candidate
        # must be added here only when walk-forward/OOS selection can compare it.
        return ({},)

    @classmethod
    def _adaptive_xgboost_grid(cls):
        # Empty means the release-pinned XGBoost defaults. Any future non-default candidate
        # must be added here only when walk-forward/OOS selection can compare it.
        return ({},)

    RANDOM_FEATURE_COUNT = len(FEATURE_NAMES)
    _RANDOM_RECIPES = {}

    @staticmethod
    def features(
        returns: list[float], end: int | None = None, fees: dict | None = None,
        dates: list[str] | None = None, target_years: int = 1,
        history_context: dict | None = None, unknown_transaction_cost: float | None = None,
    ) -> tuple[list[float], dict] | None:
        end = len(returns) if end is None else min(end, len(returns))
        target_years = max(1, int(target_years))
        if end < MIN_HISTORY_POINTS or not dates or len(dates) != len(returns):
            return None
        return_floor = -1.0 + sys.float_info.epsilon
        clean = [max(return_floor, _finite(value)) for value in returns[:end]]
        date_values = [str(value)[:DATE_TEXT_LENGTH] for value in dates[:end]]
        if any(not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) for value in date_values):
            return None
        try:
            date_objects = [_dt.date.fromisoformat(value) for value in date_values]
        except ValueError:
            return None
        if any(right <= left for left, right in zip(date_objects, date_objects[1:])):
            return None
        density_evidence = _history_density_evidence(date_values, target_years, history_context)
        if density_evidence.get("passed") is not True:
            return None
        history_start_day, feature_day = date_objects[0], date_objects[-1]
        history_days = max(1, (feature_day - history_start_day).days)
        history_years = history_days / AVERAGE_GREGORIAN_DAYS_PER_YEAR
        observed_gaps = [(right - left).days for left, right in zip(date_objects, date_objects[1:])]
        typical_gap_days = max(1, round(statistics.median(observed_gaps))) if observed_gaps else 1

        log_prefix = [0.0]
        for value in clean:
            log_prefix.append(log_prefix[-1] + math.log1p(value))

        def compound_range(start_index: int, finish_index: int) -> float:
            return math.expm1(log_prefix[finish_index] - log_prefix[start_index])

        def calendar_window_years(years: int) -> tuple[int, int, float, bool]:
            cutoff = _years_before(feature_day, years)
            anchor_index = bisect.bisect_left(date_objects, cutoff)
            if anchor_index >= len(clean) - 1:
                return anchor_index, len(clean), 0.0, False
            actual_days = max(0, (feature_day - date_objects[anchor_index]).days)
            requested_days = max(1, (feature_day - cutoff).days)
            complete = actual_days + typical_gap_days >= requested_days
            return anchor_index, anchor_index + 1, actual_days / AVERAGE_GREGORIAN_DAYS_PER_YEAR, complete

        target_anchor, target_first_return, actual_target_years, complete = calendar_window_years(target_years)
        if target_first_return >= len(clean) or not complete or actual_target_years <= 0:
            return None
        target_values = clean[target_first_return:]
        if not target_values:
            return None

        entry_return = clean[-1]
        total_target = compound_range(target_first_return, len(clean))
        target_ann = -1.0 if total_target <= -1.0 else math.expm1(
            math.log1p(total_target) / max(actual_target_years, sys.float_info.epsilon)
        )
        volatility, downside, annualized_interval_returns, _risk_years = _calendar_annualized_risk(
            clean, date_objects, target_first_return, len(clean)
        )
        divisor_floor = sys.float_info.epsilon
        return_vol_ratio = target_ann / max(volatility, divisor_floor)
        return_downside_ratio = target_ann / max(downside, divisor_floor)
        max_dd = _max_drawdown(target_values)
        calmar = target_ann / max(abs(max_dd), divisor_floor)

        # Calendar months are keyed by YYYY-MM; missing observations never change a month's boundary.
        monthly_log_returns: dict[tuple[int, int], float] = {}
        for index in range(target_first_return, len(clean)):
            month = (date_objects[index].year, date_objects[index].month)
            monthly_log_returns[month] = monthly_log_returns.get(month, 0.0) + math.log1p(clean[index])
        monthly_returns = [math.expm1(monthly_log_returns[key]) for key in sorted(monthly_log_returns)]
        positive_months = sum(value > 0 for value in monthly_returns) / max(1, len(monthly_returns))
        worst_period = min(monthly_returns) if monthly_returns else total_target
        stability = -(statistics.pstdev(monthly_returns) if len(monthly_returns) > 1 else 0.0)

        # Trend is log-wealth versus actual elapsed calendar years, not observation index.
        baseline_log = log_prefix[target_first_return]
        trend_x = [
            (date_objects[index] - date_objects[target_anchor]).days / AVERAGE_GREGORIAN_DAYS_PER_YEAR
            for index in range(target_first_return, len(clean))
        ]
        trend_y = [
            log_prefix[index + 1] - baseline_log
            for index in range(target_first_return, len(clean))
        ]
        count = len(trend_x)
        x_mean = statistics.fmean(trend_x) if trend_x else 0.0
        y_mean = statistics.fmean(trend_y) if trend_y else 0.0
        xx = sum((value - x_mean) ** 2 for value in trend_x)
        xy = sum((x - x_mean) * (y - y_mean) for x, y in zip(trend_x, trend_y))
        slope = xy / max(xx, sys.float_info.epsilon)
        fitted_var = sum((slope * (value - x_mean)) ** 2 for value in trend_x)
        total_var = sum((value - y_mean) ** 2 for value in trend_y)
        r2 = _clamp(fitted_var / max(total_var, sys.float_info.epsilon), 0.0, 1.0) if count > 1 else 0.0
        trend_quality = slope * r2

        sorted_tail = sorted(annualized_interval_returns)
        tail_count = max(1, math.isqrt(len(sorted_tail))) if sorted_tail else 0
        bear_stress = abs(statistics.fmean(sorted_tail[:tail_count])) if tail_count else 0.0

        wealth = peak = 1.0
        peak_day = date_objects[target_anchor]
        longest_recovery_days = 0
        drawdowns = []
        for index in range(target_first_return, len(clean)):
            wealth *= 1.0 + clean[index]
            current_day = date_objects[index]
            if wealth >= peak:
                peak = wealth
                peak_day = current_day
            else:
                longest_recovery_days = max(longest_recovery_days, (current_day - peak_day).days)
            drawdowns.append(wealth / max(peak, sys.float_info.min) - 1.0)
        recovery = wealth / max(peak, sys.float_info.min) - 1.0
        ulcer = math.sqrt(statistics.fmean(drawdown * drawdown for drawdown in drawdowns)) if drawdowns else 0.0

        # Rolling horizon checks are evaluated at observed calendar month ends, never every N points.
        month_end_finishes = []
        for index in range(1, len(clean)):
            current_month = (date_objects[index].year, date_objects[index].month)
            next_month = (date_objects[index + 1].year, date_objects[index + 1].month) if index + 1 < len(clean) else None
            if next_month != current_month:
                month_end_finishes.append(index + 1)
        rolling_target = []
        for finish in month_end_finishes:
            finish_day = date_objects[finish - 1]
            cutoff = _years_before(finish_day, target_years)
            anchor_index = bisect.bisect_left(date_objects, cutoff, 0, finish)
            if anchor_index >= finish - 1:
                continue
            actual_days = (finish_day - date_objects[anchor_index]).days
            requested_days = max(1, (finish_day - cutoff).days)
            if actual_days + typical_gap_days >= requested_days:
                rolling_target.append(compound_range(anchor_index + 1, finish))
        rolling_target_worst = min(rolling_target) if rolling_target else total_target
        target_span_days = max(1, (feature_day - date_objects[target_anchor]).days)
        long_evidence = _clamp(
            (history_years - target_years) / max(float(target_years), sys.float_info.epsilon), 0.0, 1.0
        )
        costs = _holding_costs(fees, target_years)
        _zero_return_after_cost, transaction_evidence = _realized_net_holding_return(
            0.0, fees, target_years, unknown_transaction_cost,
        )
        model_cost = _finite(transaction_evidence.get("effective_transaction_cost"), UNKNOWN_TRANSACTION_COST_FALLBACK)
        fee_evidence_known = 1.0 if transaction_evidence.get("fee_evidence_known") is True else 0.0

        vector = [
            entry_return, target_ann, return_vol_ratio, return_downside_ratio, calmar,
            max_dd, -volatility, worst_period, positive_months, trend_quality,
            stability, recovery, -model_cost, rolling_target_worst,
            -longest_recovery_days / target_span_days, -ulcer, -bear_stress, long_evidence,
            fee_evidence_known,
        ]
        stats = {
            "target_years": target_years, "entry_return_latest": entry_return,
            "return_target_ann": target_ann, "volatility": volatility, "max_drawdown_target": max_dd,
            "zero_baseline_return_volatility": return_vol_ratio,
            "zero_baseline_downside_ratio": return_downside_ratio, "calmar_target": calmar,
            "positive_months": positive_months, "worst_period": worst_period, "current_drawdown": recovery,
            "rolling_target_worst": rolling_target_worst, "recovery_days_target": longest_recovery_days,
            "ulcer_index_target": ulcer, "bear_stress_target": bear_stress,
            "long_evidence_strength": long_evidence,
            "observations": end, "history_years": history_years, "feature_date": date_values[-1],
            "fee_evidence_known": bool(transaction_evidence.get("fee_evidence_known")),
            "fee_cost_source": str(transaction_evidence.get("cost_source") or ""),
            "model_transaction_cost": model_cost,
            "imputed_transaction_cost": transaction_evidence.get("imputed_transaction_cost"),
            "history_density": density_evidence.get("density"),
            "history_missing_fraction": density_evidence.get("missing_fraction"),
            "recent_history_density": density_evidence.get("recent_density"),
            "max_missing_sessions_between_observations": density_evidence.get("max_missing_sessions_between_observations"),
            "history_large_gap_count": density_evidence.get("large_gap_count"),
            "history_density_evidence": density_evidence,
            **costs,
        }
        return vector, stats

    @staticmethod
    def _solve_weighted_linear(xs: list[list[float]], ys: list[float], sample_weights: list[float]) -> list[float]:
        """Weighted least squares with no policy-chosen regularization constant."""
        if not xs:
            return []
        columns = len(xs[0])
        matrix = [[0.0] * columns for _ in range(columns)]
        target = [0.0] * columns
        for row, y, weight in zip(xs, ys, sample_weights):
            for i in range(columns):
                target[i] += weight * row[i] * y
                for j in range(i, columns):
                    matrix[i][j] += weight * row[i] * row[j]
        for i in range(columns):
            for j in range(i):
                matrix[i][j] = matrix[j][i]
        augmented = [matrix[i][:] + [target[i]] for i in range(columns)]
        for pivot in range(columns):
            best = max(range(pivot, columns), key=lambda row: abs(augmented[row][pivot]))
            augmented[pivot], augmented[best] = augmented[best], augmented[pivot]
            divisor = augmented[pivot][pivot]
            if abs(divisor) <= NUMERIC_TOLERANCE:
                continue
            for column in range(pivot, columns + 1):
                augmented[pivot][column] /= divisor
            for row in range(columns):
                if row == pivot:
                    continue
                factor = augmented[row][pivot]
                if abs(factor) <= NUMERIC_TOLERANCE:
                    continue
                for column in range(pivot, columns + 1):
                    augmented[row][column] -= factor * augmented[pivot][column]
        return [augmented[i][-1] for i in range(columns)]

    @classmethod
    def _random_features(cls, row: list[float], seed: int) -> list[float]:
        n = len(row)
        operation_count = len(("product", "distance", "signed_square", "signed_parts", "balanced_tanh"))
        key = (seed, n, cls.RANDOM_FEATURE_COUNT)
        recipes = cls._RANDOM_RECIPES.get(key)
        if recipes is None:
            rng = random.Random(seed)
            recipes = tuple(
                (rng.randrange(n), rng.randrange(n), rng.randrange(n), rng.randrange(operation_count))
                for _ in range(cls.RANDOM_FEATURE_COUNT)
            )
            cls._RANDOM_RECIPES[key] = recipes
        result = []
        operations = ("product", "distance", "signed_square", "signed_parts", "balanced_tanh")
        for a, b, c, mode in recipes:
            operation = operations[mode]
            if operation == "product":
                value = row[a] * row[b]
            elif operation == "distance":
                value = abs(row[a] - row[b])
            elif operation == "signed_square":
                value = math.copysign(row[a] * row[a], row[a])
            elif operation == "signed_parts":
                value = max(row[a], 0.0) + min(row[b], 0.0)
            else:
                terms = (row[a], -row[b], row[c])
                value = math.tanh(statistics.fmean(terms) * math.sqrt(len(terms)))
            result.append(value)
        return result

    @staticmethod
    def _universe_membership_at(fund: dict, as_of_date: str) -> tuple[bool, bool]:
        date = str(as_of_date or "")[:DATE_TEXT_LENGTH]
        inception = str(fund.get("inception_date") or "")[:DATE_TEXT_LENGTH]
        termination = str(fund.get("termination_date") or "")[:DATE_TEXT_LENGTH]
        if inception and date < inception:
            return False, True
        if termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and date > termination:
            return False, True
        history = [row for row in (fund.get("catalog_history") or []) if isinstance(row, dict)]
        if history:
            for span in history:
                start = str(span.get("from") or "0000-00-00")[:DATE_TEXT_LENGTH]
                finish = str(span.get("to") or span.get("last_observed") or "9999-99-99")[:DATE_TEXT_LENGTH]
                if start <= date <= finish:
                    return span.get("active") is not False, True
            # Before the first local observation (or in a gap) is deliberately unknown.
            return True, False
        # Inception proves the fund existed, but not that it belonged to the investable point-in-time universe.
        return True, False

    @staticmethod
    def _eligibility_at(fund: dict, end: int, as_of_date: str | None = None) -> tuple[bool, bool]:
        dates = fund.get("dates") or []
        if end <= 0 or end > len(dates):
            return False, False
        date = str(as_of_date or dates[end - 1])[:DATE_TEXT_LENGTH]
        try:
            feature_day = _dt.date.fromisoformat(date)
            observation_day = _dt.date.fromisoformat(str(dates[end - 1])[:DATE_TEXT_LENGTH])
        except ValueError:
            return False, False
        if observation_day > feature_day or (feature_day - observation_day).days > calendar.monthrange(feature_day.year, feature_day.month)[1]:
            return False, False
        inception = str(fund.get("inception_date") or dates[0])[:DATE_TEXT_LENGTH]
        termination = str(fund.get("termination_date") or "")[:DATE_TEXT_LENGTH]
        if inception and date < inception:
            return False, False
        if termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and date > termination:
            return False, False
        history = fund.get("availability_history") or []
        if history:
            for span in history:
                if not isinstance(span, dict):
                    continue
                start = str(span.get("from") or "0000-00-00")[:DATE_TEXT_LENGTH]
                finish = str(span.get("to") or "9999-99-99")[:DATE_TEXT_LENGTH]
                if start <= date <= finish:
                    return span.get("purchasable") is not False, True
            # 有历史记录但该日期不在任何覆盖区间：状态未知，而不是默认“已知可购”。
            return True, False
        return True, False

    @staticmethod
    def _aggregate_underlyings(funds: list[dict]) -> list[dict]:
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        output = []
        for key, shares in groups.items():
            representative = max(
                shares,
                key=lambda fund: (
                    len(fund.get("returns") or []),
                    _share_preference(str(fund.get("name") or "")),
                    -int(str(fund.get("code") or "999999")) if str(fund.get("code") or "").isdigit() else 0,
                ),
            )
            clone = dict(representative)
            clone["underlying_fund_id"] = key
            clone["share_codes"] = sorted(str(row.get("code") or "") for row in shares)
            clone["share_count"] = len(shares)
            output.append(clone)
        output.sort(key=lambda fund: str(fund.get("code") or ""))
        return output

    @staticmethod
    def _quarterly_rebalance_dates(funds: list[dict], horizon_years: int) -> list[str]:
        first_dates, last_dates = [], []
        for fund in funds:
            dates = fund.get("dates") or []
            if dates and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[0])[:DATE_TEXT_LENGTH]) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[-1])[:DATE_TEXT_LENGTH]):
                first_dates.append(str(dates[0])[:DATE_TEXT_LENGTH])
                last_dates.append(str(dates[-1])[:DATE_TEXT_LENGTH])
        if not first_dates or not last_dates:
            return []
        start = _dt.date.fromisoformat(min(first_dates))
        finish = _add_years(_dt.date.fromisoformat(max(last_dates)), -max(1, int(horizon_years)))
        output = []
        months_per_quarter = MONTHS_PER_YEAR // QUARTERS_PER_YEAR
        for year in range(start.year, finish.year + 1):
            for month in range(months_per_quarter, MONTHS_PER_YEAR + 1, months_per_quarter):
                day = _dt.date(year, month, calendar.monthrange(year, month)[1])
                while day.weekday() >= MARKET_WEEKDAYS_PER_WEEK:
                    day -= _dt.timedelta(days=1)
                if start <= day <= finish:
                    output.append(day.isoformat())
        return output

    def _build_snapshots(
        self, funds: list[dict], target_spec: dict | None = None,
        feature_memo: dict | None = None, progress=lambda *_: None,
        *, universe_mode: str = "strict_pit",
    ) -> tuple[list[dict], dict]:
        spec = dict(target_spec or {})
        horizon_years = max(
            MIN_LONG_TERM_HORIZON_YEARS,
            int(spec.get("horizon_years") or MIN_LONG_TERM_HORIZON_YEARS),
        )
        horizon_label = f"{horizon_years}y"

        # Keep every share class in the historical source pool.  The production policy chooses
        # A/C/etc. from holding-period cost; OOS must repeat that decision at every rebalance
        # using only share classes, history and fee schedules known at that date.
        share_groups: dict[str, list[dict]] = {}
        for fund in funds:
            share_groups.setdefault(_underlying_key(fund), []).append(fund)

        snapshots = []
        feature_memo = feature_memo if feature_memo is not None else {}
        availability_checks = availability_known = 0
        universe_checks = universe_known = 0
        rebalance_dates = self._quarterly_rebalance_dates(funds, horizon_years)
        for rebalance_index, rebalance_date in enumerate(rebalance_dates, 1):
            if rebalance_dates:
                progress(
                    f"{horizon_label} 训练快照 {rebalance_index}/{max(1, len(rebalance_dates))} · {rebalance_date}",
                    PERCENT_SCALE * rebalance_index / max(1, len(rebalance_dates)),
                )
            day = _dt.date.fromisoformat(rebalance_date)
            endpoint_date = _add_years(day, horizon_years).isoformat()
            rows = []
            fee_imputation, fee_imputation_fallback = self._fee_imputation_by_bucket(
                funds, horizon_years, as_of_date=rebalance_date,
            )

            for underlying, shares in share_groups.items():
                # First reproduce production share-class choice from the PIT investable universe.
                # Unknown historical universe membership remains excluded exactly as before;
                # current catalog state is never used to make this historical choice.
                candidates = []
                membership_states = []
                for fund in shares:
                    returns = fund.get("returns") or []
                    dates = fund.get("dates") or []
                    if len(dates) != len(returns):
                        continue
                    end = bisect.bisect_right(dates, rebalance_date)
                    if end < MIN_HISTORY_POINTS:
                        continue
                    if universe_mode == "survivor_conditioned_shadow":
                        # Approximate historical membership from observed NAV existence plus explicit
                        # inception/termination dates. This is intentionally survivor-conditioned:
                        # funds that disappeared before first installation may be absent from the pool.
                        inception = str(fund.get("inception_date") or (dates[0] if dates else ""))[:DATE_TEXT_LENGTH]
                        termination = str(fund.get("termination_date") or "")[:DATE_TEXT_LENGTH]
                        universe_eligible = not (
                            (inception and rebalance_date < inception)
                            or (termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and rebalance_date > termination)
                        )
                        universe_is_known = True
                    else:
                        universe_eligible, universe_is_known = self._universe_membership_at(fund, rebalance_date)
                    membership_states.append((bool(universe_eligible), bool(universe_is_known)))
                    # A share known inactive at this date cannot be selected. If its own catalog
                    # history is unknown but the underlying is known active via a sibling share,
                    # observed share history/inception is sufficient evidence that the share existed.
                    if universe_is_known and not universe_eligible:
                        continue
                    pit_product, pit_fees, pit_fees_verified = self._pit_fields(fund, rebalance_date)
                    pit_cost_fund = {**fund, "fees": pit_fees, "fees_verified": pit_fees_verified}
                    preference = (
                        0 if pit_fees_verified else 1,
                        _share_class_cost(pit_cost_fund, horizon_years) if pit_fees_verified else float("inf"),
                        -end,
                        -_share_preference(str(fund.get("name") or "")),
                        str(fund.get("code") or ""),
                    )
                    candidates.append((preference, fund, end, pit_product, pit_fees, pit_fees_verified))

                underlying_active_known = any(eligible and known for eligible, known in membership_states)
                underlying_inactive_known = bool(membership_states) and all(known and not eligible for eligible, known in membership_states)
                universe_checks += 1
                universe_known += int(underlying_active_known or underlying_inactive_known)
                if not underlying_active_known or not candidates:
                    continue

                _preference, fund, end, pit_product, pit_fees, pit_fees_verified = min(candidates, key=lambda row: row[0])
                returns = fund.get("returns") or []
                dates = fund.get("dates") or []

                # Apply purchase eligibility only after the share class has been chosen, mirroring
                # production. Known-unavailable is excluded; unknown is retained as unknown.
                availability_checks += 1
                historically_purchasable, availability_is_known = self._eligibility_at(fund, end, rebalance_date)
                availability_known += int(availability_is_known)
                if availability_is_known and not historically_purchasable:
                    continue

                # Require observed calendar coverage through the target date. A market-day
                # point may fall just after a weekend/holiday target, so proof of coverage is
                # the first actual observation on or after the target date.
                coverage_index = bisect.bisect_left(dates, endpoint_date)
                if coverage_index >= len(dates):
                    continue
                final_index = coverage_index + 1
                if final_index <= end:
                    continue
                segment = returns[end:final_index]
                if len(segment) < MIN_HISTORY_POINTS:
                    continue

                fee_fingerprint = json.dumps(
                    pit_fees if pit_fees_verified else {},
                    sort_keys=True, ensure_ascii=True, separators=(",", ":"),
                )
                asset_bucket = _asset_bucket(str(fund.get("name") or ""), str(fund.get("type") or ""))
                unknown_transaction_cost = fee_imputation.get(asset_bucket, fee_imputation_fallback)
                memo_key = (
                    fund["code"], end, horizon_years, fee_fingerprint,
                    round(_finite(unknown_transaction_cost), FLOAT_SERIALIZATION_DIGITS),
                )
                feature_result = feature_memo.get(memo_key)
                if feature_result is None:
                    feature_result = self.features(
                        returns, end, pit_fees if pit_fees_verified else None, dates=dates,
                        target_years=horizon_years, history_context=fund,
                        unknown_transaction_cost=unknown_transaction_cost,
                    )
                    feature_memo[memo_key] = feature_result
                if not feature_result:
                    continue

                total = _compound(segment)
                net_total, realized_cost_evidence = _realized_net_holding_return(
                    total, pit_fees if pit_fees_verified else None, horizon_years,
                    unknown_transaction_cost,
                )
                try:
                    anchor_day = _dt.date.fromisoformat(str(dates[end - 1])[:DATE_TEXT_LENGTH])
                    realized_day = _dt.date.fromisoformat(str(dates[final_index - 1])[:DATE_TEXT_LENGTH])
                except ValueError:
                    continue
                actual_years = (realized_day - anchor_day).days / AVERAGE_GREGORIAN_DAYS_PER_YEAR
                if actual_years <= 0.0:
                    continue
                gross_ann = -1.0 if total <= -1.0 else math.expm1(math.log1p(total) / actual_years)
                ann = -1.0 if net_total <= -1.0 else math.expm1(math.log1p(net_total) / actual_years)
                dd = abs(_max_drawdown(segment))
                vol, _downside, _standardized, _elapsed = _calendar_annualized_risk(
                    returns, dates, end, final_index
                )
                utility = ann - dd - vol
                selected_cost = (
                    _share_class_cost({**fund, "fees": pit_fees, "fees_verified": True}, horizon_years)
                    if pit_fees_verified else None
                )
                rows.append({
                    "code": fund["code"], "features": feature_result[0], "stats": feature_result[1],
                    "utility": utility, "drawdown": dd, "end": end, "future_end": endpoint_date,
                    "gross_annualized_return": gross_ann, "net_annualized_return": ann,
                    "observation_date": str(dates[end - 1])[:DATE_TEXT_LENGTH], "name": fund.get("name", ""),
                    "type": fund.get("type", ""), "underlying": underlying,
                    "pit_purchasable": bool(historically_purchasable),
                    "pit_availability_known": bool(availability_is_known),
                    "pit_fees_verified": bool(pit_fees_verified),
                    "pit_share_class_cost": selected_cost,
                    "pit_transaction_cost": realized_cost_evidence.get("effective_transaction_cost"),
                    "pit_fee_cost_source": realized_cost_evidence.get("cost_source"),
                })

            if len(rows) < len(self.FEATURE_NAMES):
                continue
            targets = _rank_scale([row["utility"] for row in rows])
            raw_rows = [row["features"] for row in rows]
            buckets = [_asset_bucket(row["name"], row["type"]) for row in rows]
            snapshots.append({
                "rows": self._scale_feature_rows(raw_rows, buckets),
                "raw_feature_rows": [list(row["features"]) for row in rows],
                "feature_stats": [dict(row["stats"]) for row in rows],
                "targets": targets,
                "target_components": {horizon_label: targets},
                "target_weights": {horizon_label: 1.0},
                "target_spec": dict(spec),
                "codes": [row["code"] for row in rows], "drawdowns": [row["drawdown"] for row in rows],
                "ends": [row["end"] for row in rows], "future_ends": [row["future_end"] for row in rows],
                "feature_observation_dates": [row["observation_date"] for row in rows],
                "underlying_keys": [row["underlying"] for row in rows],
                "pit_purchasable": [row["pit_purchasable"] for row in rows],
                "pit_availability_known": [row["pit_availability_known"] for row in rows],
                "pit_fees_verified": [row["pit_fees_verified"] for row in rows],
                "pit_share_class_costs": [row["pit_share_class_cost"] for row in rows],
                "pit_transaction_costs": [row["pit_transaction_cost"] for row in rows],
                "pit_fee_cost_sources": [row["pit_fee_cost_source"] for row in rows],
                "gross_annualized_returns": [row["gross_annualized_return"] for row in rows],
                "net_annualized_returns": [row["net_annualized_return"] for row in rows],
                "buckets": buckets,
                "regime": self._regime_from_rows(raw_rows), "feature_date": rebalance_date,
                "target_end_date": endpoint_date, "cross_section_synchronized": True,
                "share_class_selection": "PIT holding-period fee policy at each rebalance date",
            })
        snapshots.sort(key=lambda snap: snap["feature_date"])
        return snapshots, {
            "historical_availability_coverage": availability_known / max(1, availability_checks),
            "historical_universe_known_coverage": universe_known / max(1, universe_checks),
            "source_share_count": len(funds), "underlying_count": len(share_groups),
            "duplicate_shares_removed": max(0, len(funds) - len(share_groups)),
            # OOS needs the full share-class pool because snapshots can select different codes
            # for the same underlying at different historical rebalance dates.
            "funds": list(funds),
            "target_spec": dict(spec),
            "share_class_selection_mode": "point-in-time-per-rebalance",
            "historical_universe_mode": universe_mode,
            "survivor_conditioned": universe_mode == "survivor_conditioned_shadow",
        }

    @staticmethod
    def _non_overlapping_tail(snapshots: list[dict], limit: int) -> list[dict]:
        chosen = []
        next_feature_start = ""
        for snap in reversed(snapshots):
            if not next_feature_start or str(snap.get("target_end_date") or "") <= next_feature_start:
                chosen.append(snap)
                next_feature_start = str(snap.get("feature_date") or "")
                if len(chosen) >= limit:
                    break
        return list(reversed(chosen))

    @staticmethod
    def _regime_from_rows(rows: list[list[float]]) -> str:
        if not rows:
            return "range"
        ret_index = AdaptiveRanker.FEATURE_NAMES.index("entry_return_latest")
        volatility_index = AdaptiveRanker.FEATURE_NAMES.index("volatility_quality")
        trend_index = AdaptiveRanker.FEATURE_NAMES.index("trend_quality")
        entry_return = _median([row[ret_index] for row in rows])
        vol = _median([-row[volatility_index] for row in rows])
        trend = _median([row[trend_index] for row in rows])
        if entry_return < 0.0 and trend <= 0.0:
            return "risk_off"
        if vol > max(abs(entry_return), abs(trend)):
            return "high_vol"
        if entry_return > 0.0 and trend > 0.0:
            return "trend"
        if entry_return > 0.0:
            return "risk_on"
        return "range"

    @staticmethod
    def _scale_feature_rows(rows: list[list[float]], buckets: list[str]) -> list[list[float]]:
        """Keep cross-market magnitude, within-asset percentile, and explicit asset class together."""
        if not rows:
            return []
        base_dimensions = len(AdaptiveRanker.BASE_FEATURE_NAMES)
        if any(len(row) != base_dimensions for row in rows) or len(buckets) != len(rows):
            raise DataError("模型特征维度与资产类别维度不一致")
        groups = {}
        for i, bucket in enumerate(buckets):
            groups.setdefault(bucket, []).append(i)
        global_columns = list(zip(*rows))

        # Robust cross-market magnitude: unlike percentile ranks, this preserves how far apart
        # two funds are on absolute return/risk/cost evidence while bounding extreme outliers.
        absolute_scaled = []
        for column in global_columns:
            values = [_finite(value) for value in column]
            center = statistics.median(values)
            deviations = [abs(value - center) for value in values]
            scale = statistics.median(deviations) if deviations else 0.0
            if scale <= NUMERIC_TOLERANCE:
                scale = statistics.pstdev(values) if len(values) > 1 else 0.0
            if scale <= NUMERIC_TOLERANCE:
                absolute_scaled.append([0.0] * len(values))
            else:
                absolute_scaled.append([math.tanh((value - center) / scale) for value in values])

        within_scaled = [[0.0] * base_dimensions for _ in rows]
        for indexes in groups.values():
            for j in range(len(global_columns)):
                ranked = _rank_scale([rows[i][j] for i in indexes])
                for local, i in enumerate(indexes):
                    within_scaled[i][j] = 2.0 * ranked[local] - 1.0

        bucket_index = {bucket: index for index, bucket in enumerate(MODEL_ASSET_BUCKETS)}
        output = []
        for i, bucket in enumerate(buckets):
            absolute = [absolute_scaled[j][i] for j in range(base_dimensions)]
            asset_one_hot = [0.0] * len(MODEL_ASSET_BUCKETS)
            asset_one_hot[bucket_index.get(bucket, bucket_index["其他"])] = 1.0
            output.append(absolute + within_scaled[i] + asset_one_hot)
        if any(len(row) != len(AdaptiveRanker.FEATURE_NAMES) for row in output):
            raise DataError("扩展模型特征维度与 FEATURE_NAMES 不一致")
        return output

    def _fit_hierarchical_linear(self, xs: list[list[float]], ys: list[float], weights: list[float], buckets: list[str]) -> tuple[list[float], dict]:
        global_weights = self._solve_weighted_linear(xs, ys, weights) if xs else [0.0] * len(self.FEATURE_NAMES)
        global_weights = self._normalized_linear_weights(global_weights)
        asset_models = {}
        for bucket in sorted(set(buckets)):
            indexes = [i for i, value in enumerate(buckets) if value == bucket]
            if len(indexes) < len(self.FEATURE_NAMES):
                continue
            bx = [xs[i] for i in indexes]; by = [ys[i] for i in indexes]; bw = [weights[i] for i in indexes]
            asset_models[bucket] = {
                "linear_weights": self._normalized_linear_weights(self._solve_weighted_linear(bx, by, bw)),
                "training_samples": len(indexes),
            }
        return global_weights, asset_models

    @staticmethod
    def _hierarchical_linear_predict(row: list[float], bucket: str, global_weights: list[float], asset_models: dict | None) -> float:
        global_value = sum(a*b for a,b in zip(global_weights or [], row))
        spec = (asset_models or {}).get(bucket) if isinstance(asset_models, dict) else None
        asset_weights = spec.get("linear_weights") if isinstance(spec, dict) else None
        if not asset_weights:
            return global_value
        return sum(a*b for a,b in zip(asset_weights, row))

    @staticmethod
    def _normalized_linear_weights(weights: list[float]) -> list[float]:
        scale = sum(abs(v) for v in weights) or 1.0
        return [v / scale for v in weights]

    @classmethod
    def _normalized_asset_models(cls, models: dict) -> dict:
        output = {}
        for bucket, spec in (models or {}).items():
            if not isinstance(spec, dict) or not spec.get("linear_weights"):
                continue
            output[bucket] = {
                **spec,
                "linear_weights": cls._normalized_linear_weights(list(spec.get("linear_weights") or [])),
            }
        return output

    @staticmethod
    def _history_snapshot(history, as_of_date: str, value_keys: tuple[str, ...]) -> dict:
        if not isinstance(history, list) or not as_of_date:
            return {}
        best_date, best = "", {}
        for row in history:
            if not isinstance(row, dict):
                continue
            date = str(row.get("feature_date") or row.get("effective_date") or row.get("date") or "")[:DATE_TEXT_LENGTH]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or date > as_of_date[:DATE_TEXT_LENGTH] or date < best_date:
                continue
            value = None
            for key in value_keys:
                if isinstance(row.get(key), dict):
                    value = row.get(key); break
            if value is None and isinstance(row.get("values"), dict):
                value = row.get("values")
            if value is not None:
                best_date, best = date, dict(value)
        return best

    @classmethod
    def _pit_fields(cls, fund: dict, as_of_date: str) -> tuple[dict, dict, bool]:
        product = cls._history_snapshot(fund.get("product_features_history"), as_of_date, ("product_features", "features"))
        fees = cls._history_snapshot(fund.get("fees_history"), as_of_date, ("fees",))
                                                                                               
                                                                                         
        fee_verified = bool(fees)
        return product, fees, fee_verified

    _OPTIONAL_ML_LAST_STATUS = "not-attempted"
    _OPTIONAL_TREE2_LAST_STATUS = "not-attempted"

    @staticmethod
    def _ranking_labels(ys: list[float], group_sizes: list[int] | None):
        """Encode each query's observed ordinal rank directly; relevance resolution equals that query's sample count."""
        if not group_sizes or sum(int(v) for v in group_sizes) != len(ys) or any(int(v) < 2 for v in group_sizes):
            return None
        labels = []
        cursor = 0
        for size in group_sizes:
            size = int(size)
            segment = ys[cursor:cursor + size]
            scaled = _rank_scale(segment)
            labels.extend(int(round(_clamp(value, 0.0, 1.0) * (size - 1))) for value in scaled)
            cursor += size
        return labels

    @classmethod
    def _ensure_lightgbm(cls):
        settings = _load_install_settings()
        if settings.get("lightgbm") is not True:
            cls._OPTIONAL_ML_LAST_STATUS = "disabled-by-install-profile"
            return None
        active_dir = _active_dependency_dir(settings)
        if active_dir is None:
            cls._OPTIONAL_ML_LAST_STATUS = "local-lightgbm-pending-or-missing"
            return None
        if not _loaded_modules_are_local(active_dir, ("numpy", "scipy", "lightgbm")):
            cls._OPTIONAL_ML_LAST_STATUS = "refused-preloaded-nonlocal-native-stack"
            return None
        _activate_local_dependencies()
        try:
            import lightgbm as lgb
            module_path = Path(getattr(lgb, "__file__", "")).resolve()
            if active_dir.resolve() not in module_path.parents:
                cls._OPTIONAL_ML_LAST_STATUS = "refused-nonlocal-lightgbm"
                return None
            cls._OPTIONAL_ML_LAST_STATUS = f"available-local:{getattr(lgb, '__version__', 'unknown')}"
            return lgb
        except (ImportError, OSError, RuntimeError, ValueError) as exc:
            cls._OPTIONAL_ML_LAST_STATUS = f"unavailable-local:{type(exc).__name__}"
            return None

    @classmethod
    def _ensure_xgboost(cls):
        settings = _load_install_settings()
        if settings.get("advanced_tree") is not True:
            cls._OPTIONAL_TREE2_LAST_STATUS = "disabled-by-install-profile"
            return None
        active_dir = _active_dependency_dir(settings)
        if active_dir is None:
            cls._OPTIONAL_TREE2_LAST_STATUS = "local-xgboost-pending-or-missing"
            return None
        if not _loaded_modules_are_local(active_dir, ("numpy", "scipy", "xgboost")):
            cls._OPTIONAL_TREE2_LAST_STATUS = "refused-preloaded-nonlocal-native-stack"
            return None
        _activate_local_dependencies()
        try:
            import xgboost as xgb
            module_path = Path(getattr(xgb, "__file__", "")).resolve()
            if active_dir.resolve() not in module_path.parents:
                cls._OPTIONAL_TREE2_LAST_STATUS = "refused-nonlocal-xgboost"
                return None
            cls._OPTIONAL_TREE2_LAST_STATUS = f"available-local:{getattr(xgb, '__version__', 'unknown')}"
            return xgb
        except (ImportError, OSError, RuntimeError, ValueError) as exc:
            cls._OPTIONAL_TREE2_LAST_STATUS = f"unavailable-local:{type(exc).__name__}"
            return None

    @classmethod
    def _train_optional_lightgbm(cls, xs: list[list[float]], ys: list[float], weights: list[float], group_sizes: list[int] | None = None, hyperparams: dict | None = None, num_boost_round: int | None = None):
        lgb = cls._ensure_lightgbm()
        labels = cls._ranking_labels(ys, group_sizes)
        minimum_samples = len(cls.FEATURE_NAMES)
        if lgb is None or len(xs) < minimum_samples or labels is None:
            if lgb is not None:
                cls._OPTIONAL_ML_LAST_STATUS = f"insufficient-ranking-data:{len(xs)}"
            return None, None
        lightgbm_error = getattr(getattr(lgb, "basic", None), "LightGBMError", RuntimeError)
        native_errors = (ImportError, OSError, RuntimeError, ValueError, MemoryError, lightgbm_error)
        try:
            import numpy as np
            matrix = np.asarray(xs, dtype=float)
            sample_weights = np.asarray(weights, dtype=float) if weights else None
            dataset = lgb.Dataset(
                matrix, label=np.asarray(labels, dtype=int), weight=sample_weights,
                group=[int(value) for value in group_sizes], free_raw_data=True,
            )
            label_levels = max(labels) + 1 if labels else 2
            seed = cls.NONLINEAR_SEEDS[0]
            params = {
                "objective":"lambdarank", "metric":"ndcg", "ndcg_eval_at":[MODEL_SELECTION_SIZE],
                "label_gain":list(range(label_levels)), "verbosity":-1,
                "seed":seed, "deterministic":True, "num_threads":_adaptive_ml_threads(),
            }
            if hyperparams:
                params.update({key:value for key,value in hyperparams.items() if key in {"learning_rate","num_leaves","max_depth","lambda_l1","lambda_l2"}})
            if num_boost_round is None:
                booster = lgb.train(params, dataset)
            else:
                booster = lgb.train(params, dataset, num_boost_round=_adaptive_boost_rounds(int(num_boost_round)))
            spec = {
                "backend":"lightgbm-lambdarank", "model_string":booster.model_to_string(),
                "params":params, "training_samples":len(xs), "groups":len(group_sizes),
                "ranking_label_levels":label_levels, "weight_semantics":"query-group-mean-of-row-time-weights",
            }
            cls._OPTIONAL_ML_LAST_STATUS = f"trained-lambdarank:{len(xs)}:{len(group_sizes)}groups"
            return spec, (lambda row, b=booster, np=np: float(b.predict(np.asarray([row], dtype=float))[0]))
        except native_errors as exc:
            cls._OPTIONAL_ML_LAST_STATUS = f"train-failed:{type(exc).__name__}"
            _record_diagnostic("lightgbm-train", exc)
            return None, None

    @classmethod
    def _train_optional_xgboost(cls, xs: list[list[float]], ys: list[float], weights: list[float], group_sizes: list[int] | None = None, hyperparams: dict | None = None, num_boost_round: int | None = None):
        xgb = cls._ensure_xgboost()
        labels = cls._ranking_labels(ys, group_sizes)
        minimum_samples = len(cls.FEATURE_NAMES)
        if xgb is None or len(xs) < minimum_samples or labels is None:
            if xgb is not None:
                cls._OPTIONAL_TREE2_LAST_STATUS = f"insufficient-ranking-data:{len(xs)}"
            return None, None
        xgboost_error = getattr(getattr(xgb, "core", None), "XGBoostError", RuntimeError)
        native_errors = (ImportError, OSError, RuntimeError, ValueError, MemoryError, xgboost_error)
        try:
            import numpy as np
            matrix = np.asarray(xs, dtype=float)
            label_array = np.asarray(labels, dtype=float)
            dtrain = xgb.DMatrix(matrix, label=label_array)
            normalized_groups = [int(value) for value in group_sizes]
            group_array = np.asarray(normalized_groups)
            dtrain.set_group(normalized_groups)
            group_weight_array = None
            if weights and len(weights) == len(xs) and sum(normalized_groups) == len(xs):
                group_weights = []
                offset = 0
                for size in normalized_groups:
                    chunk = [_finite(value, 1.0) for value in weights[offset:offset + size]]
                    group_weights.append(max(sys.float_info.epsilon, statistics.fmean(chunk) if chunk else 1.0))
                    offset += size
                # XGBoost learning-to-rank defines weights per query/group, not per row.
                group_weight_array = np.asarray(group_weights, dtype=float)
                dtrain.set_weight(group_weight_array)
            adaptive_settings = _load_install_settings()
            cuda_selection = {"available": False, "device": "cpu"}
            observed_working_set_bytes = matrix.nbytes + label_array.nbytes + group_array.nbytes
            if group_weight_array is not None:
                observed_working_set_bytes += group_weight_array.nbytes
            required_mib = max(1, math.ceil(observed_working_set_bytes / BYTES_PER_MIB))
            if adaptive_settings.get("xgboost_distribution") == "xgboost_gpu":
                # This is deliberately only a measured data-working-set floor, not a claim that
                # XGBoost's gradients/histograms/native allocations equal NumPy matrix bytes.
                candidate = _select_cuda_training_device(required_mib)
                blocked = bool(candidate.get("available") and _cuda_backoff_blocks(adaptive_settings, candidate.get("probe") or {}))
                cuda_selection = dict(candidate)
                if blocked:
                    cuda_selection["available"] = False
            xgb_device = str(cuda_selection.get("device") or "cpu") if cuda_selection.get("available") else "cpu"
            label_levels = max(labels) + 1 if labels else 2
            params = {
                "objective":"rank:ndcg", "eval_metric":f"ndcg@{MODEL_SELECTION_SIZE}",
                "device":xgb_device, "seed":cls.NONLINEAR_SEEDS[0], "nthread":_adaptive_ml_threads(),
            }
            if hyperparams:
                params.update({key:value for key,value in hyperparams.items() if key in {"eta","max_depth","min_child_weight","lambda","alpha"}})
            cuda_fallback = False
            train_kwargs = {"verbose_eval": False}
            if num_boost_round is not None:
                train_kwargs["num_boost_round"] = _adaptive_boost_rounds(int(num_boost_round))
            try:
                booster = xgb.train(params, dtrain, **train_kwargs)
                if _is_cuda_device(params.get("device")):
                    _record_cuda_success(cuda_selection)
            except native_errors as cuda_exc:
                if not _is_cuda_device(params.get("device")):
                    raise
                _record_cuda_failure(
                    cuda_exc, device=str(params.get("device") or ""),
                    required_free_mib=required_mib, selection=cuda_selection,
                )
                params["device"] = "cpu"
                booster = xgb.train(params, dtrain, **train_kwargs)
                cuda_fallback = True
            raw = bytes(booster.save_raw(raw_format="ubj"))
            spec = {
                "backend":"xgboost-rank-ndcg", "model_b64":base64.b64encode(raw).decode("ascii"),
                "params":params, "training_samples":len(xs), "groups":len(group_sizes),
                "ranking_label_levels":label_levels,
                "cuda_selection": {
                    "device": xgb_device,
                    "free_mib_at_start": int(_finite(cuda_selection.get("free_mib"), 0)),
                    "required_free_mib": int(_finite(cuda_selection.get("required_free_mib"), 0)),
                    "utilization_gpu_pct": int(_finite(cuda_selection.get("utilization_gpu_pct"), 0)),
                },
            }
            cls._OPTIONAL_TREE2_LAST_STATUS = (
                f"trained-rank-ndcg:{len(xs)}:{len(group_sizes)}groups"
                + (":cuda-fallback-cpu" if cuda_fallback else "")
            )
            return spec, (lambda row, b=booster, xgb=xgb, np=np: float(b.predict(xgb.DMatrix(np.asarray([row], dtype=float)))[0]))
        except native_errors as exc:
            cls._OPTIONAL_TREE2_LAST_STATUS = f"train-failed:{type(exc).__name__}"
            _record_diagnostic("xgboost-train", exc)
            return None, None

    @staticmethod
    def _optional_predictor(spec: dict | None):
        if not isinstance(spec, dict):
            return None
        backend = str(spec.get("backend") or "")
        settings = _load_install_settings()
        try:
            active_dir = _active_dependency_dir(settings)
            if active_dir is None:
                return None
            required_loaded = ("numpy", "scipy", "lightgbm") if backend == "lightgbm-lambdarank" else ("numpy", "scipy", "xgboost")
            if not _loaded_modules_are_local(active_dir, required_loaded):
                return None
            _activate_local_dependencies()
            if backend == "lightgbm-lambdarank" and spec.get("model_string") and settings.get("lightgbm") is True:
                import lightgbm as lgb
                import numpy as np
                module_path = Path(getattr(lgb, "__file__", "")).resolve()
                if active_dir.resolve() not in module_path.parents:
                    return None
                booster = lgb.Booster(model_str=spec["model_string"])
                return lambda row, b=booster, np=np: float(b.predict(np.asarray([row], dtype=float))[0])
            if backend == "xgboost-rank-ndcg" and spec.get("model_b64") and settings.get("advanced_tree") is True:
                import xgboost as xgb
                import numpy as np
                module_path = Path(getattr(xgb, "__file__", "")).resolve()
                if active_dir.resolve() not in module_path.parents:
                    return None
                booster = xgb.Booster()
                booster.load_model(bytearray(base64.b64decode(spec["model_b64"])))
                configured_device = str(settings.get("xgboost_device") or "cpu")
                trained_device = str((spec.get("params") or {}).get("device") or "cpu")
                device = trained_device if configured_device.startswith("cuda") and trained_device.startswith("cuda") else "cpu"
                booster.set_param({"device": device})
                return lambda row, b=booster, xgb=xgb, np=np: float(b.predict(xgb.DMatrix(np.asarray([row], dtype=float)))[0])
        except (ImportError, OSError, RuntimeError, ValueError, MemoryError, binascii.Error):
            return None
        return None




    @staticmethod
    def _training_flatten(group):
        xs, ys, ws, buckets, group_sizes = [], [], [], [], []
        for snap in group:
            weight = 1.0
            xs.extend(snap["rows"]); ys.extend(snap["targets"]); ws.extend([weight] * len(snap["rows"]))
            group_sizes.append(len(snap["rows"]))
            snap_buckets = list(snap.get("buckets") or [])
            if len(snap_buckets) != len(snap["rows"]):
                snap_buckets = ["其他"] * len(snap["rows"])
            buckets.extend(snap_buckets)
        return xs, ys, ws, buckets, group_sizes

    @classmethod
    def _training_entry_values(cls, rows):
        names = cls.FEATURE_NAMES
        selected = [names.index(name) for name in (
            "entry_return_latest", "trend_quality", "drawdown_quality",
            "volatility_quality", "recovery_quality",
        ) if name in names]
        return [statistics.fmean(row[index] for index in selected) if selected else 0.0 for row in rows]

    @staticmethod
    def _training_one_metrics(preds, snap):
        targets = snap["targets"]
        ric = _spearman(preds, targets) if len(preds) >= 2 else 0.0
        k = min(MODEL_SELECTION_SIZE, len(preds)); order = sorted(range(len(preds)), key=lambda i: preds[i], reverse=True)[:k]
        top = sum(targets[i] for i in order) / max(1, k)
        ddq = _rank_scale([-v for v in snap["drawdowns"]]); draw = sum(ddq[i] for i in order) / max(1, k)
        return ric, top, draw

    @staticmethod
    def _training_aggregate(records):
        if not records:
            return {"windows":0,"rank_ic_mean":0.0,"rank_ic_median":0.0,"rank_ic_positive_ratio":0.0,"rank_ic_worst":0.0,"rank_ic_p25":0.0,"model_quality":-1.0}
        rics = [record[0] for record in records]
        tops = [record[1] for record in records]
        draws = [record[2] for record in records]
        ordered = sorted(rics)
        quartile_count = len(("Q1", "Q2", "Q3", "Q4"))
        p25_index = max(0, math.ceil(len(ordered) / quartile_count) - 1)
        p25 = ordered[p25_index]
        median = statistics.median(rics)
        mean = statistics.fmean(rics)
        positive_ratio = sum(value > 0 for value in rics) / len(rics)
        worst = min(rics)
        top_utility = statistics.fmean(tops)
        drawdown_quality = statistics.fmean(draws)
        sign_quality = 2.0 * positive_ratio - 1.0
        return {
            "windows":len(rics), "rank_ic_mean":mean, "rank_ic_median":median,
            "rank_ic_positive_ratio":positive_ratio, "rank_ic_worst":worst,
            "rank_ic_p25":p25, "top100_utility":top_utility,
            "drawdown_quality":drawdown_quality,
            # Compatibility/reporting field only. Candidate selection is lexicographic via
            # _training_metric_key; no heterogeneous metrics are averaged into a policy score.
            "model_quality":median,
        }

    @staticmethod
    def _training_metric_key(metrics: dict) -> tuple[float, ...]:
        """Objective deployment ordering without hidden numeric weights."""
        floor = -sys.float_info.max
        return (
            _finite(metrics.get("rank_ic_median"), floor),
            _finite(metrics.get("top100_utility"), floor),
            _finite(metrics.get("rank_ic_worst"), floor),
            _finite(metrics.get("drawdown_quality"), floor),
            _finite(metrics.get("rank_ic_positive_ratio"), floor),
            _finite(metrics.get("rank_ic_mean"), floor),
        )

    @classmethod
    def _training_eligible_folds(cls, snaps):
        folds = []
        for index, snap in enumerate(snaps):
            prior = [candidate for candidate in snaps[:index] if str(candidate.get("target_end_date") or "") <= str(snap.get("feature_date") or "")]
            samples = sum(len(candidate["rows"]) for candidate in prior)
            if prior and samples >= len(cls.FEATURE_NAMES):
                folds.append((prior, snap))
        return folds

    def _training_split_evaluation_folds(self, folds):
        stage_names = ("development", "deployment", "untouched")
        independent_snaps = self._non_overlapping_tail([snap for _, snap in folds], len(folds))
        keys = {str(snap.get("feature_date") or "") for snap in independent_snaps}
        independent = sorted(
            (fold for fold in folds if str(fold[1].get("feature_date") or "") in keys),
            key=lambda fold: str(fold[1].get("feature_date") or ""),
        )
        if len(independent) < len(stage_names):
            return [], [], [], independent
        base_size, remainder = divmod(len(independent), len(stage_names))
        stage_sizes = [base_size + (index < remainder) for index in range(len(stage_names))]
        development_end = stage_sizes[0]
        deployment_end = development_end + stage_sizes[1]
        development = independent[:development_end]
        deployment = independent[development_end:deployment_end]
        untouched = independent[deployment_end:]
        if not development or not deployment or not untouched:
            return [], [], [], independent
        return development, deployment, untouched, independent

    def _training_development_target_search(
        self, funds: list[dict], progress=lambda *_: None, *, universe_mode: str = "strict_pit",
    ):
        """Generate >=3y horizons from observed history and select one using development walk-forward OOS."""
        target_trials = []
        shared_feature_memo = {}
        specs = _candidate_target_specs(funds)
        if not specs:
            return None
        for spec_index, spec in enumerate(specs, 1):
            years = int(spec["horizon_years"])
            progress(
                f"构建数据支持的 {years} 年长期训练快照",
                PERCENT_SCALE * (spec_index - 1) / max(1, len(specs)),
            )
            snaps, info = self._build_snapshots(
                funds, spec, feature_memo=shared_feature_memo, universe_mode=universe_mode,
                progress=lambda text, pct, si=spec_index: progress(
                    text, PERCENT_SCALE * ((si - 1) + _clamp(_finite(pct), 0.0, PERCENT_SCALE) / PERCENT_SCALE) / max(1, len(specs)),
                ),
            )
            folds = self._training_eligible_folds(snaps)
            development_folds, deployment_folds, untouched_folds, independent_folds = self._training_split_evaluation_folds(folds)
            if not development_folds or not deployment_folds or not untouched_folds:
                continue
            cached = []
            for prior, snap in development_folds:
                xs, ys, ws, bks, _groups = self._training_flatten(prior)
                gw, am = self._fit_hierarchical_linear(xs, ys, ws, bks)
                sb = snap.get("buckets") or ["其他"] * len(snap["rows"])
                long_pred = [self._hierarchical_linear_predict(row, bucket, gw, am) for row, bucket in zip(snap["rows"], sb)]
                entry_pred = [2 * value - 1 for value in _rank_scale(self._training_entry_values(snap["rows"]))]
                cached.append((snap, [2 * value - 1 for value in _rank_scale(long_pred)], entry_pred))
            # Fit the long-vs-entry blend from development OOS itself.  The coefficient is the
            # least-squares projection of target utility ranks onto (long-entry), clamped to a convex blend.
            blend_numerator = blend_denominator = 0.0
            for snap, long_rank, entry_rank in cached:
                target_rank = [2 * value - 1 for value in _rank_scale(snap.get("utility") or [])]
                for long_value, entry_value, target_value in zip(long_rank, entry_rank, target_rank):
                    delta = long_value - entry_value
                    blend_numerator += delta * (target_value - entry_value)
                    blend_denominator += delta * delta
            blend = _clamp(
                blend_numerator / blend_denominator if blend_denominator > sys.float_info.epsilon else PROBABILITY_MIDPOINT,
                0.0, 1.0,
            )
            records = [
                self._training_one_metrics([blend * long_value + (1 - blend) * entry_value for long_value, entry_value in zip(long_rank, entry_rank)], snap)
                for snap, long_rank, entry_rank in cached
            ]
            metrics = self._training_aggregate(records)
            target_trials.append((
                self._training_metric_key(metrics), metrics["rank_ic_median"], metrics["rank_ic_p25"],
                spec, blend, snaps, info, folds, development_folds, deployment_folds, untouched_folds,
                independent_folds, metrics,
            ))
        progress("数据支持的长期期限 OOS 搜索完成", PERCENT_SCALE)
        return max(target_trials, key=lambda item: (item[0], item[1], item[2])) if target_trials else None

    def _training_deployment_gate(
        self, training_funds, deployment_folds, deployment_training, best_baseline, best_ai,
        fit_mode_model, aggregate, paired_window_evidence, candidate_dev_gate, universe_coverage,
        prediction_feedback, production_baseline=None,
    ):
        deployment_snaps = [snap for _, snap in deployment_folds]
        deployment_baseline_model = fit_mode_model(
            deployment_training, best_baseline,
            "labels matured before independent deployment validation start",
        )
        baseline_oos = self._full_pipeline_oos(
            training_funds, deployment_snaps, deployment_baseline_model
        ) if deployment_baseline_model else aggregate([])

        deployment_candidate_model = fit_mode_model(
            deployment_training, best_ai,
            "labels matured before independent deployment validation start",
        ) if best_ai else None
        target_feedback = _target_feedback_for_model(prediction_feedback, deployment_candidate_model or production_baseline or {})
        feedback_gate = {
            "evaluated": False, "passed": True,
            "reason": "no AI candidate reached feedback/deployment validation",
            "target_horizon_years": _model_target_years(deployment_candidate_model or production_baseline or {}),
            "samples": int(_finite(target_feedback.get("samples"), 0)),
            "cohorts": int(_finite(target_feedback.get("cohorts"), 0)),
            "strength": _clamp(_finite(target_feedback.get("strength"), 0.0), 0.0, 1.0),
        }
        if deployment_candidate_model is not None:
            # Governance invariant: this is A′, the exact feedback-adjusted candidate. OOS below
            # validates A′ itself; no production weight mutation is allowed after this gate.
            deployment_candidate_model, feedback_gate = _prediction_feedback_adjusted_model(
                deployment_candidate_model, prediction_feedback,
            )
        candidate_oos = self._full_pipeline_oos(
            training_funds, deployment_snaps, deployment_candidate_model
        ) if deployment_candidate_model else aggregate([])
        window_evidence = paired_window_evidence(candidate_oos, baseline_oos)
        rankic_uplift = _finite(candidate_oos.get("rank_ic_median"), -sys.float_info.max) - _finite(baseline_oos.get("rank_ic_median"), 0.0)
        candidate_oos_key = self._full_oos_metric_key(candidate_oos)
        baseline_oos_key = self._full_oos_metric_key(baseline_oos)
        # Backward-compatible numeric field: quality now means the primary metric (median RankIC).
        quality_uplift = rankic_uplift
        required_windows = len(deployment_snaps)
        enough_independent_evidence = bool(
            required_windows > 0
            and window_evidence.get("windows", 0) == required_windows
            and candidate_oos.get("windows", 0) == required_windows
            and baseline_oos.get("windows", 0) == required_windows
        )
        aggregate_improved = bool(rankic_uplift >= 0.0 and candidate_oos_key > baseline_oos_key)
        production_required = bool(
            isinstance(production_baseline, dict)
            and production_baseline.get("feature_names") == self.FEATURE_NAMES
            and production_baseline.get("trained_at")
        )
        production_oos = self._full_pipeline_oos(
            training_funds, deployment_snaps, production_baseline
        ) if production_required else aggregate([])
        production_window_evidence = paired_window_evidence(candidate_oos, production_oos) if production_required else {
            "windows": required_windows, "mean_uplift": 0.0, "worst_uplift": 0.0, "all_non_degrading": True,
        }
        production_rankic_uplift = (
            _finite(candidate_oos.get("rank_ic_median"), -sys.float_info.max)
            - _finite(production_oos.get("rank_ic_median"), 0.0)
        ) if production_required else 0.0
        production_oos_key = self._full_oos_metric_key(production_oos) if production_required else candidate_oos_key
        production_quality_uplift = production_rankic_uplift
        production_passed = bool(
            not production_required
            or (
                production_window_evidence.get("windows", 0) == required_windows
                and production_oos.get("windows", 0) == required_windows
                and production_oos.get("windows_non_overlapping") is True
                and production_window_evidence.get("all_non_degrading") is True
                and production_rankic_uplift >= 0.0
                and candidate_oos_key > production_oos_key
            )
        )
        passed = bool(
            candidate_dev_gate and deployment_candidate_model is not None
            and feedback_gate.get("passed") is True
            and enough_independent_evidence
            and candidate_oos.get("windows_non_overlapping") is True
            and baseline_oos.get("windows_non_overlapping") is True
            and window_evidence.get("all_non_degrading") is True
            and aggregate_improved
            and production_passed
        )
        if universe_coverage < UNIVERSE_EXPERT_ONLY_COVERAGE:
            reason = "historical universe coverage below robust-baseline boundary"
        elif universe_coverage < UNIVERSE_COMPLEX_ML_COVERAGE and not best_ai:
            reason = "historical universe coverage permits linear but not complex ML"
        elif not candidate_dev_gate:
            reason = "development candidate did not clear stability/uplift prerequisites"
        elif deployment_candidate_model is None:
            reason = "frozen candidate could not be refit before deployment validation"
        elif feedback_gate.get("passed") is not True:
            reason = str(feedback_gate.get("reason") or "realized prediction feedback guardrail failed")
        elif not enough_independent_evidence:
            reason = "feedback-adjusted candidate A′ has insufficient mature independent deployment windows; production model retained"
        elif window_evidence.get("all_non_degrading") is not True:
            reason = f"feedback-adjusted candidate A′ degraded at least one independent deployment window; worst RankIC uplift {_format_unrounded_number(window_evidence.get('worst_uplift', -sys.float_info.max), signed=True)}"
        elif not aggregate_improved:
            reason = f"feedback-adjusted candidate A′ did not improve the lexicographic deployment objective; median RankIC uplift {_format_unrounded_number(rankic_uplift, signed=True)}"
        elif not production_passed:
            reason = (
                "feedback-adjusted candidate A′ did not prove superiority to the current production model; "
                f"production median RankIC uplift {_format_unrounded_number(production_rankic_uplift, signed=True)}; production retained"
            )
        elif not passed:
            reason = "feedback-adjusted candidate A′ failed independent deployment invariants"
        else:
            reason = "feedback-adjusted final candidate A′ was non-degrading in every mature deployment window and improved the lexicographic deployment objective"
        return {
            "passed": passed, "reason": reason, "candidate_oos": candidate_oos,
            "baseline_oos": baseline_oos, "rankic_uplift": rankic_uplift,
            "quality_uplift": quality_uplift, "window_evidence": window_evidence,
            "production_required": production_required, "production_passed": production_passed,
            "production_oos": production_oos, "production_window_evidence": production_window_evidence,
            "production_rankic_uplift": production_rankic_uplift, "production_quality_uplift": production_quality_uplift,
            "feedback_gate": feedback_gate, "final_candidate_revalidated": deployment_candidate_model is not None,
        }

    @staticmethod
    def _untouched_catastrophic_dominance(candidate_metrics: dict, reference_metrics: dict) -> bool:
        """Precommitted one-way veto: reference must strictly dominate on return/rank/risk together."""
        candidate_windows = max(0, int(_finite(candidate_metrics.get("windows"), 0)))
        reference_windows = max(0, int(_finite(reference_metrics.get("windows"), 0)))
        if candidate_windows <= 0 or candidate_windows != reference_windows:
            return False
        return bool(
            _finite(candidate_metrics.get("rank_ic_median"), -sys.float_info.max)
            < _finite(reference_metrics.get("rank_ic_median"), -sys.float_info.max)
            and _finite(candidate_metrics.get("top100_excess_return"), -sys.float_info.max)
            < _finite(reference_metrics.get("top100_excess_return"), -sys.float_info.max)
            and _finite(candidate_metrics.get("max_oos_drawdown"), sys.float_info.max)
            > _finite(reference_metrics.get("max_oos_drawdown"), sys.float_info.max)
        )

    def _training_untouched_audit(
        self, training_funds, untouched_folds, evaluation_training, deployment_gate_passed,
        best_ai, best_baseline, gate_reason, fit_mode_model, aggregate, prediction_feedback,
        production_baseline=None,
    ):
        ai_enabled = deployment_gate_passed
        selected_mode = best_ai if ai_enabled else best_baseline
        evaluation_model = fit_mode_model(
            evaluation_training, selected_mode,
            "all labels matured before untouched audit start; deployment gate already frozen",
        )
        if evaluation_model is None:
            ai_enabled = False
            selected_mode = best_baseline
            gate_reason += "; selected family refit failed, reverted to robust baseline"
            evaluation_model = fit_mode_model(evaluation_training, selected_mode, "baseline refit before untouched audit")
        elif ai_enabled:
            evaluation_model, _feedback_gate = _prediction_feedback_adjusted_model(
                evaluation_model, prediction_feedback,
            )
        untouched_snaps = [snap for _, snap in untouched_folds]
        candidate_oos = self._full_pipeline_oos(
            training_funds, untouched_snaps, evaluation_model
        ) if evaluation_model else aggregate([])
        baseline_model = fit_mode_model(
            evaluation_training, best_baseline,
            "robust baseline fit frozen before untouched safety audit",
        )
        baseline_oos = self._full_pipeline_oos(
            training_funds, untouched_snaps, baseline_model,
        ) if baseline_model else aggregate([])
        production_required = bool(
            isinstance(production_baseline, dict)
            and production_baseline.get("feature_names") == self.FEATURE_NAMES
            and production_baseline.get("trained_at")
        )
        production_oos = self._full_pipeline_oos(
            training_funds, untouched_snaps, production_baseline,
        ) if production_required else aggregate([])

        veto_sources = []
        if ai_enabled and self._untouched_catastrophic_dominance(candidate_oos, baseline_oos):
            veto_sources.append("robust_baseline")
        if ai_enabled and production_required and self._untouched_catastrophic_dominance(candidate_oos, production_oos):
            veto_sources.append("current_production")
        veto_triggered = bool(veto_sources)
        if veto_triggered:
            ai_enabled = False
            selected_mode = best_baseline
            gate_reason += "; untouched safety veto: candidate was strictly dominated on median RankIC, excess return, and max drawdown by " + ",".join(veto_sources)
            evaluation_model = baseline_model
            candidate_oos_after_veto = baseline_oos
        else:
            candidate_oos_after_veto = candidate_oos
        veto = {
            "evaluated": bool(untouched_snaps),
            "triggered": veto_triggered,
            "sources": veto_sources,
            "rule": "veto only when a frozen reference strictly dominates candidate on untouched median RankIC, Top100 excess return, and max OOS drawdown; untouched data never tune or promote",
            "candidate_untouched_oos": candidate_oos,
            "baseline_untouched_oos": baseline_oos,
            "production_untouched_oos": production_oos,
            "production_comparison_required": production_required,
        }
        return ai_enabled, selected_mode, gate_reason, evaluation_model, untouched_snaps, candidate_oos_after_veto, veto

    def _training_production_refit(self, training_funds, untouched_snaps, evaluation_training, ai_enabled, selected_mode, best_baseline, gate_reason, evaluation_model, full_oos, fit_mode_model, aggregate, mode_components, long_blend):
        # Untouched outcomes may only exercise the fixed one-way catastrophic veto above; they
        # never choose parameters, promote a family, or enter production coefficients/trees.
        production_model = fit_mode_model(evaluation_training, selected_mode, "production refit uses only labels matured before untouched audit start; untouched outcomes never enter coefficients/trees")
        if production_model is None and selected_mode != best_baseline:
            ai_enabled = False
            selected_mode = best_baseline
            gate_reason += "; production refit unavailable, reverted to robust baseline"
            evaluation_model = fit_mode_model(evaluation_training, selected_mode, "baseline refit before untouched audit")
            full_oos = self._full_pipeline_oos(training_funds, untouched_snaps, evaluation_model) if evaluation_model else aggregate([])
            production_model = fit_mode_model(evaluation_training, selected_mode, "baseline production refit excluding untouched audit outcomes")
        if production_model is None:
            production_model = {
                "linear_weights":[0.0]*len(self.FEATURE_NAMES), "asset_models":{},
                "asset_model_policy": "asset-specific-if-trained-else-global",
                "nonlinear_models":[], "optional_ml":None, "optional_tree2":None,
                "component_weights":mode_components("expert"), "baseline_mode":"expert",
                "long_term_blend":long_blend, "training_samples":0, "fit_dataset":"emergency expert fallback",
            }
            ai_enabled = False
            selected_mode = "expert"
        return ai_enabled, selected_mode, gate_reason, evaluation_model, full_oos, production_model

    def _training_baseline_predictors(self):
        names = self.FEATURE_NAMES
        def mean_predictor(feature_names):
            indexes = tuple(names.index(name) for name in feature_names if name in names)
            return lambda row, indexes=indexes: statistics.fmean(row[index] for index in indexes) if indexes else 0.0
        expert_scale = sum(abs(value) for value in self.EXPERT_WEIGHTS) or 1.0
        expert_weights = [value / expert_scale for value in self.EXPERT_WEIGHTS]
        return {
            "expert": lambda row: sum(weight * value for weight, value in zip(expert_weights, row)),
            "defensive": mean_predictor((
                "drawdown_quality", "volatility_quality", "worst_period", "stability_quality",
                "transaction_cost_target_quality", "ulcer_quality", "bear_stress_quality",
            )),
            "low_volatility": mean_predictor((
                "volatility_quality", "drawdown_quality", "ulcer_quality",
                "stability_quality", "long_evidence_strength",
            )),
            "quality_momentum": mean_predictor((
                "entry_return_latest", "return_target_ann", "zero_baseline_return_volatility_target",
                "trend_quality", "rolling_target_worst", "long_evidence_strength",
            )),
        }

    def _training_partition_selection(self, development_selection) -> dict:
        (
            _, _, _, selected_spec, long_blend, snapshots, snapshot_info, folds,
            development_folds, deployment_folds, untouched_folds, independent_folds, target_cv,
        ) = development_selection
        training_funds = snapshot_info["funds"]
        first_deployment_feature = min((snap["feature_date"] for _, snap in deployment_folds), default="")
        first_test_feature = min((snap["feature_date"] for _, snap in untouched_folds), default="")
        deployment_training = [
            snap for snap in snapshots
            if first_deployment_feature and snap["target_end_date"] <= first_deployment_feature
        ]
        evaluation_training = [
            snap for snap in snapshots
            if first_test_feature and snap["target_end_date"] <= first_test_feature
        ]
        if not deployment_training:
            excluded = {id(fold[1]) for fold in deployment_folds + untouched_folds}
            deployment_training = [snap for snap in snapshots if id(snap) not in excluded]
        if not evaluation_training:
            excluded = {id(fold[1]) for fold in untouched_folds}
            evaluation_training = [snap for snap in snapshots if id(snap) not in excluded]
        return {
            "selected_spec": selected_spec, "long_blend": long_blend, "snapshots": snapshots,
            "snapshot_info": snapshot_info, "folds": folds, "development_folds": development_folds,
            "deployment_folds": deployment_folds, "untouched_folds": untouched_folds,
            "independent_folds": independent_folds, "target_cv": target_cv,
            "training_funds": training_funds, "first_deployment_feature": first_deployment_feature,
            "first_test_feature": first_test_feature, "deployment_training": deployment_training,
            "evaluation_training": evaluation_training,
        }

    def _training_model_capacity(self, context: dict) -> dict:
        snapshot_info = context["snapshot_info"]
        coverage = _clamp(_finite(snapshot_info.get("historical_universe_known_coverage"), 0.0), 0.0, 1.0)
        known_funds = coverage * max(1, len(context["training_funds"]))
        dimensions = max(1, len(self.FEATURE_NAMES))
        linear_support = dimensions
        interaction_support = dimensions * math.log2(dimensions + 1.0)
        allow_linear = known_funds >= linear_support
        allow_complex = known_funds >= interaction_support
        allow_tree = allow_complex and bool(context["deployment_folds"])
        return {
            "universe_coverage": coverage, "effective_known_funds": known_funds,
            "linear_support_required": linear_support, "complex_support_required": interaction_support,
            "allow_linear_model": allow_linear, "allow_complex_ml": allow_complex,
            "allow_tree_models": allow_tree,
        }

    def _training_record_family(self, state: dict, name: str, preds: list[float], snap: dict) -> None:
        state["family_records"][name].append(self._training_one_metrics(preds, snap))
        codes = list(snap.get("codes") or [])
        eligible = state["family_eligible_counts"][name]
        selected = state["family_top_counts"][name]
        for code in codes:
            eligible[code] = eligible.get(code, 0) + 1
        # Stability is measured on the same Top100 selection the product actually displays.
        depth = min(len(preds), MODEL_SELECTION_SIZE)
        state["selection_depths"].append(depth)
        for index in sorted(range(len(preds)), key=lambda i: preds[i], reverse=True)[:depth]:
            if index < len(codes):
                code = codes[index]
                selected[code] = selected.get(code, 0) + 1

    def _training_tune_tree_params(self, prior, trainer, grid, long_blend: float):
        if not grid:
            return {}
        default = dict(grid[len(grid) // 2])
        if len(grid) == 1:
            return default
        if len(prior) < 2:
            return default
        feature_dimensions = max(1, len(self.FEATURE_NAMES))
        trials = []
        for params in grid:
            records = []
            for cut in range(1, len(prior)):
                train_snaps = prior[:cut]
                valid_snap = prior[cut]
                ix, iy, iw, _ib, ig = self._training_flatten(train_snaps)
                if not ix:
                    continue
                rounds = _adaptive_boost_rounds(
                    max(1, int(math.ceil(math.sqrt(len(ix)) * math.log2(feature_dimensions + 1.0))))
                )
                _spec, predict = trainer(
                    ix, iy, iw, ig, hyperparams=dict(params), num_boost_round=rounds
                )
                if predict is None:
                    continue
                long_rank = [
                    2 * value - 1
                    for value in _rank_scale([predict(row) for row in valid_snap["rows"]])
                ]
                entry_rank = [
                    2 * value - 1
                    for value in _rank_scale(self._training_entry_values(valid_snap["rows"]))
                ]
                preds = [
                    long_blend * long_value + (1 - long_blend) * entry_value
                    for long_value, entry_value in zip(long_rank, entry_rank)
                ]
                records.append(self._training_one_metrics(preds, valid_snap))
            if not records:
                continue
            metrics = self._training_aggregate(records)
            trials.append((self._training_metric_key(metrics), dict(params)))
        return max(trials, key=lambda row: row[0])[1] if trials else default

    @staticmethod
    def _equal_rank_mix(*components: list[float]) -> list[float]:
        available = [list(values) for values in components if values is not None]
        if not available:
            return []
        return [sum(values) / len(values) for values in zip(*available)]

    def _training_compare_families(self, context: dict, baseline_predictors: dict, progress) -> dict:
        capacity = self._training_model_capacity(context)
        long_blend = context["long_blend"]
        family_names = [
            *baseline_predictors.keys(), "linear", "nonlinear", "ensemble", "lightgbm",
            "ensemble_ml", "xgboost", "ensemble_xgb", "ensemble_dual_tree",
        ]
        state = {
            "family_records": {name: [] for name in family_names},
            "family_top_counts": {name: {} for name in family_names},
            "family_eligible_counts": {name: {} for name in family_names},
            "selection_depths": [],
        }
        nonlinear_seeds = self._adaptive_nonlinear_seeds()
        lgb_grid, xgb_grid = self._adaptive_lightgbm_grid(), self._adaptive_xgboost_grid()
        lgb_votes, xgb_votes = {}, {}
        ml_dev_windows = tree2_dev_windows = 0
        folds = context["development_folds"]
        total_folds = max(1, len(folds))
        for fold_index, (prior, snap) in enumerate(folds, 1):
            progress(f"开发集验证 {fold_index}/{total_folds} · {snap.get('feature_date','')}", PERCENT_SCALE * (fold_index - 1) / total_folds)
            xs, ys, ws, bks, groups = self._training_flatten(prior)
            gw, asset_models = self._fit_hierarchical_linear(xs, ys, ws, bks)
            nonlinear = []
            for seed in nonlinear_seeds:
                rx = [self._random_features(row, seed) for row in xs]
                nonlinear.append((seed, self._solve_weighted_linear(rx, ys, ws)))
            snap_buckets = snap.get("buckets") or ["其他"] * len(snap["rows"])
            component = {name: [fn(row) for row in snap["rows"]] for name, fn in baseline_predictors.items()}
            component["linear"] = [self._hierarchical_linear_predict(row, bucket, gw, asset_models) for row, bucket in zip(snap["rows"], snap_buckets)]
            component["nonlinear"] = [
                sum(sum(a*b for a, b in zip(weights, self._random_features(row, seed))) for seed, weights in nonlinear) / max(1, len(nonlinear))
                for row in snap["rows"]
            ]
            ml_predict = tree2_predict = None
            if capacity["allow_tree_models"]:
                progress(f"开发集验证 {fold_index}/{total_folds} · LightGBM/XGBoost", PERCENT_SCALE * ((fold_index - 1) + PROBABILITY_MIDPOINT) / total_folds)
                lgb_params = self._training_tune_tree_params(prior, self._train_optional_lightgbm, lgb_grid, long_blend)
                xgb_params = self._training_tune_tree_params(prior, self._train_optional_xgboost, xgb_grid, long_blend)
                lgb_key = json.dumps(lgb_params, sort_keys=True, separators=(",", ":"))
                xgb_key = json.dumps(xgb_params, sort_keys=True, separators=(",", ":"))
                lgb_votes[lgb_key] = lgb_votes.get(lgb_key, 0) + 1
                xgb_votes[xgb_key] = xgb_votes.get(xgb_key, 0) + 1
                _ml_spec, ml_predict = self._train_optional_lightgbm(xs, ys, ws, groups, hyperparams=lgb_params)
                _tree_spec, tree2_predict = self._train_optional_xgboost(xs, ys, ws, groups, hyperparams=xgb_params)
            if ml_predict is not None:
                component["lightgbm"] = [ml_predict(row) for row in snap["rows"]]
                ml_dev_windows += 1
            if tree2_predict is not None:
                component["xgboost"] = [tree2_predict(row) for row in snap["rows"]]
                tree2_dev_windows += 1

            entry_rank = [2*v-1 for v in _rank_scale(self._training_entry_values(snap["rows"]))]
            ranked = {}
            for name in list(baseline_predictors) + ["linear", "nonlinear"]:
                ranked[name] = [2*v-1 for v in _rank_scale(component[name])]
                self._training_record_family(state, name, [long_blend*l+(1-long_blend)*e for l, e in zip(ranked[name], entry_rank)], snap)
            mix = self._equal_rank_mix(ranked["expert"], ranked["linear"], ranked["nonlinear"])
            self._training_record_family(state, "ensemble", [long_blend*l+(1-long_blend)*e for l, e in zip(mix, entry_rank)], snap)
            if ml_predict is not None:
                ranked["lightgbm"] = [2*v-1 for v in _rank_scale(component["lightgbm"])]
                self._training_record_family(state, "lightgbm", [long_blend*l+(1-long_blend)*e for l, e in zip(ranked["lightgbm"], entry_rank)], snap)
                mix_ml = self._equal_rank_mix(ranked["expert"], ranked["linear"], ranked["nonlinear"], ranked["lightgbm"])
                self._training_record_family(state, "ensemble_ml", [long_blend*l+(1-long_blend)*e for l, e in zip(mix_ml, entry_rank)], snap)
            if tree2_predict is not None:
                ranked["xgboost"] = [2*v-1 for v in _rank_scale(component["xgboost"])]
                self._training_record_family(state, "xgboost", [long_blend*l+(1-long_blend)*e for l, e in zip(ranked["xgboost"], entry_rank)], snap)
                mix_xgb = self._equal_rank_mix(ranked["expert"], ranked["linear"], ranked["nonlinear"], ranked["xgboost"])
                self._training_record_family(state, "ensemble_xgb", [long_blend*l+(1-long_blend)*e for l, e in zip(mix_xgb, entry_rank)], snap)
            if ml_predict is not None and tree2_predict is not None:
                mix_dual = self._equal_rank_mix(ranked["expert"], ranked["linear"], ranked["nonlinear"], ranked["lightgbm"], ranked["xgboost"])
                self._training_record_family(state, "ensemble_dual_tree", [long_blend*l+(1-long_blend)*e for l, e in zip(mix_dual, entry_rank)], snap)

        def voted(votes, grid):
            if votes:
                return json.loads(max(votes, key=lambda key: (votes[key], key)))
            return dict(grid[len(grid) // 2]) if grid else {}
        family_metrics = {name: self._training_aggregate(rows) for name, rows in state["family_records"].items()}
        robust_baselines = ("expert", "defensive", "low_volatility") if not capacity["allow_linear_model"] else tuple(baseline_predictors)
        best_baseline = max(robust_baselines, key=lambda name: self._training_metric_key(family_metrics[name]))
        if not capacity["allow_linear_model"]:
            allowed_ai = []
        elif not capacity["allow_complex_ml"]:
            allowed_ai = ["linear"]
        else:
            allowed_ai = ["linear", "nonlinear", "ensemble"]
            if capacity["allow_tree_models"]:
                allowed_ai += ["ensemble_ml", "lightgbm", "ensemble_xgb", "xgboost", "ensemble_dual_tree"]
        ai_candidates = [name for name in allowed_ai if family_metrics[name]["windows"] > 0]
        best_ai = max(ai_candidates, key=lambda name: self._training_metric_key(family_metrics[name])) if ai_candidates else ""
        candidate = family_metrics.get(best_ai, self._training_aggregate([]))
        baseline = family_metrics[best_baseline]
        candidate_dev_gate = bool(
            best_ai and candidate["windows"] > 0
            and candidate["rank_ic_median"] > 0
            and candidate["rank_ic_positive_ratio"] > PROBABILITY_MIDPOINT
            and self._training_metric_key(candidate) > self._training_metric_key(baseline)
            and candidate["rank_ic_median"] >= baseline["rank_ic_median"]
        )
        return {
            **state, **capacity, "nonlinear_seeds": nonlinear_seeds,
            "frozen_lgb_params": voted(lgb_votes, lgb_grid), "frozen_xgb_params": voted(xgb_votes, xgb_grid),
            "ml_dev_windows": ml_dev_windows, "tree2_dev_windows": tree2_dev_windows,
            "family_metrics": family_metrics, "best_baseline": best_baseline, "best_ai": best_ai,
            "candidate": candidate, "baseline": baseline, "candidate_dev_gate": candidate_dev_gate,
        }

    @staticmethod
    def _training_mode_components(mode: str) -> dict:
        component_names = {
            "lightgbm": ("external",), "xgboost": ("tree2",),
            "ensemble_ml": ("expert", "linear", "nonlinear", "external"),
            "ensemble_xgb": ("expert", "linear", "nonlinear", "tree2"),
            "ensemble_dual_tree": ("expert", "linear", "nonlinear", "external", "tree2"),
            "ensemble": ("expert", "linear", "nonlinear"), "linear": ("linear",),
            "nonlinear": ("nonlinear",),
        }.get(mode, ("expert",))
        weight = 1.0 / len(component_names)
        return {name: (weight if name in component_names else 0.0) for name in ("expert", "linear", "nonlinear", "external", "tree2")}

    def _fit_training_mode(self, group, mode: str, label: str, comparison: dict, long_blend: float):
        x, y, w, buckets, groups = self._training_flatten(group)
        if not x:
            return None
        linear, assets = self._fit_hierarchical_linear(x, y, w, buckets)
        linear = self._normalized_linear_weights(linear)
        assets = self._normalized_asset_models(assets)
        needs_nonlinear = mode in {"nonlinear", "ensemble", "ensemble_ml", "ensemble_xgb", "ensemble_dual_tree"}
        nonlinear = []
        if needs_nonlinear:
            for seed in comparison["nonlinear_seeds"]:
                rx = [self._random_features(row, seed) for row in x]
                weights = self._solve_weighted_linear(rx, y, w)
                nonlinear.append({"seed": seed, "weights": self._normalized_linear_weights(weights)})
        needs_ml = mode in {"lightgbm", "ensemble_ml", "ensemble_dual_tree"}
        needs_tree2 = mode in {"xgboost", "ensemble_xgb", "ensemble_dual_tree"}
        ml, _ = self._train_optional_lightgbm(x, y, w, groups, hyperparams=comparison["frozen_lgb_params"]) if needs_ml else (None, None)
        tree2, _ = self._train_optional_xgboost(x, y, w, groups, hyperparams=comparison["frozen_xgb_params"]) if needs_tree2 else (None, None)
        if (needs_ml and ml is None) or (needs_tree2 and tree2 is None):
            return None
        return {
            "linear_weights": linear, "asset_models": assets,
            "asset_model_policy": "asset-specific-if-trained-else-global",
            "nonlinear_models": nonlinear, "optional_ml": ml, "optional_tree2": tree2,
            "optional_ml_status": self._OPTIONAL_ML_LAST_STATUS, "optional_tree2_status": self._OPTIONAL_TREE2_LAST_STATUS,
            "component_weights": self._training_mode_components(mode), "baseline_mode": mode,
            "long_term_blend": long_blend, "training_samples": len(x), "fit_dataset": label,
        }

    @staticmethod
    def _paired_window_evidence(candidate_metrics, baseline_metrics):
        """Deterministic deployment evidence: every paired mature window must be non-degrading."""
        left = list(candidate_metrics.get("rank_ic_values") or [])
        right = list(baseline_metrics.get("rank_ic_values") or [])
        n = min(len(left), len(right))
        if n <= 0:
            return {
                "windows": 0,
                "mean_uplift": -sys.float_info.max,
                "worst_uplift": -sys.float_info.max,
                "all_non_degrading": False,
            }
        diffs = [_finite(left[i]) - _finite(right[i]) for i in range(n)]
        return {
            "windows": n,
            "mean_uplift": statistics.fmean(diffs),
            "worst_uplift": min(diffs),
            "all_non_degrading": all(value >= 0.0 for value in diffs),
        }

    def _assemble_training_model(self, context: dict, comparison: dict, deployment: dict, audit: dict, production_model: dict, production_feedback_gate: dict, prediction_feedback: dict | None) -> dict:
        selected_mode, ai_enabled = audit["selected_mode"], audit["ai_enabled"]
        full_oos, evaluation_model = audit["full_oos"], audit["evaluation_model"]
        untouched_snaps = audit["untouched_snaps"]
        untouched_veto = dict(audit.get("untouched_veto") or {})
        prod_linear = production_model.get("linear_weights") or [0.0] * len(self.FEATURE_NAMES)
        prod_assets = production_model.get("asset_models") or {}
        prod_nonlinear = production_model.get("nonlinear_models") or []
        prod_ml, prod_tree2 = production_model.get("optional_ml"), production_model.get("optional_tree2")
        components = production_model.get("component_weights") or self._training_mode_components(selected_mode)
        final_long_blend = _finite(production_model.get("long_term_blend"), context["long_blend"])
        prod_x, _, _, _, _ = self._training_flatten(context["evaluation_training"])
        stability = {
            code: comparison["family_top_counts"].get(selected_mode, {}).get(code, 0) / max(1, eligible)
            for code, eligible in comparison["family_eligible_counts"].get(selected_mode, {}).items()
        }
        all_eval_snaps = [snap for _, snap in context["deployment_folds"] + context["untouched_folds"]]
        split_boundaries = {
            "walk_forward_folds": len(context["folds"]), "development_folds": len(context["development_folds"]),
            "deployment_validation_folds": len(context["deployment_folds"]), "untouched_test_folds": len(context["untouched_folds"]),
            "independent_evaluation_folds": len(context["independent_folds"]), "deployment_feature_start": context["first_deployment_feature"],
            "test_feature_start": context["first_test_feature"],
            "train_target_end_max": max((snap["target_end_date"] for snap in context["evaluation_training"]), default=""),
            "target_horizon_years": int(context["selected_spec"]["horizon_years"]),
            "oos_windows_non_overlapping": all(str(a.get("target_end_date") or "") <= str(b.get("feature_date") or "") for a, b in zip(all_eval_snaps, all_eval_snaps[1:])),
            "purge_rule": "each fold trains only on labels whose target_end <= fold feature_date",
            "ml_selection_rule": "target/model/tree hyperparameters use development only; feedback-adjusted final candidate must pass independent deployment validation; untouched audit can only exercise the fixed catastrophic veto and never tunes/promotes",
            "universe_model_policy": f"model capacity derived from effective historically-known funds={_format_unrounded_number(comparison['effective_known_funds'])}; linear needs >= feature dimensions; complex models need >= d*log2(d+1)",
        }
        feedback_gate = dict(deployment.get("feedback_gate") or {})
        deployment_gate = {
            "passed": bool(deployment["passed"]) and untouched_veto.get("triggered") is not True, "reason": audit["gate_reason"],
            "candidate_mode": comparison["best_ai"] or "none", "baseline_mode": comparison["best_baseline"],
            "rank_ic_median_uplift": deployment["rankic_uplift"], "quality_uplift": deployment["quality_uplift"],
            "paired_window_evidence": deployment["window_evidence"],
            "production_comparison_required": bool(deployment.get("production_required")),
            "production_comparison_passed": bool(deployment.get("production_passed")),
            "production_rank_ic_median_uplift": deployment.get("production_rankic_uplift"),
            "production_quality_uplift": deployment.get("production_quality_uplift"),
            "production_paired_window_evidence": deployment.get("production_window_evidence"),
            "candidate_oos": deployment.get("candidate_oos"),
            "baseline_oos": deployment.get("baseline_oos"),
            "production_oos": deployment.get("production_oos"),
            "production_window_evidence": deployment.get("production_window_evidence"),
            "upgrade_rule": "all mature independent deployment windows non-degrading and aggregate quality strictly improved versus both robust baseline and current production",
            "historical_universe_known_coverage": comparison["universe_coverage"], "tree_models_allowed": comparison["allow_tree_models"],
            "prediction_feedback_passed": bool(feedback_gate.get("passed", True)), "prediction_feedback_gate": feedback_gate,
            "final_candidate_revalidated": bool(deployment.get("final_candidate_revalidated")),
            "production_passed": bool(deployment["passed"]) and untouched_veto.get("triggered") is not True,
            "untouched_safety_veto": untouched_veto,
        }
        info = context["snapshot_info"]
        return {
            "schema_fingerprint": MODEL_SCHEMA_FINGERPRINT, "trained_at": _now_iso(), "feature_names": self.FEATURE_NAMES,
            "linear_weights": prod_linear, "asset_models": prod_assets,
            "asset_model_policy": "asset-specific-if-trained-else-global",
            "linear_solver": "weighted-least-squares-no-policy-regularization", "nonlinear_models": prod_nonlinear if ai_enabled else [],
            "optional_ml": prod_ml if prod_ml is not None else None, "optional_tree2": prod_tree2 if prod_tree2 is not None else None,
            "optional_ml_status": self._OPTIONAL_ML_LAST_STATUS, "optional_ml_development_windows": comparison["ml_dev_windows"],
            "optional_tree2_status": self._OPTIONAL_TREE2_LAST_STATUS, "optional_tree2_development_windows": comparison["tree2_dev_windows"],
            "component_weights": components, "lightgbm_frozen_dev_params": comparison["frozen_lgb_params"],
            "xgboost_frozen_dev_params": comparison["frozen_xgb_params"], "baseline_mode": selected_mode,
            "long_term_blend": final_long_blend, "evaluation_model": evaluation_model, "production_model": production_model,
            "prediction_feedback": dict(prediction_feedback or {}), "prediction_feedback_gate": production_feedback_gate,
            "feedback_cohorts_seen": list(_target_feedback_for_model(prediction_feedback, production_model).get("mature_cohort_ids") or []),
            "last_feedback_cohort": str(((_target_feedback_for_model(prediction_feedback, production_model).get("mature_cohort_ids") or [""])[-1])),
            "validation_ic": full_oos.get("rank_ic_median", full_oos.get("rank_ic_mean", 0.0)), "model_quality": full_oos.get("rank_ic_median", 0.0),
            "validation_metrics": full_oos, "full_pipeline_oos": full_oos, "untouched_test_oos": full_oos,
            "candidate_untouched_oos": untouched_veto.get("candidate_untouched_oos") or {},
            "baseline_untouched_oos": untouched_veto.get("baseline_untouched_oos") or {},
            "production_untouched_oos": untouched_veto.get("production_untouched_oos") or {},
            "untouched_safety_veto": untouched_veto,
            "candidate_deployment_oos": deployment["candidate_oos"], "baseline_deployment_oos": deployment["baseline_oos"],
            "expert_development_oos": comparison["family_metrics"].get("expert", {}), "development_candidate_oos": comparison["candidate"],
            "development_baseline_oos": comparison["baseline"], "deployment_gate": deployment_gate,
            "baseline_metrics": {"walk_forward": comparison["family_metrics"], "selected": comparison["best_baseline"], "selected_ai_family": comparison["best_ai"] or "none", "target_cv": context["target_cv"]},
            "training_samples": sum(len(snap["rows"]) for snap in context["evaluation_training"]),
            "tuning_samples": sum(len(fold[1]["rows"]) for fold in context["development_folds"]),
            "deployment_validation_samples": sum(len(fold[1]["rows"]) for fold in context["deployment_folds"]),
            "validation_samples": sum(len(snap["rows"]) for snap in untouched_snaps), "production_training_samples": len(prod_x),
            "universe_size": int(info.get("underlying_count") or len({_underlying_key(fund) for fund in context["training_funds"]})),
            "source_share_count": info["source_share_count"], "duplicate_shares_removed": info["duplicate_shares_removed"],
            "universe_codes": sorted(fund["code"] for fund in context["training_funds"]), "historical_availability_coverage": info["historical_availability_coverage"],
            "historical_universe_known_coverage": info.get("historical_universe_known_coverage", 0.0), "historical_availability_used_for_model_selection": True,
            "historical_availability_policy": "known unavailable excluded; known purchasable prioritized; unknown retained as unknown",
            "historical_share_class_selection": info.get("share_class_selection_mode", "point-in-time-per-rebalance"),
            "ai_enabled": ai_enabled,
            "production_replacement_passed": bool(deployment.get("production_passed")) and bool(deployment.get("passed")) and untouched_veto.get("triggered") is not True,
            "model_status": f"{selected_mode}-deployment-validated" if ai_enabled else f"{selected_mode}-guardrailed-baseline",
            "split_boundaries": split_boundaries, "selection_dataset": "development selects target/family/hyperparameters; independent deployment validation gates feedback-adjusted final candidate; non-overlapping untouched audit has a fixed one-way catastrophic veto only; production refit after freeze",
            "survivorship_bias": bool(info.get("survivor_conditioned")) or bool(info.get("historical_universe_known_coverage", 0.0) < 1.0),
            "survivor_conditioned": bool(info.get("survivor_conditioned")),
            "historical_universe_mode": (
                "survivor-conditioned shadow: inception/termination + observed NAV history approximate historical membership; pre-install disappearances may be missing"
                if info.get("survivor_conditioned") else
                "strict PIT: only locally observed point-in-time catalog membership is admitted; unknown historical membership is excluded"
            ),
            "target": f"OOS-selected {context['selected_spec']['name']} net-transaction-cost risk-adjusted forward utility",
            "target_spec": context["selected_spec"], "target_selection": "selected by development anchored walk-forward median/p25/mean RankIC and win stability",
            # Keep legacy keys for backward-compatible scoring; depth is now adaptive and documented.
            "development_top100_stability_by_code": stability, "development_top100_stability_windows": len(context["development_folds"]),
            "development_stability_depth_rule": "ceil(sqrt(cross_section_size))",
            "engine": "three-layer anchored walk-forward; sample-supported model capacity; independent feedback-adjusted deployment validation; non-overlapping untouched audit with fixed one-way catastrophic veto; one production Top100 ranking policy",
        }

    def _train_selected_development_model(
        self, funds: list[dict], development_selection, prediction_feedback: dict | None,
        production_baseline: dict | None, progress=lambda *_: None, *, survivor_conditioned: bool = False,
    ) -> dict:
        """Run model-family comparison/governance after a target/universe track has produced valid folds."""
        phases = ("compare", "deployment", "audit", "refit", "assemble")
        context = self._training_partition_selection(development_selection)
        progress("比较开发集模型族", _phase_progress_value(phases, "compare"))
        comparison = self._training_compare_families(
            context, self._training_baseline_predictors(), _nested_progress(progress, phases, "compare")
        )
        fit_mode_model = lambda group, mode, label: self._fit_training_mode(group, mode, label, comparison, context["long_blend"])

        progress("独立部署验证", _phase_progress_value(phases, "deployment"))
        deployment = self._training_deployment_gate(
            context["training_funds"], context["deployment_folds"], context["deployment_training"],
            comparison["best_baseline"], comparison["best_ai"], fit_mode_model, self._training_aggregate,
            self._paired_window_evidence, comparison["candidate_dev_gate"], comparison["universe_coverage"], prediction_feedback, production_baseline,
        )
        progress("未触碰样本审计", _phase_progress_value(phases, "audit"))
        ai_enabled, selected_mode, gate_reason, evaluation_model, untouched_snaps, full_oos, untouched_veto = self._training_untouched_audit(
            context["training_funds"], context["untouched_folds"], context["evaluation_training"], deployment["passed"],
            comparison["best_ai"], comparison["best_baseline"], deployment["reason"], fit_mode_model,
            self._training_aggregate, prediction_feedback, production_baseline,
        )
        progress("生成 production model", _phase_progress_value(phases, "refit"))
        ai_enabled, selected_mode, gate_reason, evaluation_model, full_oos, production_model = self._training_production_refit(
            context["training_funds"], untouched_snaps, context["evaluation_training"], ai_enabled, selected_mode,
            comparison["best_baseline"], gate_reason, evaluation_model, full_oos, fit_mode_model,
            self._training_aggregate, self._training_mode_components, context["long_blend"],
        )
        if ai_enabled:
            production_model, production_feedback_gate = _prediction_feedback_adjusted_model(production_model, prediction_feedback)
            if production_feedback_gate.get("passed") is not True:
                raise ModelError("feedback-adjusted production candidate lost its feedback gate after deployment validation")
        else:
            production_feedback_gate = dict(deployment.get("feedback_gate") or {})
        progress("组装并冻结模型", _phase_progress_value(phases, "assemble"))
        audit = {
            "ai_enabled": ai_enabled, "selected_mode": selected_mode, "gate_reason": gate_reason,
            "evaluation_model": evaluation_model, "untouched_snaps": untouched_snaps, "full_oos": full_oos,
            "untouched_veto": untouched_veto,
        }
        model = self._assemble_training_model(context, comparison, deployment, audit, production_model, production_feedback_gate, prediction_feedback)
        if survivor_conditioned:
            model["survivor_conditioned"] = True
            model["shadow_model"] = True
            model["strict_pit_production"] = False
            model["production_model_role"] = "provisional-survivor-conditioned-shadow-candidate"
            model["model_status"] = "shadow-survivor-conditioned-" + str(model.get("model_status") or "validated")
            model["survivorship_bias"] = True
            model["survivorship_note"] = (
                "首次安装前缺失的已退出基金无法被本地目录历史恢复；该模型仅以成立/终止日期和已观测净值近似历史基金池，"
                "已通过与正式候选相同的开发/部署/未触碰门控，但持续标记 survivor_conditioned，严格 PIT 样本成熟后优先替换。"
            )
        else:
            model["survivor_conditioned"] = False
            model["shadow_model"] = False
            model["strict_pit_production"] = True
            model["production_model_role"] = "strict-pit-production"
        return model

    def train(
        self, funds: list[dict], prediction_feedback: dict | None = None,
        production_baseline: dict | None = None, progress=lambda *_: None,
    ) -> dict:
        """Prefer strict PIT training; use an explicitly survivor-conditioned shadow track until PIT history matures."""
        phases = ("strict_target", "shadow_target", "fit")
        progress("构建严格 PIT 长期训练快照", _phase_progress_value(phases, "strict_target"))
        development_selection = self._training_development_target_search(
            funds, progress=_nested_progress(progress, phases, "strict_target"), universe_mode="strict_pit",
        )
        survivor_conditioned = False
        if development_selection is None:
            progress("严格 PIT 样本尚未成熟；构建 survivor-conditioned shadow 长期快照", _phase_progress_value(phases, "shadow_target"))
            development_selection = self._training_development_target_search(
                funds, progress=_nested_progress(progress, phases, "shadow_target"), universe_mode="survivor_conditioned_shadow",
            )
            survivor_conditioned = development_selection is not None

        if development_selection is None:
            model = LocalStore.default_model()
            model.update({
                "trained_at": _now_iso(), "universe_size": len({_underlying_key(fund) for fund in funds}),
                "universe_codes": sorted(str(fund.get("code") or "") for fund in funds),
                "model_status": "expert-fallback-insufficient-independent-long-horizon-folds", "baseline_mode": "expert",
                "target": f"at least {MIN_LONG_TERM_HORIZON_YEARS}y long-horizon independent validation unavailable: expert fallback",
                "target_selection": "development target search requires >=3y horizon plus independent deployment + untouched windows",
                "survivorship_bias": True, "survivor_conditioned": False, "shadow_model": False,
                "engine": "strict PIT first + survivor-conditioned shadow fallback + anchored walk-forward long-horizon governance",
            })
            progress("至少 3 年长期样本仍不足，当前使用基础筛选", PERCENT_SCALE)
            return model

        model = self._train_selected_development_model(
            funds, development_selection, prediction_feedback, production_baseline,
            progress=_nested_progress(progress, phases, "fit"), survivor_conditioned=survivor_conditioned,
        )
        progress(
            "shadow 长期模型训练完成；保持 survivor-conditioned 标记并等待严格 PIT 数据替换"
            if survivor_conditioned else "严格 PIT 长期模型训练完成",
            PERCENT_SCALE,
        )
        return model


    @staticmethod
    def _market_regime(usable: list[dict]) -> str:
        entry_return = _median([item["stats"]["entry_return_latest"] for item in usable])
        vol = _median([item["stats"]["volatility"] for item in usable])
        trends = _median([item["feature_vector"][AdaptiveRanker.FEATURE_NAMES.index("trend_quality")] for item in usable])
        if entry_return < 0.0 and trends <= 0.0:
            return "risk_off"
        if vol > max(abs(entry_return), abs(trends)):
            return "high_vol"
        if entry_return > 0.0 and trends > 0.0:
            return "trend"
        if entry_return > 0.0:
            return "risk_on"
        return "range"

    @staticmethod
    def _choose_share_classes(funds: list[dict], holding_years: int) -> list[dict]:
        years = _expected_holding_years(holding_years)
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        chosen = []
        for underlying, shares in groups.items():
            def preference(fund: dict):
                verified = fund.get("fees_verified") is True
                cost = _share_class_cost(fund, years) if verified else float("inf")
                return (
                    0 if verified else 1,
                    cost,
                    -len(fund.get("returns") or []),
                    -_share_preference(str(fund.get("name") or "")),
                    str(fund.get("code") or ""),
                )
            selected = dict(min(shares, key=preference))
            selected["underlying_fund_id"] = underlying
            selected["selected_holding_years"] = years
            selected["selected_share_class_cost"] = (
                _share_class_cost(selected, years) if selected.get("fees_verified") is True else None
            )
            selected["alternative_share_codes"] = sorted(
                str(row.get("code") or "") for row in shares
                if str(row.get("code") or "") != str(selected.get("code") or "")
            )
            chosen.append(selected)
        return chosen

    @classmethod
    def _fee_imputation_by_bucket(
        cls, funds: list[dict], holding_years: int, as_of_date: str | None = None,
    ) -> tuple[dict[str, float], float]:
        """PIT-safe conservative transaction-cost imputation; unknown cost is never treated as zero."""
        years = _expected_holding_years(holding_years)
        by_bucket: dict[str, list[float]] = {bucket: [] for bucket in MODEL_ASSET_BUCKETS}
        all_known: list[float] = []
        for fund in funds or []:
            if not isinstance(fund, dict):
                continue
            if as_of_date is not None:
                _product, fees, verified = cls._pit_fields(fund, str(as_of_date)[:DATE_TEXT_LENGTH])
            else:
                fees = fund.get("fees") if isinstance(fund.get("fees"), dict) else {}
                verified = fund.get("fees_verified") is True
            if not verified:
                continue
            transaction_cost = _transaction_cost_from_fees(fees, years)
            if transaction_cost is None:
                continue
            bucket = _asset_bucket(str(fund.get("name") or ""), str(fund.get("type") or ""))
            by_bucket.setdefault(bucket, []).append(transaction_cost)
            all_known.append(transaction_cost)
        global_conservative = max([UNKNOWN_TRANSACTION_COST_FALLBACK, *all_known])
        imputation = {}
        for bucket in MODEL_ASSET_BUCKETS:
            bucket_known = by_bucket.get(bucket) or []
            imputation[bucket] = (
                max([UNKNOWN_TRANSACTION_COST_FALLBACK, *bucket_known])
                if bucket_known else global_conservative
            )
        return imputation, global_conservative

    @staticmethod
    def _absolute_investability_gate(item: dict, model: dict, years: int, as_of_date: str | None) -> tuple[bool, dict]:
        """Absolute evidence gate.  No candidate-set percentile is allowed to satisfy these checks."""
        stats = item.get("stats") if isinstance(item.get("stats"), dict) else {}
        target_ann = _finite(stats.get("return_target_ann"), float("nan"))
        rolling_worst = _finite(stats.get("rolling_target_worst"), float("nan"))
        positive_months = _finite(stats.get("positive_months"), float("nan"))
        history_years = _finite(stats.get("history_years"), float("nan"))
        metrics = model.get("full_pipeline_oos") or model.get("untouched_test_oos") or model.get("validation_metrics") or {}
        oos_windows = max(0, int(_finite(metrics.get("windows"), 0)))
        universe_coverage = _clamp(_finite(model.get("historical_universe_known_coverage"), 0.0), 0.0, 1.0)
        checks = {
            "target_annualized_return_positive": math.isfinite(target_ann) and target_ann > 0.0,
            "worst_rolling_holding_period_positive": math.isfinite(rolling_worst) and rolling_worst > 0.0,
            "positive_months_majority": math.isfinite(positive_months) and positive_months > PROBABILITY_MIDPOINT,
            "two_full_holding_horizons_history": math.isfinite(history_years) and history_years >= 2.0 * max(1, int(years)),
            "out_of_sample_windows_present": oos_windows > 0,
            "historical_universe_complete": universe_coverage >= REFRESH_MIN_COVERAGE,
        }
        # Historical PIT scoring is used to evaluate the ranking algorithm, not to emit a live buy conclusion.
        if as_of_date is not None:
            checks.pop("historical_universe_complete", None)
        else:
            checks["strict_pit_production_evidence"] = model.get("strict_pit_production") is True
            checks["fees_verified_for_formal_buy"] = item.get("fees_verified") is True
            current_status = str(item.get("availability_status") or "unknown")
            checks["currently_purchasable"] = current_status in FORMAL_PURCHASABLE_STATUSES
        passed = bool(checks and all(checks.values()))
        evidence = {
            "passed": passed,
            "checks": checks,
            "target_annualized_return": target_ann if math.isfinite(target_ann) else None,
            "worst_rolling_holding_period_return": rolling_worst if math.isfinite(rolling_worst) else None,
            "positive_month_fraction": positive_months if math.isfinite(positive_months) else None,
            "history_years": history_years if math.isfinite(history_years) else None,
            "required_history_years": 2 * max(1, int(years)),
            "oos_windows": oos_windows,
            "historical_universe_known_coverage": universe_coverage,
            "fees_verified": item.get("fees_verified") is True,
            "availability_status": str(item.get("availability_status") or "unknown") if as_of_date is None else None,
            "public_purchase_status": str(item.get("public_purchase_status") or "") if as_of_date is None else None,
            "public_purchase_status_secondary": str(item.get("public_purchase_status_secondary") or "") if as_of_date is None else None,
        }
        return passed, evidence

    @staticmethod
    def _relative_buy_view(qindex: int, tindex: int, quality_count: int, timing_count: int, hot: bool) -> str:
        if qindex == quality_count - 1 and tindex >= timing_count // 2 and not hot:
            return "相对核心候选"
        if qindex >= quality_count // 2 and tindex >= timing_count // 2:
            return "相对适合分批关注"
        if hot:
            return "相对偏热"
        if qindex >= quality_count // 2:
            return "相对可观察"
        return "相对排名一般"

    def _apply_investability_views(
        self, item: dict, model: dict, years: int, as_of_date: str | None,
        *, qindex: int, tindex: int, quality_count: int, timing_count: int, hot: bool,
    ) -> None:
        relative_view = self._relative_buy_view(qindex, tindex, quality_count, timing_count, hot)
        absolute_ok, absolute_evidence = self._absolute_investability_gate(item, model, years, as_of_date)
        item["relative_buy_view"] = relative_view
        item["absolute_investability"] = absolute_ok
        item["absolute_investability_evidence"] = absolute_evidence
        checks = dict(absolute_evidence.get("checks") or {})
        fee_only_pending = bool(
            as_of_date is None
            and item.get("fees_verified") is not True
            and checks.get("fees_verified_for_formal_buy") is False
            and all(value for key, value in checks.items() if key != "fees_verified_for_formal_buy")
        )
        purchase_only_pending = bool(
            as_of_date is None
            and checks.get("currently_purchasable") is False
            and all(value for key, value in checks.items() if key != "currently_purchasable")
        )
        if absolute_ok and relative_view == "相对核心候选":
            item["buy_view"] = "长期核心持有条件满足"
        elif absolute_ok and relative_view == "相对适合分批关注":
            item["buy_view"] = "绝对门控通过，可分批买入"
        elif absolute_ok and relative_view == "相对偏热":
            item["buy_view"] = "绝对门控通过，但当前相对偏热"
        elif absolute_ok:
            item["buy_view"] = "绝对门控通过，当前以观察为主"
        elif fee_only_pending:
            item["buy_view"] = "长期质量较高，费率尚未完整核验，暂不输出正式买入结论"
        elif purchase_only_pending:
            item["buy_view"] = "长期质量门控通过，但当前申购状态未确认可买，暂不输出正式买入结论"
        else:
            item["buy_view"] = "当前绝对买入条件未满足"

    def _build_explanations_and_investability(
        self, usable: list[dict], by_class: dict, model: dict, years: int, as_of_date: str | None,
    ) -> None:
        """Attach relative explanations, absolute/current-purchase gates and user-facing conclusions."""
        explanation_metrics = (
            ("目标期年化", "return_target_ann", True),
            ("目标期回撤控制", "max_drawdown_target", True),
            ("目标收益/波动", "zero_baseline_return_volatility", True),
            ("波动控制", "volatility", False),
            ("长期证据强度", "long_evidence_strength", True),
            ("可用历史", "history_years", True),
        )
        for rows in by_class.values():
            metric_percentiles = {id(item): {} for item in rows}
            for metric_name, metric_key, higher_is_better in explanation_metrics:
                values = [_finite((item.get("stats") or {}).get(metric_key), float("nan")) for item in rows]
                finite_positions = [index for index, value in enumerate(values) if math.isfinite(value)]
                if not finite_positions:
                    continue
                ranked_values = [values[index] if higher_is_better else -values[index] for index in finite_positions]
                ranked_percentiles = _rank_scale(ranked_values)
                for index, percentile_value in zip(finite_positions, ranked_percentiles):
                    metric_percentiles[id(rows[index])][metric_name] = PERCENT_SCALE * percentile_value
            for item in rows:
                item["selection_metric_percentiles"] = metric_percentiles[id(item)]

        quality_labels = ("偏弱", "一般", "良好", "优秀")
        timing_labels = ("偏弱", "中性", "积极", "偏热")
        risk_labels = ("中低", "中", "中高", "高")
        volatility_ranks = _rank_scale([_finite(item["stats"].get("volatility")) for item in usable])
        momentum_ranks = _rank_scale([_finite(item["stats"].get("entry_return_latest")) for item in usable])
        entry_score_median = statistics.median(_rank_scale([_finite(x.get("EntryTimingScore")) for x in usable]))
        momentum_median = statistics.median(momentum_ranks)
        label_count = len(quality_labels)
        for item, volatility_rank, momentum_rank in zip(usable, volatility_ranks, momentum_ranks):
            qscore = _clamp(_finite(item.get("LongTermQualityScore")) / PERCENT_SCALE, 0.0, 1.0)
            tscore = _clamp(_finite(item.get("EntryTimingScore")) / PERCENT_SCALE, 0.0, 1.0)
            qindex = min(label_count - 1, int(qscore * label_count))
            tindex = min(len(timing_labels) - 1, int(tscore * len(timing_labels)))
            rindex = min(len(risk_labels) - 1, int(_clamp(volatility_rank, 0.0, 1.0) * len(risk_labels)))
            item["long_term_quality"] = quality_labels[qindex]
            item["timing_view"] = timing_labels[tindex]
            hot = momentum_rank >= momentum_median and tscore < entry_score_median
            self._apply_investability_views(
                item, model, years, as_of_date, qindex=qindex, tindex=tindex,
                quality_count=label_count, timing_count=len(timing_labels), hot=hot,
            )
            item["risk"] = risk_labels[rindex]
            metric_percentiles = dict(item.get("selection_metric_percentiles") or {})
            strongest = max(metric_percentiles.items(), key=lambda pair: pair[1]) if metric_percentiles else ("综合投资质量", item.get("category_percentile", 0.0))
            weakest = min(metric_percentiles.items(), key=lambda pair: pair[1]) if metric_percentiles else ("综合投资质量", item.get("category_percentile", 0.0))
            stats = item.get("stats") or {}
            target_ann_text = _format_unrounded_number(
                _finite(stats.get("return_target_ann"), float("nan")), "%", signed=True, scale=PERCENT_SCALE,
            )
            drawdown_text = _format_unrounded_number(
                _finite(stats.get("max_drawdown_target"), float("nan")), "%", signed=True, scale=PERCENT_SCALE,
            )
            history_text = _format_unrounded_number(_finite(stats.get("history_years"), float("nan")), "年")
            timing_text = _format_unrounded_number(item.get("EntryTimingScore"))
            consistency_text = _format_unrounded_number(item.get("model_consistency"), "/100")
            evidence_text = (
                "最新净值已完成双源同日交叉确认"
                if item.get("latest_cross_source_verified") is True else
                "最新净值尚未形成双源同日确认"
            )
            fee_text = "公开费率已核验" if item.get("fees_verified") is True else "公开费率仍待补充核验"
            item["reason"] = "\n".join((
                f"结论：{item.get('buy_view') or '仅作相对排名参考'}；相对视角为{item.get('relative_buy_view') or '—'}。",
                f"核心优势：{strongest[0]}是本基金在同类可比指标中最突出的项目，同类百分位 {_format_unrounded_number(strongest[1], '%')}。",
                f"关键数据：目标期年化 {target_ann_text}；目标期最大回撤 {drawdown_text}；模型稳定 {consistency_text}；可用历史 {history_text}。",
                f"最大弱项：{weakest[0]}在本基金同类可比指标中相对最弱，同类百分位 {_format_unrounded_number(weakest[1], '%')}。",
                f"当前状态：相对择时评分 {timing_text}，综合同类百分位 {_format_unrounded_number(item.get('category_percentile'), '%')}；相对择时不是绝对投资条件，也不是长期质量的替代指标。",
                f"数据可信度：{fee_text}；{evidence_text}。",
            ))

    @staticmethod
    def _final_sort(usable: list[dict]) -> None:
        usable.sort(
            key=lambda item: (
                item.get("final_ranking_utility", 0.0),
                item.get("model_consistency", 0.0),
                item.get("product_integrity_score", 0.0),
                item.get("raw_score", 0.0),
            ),
            reverse=True,
        )

    def score(
        self, funds: list[dict], model: dict,
        feature_cache: dict | None = None, as_of_date: str | None = None,
        holding_years: int | None = None, precomputed_features: dict[str, dict] | None = None,
        *, require_full_selection: bool = True,
    ) -> list[dict]:
        usable = []
        feature_cache = feature_cache if feature_cache is not None else {}
        precomputed_features = precomputed_features if isinstance(precomputed_features, dict) else {}
        years = _expected_holding_years(holding_years, model)
        selected_funds = self._choose_share_classes(funds, years)
        fee_imputation, fee_imputation_fallback = self._fee_imputation_by_bucket(
            funds, years, as_of_date=as_of_date,
        )
        for fund in selected_funds:
            returns = fund.get("returns") or []
            fees = fund.get("fees") if fund.get("fees_verified") is True else None
            dates = fund.get("dates") or []
            asset_class = _asset_bucket(fund.get("name", ""), fund.get("type", ""))
            unknown_transaction_cost = fee_imputation.get(asset_class, fee_imputation_fallback)
            # Purchase-platform availability is intentionally not part of ranking admission.
            # Historical and current scoring use the same investment-data eligibility rules.
            pit_purchasable, pit_availability_known = True, False
            fingerprint = (
                years, len(returns), fund.get("latest_date"), str(dates[-1]) if dates else "",
                round(_finite(returns[-1]) if returns else 0.0, FLOAT_SERIALIZATION_DIGITS),
                json.dumps(fees or {}, sort_keys=True, ensure_ascii=True, separators=(",", ":")),
                round(_finite(unknown_transaction_cost), FLOAT_SERIALIZATION_DIGITS),
            )
            precomputed = precomputed_features.get(str(fund.get("code") or ""))
            if (
                isinstance(precomputed, dict) and precomputed.get("vector") is not None
                and isinstance(precomputed.get("stats"), dict)
                and int(_finite(precomputed["stats"].get("target_years"), -1)) == years
            ):
                result = (list(precomputed["vector"]), dict(precomputed["stats"]))
            else:
                cached = feature_cache.get(fund["code"])
                if cached and cached.get("fingerprint") == fingerprint:
                    result = (cached["vector"], cached["stats"])
                else:
                    result = self.features(
                        returns, fees=fees, dates=dates, target_years=years,
                        history_context=fund, unknown_transaction_cost=unknown_transaction_cost,
                    )
                    if result:
                        feature_cache[fund["code"]] = {
                            "fingerprint": fingerprint, "vector": result[0], "stats": result[1]
                        }
            if result:
                scored_fund = dict(fund)
                if as_of_date is not None:
                    # Make the PIT contract structural: historical rows do not even carry today's
                    # purchase-status metadata into downstream ranking, tie-breaks or explanations.
                    for current_only_field in CURRENT_PURCHASE_EVIDENCE_FIELDS:
                        scored_fund.pop(current_only_field, None)
                usable.append({
                    **scored_fund,
                    "feature_vector": result[0],
                    "stats": result[1],
                    "asset_class": asset_class,
                    "asset_bucket": asset_class,
                    "wrapper": _wrapper_type(fund.get("type", "")),
                    "ranking_as_of_date": str(as_of_date or "")[:DATE_TEXT_LENGTH],
                    "pit_purchasable": bool(pit_purchasable),
                    "pit_availability_known": bool(pit_availability_known),
                })
        if require_full_selection:
            if len(usable) < MODEL_SELECTION_SIZE:
                return []
        elif not usable:
            return []

        scaled_rows = self._scale_feature_rows(
            [item["feature_vector"] for item in usable],
            [item["asset_class"] for item in usable],
        )
        for item, scaled in zip(usable, scaled_rows):
            item["scaled"] = scaled

        regime = self._market_regime(usable)
        # No hand-authored profile/regime coefficients: the neutral fallback is equal weight.
        # Learned model components below may become non-equal only after walk-forward validation.
        expert_weights = self.EXPERT_WEIGHTS[:]

        linear_weights = model.get("linear_weights") or [0.0] * len(self.FEATURE_NAMES)
        asset_models = model.get("asset_models") if isinstance(model.get("asset_models"), dict) else {}
        nonlinear_models = model.get("nonlinear_models") or []
        optional_predict = self._optional_predictor(model.get("optional_ml"))
        tree2_predict = self._optional_predictor(model.get("optional_tree2"))
        components = dict(
            model.get("component_weights")
            or {"expert":1.0, "linear":0.0, "nonlinear":0.0, "external":0.0, "tree2":0.0}
        )
        if optional_predict is None:
            components["external"] = 0.0
        if tree2_predict is None:
            components["tree2"] = 0.0
        component_total = sum(max(0.0, value) for value in components.values()) or 1.0
        components = {key: max(0.0, value) / component_total for key, value in components.items()}

        raw_components = {"expert": [], "linear": [], "nonlinear": [], "external": [], "tree2": []}
        for item in usable:
            vector = item["scaled"]
            raw_components["expert"].append(sum(w*x for w, x in zip(expert_weights, vector)))
            raw_components["linear"].append(self._hierarchical_linear_predict(vector, item.get("asset_class", "其他"), linear_weights, asset_models))
            nonlinear_values = []
            for model_row in nonlinear_models:
                rf = self._random_features(vector, int(model_row.get("seed", 0)))
                nonlinear_values.append(
                    sum(w*x for w, x in zip(model_row.get("weights") or [], rf))
                )
            raw_components["nonlinear"].append(
                sum(nonlinear_values) / len(nonlinear_values) if nonlinear_values else 0.0
            )
            raw_components["external"].append(
                optional_predict(vector) if optional_predict is not None else 0.0
            )
            raw_components["tree2"].append(
                tree2_predict(vector) if tree2_predict is not None else 0.0
            )

        scaled_components = {}
        for key, values in raw_components.items():
            if (key == "external" and optional_predict is None) or (key == "tree2" and tree2_predict is None) or (key == "nonlinear" and not nonlinear_models):
                scaled_components[key] = [0.0] * len(values)
            else:
                ranks = _rank_scale(values)
                scaled_components[key] = [2.0 * value - 1.0 for value in ranks]

        baseline_mode = str(model.get("baseline_mode") or "ensemble")
        feature_index = {name: index for index, name in enumerate(self.FEATURE_NAMES)}
        baseline_groups = {
            "defensive": ("drawdown_quality", "volatility_quality", "worst_period", "stability_quality", "transaction_cost_target_quality"),
            "low_volatility": ("volatility_quality", "drawdown_quality", "ulcer_quality", "long_evidence_strength"),
            "quality_momentum": ("return_target_ann", "zero_baseline_return_volatility_target", "drawdown_quality", "trend_quality", "rolling_target_worst", "long_evidence_strength"),
        }
        timing_features = ("entry_return_latest", "trend_quality", "drawdown_quality", "volatility_quality", "recovery_quality")
        timing_weights = model.get("entry_timing_weights") if isinstance(model.get("entry_timing_weights"), dict) else {}

        def mean_named(vector, names):
            values = [vector[feature_index[name]] for name in names if name in feature_index]
            return statistics.fmean(values) if values else 0.0

        def timing_value(vector):
            neutral = 1.0 / max(1, len(timing_features))
            pairs = [(vector[feature_index[name]], max(0.0, _finite(timing_weights.get(name), neutral)))
                     for name in timing_features if name in feature_index]
            total = sum(weight for _, weight in pairs)
            return sum(value * weight for value, weight in pairs) / total if total > sys.float_info.epsilon else mean_named(vector, timing_features)

        for index, item in enumerate(usable):
            vector = item["scaled"]
            if baseline_mode in baseline_groups:
                raw = mean_named(vector, baseline_groups[baseline_mode])
            elif baseline_mode == "expert":
                raw = scaled_components["expert"][index]
            else:
                raw = sum(
                    components.get(key, 0.0) * scaled_components[key][index]
                    for key in scaled_components
                )

            long_raw = raw
            timing_raw = timing_value(vector)
            valuation_signal = _valuation_entry_signal(item) if as_of_date is None else 0.0
            if as_of_date is None:
                timing_raw = statistics.fmean((timing_raw, valuation_signal))
            item["ValuationTimingSignal"] = PERCENT_SCALE * valuation_signal
            item["long_raw_score"] = long_raw
            item["entry_raw_score"] = timing_raw
            item["raw_score"] = long_raw
            item["market_regime"] = regime
            item["theme_label"] = _theme(item.get("name", ""))

            item["model_component_scores"] = {
                key: scaled_components[key][index]
                for key in ("expert", "linear", "nonlinear", "external", "tree2")
                if key in scaled_components
            }
            component_values = [
                scaled_components["expert"][index],
                scaled_components["linear"][index],
            ]
            if nonlinear_models:
                component_values.append(scaled_components["nonlinear"][index])
            if optional_predict is not None:
                component_values.append(scaled_components["external"][index])
            if tree2_predict is not None:
                component_values.append(scaled_components["tree2"][index])
            disagreement = statistics.pstdev(component_values) if len(component_values) > 1 else 0.0
            history_years = max(0.0, _finite(item["stats"].get("history_years")))
            history_completeness = _clamp(history_years / max(1.0, float(years)), 0.0, 1.0)
            long_evidence = _clamp(_finite(item["stats"].get("long_evidence_strength")), 0.0, 1.0)
            history_factor = statistics.fmean((history_completeness, long_evidence))
            evidence_factor, evidence_inputs = _model_evidence_factor(model, item)
            agreement_factor = 1.0 / (1.0 + max(0.0, disagreement))
            consistency_factors = (history_factor, evidence_factor, agreement_factor)
            consistency = math.prod(consistency_factors) ** (1.0 / len(consistency_factors))
            item["model_evidence_factor"] = PERCENT_SCALE * evidence_factor
            item["model_evidence_inputs"] = evidence_inputs
            item["model_consistency"] = PERCENT_SCALE * _clamp(consistency, 0.0, 1.0)
            stability_map = model.get("development_top100_stability_by_code") or model.get("development_top10_stability_by_code") or {}
            stability = _clamp(_finite(stability_map.get(str(item.get("code") or "")), 0.0), 0.0, 1.0)
            item["Top100SelectionStability"] = PERCENT_SCALE * stability

        long_ranks = _rank_scale([item["long_raw_score"] for item in usable])
        entry_ranks = _rank_scale([item["entry_raw_score"] for item in usable])
        blend = _clamp(_finite(model.get("long_term_blend"), PROBABILITY_MIDPOINT), 0.0, 1.0)
        for item, long_pct, entry_pct in zip(usable, long_ranks, entry_ranks):
            item["LongTermQualityScore"] = PERCENT_SCALE * long_pct
            item["EntryTimingScore"] = PERCENT_SCALE * entry_pct
            item["long_term_quality_score"] = item["LongTermQualityScore"]
            item["entry_timing_score"] = item["EntryTimingScore"]
            item["score_blend"] = {"long_term":blend, "entry_timing":1.0-blend}
            item["raw_score"] = blend * (2.0*long_pct-1.0) + (1.0-blend) * (2.0*entry_pct-1.0)

        by_class = {}
        for item in usable:
            by_class.setdefault(item["asset_class"], []).append(item)
        for rows in by_class.values():
            percentiles = _rank_scale([row["raw_score"] for row in rows])
            for item, pct in zip(rows, percentiles):
                item["category_percentile"] = PERCENT_SCALE * pct

        overall = _rank_scale([item["raw_score"] for item in usable])
        for item, pct in zip(usable, overall):
            item["overall_percentile"] = PERCENT_SCALE * pct
            item["score"] = item["overall_percentile"]
            integrity_score = _product_integrity_score(item) if as_of_date is None else PERCENT_SCALE
            item["product_integrity_score"] = integrity_score
            item["product_integrity_adjustment"] = 1.0
            # Final membership is driven only by investment quality plus underlying-fund de-duplication.
            item["final_ranking_utility"] = _finite(item["overall_percentile"]) / PERCENT_SCALE

        self._build_explanations_and_investability(usable, by_class, model, years, as_of_date)

        self._final_sort(usable)
        return usable


    @staticmethod
    def _return_correlation(left: dict, right: dict) -> float:
        """Correlation over every common dated return; Pearson needs at least two common observations."""
        ld, lr = left.get("dates") or [], left.get("returns") or []
        rd, rr = right.get("dates") or [], right.get("returns") or []
        if len(ld) != len(lr) or len(rd) != len(rr):
            return 0.0
        lmap = dict(zip(ld, lr))
        rmap = dict(zip(rd, rr))
        common = sorted(set(lmap) & set(rmap))
        if len(common) < MIN_HISTORY_POINTS:
            return 0.0
        return _clamp(_pearson([lmap[day] for day in common], [rmap[day] for day in common]), -1.0, 1.0)


    @staticmethod
    def _fixed_weight_portfolio_path(paths: list[dict]) -> tuple[float, list[float]]:
        clean_paths = []
        for path in paths:
            dates, returns = path.get("dates") or [], path.get("returns") or []
            if len(dates) == len(returns) and dates:
                clean_paths.append(dict(zip(dates, returns)))
        if not clean_paths:
            return 0.0, []
        calendar_dates = sorted(set().union(*(set(path) for path in clean_paths)))
        wealth = [1.0] * len(clean_paths)
        previous_nav = 1.0
        portfolio_returns = []
        for day in calendar_dates:
            for index, path in enumerate(clean_paths):
                if day in path:
                    wealth[index] *= 1.0 + max(-1.0 + sys.float_info.epsilon, _finite(path[day]))
            nav = sum(wealth) / len(wealth)
            portfolio_returns.append(nav / max(previous_nav, sys.float_info.min) - 1.0)
            previous_nav = nav
        return previous_nav - 1.0, portfolio_returns

    @staticmethod
    def _full_oos_metric_key(metrics: dict) -> tuple[float, ...]:
        """Primary investment objective followed by explicit tie-breakers; no weighted composite."""
        floor = -sys.float_info.max
        ceiling = sys.float_info.max
        return (
            _finite(metrics.get("rank_ic_median"), floor),
            _finite(metrics.get("top100_excess_return"), floor),
            _finite(metrics.get("rank_ic_worst"), floor),
            -_finite(metrics.get("max_oos_drawdown"), ceiling),
            -_finite(metrics.get("turnover"), ceiling),
            -_finite(metrics.get("portfolio_correlation"), ceiling),
        )

    def _full_pipeline_oos(self, funds: list[dict], snapshots: list[dict], model: dict) -> dict:
        fund_map={f["code"]:f for f in funds}; rank_ics=[]; regime_ics=[]; excess=[]; annual_excess=[]; dds=[]; downside_ratios=[]; corrs=[]; top_sets=[]; constraint_failures=[]
        for snap in snapshots:
            hist=[]; forward={}; all_forward=[]; precomputed={}
            horizon_years = max(
                1,
                int(((snap.get("target_spec") or {}).get("horizon_years") if isinstance(snap.get("target_spec"), dict) else 0) or _model_target_years(model)),
            )
            raw_feature_rows = list(snap.get("raw_feature_rows") or [])
            feature_stats = list(snap.get("feature_stats") or [])
            for row_index,(code,end,future_end) in enumerate(zip(snap.get("codes",[]),snap.get("ends",[]),snap.get("future_ends",[]))):
                fund=fund_map.get(code);
                if not fund: continue
                dates=fund.get("dates") or []; returns=fund.get("returns") or []
                future_end_text = str(future_end)[:DATE_TEXT_LENGTH]
                if bisect.bisect_left(dates, future_end_text) >= len(dates):
                    continue
                final_index=bisect.bisect_right(dates,future_end_text)
                fwd=returns[end:final_index]; fwd_dates=dates[end:final_index]
                if len(fwd) < MIN_HISTORY_POINTS: continue
                feature_date=str(snap.get("feature_date") or "")[:DATE_TEXT_LENGTH]
                pit_product,pit_fees,pit_fees_verified=self._pit_fields(fund,feature_date)
                pit_purchasable_values = list(snap.get("pit_purchasable") or [])
                pit_availability_known_values = list(snap.get("pit_availability_known") or [])
                pit_purchasable = bool(pit_purchasable_values[row_index]) if row_index < len(pit_purchasable_values) else True
                pit_availability_known = bool(pit_availability_known_values[row_index]) if row_index < len(pit_availability_known_values) else False
                clone={**fund,"returns":list(returns[:end]),"dates":list(dates[:end]),
                       "latest_date":feature_date,
                       "product_features":pit_product,"fees":pit_fees,"fees_verified":pit_fees_verified,
                       "pit_purchasable":pit_purchasable,"pit_availability_known":pit_availability_known}
                # Current purchase fields are future information from the OOS feature date.
                for current_only_field in CURRENT_PURCHASE_EVIDENCE_FIELDS:
                    clone.pop(current_only_field, None)
                clone.pop("display_nav",None); clone.pop("display_nav_date",None)
                hist.append(clone); forward[code]={"dates":fwd_dates,"returns":fwd}; all_forward.append(forward[code])
                if row_index < len(raw_feature_rows) and row_index < len(feature_stats):
                    precomputed[str(code)] = {
                        "vector": list(raw_feature_rows[row_index]),
                        "stats": dict(feature_stats[row_index]),
                    }
            # Reuse each snapshot's already-frozen PIT transaction cost so OOS evaluation has
            # exactly the same fee evidence/imputation as the forward training target.
            snapshot_transaction_costs = list(snap.get("pit_transaction_costs") or [])
            snapshot_cost_by_code = {
                str(code): snapshot_transaction_costs[index]
                for index, code in enumerate(snap.get("codes") or [])
                if index < len(snapshot_transaction_costs)
            }
            fee_imputation, fee_imputation_fallback = self._fee_imputation_by_bucket(hist, horizon_years)
            for clone in hist:
                code = str(clone.get("code") or "")
                path = forward.get(code)
                if not isinstance(path, dict):
                    continue
                bucket = _asset_bucket(str(clone.get("name") or ""), str(clone.get("type") or ""))
                frozen_cost = snapshot_cost_by_code.get(code)
                unknown_cost = (
                    max(0.0, _finite(frozen_cost))
                    if frozen_cost is not None
                    else fee_imputation.get(bucket, fee_imputation_fallback)
                )
                path["returns"], path["transaction_cost_evidence"] = _net_holding_return_path(
                    list(path.get("returns") or []),
                    clone.get("fees") if clone.get("fees_verified") is True else None,
                    horizon_years,
                    unknown_cost,
                )
            scored=self.score(
                hist,model,{},as_of_date=str(snap.get("feature_date") or ""),
                precomputed_features=precomputed,
            )
            chosen = _select_top_policy(scored, MODEL_SELECTION_SIZE)
            chosen = [item for item in chosen if item["code"] in forward]
            if len(chosen) != MODEL_SELECTION_SIZE:
                constraint_failures.append(f"{snap.get('feature_date')} 正式Top100选择策略未选满{MODEL_SELECTION_SIZE}只")
                continue
            pred={x["code"]:x["raw_score"] for x in scored}; target_map={c:t for c,t in zip(snap["codes"],snap["targets"])}; common=[c for c in pred if c in target_map]
            rank_ics.append(_spearman([pred[c] for c in common],[target_map[c] for c in common]) if len(common) >= 2 else 0.0)
            regime_ics.append((str(snap.get("regime") or "unknown"), rank_ics[-1]))
            top_sets.append({x["code"] for x in chosen}); selected=[forward[x["code"]] for x in chosen]
            top_return,portfolio_daily=self._fixed_weight_portfolio_path(selected)
            bench,_bench_daily=self._fixed_weight_portfolio_path(all_forward); excess.append(top_return-bench)
            elapsed_years = sys.float_info.epsilon
            try:
                start_day = _dt.date.fromisoformat(str(snap.get("feature_date") or "")[:DATE_TEXT_LENGTH])
                end_day = _dt.date.fromisoformat(str(snap.get("target_end_date") or "")[:DATE_TEXT_LENGTH])
                elapsed_years = max((end_day - start_day).days / AVERAGE_GREGORIAN_DAYS_PER_YEAR, 1.0 / AVERAGE_GREGORIAN_DAYS_PER_YEAR)
                if top_return > -1.0 and bench > -1.0:
                    portfolio_ann = (1.0 + top_return) ** (1.0 / elapsed_years) - 1.0
                    benchmark_ann = (1.0 + bench) ** (1.0 / elapsed_years) - 1.0
                    annual_excess.append(portfolio_ann - benchmark_ann)
            except (TypeError, ValueError, OverflowError):
                pass
            dds.append(abs(_max_drawdown(portfolio_daily)))
            periods_per_year = len(portfolio_daily) / max(elapsed_years, sys.float_info.epsilon) if portfolio_daily else 1.0
            downside = math.sqrt(statistics.fmean(min(0.0, value) ** 2 for value in portfolio_daily)) * math.sqrt(periods_per_year) if portfolio_daily else 0.0
            annual_mean = statistics.fmean(portfolio_daily) * periods_per_year if portfolio_daily else 0.0
            downside_ratios.append(annual_mean / max(downside, sys.float_info.epsilon))
            pair=[]
            for i in range(len(chosen)):
                for j in range(i+1,len(chosen)): pair.append(max(0.0,self._return_correlation(chosen[i],chosen[j])))
            corrs.append(sum(pair)/len(pair) if pair else 0.0)
        turnovers=[1.0-len(a&b)/max(1,len(a|b)) for a,b in zip(top_sets,top_sets[1:])]; mean=lambda xs: sum(xs)/max(1,len(xs))
        ric=mean(rank_ics); ex=mean(excess); annual_ex=mean(annual_excess); win=sum(v>0 for v in excess)/max(1,len(excess)); dd=max(dds) if dds else 0.0; so=mean(downside_ratios); turn=mean(turnovers); corr=mean(corrs)
        by_regime={}
        for regime,value in regime_ics: by_regime.setdefault(regime,[]).append(value)
        worst_regime=min((mean(values) for values in by_regime.values()), default=0.0)
        median_ric=statistics.median(rank_ics) if rank_ics else 0.0
        sorted_ric = sorted(rank_ics)
        quartile_count = len(("Q1", "Q2", "Q3", "Q4"))
        p25 = sorted_ric[max(0, math.ceil(len(sorted_ric) / quartile_count) - 1)] if sorted_ric else 0.0
        non_overlapping=all(str(left.get("target_end_date") or "") <= str(right.get("feature_date") or "") for left,right in zip(snapshots,snapshots[1:]))
        return {"windows":len(rank_ics),"rank_ic_mean":ric,"rank_ic_median":median_ric,"rank_ic_p25":p25,"rank_ic_positive_ratio":sum(v>0 for v in rank_ics)/max(1,len(rank_ics)),"rank_ic_worst":min(rank_ics) if rank_ics else 0.0,"rank_ic_values":list(rank_ics),"worst_regime_rank_ic":worst_regime,"top100_excess_return":ex,"oos_annual_excess_return":annual_ex,"candidate_pool_equal_weight_win_rate":win,"candidate_pool_equal_weight_excess_return":ex,"top100_benchmark_win_rate":win,"benchmark_definition":"same-window eligible candidate-pool equal-weight buy-and-hold","max_oos_drawdown":dd,"oos_zero_baseline_downside_ratio":so,"turnover":turn,"portfolio_correlation":corr,"quality":median_ric,"quality_semantics":"compatibility alias of rank_ic_median; deployment uses lexicographic OOS metrics","portfolio_assumption":"initial-equal-weight-buy-and-hold","windows_non_overlapping":non_overlapping,"fold_purge_rule":"training labels mature before each evaluation feature date","constraint_failures":constraint_failures}

# ===== 分析引擎功能单元 =====

MODEL_SCHEMA_DEFINITION = {
    "feature_names": tuple(AdaptiveRanker.FEATURE_NAMES),
    "target_identity": "runtime-data-supported-min-3y-horizon-net-purchase-redemption-transaction-cost",
    "share_cost_identity": "verified-or-category-conservative-imputed-transaction-cost-at-deployed-target-horizon",
    "fee_evidence_identity": "explicit-known-vs-unknown-feature-and-live-formal-buy-gate",
    "history_density_identity": "weekday-plus-observed-context-density-and-gap-fail-closed-gate",
    "feature_scaling_identity": "robust-cross-market-magnitude-plus-within-asset-percentile-plus-asset-one-hot",
    "historical_share_selection_identity": "per-rebalance-point-in-time-fee-class-selection",
    "historical_availability_identity": "not-used-for-ranking-admission",
    "purchase_ranking_identity": "relative-ranking-independent; formal-output-requires-currently-purchasable-and-absolute-gate",
    "feedback_identity": "target-maturity-only",
    "untouched_identity": "never-tunes-or-promotes-fixed-three-metric-catastrophic-veto-only",
}
MODEL_SCHEMA_FINGERPRINT = _sqlite_schema_fingerprint(_schema_fingerprint(MODEL_SCHEMA_DEFINITION))

class AvailabilityResolver:
    """Use fresh public multi-source evidence for every refresh operation."""
    def __init__(self, source):
        self.source = source

    def snapshot(self) -> tuple[dict[str, dict], dict]:
        if not hasattr(self.source, "public_fallback_universe"):
            raise DataError("当前基金数据源不支持公开基金目录快照")
        snapshot = self.source.public_fallback_universe()
        before = len(snapshot)
        if hasattr(self.source, "structural_prefilter"):
            snapshot = self.source.structural_prefilter(snapshot)
        if len(snapshot) < DISPLAY_TOP_N:
            raise DataError(f"公开基金证据池经结构筛选后仅 {len(snapshot)} 个具体份额，低于 Top {DISPLAY_TOP_N} 最低输出要求")
        state = {
            "mode": "public-market-inference",
            "error": "",
            "prefilter": {"before": before, "after": len(snapshot), "performance_blind": True},
            "evidence_policy": "公开基金目录与状态元数据仅用于数据同步，不参与排名",
        }
        return snapshot, state


class HistoryRepository:
    """Small storage boundary so AnalysisEngine does not know SQLite/cache representation details."""
    def __init__(self, store):
        self.store = store

    def archive(self) -> dict[str, dict]:
        rows = self.store.cache.get("funds", {})
        return rows if isinstance(rows, dict) else {}

    def load_history_for_codes(self, codes, start_date: str | None = None) -> dict[str, dict]:
        return self.store.load_history_for_codes(codes, start_date=start_date)

    def commit_latest_rows(self, latest: dict[str, dict], codes: set[str] | None = None) -> dict:
        return self.store.commit_latest_rows(latest, codes=codes)

    def save_cache(self, dirty_codes: set[str] | None = None) -> None:
        self.store.save_cache(dirty_codes=dirty_codes)

    def save_model(self, model: dict) -> None:
        self.store.save_model(model)


def _cleanup_stale_runtime_files(max_age_seconds: float | None = None) -> int:
    """Remove only stale training payloads inside the already-bound user runtime directory."""
    runtime_root = _assert_isolated_app_path(RUNTIME_TMP_DIR)
    if not runtime_root.exists():
        return 0
    now = time.time()
    removed = 0
    for path in runtime_root.glob("training-*.json.gz"):
        try:
            safe_path = _assert_isolated_app_path(path)
            if _path_is_reparse_or_symlink(safe_path) or not safe_path.is_file():
                continue
            stale_after = _objective_stale_artifact_age_seconds(safe_path) if max_age_seconds is None else max(0.0, _finite(max_age_seconds))
            if now - safe_path.stat().st_mtime > stale_after:
                safe_path.unlink()
                removed += 1
        except (OSError, StorageError):
            continue
    return removed


def _write_training_payload(funds: list[dict]) -> Path:
    """Stream a compressed JSON payload to the selected-folder runtime dir; never pickle the pool through spawn."""
    _ensure_isolated_app_dir(RUNTIME_TMP_DIR)
    descriptor, name = tempfile.mkstemp(prefix="training-", suffix=".json.gz", dir=str(RUNTIME_TMP_DIR))
    path = Path(name)
    try:
        _assert_isolated_app_path(path)
        encoder = json.JSONEncoder(ensure_ascii=False, separators=(",", ":"), allow_nan=True)
        with os.fdopen(descriptor, "wb") as raw:
            with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
                for chunk in encoder.iterencode(funds):
                    zipped.write(chunk.encode("utf-8"))
            raw.flush()
            os.fsync(raw.fileno())
        return path
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _load_training_payload(training_data_path: str | Path) -> list[dict]:
    path = _assert_isolated_app_path(Path(training_data_path))
    runtime_root = _assert_isolated_app_path(RUNTIME_TMP_DIR).resolve()
    try:
        if path.parent.resolve() != runtime_root or _path_is_reparse_or_symlink(path) or not path.is_file():
            raise StorageError("训练载荷不是运行目录中的普通临时文件")
        if path.stat().st_size > _objective_training_payload_memory_budget():
            raise StorageError("训练载荷异常过大")
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise StorageError(f"无法读取训练载荷：{exc}") from exc
    if not isinstance(payload, list) or any(not isinstance(item, dict) for item in payload):
        raise DataError("训练载荷格式非法")
    return payload


def _training_process_entry(
    base_dir_text: str, training_data_path: str, result_queue, status_queue,
    dependency_dir_name: str = "", prediction_feedback: dict | None = None,
    production_baseline: dict | None = None,
) -> None:
    """Fresh-process training with business-progress reporting and parent-side compute-stall observation."""

    def send_status(kind: str, *payload) -> None:
        try:
            status_queue.put_nowait((kind, *payload))
        except (queue.Full, OSError, ValueError):
            pass
    try:
        global _TRAINING_DEPENDENCY_OVERRIDE, _TRAINING_CHILD_EVENT_SINK
        _TRAINING_CHILD_EVENT_SINK = lambda kind, payload: send_status(kind, payload)
        _GLOBAL_STOP_EVENT.clear()
        _bind_runtime_folder(Path(base_dir_text), folder_is_data_dir=True, promote_pending=False, activate_dependencies=False)
        _apply_isolated_subprocess_env()
        settings = _load_install_settings()
        chosen = None
        if dependency_dir_name:
            candidate = _dependency_dir_from_name(str(dependency_dir_name), settings, require_import_probe=True, safety_boundary=True)
            if candidate is not None:
                _TRAINING_DEPENDENCY_OVERRIDE = candidate
                chosen = candidate
            else:
                _record_diagnostic(
                    "training-pending-dependency",
                    f"拒绝未通过 manifest/ABI/安装后文件树/import 校验的训练依赖代际：{dependency_dir_name}",
                    "DependencyVerifyFailed",
                )
        if chosen is None:
            active_candidate = _active_dependency_dir(settings)
            if active_candidate is not None:
                ok, _, _ = _verify_dependency_generation(
                    active_candidate, settings, require_import_probe=True,
                    force_tree_rehash=True, force_import_probe=True,
                )
                if ok:
                    chosen = active_candidate
        if chosen is not None:
            _TRAINING_DEPENDENCY_OVERRIDE = chosen
            _activate_local_dependencies()
        send_status("progress", "读取本地长期训练样本", 1.0)
        funds = _load_training_payload(training_data_path)
        model = AdaptiveRanker().train(
            funds, prediction_feedback=prediction_feedback, production_baseline=production_baseline,
            progress=lambda text, pct: send_status(
                "progress", str(text), _clamp(_finite(pct), 0.0, PERCENT_SCALE),
            ),
        )
        model["training_dependency_dir"] = chosen.name if chosen is not None else ""
        result_queue.put(("ok", model))
    except BaseException as exc:
        try:
            result_queue.put(("error", {"type": type(exc).__name__, "message": str(exc)}))
        except Exception as queue_exc:
            _record_diagnostic("training-child-result-queue", queue_exc)
    finally:
        _TRAINING_CHILD_EVENT_SINK = None


def _child_process_cpu_seconds(pid: int | None) -> float | None:
    """Best-effort child CPU time used only to distinguish slow computation from a stalled trainer."""
    if not pid:
        return None
    if os.name == "nt":
        from ctypes import wintypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = None
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.OpenProcess.restype = ctypes.c_void_p
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
            if not handle:
                return None
            creation = wintypes.FILETIME(); exit_time = wintypes.FILETIME()
            kernel = wintypes.FILETIME(); user = wintypes.FILETIME()
            if not kernel32.GetProcessTimes(
                ctypes.c_void_p(handle), ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel), ctypes.byref(user)
            ):
                return None
            def filetime_value(value):
                return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)
            return (filetime_value(kernel) + filetime_value(user)) / 10_000_000.0
        except Exception:
            return None
        finally:
            if handle:
                try:
                    ctypes.windll.kernel32.CloseHandle(ctypes.c_void_p(handle))
                except Exception:
                    pass
    try:
        fields = Path(f"/proc/{int(pid)}/stat").read_text(encoding="ascii").split()
        ticks = int(os.sysconf("SC_CLK_TCK"))
        return (int(fields[13]) + int(fields[14])) / max(1, ticks)
    except (OSError, ValueError, IndexError, AttributeError):
        return None

def _training_stall_watchdog_seconds(current_gaps: list[float] | None = None, fund_count: int | None = None) -> float:
    """Cold training gets a finite Windows operation bound; successful progress gaps then adapt it."""
    settings = _load_install_settings()
    observed = settings.get("training_progress_observations")
    observed = observed if isinstance(observed, dict) else {}
    values = [max(0.0, _finite(value, 0.0)) for value in (current_gaps or []) if _finite(value, 0.0) > 0.0]
    historical_max = max(0.0, _finite(observed.get("max_progress_gap_seconds"), 0.0))
    historical_count = max(0, int(_finite(observed.get("gap_count"), 0)))
    historical_mean = max(0.0, _finite(observed.get("mean_progress_gap_seconds"), 0.0))
    historical_m2 = max(0.0, _finite(observed.get("m2_progress_gap_seconds"), 0.0))
    if historical_count > 0 and historical_max > 0.0:
        values.append(historical_max)
        if historical_count > 1:
            values.append(historical_mean + math.sqrt(historical_m2 / max(1, historical_count - 1)))
    if not values:
        return _objective_external_operation_timeout("model_training", max(1, int(fund_count or DISPLAY_TOP_N)))
    maximum = max(values)
    deviation = statistics.pstdev(values) if len(values) > 1 else 0.0
    uncertainty = time.get_clock_info("monotonic").resolution
    return maximum + max(deviation, uncertainty)

def _record_training_progress_observation(fund_count: int, max_gap: float, elapsed: float, gaps: list[float] | None = None) -> None:
    samples = [max(0.0, float(value)) for value in (gaps or []) if float(value) > 0.0]
    def mutate(settings):
        previous = settings.get("training_progress_observations")
        previous = previous if isinstance(previous, dict) else {}
        count = max(0, int(_finite(previous.get("gap_count"), 0)))
        mean = max(0.0, _finite(previous.get("mean_progress_gap_seconds"), 0.0))
        m2 = max(0.0, _finite(previous.get("m2_progress_gap_seconds"), 0.0))
        observed_max = max(0.0, _finite(previous.get("max_progress_gap_seconds"), 0.0))
        for value in samples:
            count += 1
            delta = value - mean
            mean += delta / count
            m2 += delta * (value - mean)
            observed_max = max(observed_max, value)
        observed_max = max(observed_max, max(0.0, float(max_gap)))
        settings["training_progress_observations"] = {
            "fund_count": max(1, int(fund_count)),
            "gap_count": count,
            "mean_progress_gap_seconds": mean,
            "m2_progress_gap_seconds": max(0.0, m2),
            "max_progress_gap_seconds": observed_max,
            "last_training_elapsed_seconds": max(0.0, float(elapsed)),
            "observed_at": _now_iso(),
        }
    try:
        _update_install_settings(mutate)
    except Exception as exc:
        _record_diagnostic("training-progress-observation", exc)


class ModelTrainer:
    """Run fitting in a killable child; the child validates the exact feedback-adjusted final candidate."""
    def __init__(self, ranker):
        self.ranker = ranker


    def train(
        self, funds: list[dict], feedback: dict | None = None, progress=lambda *_: None,
        *, release_input_after_payload: bool = False, production_baseline: dict | None = None,
    ) -> dict:
        if _storage_survival_mode_active():
            raise ModelError("磁盘空间保护模式已启用：停止训练并保留 last-known-good")
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        settings = _load_install_settings()
        dependency_dir = _preferred_training_dependency_dir(settings, require_import_probe=True, safety_boundary=True)
        dependency_dir_name = dependency_dir.name if dependency_dir is not None else ""
        training_fund_count = len(funds)
        training_payload_path = _write_training_payload(funds)
        if release_input_after_payload:
            funds.clear()
            import gc
            gc.collect()
        context = mp.get_context("spawn")
        result_queue = context.Queue(maxsize=1)
        status_queue = context.Queue(maxsize=0)
        process = context.Process(
            target=_training_process_entry,
            args=(str(BASE_DIR), str(training_payload_path), result_queue, status_queue, dependency_dir_name, dict(feedback or {}), dict(production_baseline or {})),
            name="best-alipay-funds-model-train",
            daemon=False,
        )
        with _ACTIVE_TRAINING_LOCK:
            _ACTIVE_TRAINING_PROCESSES.add(process)
        started = time.monotonic()
        last_progress_at = started
        last_compute_activity = started
        last_progress_signature = None
        max_progress_gap = 0.0
        progress_gaps: list[float] = []
        stall_watchdog = _training_stall_watchdog_seconds(progress_gaps, training_fund_count)
        last_cpu_sample = None
        last_cpu_sample_at = started
        try:
            process.start()
            last_cpu_sample = _child_process_cpu_seconds(process.pid)
            message = None
            while message is None:
                if _cancel_requested():
                    if process.is_alive():
                        process.terminate()
                    process.join(timeout=_objective_work_timeout(1))
                    raise concurrent.futures.CancelledError("程序正在退出")

                # Drain business progress independently from the one-shot result queue.
                # Native LightGBM/XGBoost periods are guarded by observed CPU/GPU activity,
                # not by an unrelated heartbeat interval.
                try:
                    while True:
                        status = status_queue.get_nowait()
                        if not isinstance(status, tuple) or not status:
                            continue
                        status_kind = status[0]
                        if status_kind == "progress":
                            event_now = time.monotonic()
                            text = str(status[1]) if len(status) > 1 else "AI 训练中"
                            pct = _clamp(_finite(status[2] if len(status) > 2 else 0.0), 0.0, PERCENT_SCALE)
                            signature = (text, pct)
                            if signature != last_progress_signature:
                                gap = max(0.0, event_now - last_progress_at)
                                if last_progress_signature is not None and gap > 0.0:
                                    progress_gaps.append(gap)
                                    max_progress_gap = max(max_progress_gap, gap)
                                last_progress_at = event_now
                                last_progress_signature = signature
                                stall_watchdog = _training_stall_watchdog_seconds(progress_gaps, training_fund_count)
                            progress(text, pct)
                        elif status_kind == "cuda_failure":
                            payload = status[1] if len(status) > 1 and isinstance(status[1], dict) else {}
                            _record_cuda_failure_payload(payload)
                        elif status_kind == "cuda_success":
                            payload = status[1] if len(status) > 1 and isinstance(status[1], dict) else {}
                            _record_cuda_success_payload(payload)
                        elif status_kind == "diagnostic":
                            payload = status[1] if len(status) > 1 and isinstance(status[1], dict) else {}
                            _record_diagnostic(
                                str(payload.get("component") or "training-child"),
                                str(payload.get("message") or ""),
                                str(payload.get("type") or "Info"),
                            )
                except queue.Empty:
                    pass

                now = time.monotonic()
                cpu_now = _child_process_cpu_seconds(process.pid) if process.is_alive() else None
                if cpu_now is not None and last_cpu_sample is not None:
                    sample_elapsed = max(time.get_clock_info("monotonic").resolution, now - last_cpu_sample_at)
                    cpu_delta = max(0.0, cpu_now - last_cpu_sample)
                    logical = max(1, int(os.cpu_count() or 1))
                    normalized_cpu = cpu_delta / sample_elapsed / logical
                    if normalized_cpu >= 1.0 / (logical * max(1, MODEL_SELECTION_SIZE)):
                        last_compute_activity = now
                if cpu_now is not None:
                    last_cpu_sample = cpu_now
                    last_cpu_sample_at = now

                progress_stalled = bool(stall_watchdog is not None and process.is_alive() and now - last_progress_at > stall_watchdog)
                compute_stalled = bool(stall_watchdog is not None and now - last_compute_activity > stall_watchdog)
                if progress_stalled and compute_stalled:
                    gpu_probe = _nvidia_cuda_probe()
                    gpu_active = any(
                        _finite(row.get("utilization_gpu_pct"), 0.0) > 0.0
                        for row in (gpu_probe.get("gpus") or [])
                    ) if isinstance(gpu_probe, dict) else False
                    if gpu_active:
                        last_compute_activity = now
                    else:
                        process.terminate()
                        process.join(timeout=_objective_work_timeout(1))
                        raise ModelError(
                            f"独立 AI 训练业务进度与 CPU/GPU 计算活动均停滞超过 {_human_seconds(stall_watchdog)}，已终止疑似卡死任务"
                        )

                try:
                    message = result_queue.get(timeout=_process_poll_seconds())
                except queue.Empty:
                    if not process.is_alive():
                        try:
                            message = result_queue.get(timeout=_process_poll_seconds())
                        except queue.Empty:
                            raise ModelError(f"独立 AI 训练进程异常退出，exitcode={process.exitcode}")
            kind, payload = message
            process.join(timeout=_objective_work_timeout(1))
            if process.is_alive():
                process.terminate(); process.join(timeout=_objective_work_timeout(1))
            if kind != "ok":
                detail = payload if isinstance(payload, dict) else {"message": str(payload)}
                raise ModelError(f"独立 AI 训练失败：{detail.get('type','Error')}: {detail.get('message','')}")
            if not isinstance(payload, dict):
                raise ModelError("独立 AI 训练返回了非法模型 payload")
            finished = time.monotonic()
            max_progress_gap = max(max_progress_gap, finished - last_progress_at)
            _record_training_progress_observation(training_fund_count, max_progress_gap, finished - started, progress_gaps)
            progress("长期模型训练完成", PERCENT_SCALE)
            return payload
        finally:
            with _ACTIVE_TRAINING_LOCK:
                _ACTIVE_TRAINING_PROCESSES.discard(process)
            try:
                if process.is_alive():
                    process.terminate(); process.join(timeout=_objective_work_timeout(1))
            except (OSError, ValueError):
                pass
            for managed_queue in (status_queue, result_queue):
                try:
                    managed_queue.cancel_join_thread()
                    managed_queue.close()
                except (OSError, ValueError):
                    pass
            try:
                training_payload_path.unlink(missing_ok=True)
            except OSError:
                pass



def _commit_upgrade_with_rollback(
    save_model, save_snapshot, new_model: dict, prior_model: dict | None, *, upgrade_requested: bool, diagnose: bool = True,
) -> None:
    """One-process atomicity guard: a failed formal snapshot can never strand a newly promoted model."""
    if upgrade_requested:
        save_model(new_model)
    try:
        save_snapshot()
    except Exception as exc:
        if diagnose:
            _record_diagnostic("formal-ranking-commit", exc)
        if upgrade_requested and isinstance(prior_model, dict):
            try:
                save_model(prior_model)
            except Exception as rollback_exc:
                if diagnose:
                    _record_diagnostic("formal-model-rollback", rollback_exc)
        raise




def _select_formal_buy_candidates(scored: list[dict], count: int = DISPLAY_TOP_N) -> list[dict]:
    """Select up to Top-N candidates that are both absolutely investable and currently purchasable."""
    count = max(1, int(count))
    selected = []
    used_underlying = set()
    for raw_rank, item in enumerate(scored, 1):
        if item.get("absolute_investability") is not True:
            continue
        if str(item.get("availability_status") or "unknown") not in FORMAL_PURCHASABLE_STATUSES:
            continue
        underlying = _underlying_key(item)
        if underlying in used_underlying:
            continue
        clone = dict(item)
        clone["ai_raw_rank"] = raw_rank
        clone["ranking_rank"] = len(selected) + 1
        selected.append(clone)
        used_underlying.add(underlying)
        if len(selected) >= count:
            break
    return selected

def _select_top_policy(scored: list[dict], count: int = DISPLAY_TOP_N) -> list[dict]:
    """Select Top-N strictly by investment-quality order, de-duplicated by underlying fund."""
    count = max(1, int(count))
    selected = []
    used_underlying = set()
    for raw_rank, item in enumerate(scored, 1):
        underlying = _underlying_key(item)
        if underlying in used_underlying:
            continue
        clone = dict(item)
        clone["ai_raw_rank"] = raw_rank
        clone["ranking_rank"] = len(selected) + 1
        selected.append(clone)
        used_underlying.add(underlying)
        if len(selected) >= count:
            break
    return selected


class OfficialChinaMarketCalendar:
    """Independent SSE calendar/status evidence; fund-data dates never define the expected session."""

    URL = "https://www.sse.com.cn/disclosure/dealinstruc/closed/"
    SOURCE = "上海证券交易所年度休市安排"
    _lock = threading.RLock()
    _year_cache: dict[int, frozenset[_dt.date]] = {}

    @classmethod
    def _parse_closure_dates(cls, page: str, year: int) -> frozenset[_dt.date]:
        text = html.unescape(str(page or ""))
        text = re.sub(r"(?is)<script\b.*?</script>|<style\b.*?</style>", " ", text)
        text = re.sub(r"(?s)<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text)
        marker = f"{int(year)}年休市安排"
        if marker not in text:
            raise ContractError(f"上交所页面未包含 {marker}")
        section = text.split(marker, 1)[1]
        if "相关公告" in section:
            section = section.split("相关公告", 1)[0]
        closures: set[_dt.date] = set()
        range_pattern = re.compile(
            r"(\d{1,2})月(\d{1,2})日[^。；]{0,40}?至\s*(\d{1,2})月(\d{1,2})日[^。；]{0,40}?休市"
        )
        for sm, sd, em, ed in range_pattern.findall(section):
            start = _dt.date(int(year), int(sm), int(sd))
            end_year = int(year) + (int(em) < int(sm))
            end = _dt.date(end_year, int(em), int(ed))
            span = (end - start).days
            if span < 0 or span > int(AVERAGE_GREGORIAN_DAYS_PER_MONTH * 2):
                raise ContractError(f"上交所休市区间异常：{start}..{end}")
            for offset in range(span + 1):
                closures.add(start + _dt.timedelta(days=offset))
        if not closures:
            raise ContractError(f"上交所 {year} 年休市安排未解析出任何休市区间")
        return frozenset(closures)

    @classmethod
    def _closures_for_year(cls, year: int, *, force: bool = False) -> frozenset[_dt.date]:
        year = int(year)
        with cls._lock:
            cached = cls._year_cache.get(year)
        if cached is not None and not force:
            return cached
        page = _http_text(
            cls.URL,
            referer="https://www.sse.com.cn/",
            accept="text/html,application/xhtml+xml",
            allowed_redirect_hosts=frozenset({"www.sse.com.cn", "sse.com.cn"}),
        )
        closures = cls._parse_closure_dates(page, year)
        with cls._lock:
            cls._year_cache[year] = closures
        return closures

    @classmethod
    def snapshot(cls, today: _dt.date | None = None, *, force: bool = False) -> dict:
        today = today or _china_today()
        now = _dt.datetime.now(tz=CHINA_TZ)
        cutoff = today
        market_phase = "closed-session-eligible"
        if today == now.date() and now.time() < MARKET_CLOSE:
            cutoff = today - _dt.timedelta(days=1)
            market_phase = "current-session-not-closed"
        try:
            closures = cls._closures_for_year(cutoff.year, force=force)
            day = cutoff
            # Normal exchange closures are far shorter than one Gregorian month.  Crossing a
            # year without that year's official schedule is treated as unknown, never guessed.
            for _ in range(int(math.ceil(AVERAGE_GREGORIAN_DAYS_PER_MONTH)) + MARKET_WEEKDAYS_PER_WEEK):
                if day.year != cutoff.year:
                    raise ContractError("独立交易日历回溯跨年，当前官方页面不足以证明上一年度会话")
                if day.weekday() <= calendar.FRIDAY and day not in closures:
                    return {
                        "reliable": True,
                        "source": cls.SOURCE,
                        "as_of_date": today.isoformat(),
                        "expected_latest_session": day.isoformat(),
                        "market_phase": market_phase,
                        "checked_at": _now_iso(),
                        "reason": "由上交所年度休市安排、周一至周五交易规则与15:00收市边界独立推导",
                    }
                day -= _dt.timedelta(days=1)
            raise ContractError("独立交易日历在客观回溯窗口内未找到已完成交易日")
        except (DataError, ParseError, ContractError, NetworkError, OSError, TimeoutError, ValueError) as exc:
            _record_diagnostic("official-market-calendar", exc)
            return {
                "reliable": False,
                "source": cls.SOURCE,
                "as_of_date": today.isoformat(),
                "expected_latest_session": "",
                "market_phase": market_phase,
                "checked_at": _now_iso(),
                "reason": f"无法独立确认最新应有交易日：{type(exc).__name__}: {exc}",
            }


class FreshnessGate:
    """Fail-closed NAV freshness gate backed by an independent official market calendar."""

    def __init__(self):
        self._market_state: dict = {
            "reliable": False,
            "source": OfficialChinaMarketCalendar.SOURCE,
            "as_of_date": "",
            "expected_latest_session": "",
            "reason": "尚未获取独立交易日历证据",
        }

    def refresh_independent_market_state(self, today: _dt.date | None = None, *, force: bool = False) -> dict:
        today = today or _china_today()
        if (
            not force
            and str(self._market_state.get("as_of_date") or "") == today.isoformat()
            and self._market_state.get("checked_at")
        ):
            return dict(self._market_state)
        self._market_state = OfficialChinaMarketCalendar.snapshot(today, force=force)
        return dict(self._market_state)

    def set_market_state_for_test(self, state: dict) -> None:
        self._market_state = dict(state or {})

    def market_state(self) -> dict:
        return dict(self._market_state)

    @staticmethod
    def _calendar_supported(row: dict, fund_type: str = "") -> bool:
        probe = dict(row or {})
        probe.setdefault("type", fund_type)
        # QDII/overseas funds can legitimately publish on a lagged foreign-market calendar.
        # Until an equally independent overseas calendar is available, fail closed rather than
        # infer expected dates from Eastmoney/Sina themselves.
        return _asset_bucket(str(probe.get("name") or ""), str(probe.get("type") or "")) != "QDII/海外"

    def evaluate(self, row: dict, today: _dt.date, fund_type: str = "") -> tuple[bool, str]:
        row = dict(row or {})
        try:
            day = _dt.date.fromisoformat(str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH])
        except ValueError:
            return False, "净值日期无效"
        nav = _finite(row.get("nav"), float("nan"))
        if not math.isfinite(nav) or nav <= 0 or day > today:
            return False, "净值或净值日期无效"
        if not self._calendar_supported(row, fund_type):
            return False, "QDII/海外基金尚无独立对应市场日历，按 last-known-good 降级"
        state = self.refresh_independent_market_state(today, force=False)
        expected_text = str(state.get("expected_latest_session") or "")[:DATE_TEXT_LENGTH]
        if state.get("reliable") is not True or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", expected_text):
            return False, str(state.get("reason") or "独立交易日历不可用")
        return day.isoformat() == expected_text, (
            f"净值日期 {day.isoformat()} 与独立应有交易日 {expected_text} 一致"
            if day.isoformat() == expected_text else
            f"净值日期 {day.isoformat()} 落后于独立应有交易日 {expected_text}"
        )

    def is_fresh(self, row: dict, today: _dt.date, fund_type: str = "") -> bool:
        return self.evaluate(row, today, fund_type)[0]

    def filter_latest(self, rows: dict[str, dict], today: _dt.date, fund_types: dict[str, str] | None = None) -> dict[str, dict]:
        fund_types = fund_types or {}
        # Resolve one market-state snapshot before looking at any provider dates.  This ordering
        # is intentional: source rows can prove a NAV exists, never what date should exist.
        self.refresh_independent_market_state(today, force=False)
        fresh: dict[str, dict] = {}
        for code, raw_row in (rows or {}).items():
            ok, reason = self.evaluate(raw_row, today, fund_types.get(code, ""))
            if ok:
                row = dict(raw_row or {})
                row["freshness_basis"] = "independent-official-market-calendar"
                row["freshness_note"] = reason
                row["expected_market_session"] = str(self._market_state.get("expected_latest_session") or "")
                fresh[str(code)] = row
        return fresh


# ===== 分析引擎 =====

@dataclass
class RankingResult:
    rows: list[dict]
    state: str  # preview / basic_screening / last_known_good / current_verified
    gate: dict = field(default_factory=dict)

    def __post_init__(self):
        self.rows = list(self.rows or [])
        self.gate = dict(self.gate or {})
        if self.state not in {"preview", "basic_screening", "last_known_good", "current_verified"}:
            raise DataError(f"未知排名结果状态：{self.state}")
        if self.state in {"last_known_good", "current_verified"}:
            self.rows = _validate_formal_results(self.rows)


class AnalysisEngine:
    def __init__(self, source=None, store=None):
            self.source = source or FundDataSource()
            self.store = store or LocalStore()
            self.ranker = AdaptiveRanker()
            self.availability_resolver = AvailabilityResolver(self.source)
            self.history_repository = HistoryRepository(self.store)
            self.model_trainer = ModelTrainer(self.ranker)
            self.freshness_gate = FreshnessGate()
            self.funds: list[dict] = []
            self.market_funds: list[dict] = []
            self.feature_cache: dict[str, dict] = {}
            self._cross_check_cache: dict[tuple[str,str], dict] = {}
            self.lock = threading.RLock()
            self._last_full_nav_refresh_at = 0.0
            self.last_freshness_gate = {"ok": False, "reason": "尚未执行正式结果新鲜度门控"}
            self.last_catalog_sync_degraded = False
            self.last_catalog_sync_reason = ""
            self._last_verified_rows: list[dict] = []
            # Lazy cached startup intentionally hydrates only a bounded foreground set.
            # Track whether self.funds currently represents the complete ranked candidate pool
            # so persistence/periodic refresh never mistakes "not hydrated" for "not a candidate".
            self._candidate_pool_complete = False

    def result_for_display(self, holding_years: int | None = None) -> RankingResult | None:
        years = _expected_holding_years(holding_years, self.store.model)
        gate = dict(self.last_freshness_gate or {})
        market_state = self.freshness_gate.market_state()
        current_market_proof = bool(
            market_state.get("reliable") is True
            and str(market_state.get("as_of_date") or "") == _china_today().isoformat()
            and str(gate.get("expected_market_session") or "")
                == str(market_state.get("expected_latest_session") or "")
        )
        if gate.get("ok") and current_market_proof and self._last_verified_rows:
            return RankingResult([dict(item) for item in self._last_verified_rows], "current_verified", gate)
        snapshot = self.store.load_formal_ranking(years)
        if snapshot:
            gate = dict(snapshot.get("gate") or {})
            gate["current_recheck_ok"] = False
            return RankingResult(snapshot["rows"], "last_known_good", gate)
        return None

    def basic_screening_result(self, holding_years: int | None = None, reason: str = "") -> RankingResult | None:
        """Stable non-formal relative ranking used while strict PIT long-horizon evidence is still immature."""
        years = _expected_holding_years(holding_years, self.store.model)
        with self.lock:
            pool = [
                item for item in self.funds
                if isinstance(item, dict)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ]
            scored = self.ranker.score(
                pool, self.store.model, self.feature_cache, holding_years=years, require_full_selection=False
            ) if pool else []
        rows = _select_top_policy(scored, min(DISPLAY_TOP_N, len(scored))) if scored else []
        if not rows:
            return None
        for item in rows:
            item["basic_screening"] = True
            item["formal_buy_candidate"] = False
        gate_reason = reason or (
            f"长期历史证据不足：正式 production 要求严格 PIT 且目标期限至少 {MIN_LONG_TERM_HORIZON_YEARS} 年；"
            "当前仅展示基础筛选/相对排名，不输出正式买入结论"
        )
        return RankingResult(rows, "basic_screening", {
            "ok": False, "formal": False, "basic_screening": True,
            "reason": gate_reason, "checked_at": _now_iso(),
        })

    def _ranking_boundary_snapshot(self, model: dict, holding_years: int) -> dict:
        """Persist the exact current Top100 boundary evidence used to judge future universe changes."""
        with self.lock:
            pool = [
                item for item in self.funds
                if isinstance(item, dict)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ]
            try:
                scored = self.ranker.score(
                    pool, model, {}, holding_years=holding_years, require_full_selection=False
                ) if pool else []
            except (DataError, ModelError, ValueError, TypeError, ArithmeticError) as exc:
                _record_diagnostic("ranking-boundary-snapshot", exc)
                raise DataError("排名边界计算失败，本轮正式结果失效") from exc
        ranked = self._boundary_ranked_band(scored) if scored else []
        top = ranked[:DISPLAY_TOP_N]
        boundary = _finite(top[-1].get("final_ranking_utility"), float("nan")) if len(top) >= DISPLAY_TOP_N else float("nan")
        return {
            "ranking_boundary_codes": [str(item.get("code") or "") for item in ranked if _valid_fund_code(item.get("code"))],
            "ranking_boundary_utility": boundary if math.isfinite(boundary) else None,
            "ranking_boundary_checked_at": _now_iso(),
            "ranking_boundary_holding_years": int(holding_years),
            "ranking_boundary_asset_classes": sorted({str(item.get("asset_class") or "其他") for item in ranked}),
        }

    def _training_universe_change_affects_boundary(
        self, current_model: dict, training_pool: list[dict], old_codes: set[str], new_codes: set[str],
    ) -> bool:
        changed = old_codes ^ new_codes
        if not changed:
            return False
        prior_boundary = {str(code) for code in (current_model.get("ranking_boundary_codes") or [])}
        removed = old_codes - new_codes
        # Models saved before boundary snapshots existed cannot prove that a removal is irrelevant.
        if removed and not prior_boundary:
            return True
        if removed & prior_boundary:
            return True

        active_pool = [
            item for item in training_pool
            if isinstance(item, dict)
            and str(item.get("code") or "") in new_codes
            and item.get("catalog_active") is not False
            and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
            and len(item.get("returns") or []) == len(item.get("dates") or [])
        ]
        old_asset_classes = {str(value) for value in (current_model.get("training_asset_classes") or []) if str(value)}
        new_asset_classes = {str(item.get("asset_class") or _asset_bucket(item.get("name", ""), item.get("type", ""))) for item in active_pool}
        if old_asset_classes and new_asset_classes - old_asset_classes:
            return True

        added = new_codes - old_codes
        if not added:
            return False
        scorable_added = {str(item.get("code") or "") for item in active_pool if str(item.get("code") or "") in added}
        if not scorable_added:
            return False
        try:
            scored = self.ranker.score(
                active_pool, current_model, {},
                holding_years=_model_target_years(current_model), require_full_selection=False,
            )
            band = self._boundary_ranked_band(scored) if scored else []
            band_codes = {str(item.get("code") or "") for item in band}
            # If fewer than Top100 active samples were available, scoring cannot prove irrelevance.
            if len(scored) < DISPLAY_TOP_N:
                return True
            return bool(scorable_added & band_codes)
        except (DataError, ModelError, ValueError, TypeError, ArithmeticError) as exc:
            _record_diagnostic("universe-boundary-retrain-check", exc)
            return True

    def _availability_change_affects_boundary(
        self, current_model: dict, old_codes: set[str], new_codes: set[str], availability: dict[str, dict],
    ) -> bool:
        changed = old_codes ^ new_codes
        if not changed:
            return False
        prior_boundary = {str(code) for code in (current_model.get("ranking_boundary_codes") or [])}
        removed = old_codes - new_codes
        if removed and not prior_boundary:
            return True
        if removed & prior_boundary:
            return True
        added = new_codes - old_codes
        if not added:
            return False

        with self.lock:
            working = [dict(item) for item in self.funds if isinstance(item, dict)]
        archive = self.history_repository.archive()
        added_ready = set()
        candidate_pool = []
        for item in working:
            code = str(item.get("code") or "")
            if (
                _valid_fund_code(code)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ):
                candidate_pool.append(item)
                if code in added:
                    added_ready.add(code)

        missing_ready = added - added_ready
        if missing_ready:
            histories = self.history_repository.load_history_for_codes([
                code for code in missing_ready
                if int(_finite((archive.get(code) or {}).get("_nav_series_count"), 0)) >= MIN_HISTORY_POINTS
            ])
            for code in sorted(missing_ready):
                meta = archive.get(code) if isinstance(archive.get(code), dict) else {}
                history = histories.get(code) if isinstance(histories.get(code), dict) else {}
                dates, returns = history.get("dates") or [], history.get("returns") or []
                if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                    continue
                declared = availability.get(code) if isinstance(availability.get(code), dict) else {}
                item = {"code": code, **meta, **declared, "dates": dates, "returns": returns}
                item.setdefault("asset_class", _asset_bucket(item.get("name", ""), item.get("type", "")))
                candidate_pool.append(item)
                added_ready.add(code)

        # A newly catalogued share with insufficient mature history cannot yet enter the model/Top100.
        if not added_ready:
            return False
        old_asset_classes = {str(value) for value in (current_model.get("availability_asset_classes") or []) if str(value)}
        added_asset_classes = {
            str(_asset_bucket((availability.get(code) or {}).get("name", ""), (availability.get(code) or {}).get("type", "")))
            for code in added_ready
        }
        if old_asset_classes and added_asset_classes - old_asset_classes:
            return True
        try:
            scored = self.ranker.score(
                candidate_pool, current_model, {},
                holding_years=_model_target_years(current_model), require_full_selection=False,
            )
            if len(scored) < DISPLAY_TOP_N:
                return True
            band_codes = {str(item.get("code") or "") for item in self._boundary_ranked_band(scored)}
            return bool(added_ready & band_codes)
        except (DataError, ModelError, ValueError, TypeError, ArithmeticError) as exc:
            _record_diagnostic("availability-boundary-retrain-check", exc)
            return True

    def _prediction_rows_with_controls(
        self, formal_rows: list[dict], holding_years: int, model: dict,
    ) -> list[dict]:
        """Persist Top100 plus every currently hydrated candidate that can still reach the Top100 boundary."""
        displayed = []
        formal_codes = set()
        for item in formal_rows:
            clone = dict(item)
            clone["prediction_sample_role"] = "display_top100"
            displayed.append(clone)
            formal_codes.add(str(clone.get("code") or ""))

        with self.lock:
            pool = [
                item for item in self.funds
                if isinstance(item, dict)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ]
            scored = self.ranker.score(
                pool, model, self.feature_cache, holding_years=holding_years
            ) if pool else []
            ranked = self._boundary_ranked_band(scored) if scored else []

        challengers = []
        for item in ranked:
            code = str(item.get("code") or "")
            if not code or code in formal_codes:
                continue
            clone = dict(item)
            clone["prediction_sample_role"] = "boundary_challenger"
            challengers.append(clone)
        return displayed + challengers


    def _commit_verified_top100(
        self, rows: list[dict], holding_years: int | None, gate: dict,
        *, model: dict | None = None, rollback_model: dict | None = None,
    ) -> RankingResult:
        if not (gate or {}).get("ok"):
            raise DataError("拒绝提交未通过最终门控的正式买入候选")
        formal_rows = _validate_formal_results([dict(item) for item in rows])
        commit_model = dict(model if model is not None else self.store.model)
        years = _expected_holding_years(holding_years, commit_model)
        commit_model.update(self._ranking_boundary_snapshot(commit_model, years))
        prior_model = dict(rollback_model) if isinstance(rollback_model, dict) else None
        try:
            _commit_upgrade_with_rollback(
                self.history_repository.save_model,
                lambda: self.store.save_formal_ranking(formal_rows, years, commit_model, gate),
                commit_model, prior_model, upgrade_requested=model is not None,
            )
        except Exception:
            if prior_model is not None:
                self.store.model = prior_model
            raise
        self.store.model = commit_model
        try:
            prediction_rows = self._prediction_rows_with_controls(formal_rows, years, commit_model)
            self.store.record_ranking_predictions(prediction_rows, years, commit_model)
        except (StorageError, sqlite3.Error, OSError, DataError, ValueError, TypeError) as exc:
            # Prediction feedback is non-essential to the already validated formal snapshot; known
            # storage/data failures are diagnostic-only, while unknown bugs propagate to the cycle.
            _record_diagnostic("ranking-prediction-snapshot", exc)
        self._last_verified_rows = [dict(item) for item in formal_rows]
        self.last_freshness_gate = dict(gate)
        return RankingResult(formal_rows, "current_verified", dict(gate))

    def ensure_source_contract(self, progress=lambda *_: None, *, force: bool = False) -> dict:
            if hasattr(self.source, "startup_contract_test"):
                return self.source.startup_contract_test(force=force, progress=progress)
            progress("数据源检查不可用，使用当前适配器", PERCENT_SCALE)
            return {"checked": False, "details": {}}

    def next_source_contract_recheck_at(self) -> _dt.datetime | None:
        if hasattr(self.source, "next_contract_recheck_at"):
            try:
                return self.source.next_contract_recheck_at()
            except Exception as exc:
                _record_diagnostic("source-contract-next-check", exc)
        return None


    def _availability_snapshot(self) -> dict[str, dict]:
        snapshot, state = self.availability_resolver.snapshot()
        if not state.get("cached"):
            self.last_availability_mode = str(state.get("mode") or "")
        return {code: dict(row) for code, row in snapshot.items()}


    def maintenance_status(self) -> dict:
        # Under disk pressure reclaim only rebuildable/freelist storage first. If pressure remains,
        # enter read-only survival before retention/history or any other nonessential write.
        storage_gc = _run_unified_storage_gc(self.store)
        if _storage_survival_mode_active():
            return {
                "due": False, "reason": "read-only-last-known-good", "model_age_days": float("inf"),
                "availability_change_ratio": 0.0, "storage_gc": storage_gc, "survival_mode": True,
            }
        self.store.check_cache_integrity()
        contract_status = {}
        try:
            contract_status = self.ensure_source_contract(force=False)
        except (DataError, NetworkError, ContractError) as exc:
            contract_status = {"checked": True, "core_ok": False, "core_error": str(exc), "checked_at": _now_iso()}
            _record_diagnostic("maintenance-source-contract", exc)
        retention = self.store.maintain_prediction_retention()
        storage = self.store.maintain_history_storage()
        current_model = self.store.model if isinstance(self.store.model, dict) else {}
        trained_at = _parse_iso(current_model.get("trained_at"))
        if trained_at is not None and trained_at.tzinfo is None:
            trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        age_days = float("inf") if trained_at is None else max(0.0, (_dt.datetime.now().astimezone() - trained_at).total_seconds() / SECONDS_PER_DAY)
        availability = self._availability_snapshot()
        old_codes = set(current_model.get("availability_codes") or [])
        new_codes = set(availability)
        change_ratio = (len(old_codes ^ new_codes) / max(1, len(old_codes | new_codes))) if old_codes else 1.0
        force_reason = str(current_model.get("force_retrain_reason") or "")
        feedback_snapshot = current_model.get("prediction_feedback_latest_observation")
        if not isinstance(feedback_snapshot, dict):
            feedback_snapshot = current_model.get("prediction_feedback") if isinstance(current_model.get("prediction_feedback"), dict) else {}
        current_cohorts = set(_target_feedback_for_model(feedback_snapshot, current_model).get("mature_cohort_ids") or [])
        seen_cohorts = set(current_model.get("feedback_cohorts_seen") or [])
        new_feedback_cohorts = sorted(current_cohorts - seen_cohorts)
        due_feedback = bool(new_feedback_cohorts)
        due_universe = bool(
            old_codes and old_codes != new_codes
            and self._availability_change_affects_boundary(current_model, old_codes, new_codes, availability)
        )
        shadow_at = _parse_iso(current_model.get("shadow_candidate_trained_at"))
        if shadow_at is not None and shadow_at.tzinfo is None:
            shadow_at = shadow_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        shadow_age_days = (
            float("inf") if shadow_at is None else
            max(0.0, (_dt.datetime.now().astimezone() - shadow_at).total_seconds() / SECONDS_PER_DAY)
        )
        due_shadow_recheck = bool(
            current_model.get("shadow_candidate_available") is True
            and shadow_age_days >= SHADOW_STRICT_PIT_RECHECK_DAYS
        )
        schema_changed = current_model.get("schema_fingerprint") != MODEL_SCHEMA_FINGERPRINT
        due = bool(force_reason or due_feedback or due_universe or due_shadow_recheck or schema_changed)
        if due_feedback and not force_reason:
            current_model["force_retrain_reason"] = "new-mature-feedback-cohort"
        elif due_universe and not force_reason:
            current_model["force_retrain_reason"] = "maintenance-top100-boundary-change"
        elif due_shadow_recheck and not force_reason:
            current_model["force_retrain_reason"] = "strict-pit-maturity-recheck"
        reason = force_reason or (
            "new-mature-feedback-cohort" if due_feedback else
            "top100-boundary-or-training-distribution-change" if due_universe else
            "strict-pit-maturity-recheck" if due_shadow_recheck else
            "schema-version" if schema_changed else "not-due"
        )
        return {
            "due": due, "reason": reason, "model_age_days": age_days,
            "new_feedback_cohorts": new_feedback_cohorts,
            "availability_change_ratio": change_ratio, "availability_count": len(new_codes),
            "prediction_retention": retention,
            "source_contract": contract_status,
            "storage_maintenance": storage,
            "storage_gc": storage_gc,
            "live_resources": _runtime_resource_snapshot(),
            "checked_at": _now_iso(),
        }

    def load_cached(
        self, holding_years: int | None = None, *, allow_stale: bool = True,
    ) -> bool:
        """Restore a bounded foreground working set without confusing displayability with freshness.

        A last-known-good formal ranking is allowed to hydrate from older local NAV history so the
        UI can recover immediately after restart. Freshness remains a separate formal-result gate.
        """
        self._candidate_pool_complete = False
        self.last_freshness_gate = {"ok": False, "reason": "本地上次有效结果；尚未完成本次启动的在线新鲜度复核"}
        self.last_availability_mode = "cached-last-known"
        archive = self.history_repository.archive()
        years = _expected_holding_years(holding_years, self.store.model)
        working_codes = self.store.load_working_set_codes(years)
        if len(working_codes) < DISPLAY_TOP_N:
            fallback = [
                code for code, item in archive.items()
                if isinstance(item, dict) and item.get("ranking_candidate") is True
                and int(_finite(item.get("_nav_series_count"), 0)) >= MIN_HISTORY_POINTS
            ]
            fallback.sort(key=lambda code: (
                str((archive.get(code) or {}).get("latest_date") or ""),
                str(code),
            ), reverse=True)
            known_underlyings = {
                _underlying_key({"code": code, **(archive.get(code) or {})})
                for code in working_codes if isinstance(archive.get(code), dict)
            }
            for code in fallback:
                if code in working_codes:
                    continue
                working_codes.append(code)
                known_underlyings.add(_underlying_key({"code": code, **(archive.get(code) or {})}))
                if len(known_underlyings) >= DISPLAY_TOP_N:
                    break

        hydrated = self.history_repository.load_history_for_codes(working_codes)
        active = []
        market_cached = []
        for code in working_codes:
            meta = archive.get(code) if isinstance(archive.get(code), dict) else {}
            history = hydrated.get(code) if isinstance(hydrated.get(code), dict) else {}
            item = {"code": code, **meta, **history}
            dates, returns = item.get("dates") or [], item.get("returns") or []
            if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                continue
            if item.get("training_representative") is True:
                market_cached.append(dict(item))
            if item.get("ranking_candidate") is not True:
                continue
            cache_fresh = self._history_recent_enough(item)
            item["startup_cache_fresh"] = cache_fresh
            if allow_stale or cache_fresh:
                active.append(item)

        with self.lock:
            self.funds = active
            self.market_funds = market_cached or active
            self.feature_cache.clear()
        full_refresh_stamp = _parse_iso(self.store.cache.get("last_full_nav_refresh_at"))
        if full_refresh_stamp is not None:
            if full_refresh_stamp.tzinfo is None:
                full_refresh_stamp = full_refresh_stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
            elapsed = max(0.0, (_dt.datetime.now().astimezone() - full_refresh_stamp).total_seconds())
            self._last_full_nav_refresh_at = time.monotonic() - elapsed
        else:
            # Legacy caches have no dedicated full-market timestamp. Treat them as due instead
            # of letting a recent foreground cache write postpone the first full refresh.
            self._last_full_nav_refresh_at = 0.0
        eligible_underlying = {_underlying_key(item) for item in active}
        return len(eligible_underlying) >= DISPLAY_TOP_N


    @staticmethod
    def _history_recent_enough(item: dict) -> bool:
        try:
            latest = _dt.date.fromisoformat(str(item.get("latest_date") or "")[:DATE_TEXT_LENGTH])
        except ValueError:
            return False
        return _observed_market_sessions_for_item(latest, _china_today(), item) <= MAX_OBSERVED_SESSION_GAP

    @staticmethod
    def _cache_item(item: dict) -> dict:
        keys = (
            "name","type","dates","returns","latest_nav","latest_date","updated_at","day_change",
            "availability_status","availability_note","fund_data_source","availability_generated_at",
            "availability_source","availability_source_id","availability_evidence",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete",
            "fee_field_verified","annual_cost","embedded_annual_cost","purchase_cost",
"available_from","available_to",
            "availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status","public_purchase_status_secondary",
            "availability_public_signals","availability_public_confirmations","purchase_public_confirmations","metadata_sources",
            "catalog_sources","public_catalog_confirmations","latest_sources","latest_source_count","latest_public_confirmations",
            "latest_cross_source_verified","latest_cross_source_relative_diff","latest_primary_date","latest_secondary_date","latest_cross_source_note",
            "redemption_state","underlying_fund_id","master_code",
            "primary_code","inception_date","termination_date","merged_into","catalog_active",
            "catalog_first_seen","catalog_last_seen","metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","return_pending_adjustment","return_basis",
            "return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
            "ranking_candidate","training_representative","representative_history_code",
            "share_specific_history","share_history_truncated_at_inception","return_basis","return_basis_label","catalog_history",
        )
        output = {key: item.get(key) for key in keys if key not in {"dates", "returns"}}
        if "dates" in item and "returns" in item:
            output["dates"] = item.get("dates")
            output["returns"] = item.get("returns")
        return output


    @staticmethod
    def _normalized_spans(history) -> list[dict]:
        out, seen = [], set()
        if not isinstance(history, list):
            return out
        for span in history:
            if not isinstance(span, dict):
                continue
            start = str(span.get("from") or "")[:DATE_TEXT_LENGTH]
            finish = str(span.get("to") or "")[:DATE_TEXT_LENGTH]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start):
                continue
            key = (start, finish, bool(span.get("purchasable", True)))
            if key in seen:
                continue
            seen.add(key)
            out.append({**span, "from": start, "to": finish, "purchasable": span.get("purchasable", True) is True})
        out.sort(key=lambda x: (x["from"], x.get("to") or "9999-99-99"))
        return out

    @classmethod
    def _merge_observed_availability(cls, declared: dict, cached: dict | None) -> list[dict]:
        """Persist dated public-market status observations for compatibility and diagnostics."""
        source_history = cls._normalized_spans(declared.get("availability_history"))
        cached_history = cls._normalized_spans((cached or {}).get("availability_history"))
        history = source_history or cached_history
        status = str(declared.get("availability_status") or "unknown")
        known_statuses = {
            "public_open", "limited_purchasable", "redemption_suspended",
            "purchase_suspended", "closed",
        }
        if status not in known_statuses:
            return history
        observed = str(declared.get("availability_generated_at") or declared.get("metadata_checked_at") or "")[:DATE_TEXT_LENGTH]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            return history
        purchasable = status not in PURCHASE_UNAVAILABLE_STATUSES
        evidence = f"public-market-inference:{status}"
        # Close the previous open observation when evidence changes, then start a new span.
        if history:
            last = history[-1]
            last_status = str(last.get("status") or "")
            if not last_status:
                last_status = "public_open" if last.get("purchasable") is True else "purchase_suspended"
            if last_status == status and last.get("purchasable") is purchasable and not last.get("to"):
                last["last_observed"] = observed
                last["evidence"] = evidence
                return history
            if not last.get("to"):
                try:
                    last["to"] = (_dt.date.fromisoformat(observed) - _dt.timedelta(days=1)).isoformat()
                except ValueError:
                    last["to"] = observed
        history.append({
            "from": observed, "to": "", "last_observed": observed,
            "purchasable": purchasable, "status": status, "evidence": evidence,
        })
        return history

    @staticmethod
    def _unknown_market_declaration(meta: dict) -> dict:
        return {
            "availability_status": "unknown", "availability_generated_at": _now_iso(),
            "availability_source": "东方财富公开基金全集",
            "availability_source_id": "eastmoney-public-market",
            "availability_evidence": "仅用于全市场数据同步",
            "availability_note": "公开状态元数据未知",
            "fund_data_source": "东方财富基金公开清单/历史净值",
            "fees_verified": False, "fees": {}, "fees_history": [],
            "available_from": "", "available_to": "", "availability_history": [],
            "share_class": "", "product_features": {}, "product_features_history": [],
            "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
            **_holding_costs({}),
        }

    def _retained_training_pool(self, current_market: list[dict], archive: dict) -> list[dict]:
        """Retain every eligible historical training representative; later payload admission is RAM-derived."""
        output = {str(item.get("code") or ""): item for item in current_market if str(item.get("code") or "")}
        inactive_buckets: dict[tuple[str, str], list[tuple[str, str, dict]]] = {}
        for code, cached in (archive or {}).items():
            code = str(code or "")
            if code in output or not isinstance(cached, dict):
                continue
            if cached.get("training_representative") is not True and cached.get("catalog_active") is not False:
                continue
            dates, returns = cached.get("dates") or [], cached.get("returns") or []
            series_count = len(returns) if len(dates) == len(returns) and returns else int(_finite(cached.get("_nav_series_count"), 0))
            if series_count < MIN_HISTORY_POINTS:
                continue
            exit_text = str(cached.get("termination_date") or cached.get("latest_date") or (dates[-1] if dates else ""))[:DATE_TEXT_LENGTH]
            try:
                exit_year = int(exit_text[:DATE_YEAR_DIGITS])
            except (TypeError, ValueError):
                exit_year = None
            year_bucket = str(exit_year) if exit_year is not None else "unknown"
            asset_class = str(cached.get("asset_class") or _asset_bucket(cached.get("name", ""), cached.get("type", "")) or "其他")
            stable_key = hashlib.sha256(f"{year_bucket}|{asset_class}|{code}".encode("utf-8")).hexdigest()
            inactive_buckets.setdefault((year_bucket, asset_class), []).append((stable_key, code, cached))

        selected: list[tuple[str, dict]] = []
        for bucket in sorted(inactive_buckets):
            rows = sorted(inactive_buckets[bucket], key=lambda row: (row[0], row[1]))
            selected.extend((code, cached) for _, code, cached in rows)
        hydrated = self.history_repository.load_history_for_codes([code for code, _ in selected])
        for code, cached in selected:
            history = hydrated.get(code) if isinstance(hydrated.get(code), dict) else {}
            item = {"code": code, **cached, **history, "catalog_active": False}
            dates, returns = item.get("dates") or [], item.get("returns") or []
            if len(returns) >= MIN_HISTORY_POINTS and len(dates) == len(returns):
                output[code] = item
        return list(output.values())


    @staticmethod
    def _classify_public_purchase_status(status_text: str, termination_date: str = "") -> str:
        return _parse_purchase_status(status_text, termination_date)

    @staticmethod
    def _public_status_note(status: str) -> str:
        return {
            "limited_purchasable": "公开基金状态：存在限额信息",
            "purchase_suspended": "公开基金状态：申购暂停或终止",
            "redemption_suspended": "公开基金状态：赎回受限",
            "closed": "公开基金状态：封闭、终止或清盘",
            "public_open": "公开基金状态：渠道显示开放",
            "unknown": "公开基金状态未知",
        }.get(status, "公开基金状态未知")

    @staticmethod
    def _apply_share_history_semantics(item: dict) -> dict:
        """Never present representative history as independent A/C/I share-class history."""
        rep_code = str(item.get("representative_history_code") or item.get("code") or "")
        code = str(item.get("code") or "")
        dates = list(item.get("dates") or [])
        returns = list(item.get("returns") or [])
        if len(dates) != len(returns):
            return item
        inherited = bool(rep_code and code and rep_code != code)
        item["share_specific_history"] = not inherited
        item["return_basis"] = "underlying_fund_history" if inherited else "share_class_history"
        item["return_basis_label"] = "底层基金历史（非该份额独立历史）" if inherited else "该份额公开历史"
        inception = str(item.get("inception_date") or "")[:DATE_TEXT_LENGTH]
        if inherited and re.fullmatch(r"\d{4}-\d{2}-\d{2}", inception) and dates:
            cut = bisect.bisect_left(dates, inception)
            if cut > 0 and cut < len(dates):
                item["dates"] = dates[cut:]
                item["returns"] = returns[cut:]
                item["share_history_truncated_at_inception"] = inception
        return item


    @staticmethod
    def _append_effective_history(item: dict, key: str, values: dict, effective_date: str) -> None:
        if not isinstance(values, dict) or not values or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(effective_date)[:DATE_TEXT_LENGTH]):
            return
        history_key = f"{key}_history"
        history = [row for row in (item.get(history_key) or []) if isinstance(row, dict)]
        day = str(effective_date)[:DATE_TEXT_LENGTH]
        payload = {"effective_date": day, key: dict(values)}
        history = [row for row in history if str(row.get("effective_date") or row.get("date") or "")[:DATE_TEXT_LENGTH] != day]
        history.append(payload); history.sort(key=lambda row: str(row.get("effective_date") or row.get("date") or "")[:DATE_TEXT_LENGTH])
        item[history_key] = history

    def _enrich_structural_metadata(self, active: list[dict], model: dict, progress=lambda *_: None) -> None:
        """Iteratively enrich challengers until the Top100 boundary is stable.

        Metadata can materially change fee/share-class and structural scores. A fixed
        pre-enrichment rank cutoff therefore creates a self-fulfilling ranking. Each pass
        refreshes every unresolved underlying whose conservative ranking-utility ceiling can
        still reach the current 100th-place boundary, then re-scores until that set is empty.
        """
        if not active or not hasattr(self.source, "metadata_many"):
            model["public_metadata_coverage"] = 0.0
            return

        lookup = {str(item.get("code") or ""): item for item in active if item.get("code")}
        checked_this_run: set[str] = set()
        groups: dict[str, list[dict]] = {}
        for item in active:
            groups.setdefault(_underlying_key(item), []).append(item)

        def item_metadata_complete(item: dict) -> bool:
            asset_class = _asset_bucket(item.get("name", ""), item.get("type", ""))
            complete = (
                bool(item.get("fund_company"))
                and (asset_class != "指数" or bool(item.get("index_code")))
                and bool(item.get("product_features"))
                and item.get("fees_verified") is True
            )
            return bool(complete and str(item.get("code") or "") in checked_this_run)

        def underlying_complete(key: str) -> bool:
            rows = groups.get(key) or []
            return bool(rows) and all(item_metadata_complete(item) for item in rows)

        def apply_metadata(metadata: dict) -> None:
            for code, values in (metadata or {}).items():
                item = lookup.get(str(code))
                if not item or not isinstance(values, dict):
                    continue
                checked_this_run.add(str(code))
                for field in (
                    "fund_company", "benchmark", "index_code", "theme", "inception_date",
                    "termination_date", "fund_manager", "product_features", "metadata_source", "metadata_checked_at",
                ):
                    if values.get(field):
                        item[field] = values[field]
                for field in (
                    "public_purchase_status", "public_purchase_status_secondary",
                    "availability_public_signals", "availability_public_confirmations",
                    "purchase_public_confirmations", "metadata_sources",
                ):
                    if field in values:
                        item[field] = values[field]
                for field in (
                    "fees", "fees_verified", "fees_source", "fee_schedule_complete",
                    "fee_field_verified", "annual_cost", "embedded_annual_cost",
                    "purchase_cost",
                ):
                    if field in values:
                        item[field] = values[field]
                effective_date = str(values.get("metadata_checked_at") or _now_iso())[:DATE_TEXT_LENGTH]
                features_now = dict(item.get("product_features") or {})
                try:
                    current_day = _dt.date.fromisoformat(effective_date)
                    target_years = _model_target_years(model)
                    cutoff = _years_before(current_day, target_years).isoformat()
                except ValueError:
                    current_day = _china_today()
                    cutoff = ""
                historical_feature_rows = [
                    row for row in (item.get("product_features_history") or []) if isinstance(row, dict)
                ]
                dated_rows = []
                for row in historical_feature_rows:
                    day = str(row.get("effective_date") or row.get("date") or "")[:DATE_TEXT_LENGTH]
                    vals = row.get("product_features") if isinstance(row.get("product_features"), dict) else {}
                    if cutoff and cutoff <= day < effective_date:
                        dated_rows.append((day, vals))
                earliest_known = min(
                    (str(row.get("effective_date") or row.get("date") or "")[:DATE_TEXT_LENGTH] for row in historical_feature_rows),
                    default="",
                )
                if cutoff and earliest_known and earliest_known <= _years_before(current_day, _model_target_years(model)).isoformat():
                    manager_sequence = [str(vals.get("manager_name") or "").strip() for _, vals in sorted(dated_rows)]
                    manager_sequence.append(str(features_now.get("manager_name") or "").strip())
                    manager_sequence = [name for name in manager_sequence if name]
                    if len(manager_sequence) >= 2:
                        features_now["manager_changes_target"] = float(
                            sum(a != b for a, b in zip(manager_sequence, manager_sequence[1:]))
                        )
                    style_sequence = [str(vals.get("style_label") or "").strip() for _, vals in sorted(dated_rows)]
                    style_sequence.append(str(features_now.get("style_label") or "").strip())
                    style_sequence = [label for label in style_sequence if label]
                    if len(style_sequence) >= 2:
                        changes = sum(a != b for a, b in zip(style_sequence, style_sequence[1:]))
                        features_now["style_drift"] = changes / max(1, len(style_sequence) - 1)
                item["product_features"] = features_now
                self._append_effective_history(item, "product_features", features_now, effective_date)
                if item.get("fees_verified") is True:
                    self._append_effective_history(item, "fees", item.get("fees") or {}, effective_date)
                status_text = " ".join(filter(None, (
                    str(item.get("public_purchase_status") or ""),
                    str(item.get("public_purchase_status_secondary") or ""),
                )))
                if item.get("availability_status") != "closed":
                    classified = self._classify_public_purchase_status(
                        status_text, str(item.get("termination_date") or "")
                    )
                    item["availability_status"] = classified
                    signals = _public_availability_signals(item)
                    item["availability_public_signals"] = sorted(signals)
                    item["availability_public_confirmations"] = int(_finite(item.get("purchase_public_confirmations"), 0))
                    item["availability_note"] = self._public_status_note(classified)
                    self._apply_share_history_semantics(item)

        attempted_underlyings: set[str] = set()
        considered_underlyings: set[str] = set()
        previous_top: tuple[str, ...] = ()
        rounds = 0
        boundary_stable = False

        while not _cancel_requested():
            scored = self.ranker.score(active, model, {}, holding_years=_model_target_years(model))
            ranked = _select_top_policy(scored, max(DISPLAY_TOP_N, len(scored)))
            top = ranked[:DISPLAY_TOP_N]
            if len(top) < DISPLAY_TOP_N:
                break
            previous_top = tuple(_underlying_key(item) for item in top)
            boundary = _finite(top[-1].get("final_ranking_utility"), -sys.float_info.max)

            qualifying = []
            for key, rows in groups.items():
                ceiling = max((self._ranking_utility_ceiling(row) for row in rows), default=-sys.float_info.max)
                if key in previous_top or ceiling >= boundary:
                    qualifying.append(key)

            target_keys = [
                key for key in qualifying
                if not underlying_complete(key) and key not in attempted_underlyings
            ]
            if not target_keys:
                unresolved = [key for key in qualifying if not underlying_complete(key)]
                boundary_stable = not unresolved and all(underlying_complete(key) for key in previous_top)
                break

            attempted_underlyings.update(target_keys)
            considered_underlyings.update(target_keys)
            pending = [
                item
                for key in target_keys
                for item in (groups.get(key) or [])
                if not item_metadata_complete(item)
            ]
            if not pending:
                continue

            rounds += 1
            progress(
                f"边界补全：本轮 {len(target_keys)} 个底层 / {len(pending)} 个份额",
                PERCENT_SCALE * len(considered_underlyings) / max(1, len(groups)),
            )
            metadata = self.source.metadata_many(pending)
            apply_metadata(metadata if isinstance(metadata, dict) else {})

        # Re-apply status semantics to every underlying touched in this run, including
        # fresh cached metadata that required no HTTP call.
        considered = []
        for key in considered_underlyings | set((previous_top or ())):
            considered.extend(groups.get(key) or [])
        for item in considered:
            status_text = " ".join(filter(None, (
                str(item.get("public_purchase_status") or ""),
                str(item.get("public_purchase_status_secondary") or ""),
            )))
            if item.get("availability_status") != "closed":
                classified = self._classify_public_purchase_status(
                    status_text, str(item.get("termination_date") or "")
                )
                item["availability_status"] = classified
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
                item["availability_public_confirmations"] = int(_finite(item.get("purchase_public_confirmations"), 0))
                item["availability_note"] = self._public_status_note(classified)
                self._apply_share_history_semantics(item)

        complete = sum(item_metadata_complete(item) for item in considered)
        model["public_metadata_coverage"] = complete / max(1, len(considered))
        model["metadata_enriched_candidates"] = len(considered)
        model["metadata_enriched_underlyings"] = len(considered_underlyings)
        model["metadata_boundary_rounds"] = rounds
        model["metadata_boundary_stable"] = bool(boundary_stable)


    @staticmethod
    def _observe_catalog_history(cached: dict, active: bool, observed: str) -> list[dict]:
        history = [dict(row) for row in (cached.get("catalog_history") or []) if isinstance(row, dict)]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            return history
        if history and history[-1].get("active") is active and not history[-1].get("to"):
            history[-1]["last_observed"] = observed
            return history
        if history and not history[-1].get("to"):
            try:
                history[-1]["to"] = (_dt.date.fromisoformat(observed) - _dt.timedelta(days=1)).isoformat()
            except ValueError:
                history[-1]["to"] = observed
        history.append({"from": observed, "to": "", "last_observed": observed, "active": bool(active)})
        return history

    def _persist_current(self) -> None:
        archive = dict(self.history_repository.archive())
        observed_dates = [
            str(item.get("availability_generated_at") or item.get("metadata_checked_at") or "")[:DATE_TEXT_LENGTH]
            for item in self.funds
        ]
        observed_dates = [
            value
            for value in observed_dates
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value)
        ]
        observed = max(observed_dates, default=_china_today().isoformat())
        for code, cached in list(archive.items()):
            if not isinstance(cached, dict):
                continue
            if self._candidate_pool_complete:
                cached["ranking_candidate"] = False
            # Preserve unseen ranking_candidate flags during lazy foreground operation: absence
            # from self.funds then means "not hydrated", not "no longer a market candidate".
            # Preserve training_representative for metadata-only archive rows. Lazy startup no
            # longer hydrates the complete training universe, so absence from self.market_funds
            # is not evidence that a historical representative should be forgotten.

        for item in self.market_funds or []:
            cached = (
                archive.get(item["code"])
                if isinstance(archive.get(item["code"]), dict)
                else {}
            )
            merged = dict(item)
            merged["catalog_history"] = self._observe_catalog_history(cached, item.get("catalog_active") is not False, observed)
            merged["training_representative"] = True
            merged["ranking_candidate"] = False
            merged["availability_history"] = self._merge_observed_availability(
                merged, cached
            )
            archive[item["code"]] = self._cache_item(merged)

        for item in self.funds:
            cached = (
                archive.get(item["code"])
                if isinstance(archive.get(item["code"]), dict)
                else {}
            )
            merged = dict(item)
            merged["catalog_history"] = self._observe_catalog_history(cached, item.get("catalog_active") is not False, observed)
            merged["ranking_candidate"] = True
            merged["training_representative"] = bool(
                cached.get("training_representative")
            )
            merged["availability_history"] = self._merge_observed_availability(
                merged, cached
            )
            archive[item["code"]] = self._cache_item(merged)

        master = dict(self.store.cache.get("fund_master", {}))
        for code, item in archive.items():
            if not isinstance(item, dict):
                continue
            previous = master.get(code) if isinstance(master.get(code), dict) else {}
            master[code] = {
                "code": code,
                "name": item.get("name"),
                "type": item.get("type"),
                "underlying_fund_id": (
                    item.get("underlying_fund_id")
                    or _underlying_key({"code": code, **item})
                ),
                "inception_date": (
                    item.get("inception_date")
                    or ((item.get("dates") or [""])[0])
                ),
                "termination_date": item.get("termination_date") or "",
                "merged_into": item.get("merged_into") or "",
                "catalog_first_seen": (
                    previous.get("catalog_first_seen")
                    or item.get("catalog_first_seen")
                    or _china_today().isoformat()
                ),
                "catalog_last_seen": (
                    item.get("catalog_last_seen")
                    or previous.get("catalog_last_seen")
                    or ""
                ),
                "catalog_active": item.get("catalog_active") is True,
            }

        self.store.cache = {
            "schema_fingerprint": CACHE_SCHEMA_FINGERPRINT,
            "updated_at": _now_iso(),
            "last_full_nav_refresh_at": self.store.cache.get("last_full_nav_refresh_at"),
            "funds": archive,
            "fund_master": master,
        }
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        self.history_repository.save_cache()


    @staticmethod
    def _quick_start_representatives(representatives: list[dict], limit: int | None = None) -> list[dict]:
        """Performance-blind deterministic stratified sample for the visible Top100."""
        if limit is None:
            limit = min(len(representatives), max(1, DISPLAY_TOP_N))
        limit = max(1, min(len(representatives), int(limit)))
        if len(representatives) <= limit:
            return list(representatives)
        buckets = {}
        for item in representatives:
            buckets.setdefault(str(item.get("asset_class") or "其他"), []).append(item)
        for rows in buckets.values():
            rows.sort(key=lambda item: hashlib.sha256(str(item.get("code") or "").encode("utf-8")).hexdigest())
        labels = sorted(buckets)
        chosen = []
        cursor = 0
        while len(chosen) < limit and labels:
            label = labels[cursor % len(labels)]
            rows = buckets[label]
            if rows:
                chosen.append(rows.pop(0))
            if not rows:
                labels.remove(label)
                cursor = 0
            else:
                cursor += 1
        return chosen

    def _prepare_history_scan_state(self, representatives: list[dict], existing: dict[str, dict]) -> dict:
        current_codes = {str(item.get("code") or "") for item in representatives if str(item.get("code") or "")}
        # Checkpoint compatibility is tied to the history/model schema, not to an exact
        # whole-market code list. Catalog additions/removals therefore preserve completed work.
        scan_id = hashlib.sha256(str(MODEL_SCHEMA_FINGERPRINT).encode("utf-8")).hexdigest()
        stored = self.store.load_history_rebuild_checkpoint()
        compatible = bool(
            isinstance(stored, dict)
            and stored.get("model_fingerprint") == MODEL_SCHEMA_FINGERPRINT
        )
        requested_resume = {
            str(code) for code in ((stored.get("completed_codes") or []) if compatible else [])
            if str(code) in current_codes and str(code) in existing
        }
        if stored and not compatible:
            self.store.save_history_rebuild_checkpoint(None)

        results: list[dict] = []
        historical_results: list[dict] = []
        resume_codes: set[str] = set()
        completed_codes: set[str] = set()
        for code in sorted(requested_resume):
            cached = existing.get(code)
            if not isinstance(cached, dict):
                continue
            dates = list(cached.get("dates") or [])
            returns = list(cached.get("returns") or [])
            if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                continue
            # Durable scan completion survives a restart even when the cached row now needs
            # an incremental freshness update. Fresh rows can be skipped; stale rows stay
            # pending but do not erase already completed work from the progress numerator.
            completed_codes.add(code)
            item = dict(cached)
            item.setdefault("code", code)
            item["training_representative"] = True
            if not self._history_recent_enough(item):
                continue
            historical_results.append(item)
            results.append(item)
            resume_codes.add(code)
        return {
            "scan_id": scan_id,
            "total": len(representatives),
            "results": results,
            "historical_results": historical_results,
            "failures": [],
            "dirty_codes": set(),
            "resume_codes": resume_codes,
            "completed_codes": completed_codes,
            "completed": len(completed_codes),
            "preview_feature_cache": {},
            "preview_source_count": 0,
            "preview_signature": (),
            "preview_emitted": False,
        }

    def _save_history_scan_checkpoint(self, state: dict, existing: dict[str, dict], stage: str) -> None:
        if _cancel_requested():
            return
        dirty_codes = state["dirty_codes"]
        if dirty_codes:
            codes = set(dirty_codes)
            latest_rows = {
                row["code"]: row for row in state["historical_results"]
                if row.get("code") in codes
            }
            cache_funds = dict(self.history_repository.archive())
            for code, row in latest_rows.items():
                merged = dict(cache_funds.get(code) or {})
                merged.update(row)
                merged["training_representative"] = True
                cache_funds[code] = self._cache_item(merged)
            self.store.cache["funds"] = cache_funds
            self.store.cache["schema_fingerprint"] = CACHE_SCHEMA_FINGERPRINT
            self.store.cache["updated_at"] = _now_iso()
            self.history_repository.save_cache(dirty_codes=codes)
            state["completed_codes"].update(latest_rows)
            dirty_codes.difference_update(codes)
        state["completed"] = len(state["completed_codes"])
        self.store.save_history_rebuild_checkpoint({
            "scan_id": state["scan_id"],
            "model_fingerprint": MODEL_SCHEMA_FINGERPRINT,
            "stage": stage,
            "completed_codes": sorted(state["completed_codes"]),
            "completed": state["completed"],
            "total": state["total"],
            "updated_at": _now_iso(),
        })

    def _load_history_candidate(
        self, candidate: dict, existing: dict[str, dict], cached_override=None,
        *, latest_row: dict | None = None, latest_checked: bool = False,
    ) -> dict:
        cached = cached_override if isinstance(cached_override, dict) else existing.get(candidate["code"])
        cached_usable = (
            isinstance(cached, dict)
            and len(cached.get("returns") or []) >= MIN_HISTORY_POINTS
            and len(cached.get("returns") or []) == len(cached.get("dates") or [])
        )
        if cached_usable:
            history = (
                self.source.update_history(
                    candidate["code"], cached, latest_row=latest_row, latest_checked=latest_checked,
                )
                if hasattr(self.source, "update_history")
                else {
                    "dates": cached["dates"], "returns": cached["returns"],
                    "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", ""),
                }
            )
        else:
            history = self.source.history(candidate["code"])
        item = {**candidate, **history, "updated_at": _now_iso()}
        item["inception_date"] = item.get("inception_date") or ((item.get("dates") or [""])[0])
        item["underlying_fund_id"] = item.get("underlying_fund_id") or _underlying_key(item)
        return item

    @staticmethod
    def _history_worker_status(workers: int) -> str:
        snapshot = _RESOURCE_CONTROLLER.snapshot()
        details = [f"并发{max(1, int(workers))}"]
        if "cpu_headroom" in snapshot:
            details.append(
                f"CPU空闲{_format_unrounded_number(snapshot.get('cpu_headroom'), '%', scale=PERCENT_SCALE)}"
            )
        if "ram_headroom" in snapshot:
            details.append(
                f"内存余量{_format_unrounded_number(snapshot.get('ram_headroom'), '%', scale=PERCENT_SCALE)}"
            )
        details.append("实时资源自动调节")
        return " · ".join(details)

    def _download_history_batch(
        self, batch: list[dict], state: dict, existing: dict[str, dict], progress, label: str,
        *, after_wave=None,
    ) -> None:
        if not batch:
            return
        pending = [candidate for candidate in batch if candidate.get("code") not in state["resume_codes"]]
        resumed = len(batch) - len(pending)
        batch_attempted = resumed
        phase_started = time.monotonic()
        state["completed"] = len(state["completed_codes"])
        if resumed:
            progress(
                f"{label} · 全市场 {state['completed']}/{state['total']} · 本阶段已续跑 {resumed}/{len(batch)} · 有效 {len(state['results'])}",
                PERCENT_SCALE * state["completed"] / max(1, state["total"]),
            )
        cursor = 0
        while cursor < len(pending):
            if _cancel_requested():
                self._save_history_scan_checkpoint(state, existing, label)
                raise concurrent.futures.CancelledError("程序正在退出")
            remaining_candidates = len(pending) - cursor
            workers = min(remaining_candidates, _adaptive_worker_count("history", remaining_candidates))
            wave = pending[cursor:cursor + workers]
            cursor += len(wave)
            results_before_wave = len(state["results"])
            wave_histories = self.history_repository.load_history_for_codes(
                [candidate.get("code") for candidate in wave]
            )
            wave_cached = {}
            for candidate in wave:
                code = str(candidate.get("code") or "")
                meta = existing.get(code) if isinstance(existing.get(code), dict) else {}
                history = wave_histories.get(code) if isinstance(wave_histories.get(code), dict) else {}
                wave_cached[code] = {**meta, **history}

            # Cached funds share one batch latest-NAV request per admitted wave. Full historical
            # downloads are therefore reserved for funds with no cache or an objective anomaly.
            cached_codes = [
                str(candidate.get("code") or "") for candidate in wave
                if len((wave_cached.get(str(candidate.get("code") or "")) or {}).get("returns") or []) >= MIN_HISTORY_POINTS
                and len((wave_cached.get(str(candidate.get("code") or "")) or {}).get("returns") or [])
                    == len((wave_cached.get(str(candidate.get("code") or "")) or {}).get("dates") or [])
            ]
            latest_rows = {}
            latest_checked_codes = set()
            if cached_codes and hasattr(self.source, "latest_many"):
                try:
                    latest_report = self.source.latest_many(cached_codes)
                    latest_rows = dict(latest_report.get("rows") or {})
                    latest_checked_codes = set(cached_codes)
                except Exception as exc:
                    _record_diagnostic("history-wave-latest", exc)
                    latest_checked_codes = set(cached_codes)

            with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="fund-data") as executor:
                future_map = {
                    executor.submit(
                        self._load_history_candidate, candidate, existing,
                        wave_cached.get(str(candidate.get("code") or "")),
                        latest_row=latest_rows.get(str(candidate.get("code") or "")),
                        latest_checked=str(candidate.get("code") or "") in latest_checked_codes,
                    ): candidate
                    for candidate in wave
                }
                for future in concurrent.futures.as_completed(future_map):
                    candidate = future_map[future]
                    batch_attempted += 1
                    try:
                        item = future.result()
                        if len(item.get("returns") or []) >= MIN_HISTORY_POINTS:
                            item = dict(item)
                            item["startup_cache_fresh"] = self._history_recent_enough(item)
                            state["historical_results"].append(item)
                            if item["startup_cache_fresh"]:
                                state["results"].append(item)
                            state["dirty_codes"].add(item["code"])
                            state["completed_codes"].add(item["code"])
                    except (DataError, OSError, TimeoutError, urllib.error.URLError) as exc:
                        state["failures"].append((candidate["code"], str(exc)))
                    state["completed"] = len(state["completed_codes"])
                    elapsed = max(time.get_clock_info("monotonic").resolution, time.monotonic() - phase_started)
                    newly_attempted = max(0, batch_attempted - resumed)
                    throughput = newly_attempted / elapsed
                    remaining_attempts = max(0, len(batch) - batch_attempted)
                    eta = remaining_attempts / throughput if throughput > 0 else float("inf")
                    eta_text = _human_seconds(eta) if math.isfinite(eta) else "计算中"
                    progress(
                        f"{label} · 全市场 {state['completed']}/{state['total']} · 本阶段已处理 {batch_attempted}/{len(batch)} · "
                        f"有效 {len(state['results'])} · {_format_unrounded_number(throughput)}只/秒 · "
                        f"本阶段预计还需 {eta_text} · {self._history_worker_status(workers)}",
                        PERCENT_SCALE * state["completed"] / max(1, state["total"]),
                    )
            # Persist after every admitted wave so restart progress comes from durable work.
            self._save_history_scan_checkpoint(state, existing, label)
            if after_wave is not None and len(state["results"]) > results_before_wave:
                after_wave()

    def _emit_history_preview(
        self, state: dict, preview_callback,
        preview_holding_years: int | None, preview_model: dict | None,
    ) -> bool:
        if preview_callback is None:
            return False
        source_count = len(state["results"])
        if not source_count or source_count == state.get("preview_source_count"):
            return bool(state.get("preview_emitted"))
        state["preview_source_count"] = source_count
        try:
            preview_pool = [dict(item) for item in state["results"]]
            model_for_preview = dict(preview_model or self.store.model or LocalStore.default_model())
            preview_scored = self.ranker.score(
                preview_pool, model_for_preview, state.get("preview_feature_cache"),
                holding_years=_expected_holding_years(preview_holding_years, model_for_preview),
                require_full_selection=False,
            )
            preview_rows = _select_top_policy(
                preview_scored, min(DISPLAY_TOP_N, len(preview_scored)),
            )
            if not preview_rows:
                return bool(state.get("preview_emitted"))
            signature = tuple(str(item.get("code") or "") for item in preview_rows)
            if signature == state.get("preview_signature"):
                return bool(state.get("preview_emitted"))
            state["preview_signature"] = signature
            state["preview_emitted"] = True
            for item in preview_rows:
                item["preliminary_history_preview"] = True
            preview_callback(RankingResult(
                preview_rows, "preview",
                {
                    "ok": False,
                    "reason": (
                        f"全市场历史扫描中预览 Top{len(preview_rows)}；"
                        f"已完成 {state['completed']}/{state['total']}，正式 OOS/新鲜度门控仍在进行"
                    ),
                },
            ))
            return True
        except (DataError, ModelError, ValueError) as exc:
            _record_diagnostic("history-preview", exc)
            return bool(state.get("preview_emitted"))

    def _refresh_history_pool(
        self, representatives: list[dict], existing: dict[str, dict], progress,
        *, preview_callback=None, preview_holding_years: int | None = None,
        preview_model: dict | None = None, early_training_callback=None,
    ):
        state = self._prepare_history_scan_state(representatives, existing)
        total = state["total"]
        if state["completed_codes"]:
            progress(
                f"恢复上次全市场扫描：已完成 {state['completed']}/{total} 个底层代表；"
                f"其中 {len(state['resume_codes'])} 个历史当前可直接复用，其余按最新市场会话增量更新",
                PERCENT_SCALE * state["completed"] / max(1, total),
            )
        self._save_history_scan_checkpoint(state, existing, "history-scan")

        quick_representatives = self._quick_start_representatives(representatives)
        quick_codes = {item["code"] for item in quick_representatives}
        remaining = [item for item in representatives if item["code"] not in quick_codes]

        def emit_preview_after_wave():
            self._emit_history_preview(
                state, preview_callback, preview_holding_years, preview_model,
            )

        # A resumed scan can show a non-formal list immediately, before any new network wave.
        emit_preview_after_wave()
        self._download_history_batch(
            quick_representatives, state, existing, progress, "阶段1/2 结构盲选历史",
            after_wave=emit_preview_after_wave,
        )

        if early_training_callback is not None:
            partial_training_pool = self._retained_training_pool(
                state["historical_results"] or state["results"], existing,
            )
            early_training_callback(partial_training_pool)

        preview_emitted = bool(state.get("preview_emitted"))
        progress(
            f"阶段1/2已完成；{'分析中预览已显示，' if preview_emitted else ''}继续扫描全市场底层代表 "
            f"{state['completed']}/{total}，完成后进入正式 OOS 门控",
            PERCENT_SCALE * state["completed"] / max(1, total),
        )
        self._download_history_batch(
            remaining, state, existing, progress, "阶段2/2 全量历史扫描",
            after_wave=emit_preview_after_wave,
        )
        self._save_history_scan_checkpoint(state, existing, "history-complete")

        required_active = min(DISPLAY_TOP_N, total)
        if len(state["results"]) < required_active:
            if self.load_cached(allow_stale=True):
                raise DataError("本次底层代表历史更新失败，已保留上次可用结果")
            raise DataError(f"有效历史数据仅 {len(state['results'])} 个底层代表，低于正式输出所需 {required_active} 个")
        _register_observed_fund_histories(state["historical_results"] or state["results"])
        training_pool = self._retained_training_pool(state["historical_results"] or state["results"], existing)
        return state["results"], state["historical_results"], training_pool, quick_representatives, state["failures"], state["scan_id"]


    def _decide_model_retrain(
        self, current_model: dict, training_pool: list[dict], feedback: dict | None = None, force: bool = False,
    ) -> tuple[bool, float, str]:
        trained_at = _parse_iso(current_model.get("trained_at"))
        old_codes = set(current_model.get("retrain_observed_universe_codes") or current_model.get("universe_codes") or [])
        new_codes = {item["code"] for item in training_pool if item.get("code")}
        change_ratio = len(old_codes ^ new_codes) / max(1, len(old_codes | new_codes)) if old_codes else 1.0
        feedback = dict(feedback or {})
        current_cohorts = set(_target_feedback_for_model(feedback, current_model).get("mature_cohort_ids") or [])
        seen_cohorts = set(current_model.get("feedback_cohorts_seen") or [])
        new_feedback_cohorts = sorted(current_cohorts - seen_cohorts)
        auto_update_model = _model_auto_update_enabled()
        force_reason = str(current_model.get("force_retrain_reason") or "")
        never_trained = trained_at is None
        shadow_at = _parse_iso(current_model.get("shadow_candidate_trained_at"))
        if shadow_at is not None and shadow_at.tzinfo is None:
            shadow_at = shadow_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        shadow_age_days = (
            float("inf") if shadow_at is None else
            max(0.0, (_dt.datetime.now().astimezone() - shadow_at).total_seconds() / SECONDS_PER_DAY)
        )
        shadow_recheck_due = bool(
            current_model.get("shadow_candidate_available") is True
            and shadow_age_days >= SHADOW_STRICT_PIT_RECHECK_DAYS
        )
        schema_changed = current_model.get("schema_fingerprint") != MODEL_SCHEMA_FINGERPRINT
        feedback_due = bool(auto_update_model and new_feedback_cohorts)
        universe_due = bool(
            auto_update_model and old_codes and old_codes != new_codes
            and self._training_universe_change_affects_boundary(current_model, training_pool, old_codes, new_codes)
        )
        should = bool(force or force_reason or never_trained or shadow_recheck_due or schema_changed or feedback_due or universe_due)
        reason = (
            "forced-rebuild" if force else force_reason
            or "never-trained" if never_trained else
            "strict-pit-maturity-recheck" if shadow_recheck_due else
            "schema-version" if schema_changed else
            "new-mature-feedback-cohort" if feedback_due else
            "top100-boundary-or-training-distribution-change" if universe_due else
            "not-due"
        )
        return should, change_ratio, reason

    def _build_candidate_universe(self, availability: dict[str, dict], existing: dict[str, dict]) -> list[dict]:
        if getattr(self, "last_availability_mode", "") == "public-market-inference":
            market_rows = [
                {"code": code, "name": row.get("name") or code, "type": row.get("type") or "其他"}
                for code, row in availability.items()
            ]
        else:
            market_rows = self.source.all_funds()
        market = {item["code"]: item for item in market_rows}
        for code, declared in availability.items():
            market.setdefault(code, {"code": code, "name": declared.get("name") or code, "type": declared.get("type") or "其他"})

        today_text = _china_today().isoformat()
        structural_fields = (
            "benchmark", "index_code", "fund_company", "fund_manager", "theme", "underlying_fund_id",
            "master_code", "primary_code", "inception_date", "termination_date", "merged_into",
            "metadata_source", "metadata_checked_at", "product_features", "product_features_history", "fees_history",
        )
        all_candidates = []
        for code, meta in market.items():
            declared = availability.get(code)
            cached = existing.get(code) if isinstance(existing.get(code), dict) else {}
            name = (declared or {}).get("name") or meta.get("name") or cached.get("name") or code
            fund_type = (declared or {}).get("type") or meta.get("type") or cached.get("type") or "其他"
            if not _candidate_allowed(name):
                continue
            cached_termination = str(cached.get("termination_date") or "")[:DATE_TEXT_LENGTH]
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", cached_termination) and cached_termination <= today_text:
                continue
            base = {**meta, **self._unknown_market_declaration(meta), "code": code, "name": name, "type": fund_type}
            for field in structural_fields:
                if cached.get(field):
                    base[field] = cached[field]
            if declared:
                base.update(self._availability_fields(declared))
                base["name"], base["type"] = name, fund_type
                base["availability_history"] = self._merge_observed_availability(declared, cached)
            else:
                base["availability_history"] = self._normalized_spans(cached.get("availability_history"))
            base["catalog_active"] = True
            base["catalog_first_seen"] = cached.get("catalog_first_seen") or today_text
            base["catalog_last_seen"] = today_text
            base["asset_class"] = _asset_bucket(name, fund_type)
            base["wrapper"] = _wrapper_type(fund_type)
            all_candidates.append(base)
        if len(all_candidates) < CATALOG_CACHE_MIN_ROWS:
            raise DataError(f"公开全市场中符合结构条件的具体份额仅 {len(all_candidates)} 个，样本不足")
        return all_candidates

    def _persist_results(self, model: dict, training_pool: list[dict], active_results: list[dict]) -> None:
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        with self.lock:
            self.market_funds = training_pool
            self.funds = active_results
            self._candidate_pool_complete = True
            self.feature_cache.clear()
            # Staging only: candidate/history state may be checkpointed, but the model file
            # is not promoted until a verified Top100 is committed.
            self.store.model = dict(model)
            self._persist_current()

    def _shrink_to_ranked_working_set(self, holding_years: int) -> int:
        """Release full-market histories after a rebuild while retaining exactly the data-driven boundary band."""
        years = _expected_holding_years(holding_years, self.store.model)
        with self.lock:
            pool = [
                item for item in self.funds
                if isinstance(item, dict)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ]
            scored = self.ranker.score(
                pool, self.store.model, self.feature_cache, holding_years=years
            ) if pool else []
            ranked = self._boundary_ranked_band(scored) if scored else []
            if len(ranked) >= DISPLAY_TOP_N:
                self.funds = [dict(item) for item in ranked]
                selected_codes = {str(item.get("code") or "") for item in self.funds}
                self.market_funds = [
                    dict(item) for item in (self.market_funds or [])
                    if str(item.get("code") or "") in selected_codes
                ]
                self._candidate_pool_complete = False
                self.feature_cache.clear()
                gc.collect()
                return len(self.funds)
        return len(self.funds)

    def retrain_model_from_current_history(self, progress=lambda *_: None, reason: str = "advanced-ai-became-ready") -> dict:
        """Retrain only the model from the already-loaded history; no network refresh and no user action."""
        # Background training hydrates the complete retained training set on demand from SQLite
        # instead of depending on whatever bounded foreground histories happen to be resident.
        archive = self.history_repository.archive()
        training_codes = [
            code for code, item in archive.items()
            if isinstance(item, dict) and item.get("training_representative") is True
            and int(_finite(item.get("_nav_series_count"), 0)) >= MIN_HISTORY_POINTS
        ]
        histories = self.history_repository.load_history_for_codes(training_codes)
        representative_pool = []
        for code in training_codes:
            item = archive.get(code) if isinstance(archive.get(code), dict) else {}
            history = histories.get(code) if isinstance(histories.get(code), dict) else {}
            merged = {"code": code, **item, **history}
            if len(merged.get("returns") or []) >= MIN_HISTORY_POINTS and len(merged.get("returns") or []) == len(merged.get("dates") or []):
                representative_pool.append(merged)
        if len(representative_pool) < CATALOG_CACHE_MIN_ROWS:
            with self.lock:
                representative_pool = [
                    dict(item) for item in (self.market_funds or [])
                    if isinstance(item, dict)
                    and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                    and len(item.get("returns") or []) == len(item.get("dates") or [])
                ]
        if len(representative_pool) < CATALOG_CACHE_MIN_ROWS:
            raise DataError(f"本地成熟历史仅 {len(representative_pool)} 个底层训练样本，暂不足以执行高级 AI 自动补训")
        training_pool = self._expand_archived_training_share_classes(representative_pool, archive)
        phases = ("feedback", "train", "commit")
        progress("使用本轮已缓存历史后台训练 AI，不重复下载净值", _phase_progress_value(phases, "feedback"))
        old_model = self.store.model
        realized_outcomes = self.store.update_prediction_outcomes(training_pool)
        feedback = self.store.prediction_feedback_summary()
        progress(
            f"已回填 {realized_outcomes} 条历史预测结果；当前目标成熟反馈样本 {int(_finite(_target_feedback_for_model(feedback, old_model).get('samples'), 0))} 条",
            _phase_progress_value(phases, "train"),
        )
        production_baseline = (
            dict(old_model) if isinstance(old_model, dict)
            and old_model.get("feature_names") == self.ranker.FEATURE_NAMES
            and old_model.get("trained_at") else {}
        )
        model = self.model_trainer.train(
            training_pool, feedback=feedback,
            progress=_nested_progress(progress, phases, "train"),
            release_input_after_payload=True, production_baseline=production_baseline,
        )
        if model.get("survivor_conditioned") is True and model.get("shadow_model") is True:
            retained = self._retain_shadow_candidate(old_model, model)
            retained["prediction_feedback_latest_observation"] = feedback
            retained["automatic_retrain_reason"] = reason
            retained["advanced_dependency_retrain_at"] = _now_iso()
            progress("shadow challenger 已更新；严格 PIT 未成熟，因此不替换正式 production", PERCENT_SCALE)
            return retained
        if production_baseline and model.get("production_replacement_passed") is not True:
            retained = dict(old_model)
            gate = dict(model.get("deployment_gate") or {})
            rejection_reason = str(gate.get("reason") or "candidate lacked sufficient independent evidence")
            retained["prediction_feedback_latest_observation"] = feedback
            retained["last_rejected_candidate_at"] = _now_iso()
            retained["last_rejected_candidate_reason"] = rejection_reason
            retained["champion_challenger_audit"] = {
                "compared_at": _now_iso(), "replaced": False, "reason": rejection_reason,
                "champion_trained_at": str(old_model.get("trained_at") or ""),
                "champion_same_window_oos": dict(gate.get("production_oos") or {}),
                "challenger_trained_at": str(model.get("trained_at") or ""),
                "challenger_same_window_oos": dict(gate.get("candidate_oos") or {}),
                "robust_baseline_same_window_oos": dict(gate.get("baseline_oos") or {}),
                "production_window_evidence": dict(gate.get("production_window_evidence") or {}),
            }
            retained["background_retrain_pending"] = False
            progress("新模型未证明优于当前生产模型；继续保留 last-known-good 生产模型", _phase_progress_value(phases, "commit"))
            with self.lock:
                self.store.model = retained
                self.feature_cache.clear()
            return retained
        if production_baseline:
            gate = dict(model.get("deployment_gate") or {})
            model["champion_challenger_audit"] = {
                "compared_at": _now_iso(), "replaced": True, "reason": str(gate.get("reason") or "promotion gate passed"),
                "previous_champion_trained_at": str(old_model.get("trained_at") or ""),
                "previous_champion_same_window_oos": dict(gate.get("production_oos") or {}),
                "challenger_trained_at": str(model.get("trained_at") or ""),
                "challenger_same_window_oos": dict(gate.get("candidate_oos") or {}),
                "robust_baseline_same_window_oos": dict(gate.get("baseline_oos") or {}),
                "production_window_evidence": dict(gate.get("production_window_evidence") or {}),
            }
        for key in ("full_market_scanned_shares", "representative_history_downloads", "quick_start_representatives", "retained_inactive_funds", "survivorship_bias", "survivorship_mitigation", "survivorship_note"):
            if key in old_model and key not in model:
                model[key] = old_model[key]
        model["auto_update_model"] = _model_auto_update_enabled()
        model["automatic_retrain_reason"] = reason
        model["advanced_dependency_retrain_at"] = _now_iso()
        model.pop("force_retrain_reason", None)
        model.pop("background_retrain_pending", None)
        progress("提交后台训练模型到待验证状态", _phase_progress_value(phases, "commit"))
        with self.lock:
            self.store.model = dict(model)
            self.feature_cache.clear()
        progress("AI 后台训练完成；新模型已进入待验证状态", PERCENT_SCALE)
        return model

    def _rebuild_representatives(self, availability: dict, existing: dict, progress):
        all_candidates = self._build_candidate_universe(availability, existing)
        groups = {}
        for item in all_candidates:
            group_key = (_base_name(item.get("name", "")).casefold(), item["asset_class"], item["wrapper"])
            groups.setdefault(group_key, []).append(item)
        representatives, shares_by_group, group_key_by_rep = [], {}, {}
        for group_key, shares in groups.items():
            def rep_preference(item):
                cached = existing.get(item["code"]) if isinstance(existing.get(item["code"]), dict) else {}
                usable_cache = bool(
                    int(_finite(cached.get("_nav_series_count"), 0)) >= MIN_HISTORY_POINTS
                    or (len(cached.get("returns") or []) >= MIN_HISTORY_POINTS and len(cached.get("returns") or []) == len(cached.get("dates") or []))
                )
                return (0 if usable_cache else 1, -_share_preference(item.get("name", "")), item["code"])
            representative = min(shares, key=rep_preference)
            representatives.append(representative)
            shares_by_group[group_key] = shares
            group_key_by_rep[representative["code"]] = group_key
        representatives.sort(key=lambda item: item["code"])
        progress(
            f"结构阶段 {len(all_candidates)} 个具体份额已聚合为 {len(representatives)} 个底层代表；开始历史增量",
            PERCENT_SCALE,
        )
        return all_candidates, representatives, shares_by_group, group_key_by_rep

    def _rebuild_model_decision(
        self, availability: dict, all_candidates: list[dict], representatives: list[dict],
        quick_representatives: list[dict], training_pool: list[dict], force: bool, progress,
        early_model: dict | None = None,
    ):
        retained_inactive = len({
            _underlying_key(item) for item in training_pool if item.get("catalog_active") is False
        })
        current_model = self.store.model
        previous_model = dict(current_model)
        realized_outcomes = self.store.update_prediction_outcomes(training_pool)
        feedback = self.store.prediction_feedback_summary()
        current_target_feedback = _target_feedback_for_model(feedback, current_model)
        feedback_failed = bool(
            str(current_target_feedback.get("status") or "") == "mature-feedback"
            and (
                _finite(current_target_feedback.get("rank_ic"), 0.0) < 0.0
                or _finite(current_target_feedback.get("display_excess"), 0.0) < 0.0
            )
        )
        decision_model = dict(current_model)
        if feedback_failed:
            decision_model["force_retrain_reason"] = "realized-prediction-feedback-guardrail"
        should_retrain, change_ratio, retrain_reason = self._decide_model_retrain(decision_model, training_pool, feedback=feedback, force=force)
        if should_retrain:
            current_valid = bool(
                isinstance(current_model, dict) and current_model.get("schema_fingerprint") == MODEL_SCHEMA_FINGERPRINT
                and current_model.get("feature_names") == self.ranker.FEATURE_NAMES
            )
            early_valid = bool(
                isinstance(early_model, dict)
                and early_model.get("schema_fingerprint") == MODEL_SCHEMA_FINGERPRINT
                and early_model.get("feature_names") == self.ranker.FEATURE_NAMES
                and early_model.get("trained_at")
                and early_model.get("survivor_conditioned") is not True
                and not str(early_model.get("model_status") or "").startswith("expert-fallback")
                and (
                    early_model.get("production_replacement_passed") is True
                    or (not current_model.get("trained_at") and str(early_model.get("baseline_mode") or "") != "expert")
                )
            )
            early_shadow_valid = bool(
                isinstance(early_model, dict)
                and early_model.get("schema_fingerprint") == MODEL_SCHEMA_FINGERPRINT
                and early_model.get("feature_names") == self.ranker.FEATURE_NAMES
                and early_model.get("trained_at")
                and early_model.get("survivor_conditioned") is True
                and early_model.get("shadow_model") is True
            )
            if early_valid:
                model = dict(early_model)
                model["background_retrain_pending"] = True
                model["force_retrain_reason"] = "full-market-post-preview-retrain"
                progress(
                    "并行训练的 OOS 模型已通过可用性检查；本轮正式买入候选使用该模型，全市场历史模型继续后台升级",
                    PERCENT_SCALE,
                )
            elif early_shadow_valid and current_model.get("strict_pit_production") is not True:
                # A survivor-conditioned model may be trained immediately, but it remains a challenger only.
                # The final formal gate below will never promote it as strict-PIT production evidence.
                model = dict(early_model)
                model["background_retrain_pending"] = False
                model["force_retrain_reason"] = ""
                progress("shadow 模型已完成训练；仅保存为候选，不用于正式买入结论", PERCENT_SCALE)
            else:
                model = dict(current_model) if current_valid and not feedback_failed else LocalStore.default_model()
                model["background_retrain_pending"] = True
                model["force_retrain_reason"] = retrain_reason
                progress("并行模型未形成可部署候选；保留当前生产模型并在正式结果后继续后台训练", PERCENT_SCALE)
        else:
            model = dict(current_model)
            progress(f"历史已增量刷新；没有新增成熟独立反馈 cohort，底层池变化 {_format_unrounded_number(change_ratio, '%', scale=PERCENT_SCALE)}，本轮不重训", PERCENT_SCALE)
        survivor_conditioned = model.get("survivor_conditioned") is True
        survivorship_note = str(model.get("survivorship_note") or "").strip() if survivor_conditioned else ""
        if not survivorship_note:
            survivorship_note = (
                f"已纳入 {retained_inactive} 个历史退出/非活动底层样本；历史成员资格未知的时间点不会进入训练或 OOS 验证；"
                "若公开基金目录未覆盖首次运行前已经彻底消失的基金，仍保留剩余存续偏差告警。"
            )
        model.update({
            "prediction_feedback_latest_observation": feedback,
            "prediction_outcomes_updated": realized_outcomes,
            "availability_codes": sorted(availability), "availability_snapshot_at": _now_iso(),
            "retrain_observed_universe_codes": sorted({str(item.get("code") or "") for item in training_pool if item.get("code")}),
            "training_asset_classes": sorted({str(item.get("asset_class") or _asset_bucket(item.get("name", ""), item.get("type", ""))) for item in training_pool if isinstance(item, dict)}),
            "availability_asset_classes": sorted({str(_asset_bucket((row or {}).get("name", ""), (row or {}).get("type", ""))) for row in availability.values()}),
            "full_market_scanned_shares": len(all_candidates), "representative_history_downloads": len(representatives),
            "quick_start_representatives": len(quick_representatives), "auto_update_model": _model_auto_update_enabled(),
            "retained_inactive_funds": retained_inactive,
            "survivorship_bias": survivor_conditioned or bool(_finite(model.get("historical_universe_known_coverage"), 0.0) < 1.0),
            "survivorship_mitigation": (
                "survivor-conditioned shadow until strict PIT history matures; persistent inactive archive retained"
                if survivor_conditioned else
                "known point-in-time universe membership only + stale histories + persistent inactive archive"
            ),
            "survivorship_note": survivorship_note,
        })
        return model, previous_model, should_retrain, retrain_reason

    def _expand_rebuild_shares(self, representative_results: list[dict], shares_by_group: dict, group_key_by_rep: dict, existing: dict) -> list[dict]:
        expanded = []
        # These histories/structural fields are needed by point-in-time share selection.  Current
        # availability_status deliberately comes from the fresh market row; historical availability
        # and catalog spans come from the durable cache and are never reconstructed from today's state.
        preserved_fields = (
            "fees", "fees_verified", "fees_source", "fee_schedule_complete", "fee_field_verified",
            "annual_cost", "embedded_annual_cost", "purchase_cost", "fund_company", "benchmark", "index_code",
            "theme", "product_features", "product_features_history", "fees_history", "fund_manager",
            "availability_history", "catalog_history", "inception_date", "termination_date", "merged_into",
            "catalog_first_seen", "catalog_last_seen", "catalog_active",
            "public_purchase_status", "public_purchase_status_secondary",
            "availability_public_signals", "availability_public_confirmations", "purchase_public_confirmations",
            "metadata_sources", "metadata_checked_at",
        )
        for representative in representative_results:
            group_key = group_key_by_rep.get(representative["code"])
            shares = shares_by_group.get(group_key, [representative])
            underlying_id = _underlying_key(representative)
            for share in shares:
                cached = existing.get(share["code"]) if isinstance(existing.get(share["code"]), dict) else {}
                item = {
                    **share, "dates": list(representative.get("dates") or []), "returns": list(representative.get("returns") or []),
                    "latest_nav": representative.get("latest_nav"), "latest_date": representative.get("latest_date"),
                    "updated_at": representative.get("updated_at"), "underlying_fund_id": underlying_id,
                    "representative_history_code": representative["code"],
                }
                for field in preserved_fields:
                    if field in cached:
                        item[field] = cached[field]
                self._apply_share_history_semantics(item)
                expanded.append(item)
        return expanded

    def _expand_training_share_classes(
        self, representative_pool: list[dict], shares_by_group: dict,
        group_key_by_rep: dict, existing: dict,
    ) -> list[dict]:
        """Expand representative histories into the PIT share-class universe used by OOS training.

        Histories remain downloaded once per underlying representative.  Sibling A/C/I rows borrow
        that retained history only for modelling, are truncated at their own inception date, and keep
        their own point-in-time fee/catalog/availability histories.  The first occurrence of a code
        wins so a fresh current representative expansion cannot be overwritten by an older cached row.
        """
        expanded = self._expand_rebuild_shares(
            representative_pool, shares_by_group, group_key_by_rep, existing
        )
        unique: dict[str, dict] = {}
        for item in expanded:
            code = str(item.get("code") or "")
            if code:
                unique.setdefault(code, item)
        return list(unique.values())

    def _expand_archived_training_share_classes(
        self, representative_pool: list[dict], archive: dict,
    ) -> list[dict]:
        """Recreate the same share-level training universe for background retraining, without redownloading NAV."""
        shares_by_group: dict[str, list[dict]] = {}
        group_key_by_rep: dict[str, str] = {}
        archived_siblings: dict[str, list[dict]] = {}
        for code, cached in (archive or {}).items():
            if not isinstance(cached, dict):
                continue
            history_code = str(cached.get("representative_history_code") or "")
            if history_code:
                archived_siblings.setdefault(history_code, []).append({"code": str(code), **cached})
        for representative in representative_pool:
            rep_code = str(representative.get("code") or "")
            if not rep_code:
                continue
            group_key_by_rep[rep_code] = rep_code
            siblings = list(archived_siblings.get(rep_code) or [])
            if not any(str(row.get("code") or "") == rep_code for row in siblings):
                siblings.insert(0, dict(representative))
            shares_by_group[rep_code] = siblings or [dict(representative)]

        expanded = self._expand_training_share_classes(
            representative_pool, shares_by_group, group_key_by_rep, archive
        )
        # Historical representatives that are no longer tied to a current share group remain valid
        # single-share samples; _expand_training_share_classes already preserves them.
        return expanded

    @staticmethod
    def _rebuild_active_candidates(expanded: list[dict], availability: dict) -> list[dict]:
        active = [item for item in expanded if item["code"] in set(availability)]
        if len({_underlying_key(item) for item in active}) < DISPLAY_TOP_N:
            active = [item for item in expanded if _candidate_allowed(str(item.get("name") or item.get("code") or ""))]
        if len({_underlying_key(item) for item in active}) < DISPLAY_TOP_N:
            raise DataError(f"最终候选区历史充分的底层基金不足 {DISPLAY_TOP_N} 个，无法输出 Top{DISPLAY_TOP_N}")
        return active

    def _retain_shadow_candidate(self, previous_model: dict, shadow_model: dict) -> dict:
        """Persist survivor-conditioned learning without changing the formal production scorer."""
        base = dict(previous_model) if (
            isinstance(previous_model, dict)
            and previous_model.get("schema_fingerprint") == MODEL_SCHEMA_FINGERPRINT
            and previous_model.get("feature_names") == self.ranker.FEATURE_NAMES
        ) else LocalStore.default_model()
        trained_at = str(shadow_model.get("trained_at") or _now_iso())
        base["shadow_candidate_available"] = True
        base["shadow_candidate_trained_at"] = trained_at
        base["shadow_candidate_model"] = dict(shadow_model)
        base["shadow_candidate_summary"] = {
            "model_status": str(shadow_model.get("model_status") or ""),
            "ai_enabled": shadow_model.get("ai_enabled") is True,
            "target_spec": dict(shadow_model.get("target_spec") or {}),
            "validation_ic": _finite(shadow_model.get("validation_ic"), 0.0),
            "historical_universe_mode": str(shadow_model.get("historical_universe_mode") or ""),
            "survivor_conditioned": True,
        }
        # On a first install there is no strict champion yet. Keep the production scorer as the
        # neutral expert baseline, but record that training really occurred so startup does not
        # retrain the same shadow candidate on every launch.
        if base.get("strict_pit_production") is not True:
            base["trained_at"] = trained_at
            base["model_status"] = "expert-fallback-strict-pit-pending-shadow-candidate-ready"
            base["baseline_mode"] = "expert"
            base["ai_enabled"] = False
            base["production_model_role"] = "expert-fallback-until-strict-pit"
            base["strict_pit_production"] = False
            base["survivor_conditioned"] = False
            base["shadow_model"] = False
            base["survivorship_bias"] = True
            base["survivorship_note"] = (
                "survivor-conditioned shadow 已训练并仅作为 challenger 保存；正式 production 仍要求严格 PIT 历史。"
            )
            base["target"] = f"strict PIT >= {MIN_LONG_TERM_HORIZON_YEARS}y production pending; shadow candidate trained"
        base.pop("force_retrain_reason", None)
        base.pop("background_retrain_pending", None)
        self.history_repository.save_model(base)
        self.store.model = dict(base)
        self.feature_cache.clear()
        return base

    def _finish_rebuild_gate(self, model: dict, previous_model: dict, training_pool: list[dict], active_results: list[dict], quick_holding_years: int | None, progress, should_retrain: bool, retrain_reason: str, history_scan_id: str, failures: list) -> dict:
        phases = ("metadata", "share_selection", "freshness", "commit")
        deployed_years = _model_target_years(model)
        self._enrich_structural_metadata(active_results, model, _nested_progress(progress, phases, "metadata"))
        progress("按完整费率选择 A/C/I 具体份额，并生成去重后的长期综合排名 Top 100", _phase_progress_value(phases, "share_selection"))
        self._persist_results(model, training_pool, active_results)
        if model.get("survivor_conditioned") is True:
            gate = {
                "ok": False,
                "candidate_only": True,
                "reason": "survivor-conditioned shadow 仅作为候选模型；未取得严格 PIT production 证据，不提交正式买入快照",
                "checked_at": _now_iso(),
            }
        else:
            gate = self._final_freshness_gate(
                deployed_years, _nested_progress(progress, phases, "freshness")
            )
        progress("提交正式快照", _phase_progress_value(phases, "commit"))
        background_retrain_required = False
        if gate.get("ok"):
            self._commit_verified_top100(self._last_verified_rows, deployed_years, gate, model=model, rollback_model=previous_model)
            checkpoint = self.store.load_history_rebuild_checkpoint()
            if checkpoint.get("scan_id") == history_scan_id:
                self.store.save_history_rebuild_checkpoint(None)
            background_retrain_required = bool(should_retrain)
            progress(
                "正式买入候选已可用；长期 AI 将使用本地历史后台训练，成功门控后再原子切换"
                if background_retrain_required else
                "正式买入候选已通过完整 OOS + 净值/历史数据强制门控；last-known-good 快照与 SQLite 已提交",
                PERCENT_SCALE,
            )
        else:
            if model.get("survivor_conditioned") is True:
                self._retain_shadow_candidate(previous_model, model)
                progress("shadow 候选已持久化；正式模型/正式快照保持严格 PIT 或基础筛选状态", PERCENT_SCALE)
            else:
                self.store.model = previous_model
                self.feature_cache.clear()
                progress("新鲜度门控未通过；正式快照与正式模型保持不变，仅保留 staging 数据", PERCENT_SCALE)
        self._last_full_nav_refresh_at = time.monotonic()
        self.store.cache["last_full_nav_refresh_at"] = _now_iso()
        self.history_repository.save_cache(dirty_codes=set())
        foreground_kept = self._shrink_to_ranked_working_set(deployed_years)
        basic_result = None
        if not gate.get("ok") and self.result_for_display(deployed_years) is None and self.store.model.get("strict_pit_production") is not True:
            basic_result = self.basic_screening_result(deployed_years, str(gate.get("reason") or ""))
        return {
            "background_retrain_required": background_retrain_required,
            "background_retrain_reason": retrain_reason if background_retrain_required else "",
            "basic_screening_result": basic_result,
            "history_failures": len(failures), "foreground_histories_kept": foreground_kept,
        }

    def rebuild(
        self, progress=lambda *_: None, force: bool = False,
        quick_holding_years: int | None = None, preview_callback=None,
    ) -> dict:
        if _storage_survival_mode_active():
            raise StorageError("磁盘空间保护模式已启用：停止全市场扩充/训练并保留 last-known-good")
        # Only work with an objective numerator/denominator is shown as a percentage here.
        # Catalog/model/final-gate phases are shown as indeterminate instead of pretending
        # that each control-flow phase consumes an equal share of total runtime.
        progress("读取公开基金目录并准备长期分析", None)
        availability = self._availability_snapshot()
        existing = self.store.cache.get("funds", {}) if isinstance(self.store.cache.get("funds", {}), dict) else {}
        indeterminate_progress = lambda text, _pct: progress(text, None)
        all_candidates, representatives, shares_by_group, group_key_by_rep = self._rebuild_representatives(
            availability, existing, indeterminate_progress
        )
        preview_model = dict(self.store.model or LocalStore.default_model())
        early_executor = None
        early_future = None
        early_model = None
        current_model = dict(self.store.model or {})
        early_training_needed = bool(
            force
            or not current_model.get("trained_at")
            or current_model.get("schema_fingerprint") != MODEL_SCHEMA_FINGERPRINT
            or current_model.get("force_retrain_reason")
        )

        def start_early_training(partial_training_pool):
            nonlocal early_executor, early_future
            if not early_training_needed or early_future is not None:
                return
            mature_pool = [
                dict(item) for item in (partial_training_pool or [])
                if isinstance(item, dict)
                and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(item.get("returns") or []) == len(item.get("dates") or [])
            ]
            if len(mature_pool) < CATALOG_CACHE_MIN_ROWS:
                return
            mature_share_pool = self._expand_training_share_classes(
                mature_pool, shares_by_group, group_key_by_rep, existing
            )
            production_baseline = (
                dict(current_model)
                if current_model.get("feature_names") == self.ranker.FEATURE_NAMES and current_model.get("trained_at")
                else {}
            )
            feedback_snapshot = self.store.prediction_feedback_summary()
            early_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="preview-model")
            early_future = early_executor.submit(
                self.model_trainer.train, mature_share_pool, feedback_snapshot,
                lambda *_args: None, production_baseline=production_baseline,
            )
            progress("阶段1历史已形成训练样本；轻量 OOS 模型与剩余全市场网络扫描并行训练", None)

        try:
            results, _historical_results, training_pool, quick_representatives, failures, history_scan_id = self._refresh_history_pool(
                representatives, existing, progress, preview_callback=preview_callback,
                preview_holding_years=quick_holding_years, preview_model=preview_model,
                early_training_callback=start_early_training,
            )
            if early_future is not None:
                progress("全市场历史扫描完成；正在汇合并行 OOS 模型结果", None)
                try:
                    early_model = early_future.result()
                except (ModelError, DataError, StorageError, OSError, TimeoutError) as exc:
                    # This speculative parallel model may fall back to the normal rebuild path for
                    # known operational failures.  Unknown programming errors must invalidate the
                    # rebuild instead of being misreported as a temporary model miss.
                    _record_diagnostic("early-parallel-model", exc)
                    early_model = None
            else:
                progress("全市场历史扫描完成；正在检查长期模型状态", None)
        finally:
            if early_executor is not None:
                early_executor.shutdown(wait=True, cancel_futures=False)

        training_share_pool = self._expand_training_share_classes(
            training_pool, shares_by_group, group_key_by_rep, existing
        )
        model, previous_model, should_retrain, retrain_reason = self._rebuild_model_decision(
            availability, all_candidates, representatives, quick_representatives, training_share_pool, force,
            indeterminate_progress, early_model=early_model,
        )
        expanded = self._expand_rebuild_shares(results, shares_by_group, group_key_by_rep, existing)
        active_results = self._rebuild_active_candidates(expanded, availability)
        progress("长期模型阶段完成；正在执行正式买入候选净值新鲜度与排名边界门控", None)
        return self._finish_rebuild_gate(
            model, previous_model, training_pool, active_results, quick_holding_years,
            indeterminate_progress, should_retrain, retrain_reason, history_scan_id, failures,
        )


    def rankings(
        self,
        *,
        cross_verify: bool = True,
        holding_years: int | None = None,
    ) -> list[dict]:
        with self.lock:
            scored = self.ranker.score(
                self.funds,
                self.store.model,
                self.feature_cache,
                holding_years=_expected_holding_years(holding_years, self.store.model),
            )
            chosen = _select_formal_buy_candidates(scored, DISPLAY_TOP_N)
            raw_rank = {item["code"]: index+1 for index,item in enumerate(scored)}
            for rank, item in enumerate(chosen, 1):
                item["ai_raw_rank"] = raw_rank.get(item["code"], rank)
                item["ranking_rank"] = rank
            chosen = _validate_formal_results(chosen)

        if (
            cross_verify
            and len(chosen) >= MODEL_SELECTION_SIZE
            and hasattr(getattr(self, "source", None), "cross_verify_top100")
        ):
            try:
                keys = [
                    (
                        item["code"],
                        str(
                            item.get("display_nav_date")
                            or item.get("latest_date")
                            or ""
                        ),
                    )
                    for item in chosen[:MODEL_SELECTION_SIZE]
                ]
                if all(key in self._cross_check_cache for key in keys):
                    for item, key in zip(chosen[:MODEL_SELECTION_SIZE], keys):
                        item.update(self._cross_check_cache[key])
                else:
                    self.source.cross_verify_top100(chosen[:MODEL_SELECTION_SIZE])
                    for item, key in zip(chosen[:MODEL_SELECTION_SIZE], keys):
                        self._cross_check_cache[key] = {
                            field: item.get(field)
                            for field in (
                                "independent_source_verified",
                                "metadata_cross_verified",
                                "independent_source",
                                "independent_source_nav",
                                "independent_source_note",
                            )
                        }
            except (NetworkError, ParseError, ContractError, DataError, OSError, TimeoutError, urllib.error.URLError, ValueError, TypeError) as exc:
                _record_diagnostic("ranking-cross-verify", exc)

        # Cross verification happens after scoring, so refresh the evidence line only
        # after the actual verification result is known.  This keeps every reason
        # aligned with the evidence currently shown to the user.
        for item in chosen:
            fee_text = "公开费率已核验" if item.get("fees_verified") else "公开费率信息尚未完整核验"
            cross_ok = (
                item.get("latest_cross_source_verified") is True
                or item.get("independent_source_verified") is True
            )
            evidence_text = (
                "最新净值已完成双源同日交叉确认"
                if cross_ok
                else "最新净值尚未形成双源同日确认"
            )
            trust_line = (
                f"数据可信度：{fee_text}；{evidence_text}；"
                "公开基金状态元数据不参与排名。"
            )
            reason_lines = [
                line for line in str(item.get("reason") or "").splitlines()
                if not line.startswith("数据可信度：")
            ]
            item["reason"] = "\n".join(reason_lines + [trust_line])
        return chosen


    @staticmethod
    def _apply_latest_display_rows(funds: list[dict], latest: dict[str, dict]) -> int:
        """Apply every successfully fetched fresh NAV to visible fields, independent of ranking gates."""
        changed = 0
        lookup = {item["code"]: item for item in funds}
        for code, row in (latest or {}).items():
            item = lookup.get(code)
            if not item:
                continue
            before = (
                item.get("display_nav"), item.get("display_nav_date"), item.get("day_change"),
                tuple(item.get("latest_sources") or []), item.get("name"),
            )
            new_date = str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH]
            new_nav = _finite(row.get("nav"), float("nan"))
            source_day = _finite(row.get("day_change"), float("nan"))
            if row.get("name"):
                item["name"] = row["name"]
            if row.get("latest_sources"):
                item["latest_sources"] = list(row.get("latest_sources") or [])
                item["latest_source_count"] = int(_finite(row.get("latest_source_count"), len(item["latest_sources"])))
                item["latest_public_confirmations"] = int(_finite(row.get("latest_public_confirmations"), 1))
                item["latest_cross_source_verified"] = row.get("latest_cross_source_verified") is True
                for field in (
                    "latest_cross_source_relative_diff", "latest_primary_date",
                    "latest_secondary_date", "latest_cross_source_note",
                ):
                    if field in row:
                        item[field] = row[field]
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
            if math.isfinite(new_nav) and new_nav > 0:
                item["display_nav"] = new_nav
                if row.get("nav_decimals") is not None:
                    item["display_nav_decimals"] = int(row.get("nav_decimals"))
            if new_date:
                item["display_nav_date"] = new_date
            if math.isfinite(source_day):
                item["day_change"] = source_day
            after = (
                item.get("display_nav"), item.get("display_nav_date"), item.get("day_change"),
                tuple(item.get("latest_sources") or []), item.get("name"),
            )
            changed += int(after != before)
        return changed

    @staticmethod
    def _apply_latest_history_rows(funds: list[dict], latest: dict[str, dict]) -> int:
        """Commit fresh rows to the historical return series only after the atomic ranking gate passes."""
        updated_series = 0
        lookup = {item["code"]: item for item in funds}
        for code, row in (latest or {}).items():
            item = lookup.get(code)
            if not item:
                continue
            old_date = str(item.get("latest_date") or ((item.get("dates") or [""])[-1]))
            old_nav = _finite(item.get("latest_nav"), float("nan"))
            new_date = str(row.get("nav_date") or "")[:DATE_TEXT_LENGTH]
            new_nav = _finite(row.get("nav"), float("nan"))
            source_day = _finite(row.get("day_change"), float("nan"))
            if new_date and new_date > old_date and math.isfinite(new_nav) and new_nav > 0 and math.isfinite(old_nav) and old_nav > 0:
                nav_return = new_nav / old_nav - 1.0
                source_return = source_day / PERCENT_SCALE if math.isfinite(source_day) else float("nan")
                agreed = math.isfinite(source_return) and abs(source_return - nav_return) <= RETURN_AGREEMENT_NUMERIC_TOLERANCE * max(1.0, abs(source_return))
                if agreed:
                    item.setdefault("dates", []).append(new_date)
                    item.setdefault("returns", []).append(max(-1.0 + sys.float_info.epsilon, nav_return))
                    item["latest_nav"] = new_nav
                    item["latest_date"] = new_date
                    if row.get("nav_decimals") is not None:
                        item["latest_nav_decimals"] = int(row.get("nav_decimals"))
                    item["return_pending_adjustment"] = False
                    item["updated_at"] = _now_iso()
                    updated_series += 1
                else:
                    item["return_pending_adjustment"] = True
            elif new_date == old_date and math.isfinite(new_nav) and new_nav > 0:
                item["latest_nav"] = new_nav
                if row.get("nav_decimals") is not None:
                    item["latest_nav_decimals"] = int(row.get("nav_decimals"))
        return updated_series

    def _resolve_pending_adjustments(self, funds: list[dict], max_workers: int | None = None) -> int:
        pending = [item for item in funds if item.get("return_pending_adjustment") is True]
        if not pending:
            return 0
        resolved = 0
        def resolve(item):
            cached = {"dates": list(item.get("dates") or []), "returns": list(item.get("returns") or []),
                      "latest_nav": item.get("latest_nav"), "latest_date": item.get("latest_date", "")}
            return self.source.update_history(item["code"], cached) if hasattr(self.source, "update_history") else self.source.history(item["code"])
        worker_cap = _adaptive_worker_count("network", len(pending)) if max_workers is None else min(max(1, int(max_workers)), len(pending))
        with concurrent.futures.ThreadPoolExecutor(max_workers=worker_cap, thread_name_prefix="corp-action") as pool:
            futures = {pool.submit(resolve, item): item for item in pending}
            for future in concurrent.futures.as_completed(futures):
                item = futures[future]
                try:
                    history = future.result()
                except (DataError, OSError, TimeoutError, ValueError, RuntimeError):
                    continue
                dates, returns = history.get("dates") or [], history.get("returns") or []
                if len(dates) == len(returns) and len(returns) >= MIN_HISTORY_POINTS and str(history.get("latest_date") or "") >= str(item.get("display_nav_date") or ""):
                    for key in ("dates","returns","latest_nav","latest_date","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations"):
                        if key in history:
                            item[key] = history[key]
                    item["return_pending_adjustment"] = False; item["updated_at"] = _now_iso(); resolved += 1
        return resolved

    @staticmethod
    def _availability_fields(declared: dict) -> dict:
        keys = (
            "availability_status","availability_note","fund_data_source","availability_generated_at",
            "availability_source","availability_source_id","availability_evidence",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete","fee_field_verified","annual_cost","embedded_annual_cost","purchase_cost",

            "available_from","available_to","availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status",
            "underlying_fund_id","master_code","primary_code","inception_date","termination_date","merged_into",
            "metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","display_nav_decimals","latest_nav_decimals","return_pending_adjustment","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
        )
        optional_structural = {
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status","underlying_fund_id","master_code","primary_code",
            "inception_date","termination_date","merged_into","metadata_source","metadata_checked_at","product_features","product_features_history","fees_history",
        }
        return {
            key: declared[key] for key in keys if key in declared
            and (key not in optional_structural or declared.get(key) not in (None, "", {}, []))
        }

    @staticmethod
    def _merge_catalog_snapshot(current: dict, incoming: dict) -> dict:
        """Merge catalog-level evidence without erasing previously verified detail metadata."""
        result = dict(current or {})
        catalog_fields = (
            "name", "type", "catalog_sources", "public_catalog_confirmations",
            "availability_generated_at", "availability_source", "availability_source_id",
            "availability_evidence", "availability_note", "fund_data_source",
            "catalog_first_seen", "catalog_last_seen",
        )
        for key in catalog_fields:
            value = (incoming or {}).get(key)
            if value not in (None, "", [], {}):
                result[key] = value
        return result

    @staticmethod
    def _catalog_removals_are_authoritative(
        old_codes: set[str], new_codes: set[str], snapshot_sources: set[str],
    ) -> tuple[bool, str]:
        """Allow shrink only when every configured public catalog participated in this snapshot."""
        missing_codes = set(old_codes) - set(new_codes)
        if not missing_codes:
            return True, ""
        required_sources = set(PUBLIC_DATA_SOURCE_FAMILIES)
        observed_sources = {str(value) for value in snapshot_sources if str(value)}
        missing_sources = sorted(required_sources - observed_sources)
        if not missing_sources:
            return True, ""
        observed_text = "、".join(sorted(observed_sources)) or "无"
        return False, (
            f"目录缩减待全公开源同轮确认：缺少 {'、'.join(missing_sources)}；"
            f"本轮已确认 {observed_text}，保留 {len(missing_codes)} 个旧候选"
        )

    @staticmethod
    def _metadata_response_is_usable(values: dict) -> bool:
        if not isinstance(values, dict):
            return False
        source_text = " ".join(str(values.get(key) or "") for key in (
            "metadata_source", "metadata_source_secondary", "metadata_sources"
        ))
        if "暂不可用" in source_text:
            return False
        stamp = values.get("metadata_checked_at") or values.get("metadata_checked_at_secondary")
        return bool(stamp and _parse_iso(stamp) is not None)

    def _apply_refresh_metadata(self, metadata: dict[str, dict]) -> set[str]:
        """Apply only meaningful detail metadata and return codes actually checked in this refresh."""
        checked: set[str] = set()
        with self.lock:
            lookup = {str(item.get("code") or ""): item for item in self.funds}
            for code, values in (metadata or {}).items():
                code = str(code or "")
                item = lookup.get(code)
                if not item or not self._metadata_response_is_usable(values):
                    continue
                checked.add(code)
                for field in (
                    "fund_company", "benchmark", "index_code", "theme", "inception_date",
                    "termination_date", "fund_manager", "metadata_source", "metadata_source_secondary",
                    "metadata_checked_at", "metadata_checked_at_secondary", "metadata_sources",
                ):
                    value = values.get(field)
                    if value not in (None, "", [], {}):
                        item[field] = value
                if values.get("metadata_checked_at"):
                    item["metadata_checked_at"] = values["metadata_checked_at"]
                elif values.get("metadata_checked_at_secondary"):
                    item["metadata_checked_at"] = values["metadata_checked_at_secondary"]

                # An incomplete fee response is not evidence that previously verified fees became invalid.
                if values.get("fees_verified") is True:
                    for field in (
                        "fees", "fees_verified", "fees_source", "fee_schedule_complete",
                        "fee_field_verified", "annual_cost", "embedded_annual_cost", "purchase_cost",
                    ):
                        if field in values:
                            item[field] = values[field]
                    effective_date = str(item.get("metadata_checked_at") or _now_iso())[:DATE_TEXT_LENGTH]
                    self._append_effective_history(item, "fees", item.get("fees") or {}, effective_date)

                incoming_features = values.get("product_features")
                if isinstance(incoming_features, dict) and incoming_features:
                    merged_features = dict(item.get("product_features") or {})
                    merged_features.update(incoming_features)
                    item["product_features"] = merged_features
                    effective_date = str(item.get("metadata_checked_at") or _now_iso())[:DATE_TEXT_LENGTH]
                    self._append_effective_history(item, "product_features", merged_features, effective_date)

                # Classify from this run's purchase-status evidence. A blank status after a real
                # fetch is "checked but unknown", not permission to reuse stale open evidence.
                current_status_text = str(
                    values.get("public_purchase_status")
                    or values.get("public_purchase_status_secondary")
                    or ""
                )
                item["public_purchase_status"] = current_status_text
                secondary_status = str(values.get("public_purchase_status_secondary") or "")
                item["public_purchase_status_secondary"] = secondary_status
                termination = str(values.get("termination_date") or item.get("termination_date") or "")
                combined_status_text = " ".join(filter(None, (current_status_text, secondary_status)))
                classified = self._classify_public_purchase_status(combined_status_text, termination)
                item["availability_status"] = classified
                item["availability_note"] = self._public_status_note(classified)
                item["availability_reviewed_at"] = str(item.get("metadata_checked_at") or _now_iso())
                item["availability_public_signals"] = list(values.get("availability_public_signals") or [])
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
                item["purchase_public_confirmations"] = int(_finite(values.get("purchase_public_confirmations"), 0))
                item["availability_public_confirmations"] = item["purchase_public_confirmations"]
                item["redemption_state"] = _redemption_state(
                    " ".join(filter(None, (current_status_text, secondary_status)))
                )
                self._apply_share_history_semantics(item)
        return checked

    def _sync_candidate_pool(
        self,
        availability: dict[str, dict],
    ) -> tuple[list[str], list[str], list[str], list[str]]:
        with self.lock:
            current = {item["code"]: item for item in self.funds}

        archive = self.history_repository.archive()
        current_codes = set(current)
        archive_candidate_codes = {
            str(code) for code, item in archive.items()
            if isinstance(item, dict) and item.get("ranking_candidate") is True
        }
        known_codes = current_codes if self._candidate_pool_complete else (archive_candidate_codes or current_codes)
        availability_codes = {
            str(code) for code, row in availability.items()
            if _valid_fund_code(code)
            and _candidate_allowed(str((row or {}).get("name") or code))
        }
        snapshot_sources = {
            str(source_name)
            for row in availability.values() if isinstance(row, dict)
            for source_name in (row.get("catalog_snapshot_sources") or [])
            if str(source_name)
        }
        removals_authoritative, removal_reason = self._catalog_removals_are_authoritative(
            known_codes, availability_codes, snapshot_sources
        )
        self.last_catalog_sync_degraded = not removals_authoritative
        self.last_catalog_sync_reason = removal_reason if not removals_authoritative else ""
        if not removals_authoritative:
            _record_diagnostic("catalog-sync-degraded", removal_reason, "CatalogSnapshotDegraded")

        removed_codes = []
        kept = []

        # Only mutate the bounded histories that are actually hydrated. When lazy startup is
        # active, unseen archive candidates remain authoritative in SQLite and are not mistaken
        # for newly discovered or removed funds merely because they are outside the foreground set.
        for code, item in current.items():
            if code not in availability_codes:
                if removals_authoritative:
                    removed_codes.append(code)
                else:
                    # A partial-source snapshot may contribute additions/updates, but absence is
                    # not deletion evidence. Keep the last-known-good candidate until all public
                    # catalog families participate in the same refresh observation.
                    kept.append(dict(item))
                continue
            declared = availability[code]
            updated = self._merge_catalog_snapshot(item, declared)
            updated["catalog_missing_observations"] = 0
            updated["catalog_active"] = True
            updated["availability_history"] = self._merge_observed_availability(declared, item)
            updated["name"] = declared.get("name") or updated.get("name") or code
            updated["type"] = declared.get("type") or updated.get("type") or "其他"
            if _candidate_allowed(updated["name"]):
                kept.append(updated)

        if removals_authoritative:
            # Lazy startup hydrates only a foreground subset, so authoritative removals must also
            # retire unseen persisted candidates. Otherwise they would stay ranking_candidate=True
            # in SQLite forever and the effective directory would still be monotonic-increasing.
            observed = _china_today().isoformat()
            for code in sorted(known_codes - availability_codes):
                cached = archive.get(code)
                if not isinstance(cached, dict):
                    continue
                cached["ranking_candidate"] = False
                cached["catalog_active"] = False
                cached["catalog_history"] = self._observe_catalog_history(cached, False, observed)
                if code not in removed_codes:
                    removed_codes.append(code)

        current_group_lookup = {}
        for item in kept:
            group_key = (
                _base_name(item.get("name", "")).casefold(),
                _asset_bucket(item.get("name", ""), item.get("type", "")),
                _wrapper_type(item.get("type", "")),
            )
            current_group_lookup.setdefault(group_key, item)

        genuinely_new_codes = sorted(availability_codes - known_codes)
        cached_new_histories = self.history_repository.load_history_for_codes([
            code for code in genuinely_new_codes
            if isinstance(archive.get(code), dict)
            and int(_finite((archive.get(code) or {}).get("_nav_series_count"), 0)) >= MIN_HISTORY_POINTS
        ])
        added_items = []
        failed_new: list[str] = []
        deferred_codes: list[str] = []
        for code in genuinely_new_codes:
            declared = availability[code]
            try:
                cached = archive.get(code) if isinstance(archive.get(code), dict) else None
                name = declared.get("name") or (cached or {}).get("name") or code
                fund_type = declared.get("type") or (cached or {}).get("type") or "其他"
                if not _candidate_allowed(name):
                    continue

                candidate = None
                history = cached_new_histories.get(code) if isinstance(cached_new_histories.get(code), dict) else {}
                if cached and history:
                    hydrated = {"code": code, **cached, **history}
                    dates, returns = hydrated.get("dates") or [], hydrated.get("returns") or []
                    if (
                        len(returns) >= MIN_HISTORY_POINTS
                        and len(dates) == len(returns)
                        and self._history_recent_enough(hydrated)
                    ):
                        candidate = self._merge_catalog_snapshot(hydrated, declared)

                if candidate is None:
                    group_key = (
                        _base_name(name).casefold(),
                        _asset_bucket(name, fund_type),
                        _wrapper_type(fund_type),
                    )
                    representative = current_group_lookup.get(group_key)
                    if representative is not None:
                        candidate = self._merge_catalog_snapshot({
                            "code": code,
                            "name": name,
                            "type": fund_type,
                            "dates": list(representative.get("dates") or []),
                            "returns": list(representative.get("returns") or []),
                            "latest_nav": representative.get("latest_nav"),
                            "latest_date": representative.get("latest_date"),
                            "updated_at": representative.get("updated_at"),
                            "underlying_fund_id": _underlying_key(representative),
                            "representative_history_code": representative.get(
                                "representative_history_code", representative.get("code")
                            ),
                        }, declared)

                if candidate is None:
                    deferred_codes.append(code)
                    continue

                candidate = self._merge_catalog_snapshot(candidate, declared)
                candidate["catalog_missing_observations"] = 0
                candidate["catalog_active"] = True
                self._apply_share_history_semantics(candidate)
                candidate["availability_history"] = self._merge_observed_availability(
                    declared, cached if isinstance(cached, dict) else None
                )
                candidate["name"] = name
                candidate["type"] = fund_type
                added_items.append(candidate)
            except (DataError, NetworkError, ParseError, ContractError, StorageError, OSError, ValueError, TypeError) as exc:
                failed_new.append(code)
                _record_diagnostic("candidate-sync-new", exc, type(exc).__name__)

        with self.lock:
            self.funds = kept + added_items
            for code in removed_codes:
                self.feature_cache.pop(code, None)
            for item in added_items:
                self.feature_cache.pop(item["code"], None)

        return (
            [item["code"] for item in added_items],
            sorted(removed_codes),
            deferred_codes,
            failed_new,
        )


    def _candidate_nav_universe(self) -> tuple[list[str], dict[str, str]]:
        """Return the complete persisted ranking-candidate code set plus currently hydrated additions."""
        archive = self.history_repository.archive()
        with self.lock:
            current = {str(item.get("code") or ""): dict(item) for item in self.funds if item.get("code")}
        candidates: dict[str, dict] = {}
        for code, item in archive.items():
            code = str(code)
            if (
                isinstance(item, dict)
                and item.get("ranking_candidate") is True
                and _valid_fund_code(code)
                and _candidate_allowed(str(item.get("name") or code))
            ):
                candidates[code] = item
        for code, item in current.items():
            if (
                _valid_fund_code(code)
                and _candidate_allowed(str(item.get("name") or code))
            ):
                candidates[code] = item
        codes = sorted(candidates)
        return codes, {code: str(candidates[code].get("type") or "") for code in codes}

    def _classify_latest_rows(
        self, rows: dict[str, dict], fund_types: dict[str, str], today: _dt.date | None = None,
    ) -> tuple[dict[str, dict], list[str]]:
        today = today or _china_today()
        fresh = self.freshness_gate.filter_latest(rows, today, fund_types)
        stale = sorted(set(str(code) for code in (rows or {})) - set(fresh))
        return fresh, stale

    def _refresh_ranked_metadata_band(
        self, years: int, fresh_metadata_codes: set[str] | None = None,
        progress=lambda *_: None,
    ) -> tuple[list[dict], set[str]]:
        """Refresh ranked public metadata until the current Top100 is covered or a pass adds no evidence."""
        checked = set(fresh_metadata_codes or set())

        def ranked_band() -> list[dict]:
            with self.lock:
                scored = self.ranker.score(
                    self.funds, self.store.model, self.feature_cache, holding_years=years
                )
                return self._formal_boundary_ranked_band(scored)

        band = ranked_band()
        if not hasattr(self.source, "metadata_many") or not band:
            return band, checked

        pending = list(band)
        while pending:
            boundary_codes = {str(item.get("code") or "") for item in band if item.get("code")}
            covered = len(boundary_codes & checked)
            progress(
                f"复核理论仍可进入 Top{DISPLAY_TOP_N} 的基金详情 {covered}/{max(1, len(boundary_codes))}",
                PERCENT_SCALE * covered / max(1, len(boundary_codes)),
            )
            before = len(checked)
            metadata = self.source.metadata_many(pending)
            checked |= self._apply_refresh_metadata(metadata if isinstance(metadata, dict) else {})
            band = ranked_band()
            missing = [
                item for item in band
                if str(item.get("code") or "") not in checked
            ]
            if not missing or len(checked) == before:
                break
            pending = missing
        boundary_codes = {str(item.get("code") or "") for item in band if item.get("code")}
        progress(
            f"排名边界公开基金详情复核完成 {len(boundary_codes & checked)}/{max(1, len(boundary_codes))}",
            PERCENT_SCALE * len(boundary_codes & checked) / max(1, len(boundary_codes)),
        )
        return band, checked

    def _final_freshness_gate(self, holding_years: int | None = None, progress=lambda *_: None) -> dict:
        """Formal gate: require 100% fresh NAV only for formal candidates and every utility-boundary challenger."""
        phases = ("metadata", "latest", "commit", "features")
        years = _expected_holding_years(holding_years, self.store.model)
        self._last_verified_rows = []
        all_codes, fund_types = self._candidate_nav_universe()
        if len(all_codes) < DISPLAY_TOP_N:
            self.last_freshness_gate = {
                "ok": False,
                "reason": f"正式门控前全候选仅 {len(all_codes)} 只，不足建立 Top{DISPLAY_TOP_N} 排名边界",
                "checked_at": _now_iso(),
            }
            return dict(self.last_freshness_gate)

        calendar_state = self.freshness_gate.refresh_independent_market_state(_china_today(), force=True)
        if calendar_state.get("reliable") is not True:
            self.last_freshness_gate = {
                "ok": False,
                "independent_market_calendar_verified": False,
                "expected_market_session": "",
                "market_calendar_source": calendar_state.get("source"),
                "reason": str(calendar_state.get("reason") or "无法独立确认最新应有交易日"),
                "checked_at": _now_iso(),
            }
            return dict(self.last_freshness_gate)

        band, fresh_metadata_codes = self._refresh_ranked_metadata_band(
            years, set(), _nested_progress(progress, phases, "metadata")
        )
        if len(band) < DISPLAY_TOP_N:
            self.last_freshness_gate = {
                "ok": False,
                "reason": f"当前可评分候选仅 {len(band)} 只，不足建立正式排名边界",
                "checked_at": _now_iso(),
            }
            return dict(self.last_freshness_gate)

        requested_codes: list[str] = []
        requested_set: set[str] = set()
        fresh_rows: dict[str, dict] = {}
        returned_rows: dict[str, dict] = {}
        stale_set: set[str] = set()
        failed_set: set[str] = set()
        persisted = {"updated_series": 0, "same_day_updates": 0, "pending_adjustments": 0}
        boundary_rounds = 0
        boundary_stable = False
        full_rank_info: dict = {}
        pending = self._refresh_nav_challenger_codes(band)

        while pending and not _cancel_requested():
            batch = [code for code in pending if code not in requested_set]
            if not batch:
                boundary_stable = True
                break
            boundary_rounds += 1
            requested_codes.extend(batch)
            requested_set.update(batch)
            progress(
                f"正式边界净值复核第 {boundary_rounds} 轮，本轮 {len(batch)} 只",
                _phase_progress_value(phases, "latest"),
            )
            report = self.source.latest_many(
                batch, progress=_nested_progress(progress, phases, "latest"),
            )
            batch_rows = report.get("rows") or {}
            returned_rows.update(batch_rows)
            _register_observed_market_rows(batch_rows, fund_types)
            batch_fresh, batch_stale = self._classify_latest_rows(batch_rows, fund_types)
            fresh_rows.update(batch_fresh)
            stale_set.update(batch_stale)
            failed_set.update(str(code) for code in (report.get("failed_codes") or []))
            failed_set.update(set(batch) - set(batch_rows))

            # Every fund that can still reach the formal boundary is mandatory. Tail funds are
            # deliberately outside this gate; a failure inside this scope keeps last-known-good.
            if len(batch_fresh) != len(batch):
                break

            committed = self.history_repository.commit_latest_rows(batch_fresh, codes=set(batch))
            for key in tuple(persisted):
                persisted[key] += int(_finite((committed or {}).get(key), 0))

            full_rank_info = self._rebuild_foreground_from_archive_features(
                years, _nested_progress(progress, phases, "features"), eligible_codes=set(fresh_rows)
            )
            band, fresh_metadata_codes = self._refresh_ranked_metadata_band(
                years, fresh_metadata_codes, _nested_progress(progress, phases, "metadata")
            )
            expanded = self._refresh_nav_challenger_codes(band)
            pending = [code for code in expanded if code not in requested_set]
            if not pending:
                boundary_stable = True
                break

        requested = len(requested_set)
        fresh_coverage = len(fresh_rows) / max(1, requested)
        returned_coverage = len(returned_rows) / max(1, requested)
        if not boundary_stable or fresh_coverage < FINAL_FRESHNESS_COVERAGE:
            self.last_freshness_gate = {
                "ok": False,
                "fresh_coverage": fresh_coverage,
                "returned_coverage": returned_coverage,
                "verified_candidate_count": requested,
                "full_candidate_count": len(all_codes),
                "tail_candidate_count": max(0, len(all_codes) - requested),
                "stale_count": len(stale_set),
                "failed_count": len(failed_set),
                "boundary_rounds": boundary_rounds,
                "boundary_stable": boundary_stable,
                "reason": (
                    f"正式排名边界所需 {requested} 只候选未能 100% 完成本轮新鲜净值复核；"
                    "保留 last-known-good，尾部候选缺失本身不会阻断"
                ),
                "checked_at": _now_iso(),
            }
            return dict(self.last_freshness_gate)

        with self.lock:
            scored = self.ranker.score(
                self.funds, self.store.model, self.feature_cache, holding_years=years, require_full_selection=False
            )
            final_top = _select_formal_buy_candidates(scored, DISPLAY_TOP_N)
            display_updates = self._apply_latest_display_rows(self.funds, fresh_rows)
            self._persist_current()

        if not final_top:
            self.last_freshness_gate = {
                "ok": False,
                "fresh_coverage": fresh_coverage,
                "returned_coverage": returned_coverage,
                "verified_candidate_count": requested,
                "full_candidate_count": len(all_codes),
                "tail_candidate_count": max(0, len(all_codes) - requested),
                "boundary_rounds": boundary_rounds,
                "boundary_stable": boundary_stable,
                "reason": "本轮边界已完整复核，但当前没有基金同时满足绝对买入条件与可确认申购状态",
                "checked_at": _now_iso(),
            }
            return dict(self.last_freshness_gate)

        final_top = _validate_formal_results(final_top)
        final_codes = {str(item.get("code") or "") for item in final_top}
        nav_verified = _formal_top_nav_verified(final_top, fresh_rows)
        boundary_codes = set(self._refresh_nav_challenger_codes(band))
        final_metadata_coverage = len(final_codes & fresh_metadata_codes) / max(1, len(final_codes))
        boundary_metadata_coverage = len(boundary_codes & fresh_metadata_codes) / max(1, len(boundary_codes))
        metadata_verified = bool(
            final_metadata_coverage >= FINAL_PUBLIC_METADATA_REFRESH_COVERAGE
            and boundary_metadata_coverage >= REFRESH_MIN_COVERAGE
        )
        ok = bool(nav_verified and boundary_stable and boundary_codes <= set(fresh_rows))
        if ok:
            self._last_verified_rows = [dict(item) for item in final_top]

        reasons = [
            f"正式边界候选最新净值新鲜覆盖 {_format_unrounded_number(fresh_coverage, '%', scale=PERCENT_SCALE)}（{requested}只）",
            f"最终正式 {len(final_top)} 只本轮净值复核 {'通过' if nav_verified else '未通过'}",
            f"最终正式候选详情复核覆盖 {_format_unrounded_number(final_metadata_coverage, '%', scale=PERCENT_SCALE)}",
            f"理论边界候选详情复核覆盖 {_format_unrounded_number(boundary_metadata_coverage, '%', scale=PERCENT_SCALE)}（{len(boundary_codes)}只）",
            f"全市场候选 {len(all_codes)} 只，其中尾部 {max(0, len(all_codes)-requested)} 只不要求 100% 同步新鲜",
            f"边界重算候选 {int(full_rank_info.get('candidate_count') or requested)} 只；已刷新可见净值 {display_updates} 只",
        ]
        if not metadata_verified:
            reasons.append("公开基金详情元数据未完整覆盖；不阻断投资排名更新")
        self.last_freshness_gate = {
            "ok": ok,
            "independent_market_calendar_verified": calendar_state.get("reliable") is True,
            "expected_market_session": str(calendar_state.get("expected_latest_session") or ""),
            "market_calendar_source": calendar_state.get("source"),
            "market_calendar_reason": calendar_state.get("reason"),
            "fresh_coverage": fresh_coverage,
            "returned_coverage": returned_coverage,
            "displayed_fresh_coverage": 1.0 if nav_verified else len(final_codes & set(fresh_rows)) / max(1, len(final_codes)),
            "metadata_coverage": final_metadata_coverage,
            "final_metadata_coverage": final_metadata_coverage,
            "boundary_metadata_coverage": boundary_metadata_coverage,
            "boundary_candidate_count": len(boundary_codes),
            "metadata_evidence_good": metadata_verified,
            "nav_verified": nav_verified,
            "metadata_verified": metadata_verified,
            "verified_candidate_count": requested,
            "full_candidate_count": len(all_codes),
            "tail_candidate_count": max(0, len(all_codes) - requested),
            "verified_nav_codes": sorted(set(fresh_rows)),
            "verified_metadata_codes": sorted(final_codes & fresh_metadata_codes),
            "stale_count": len(stale_set),
            "failed_count": len(failed_set),
            "boundary_rounds": boundary_rounds,
            "boundary_stable": boundary_stable,
            "updated_series": int(persisted.get("updated_series") or 0),
            "reason": "；".join(reasons),
            "checked_at": _now_iso(),
        }
        return dict(self.last_freshness_gate)

    def _finalize_refresh_ranking(
        self, results: list[dict], years: int, *, ranking_updated: bool,
        priority_codes: list[str], priority_missing: list[str], fresh_coverage: float,
        fresh_rows: dict[str, dict], fresh_metadata_codes: set[str],
    ) -> tuple[RankingResult, int, int]:
        """Build the refresh gate using detail metadata actually fetched in this refresh."""
        results = _validate_formal_results(results)
        final_codes = {str(item.get("code") or "") for item in results}
        final_nav_verified = _formal_top_nav_verified(results, fresh_rows)
        final_metadata_coverage = len(final_codes & set(fresh_metadata_codes)) / max(1, len(final_codes))
        boundary_codes = {str(code) for code in priority_codes if _valid_fund_code(code)}
        boundary_metadata_coverage = len(boundary_codes & set(fresh_metadata_codes)) / max(1, len(boundary_codes))
        final_metadata_verified = bool(
            final_metadata_coverage >= FINAL_PUBLIC_METADATA_REFRESH_COVERAGE
            and boundary_metadata_coverage >= REFRESH_MIN_COVERAGE
        )
        calendar_state = self.freshness_gate.market_state()
        current_gate_ok = bool(
            calendar_state.get("reliable") is True
            and ranking_updated
            and not priority_missing
            and final_nav_verified
        )
        reason_parts = [
            "当前公开基金详情已按本轮实际请求复核",
            f"Top{len(priority_codes)} 最新净值覆盖 {_format_unrounded_number((len(priority_codes)-len(priority_missing))/max(1,len(priority_codes)), '%', scale=PERCENT_SCALE)}",
            f"最终正式 {len(results)} 只基金详情复核覆盖 {_format_unrounded_number(final_metadata_coverage, '%', scale=PERCENT_SCALE)}",
            f"理论边界候选详情复核覆盖 {_format_unrounded_number(boundary_metadata_coverage, '%', scale=PERCENT_SCALE)}（{len(boundary_codes)}只）",
        ]
        if not final_nav_verified:
            reason_parts.append("最终正式候选包含未经过本轮净值复核的基金")
        if not final_metadata_verified:
            reason_parts.append("基金详情复核覆盖不足；不阻断投资排名更新")
        if not ranking_updated:
            reason_parts.append("本轮未满足全池原子重排条件，不升级正式快照")
        self.last_freshness_gate = {
            "ok": current_gate_ok,
            "independent_market_calendar_verified": calendar_state.get("reliable") is True,
            "expected_market_session": str(calendar_state.get("expected_latest_session") or ""),
            "market_calendar_source": calendar_state.get("source"),
            "market_calendar_reason": calendar_state.get("reason"),
            "fresh_coverage": fresh_coverage,
            "displayed_fresh_coverage": (len(priority_codes) - len(priority_missing)) / max(1, len(priority_codes)),
            "metadata_coverage": final_metadata_coverage,
            "final_metadata_coverage": final_metadata_coverage,
            "boundary_metadata_coverage": boundary_metadata_coverage,
            "boundary_candidate_count": len(boundary_codes),
            "metadata_checked": bool(fresh_metadata_codes),
            "verified_metadata_codes": sorted(final_codes & set(fresh_metadata_codes)),
            "nav_verified": final_nav_verified,
            "metadata_verified": final_metadata_verified,
            "reason": "；".join(reason_parts),
            "checked_at": _now_iso(),
        }
        prediction_outcomes_updated = 0
        predictions_recorded = 0
        if current_gate_ok:
            self._last_verified_rows = [dict(item) for item in results]
            self._commit_verified_top100(results, years, self.last_freshness_gate)
            prediction_outcomes_updated = self.store.update_prediction_outcomes(self.funds)
            predictions_recorded = len(results)
        else:
            self._last_verified_rows = []
        ranking_result = self.result_for_display(years)
        if ranking_result is None:
            ranking_result = RankingResult(results, "preview", dict(self.last_freshness_gate))
        return ranking_result, prediction_outcomes_updated, predictions_recorded

    def _rebuild_foreground_from_archive_features(
        self, years: int, progress=lambda *_: None, *, eligible_codes: set[str] | None = None,
    ) -> dict:
        """Re-score the persisted candidate universe in bounded batches, optionally restricted to this fresh snapshot."""
        archive = self.history_repository.archive()
        with self.lock:
            current_lookup = {str(item.get("code") or ""): dict(item) for item in self.funds if item.get("code")}

        metadata_by_code: dict[str, dict] = {}
        for code, item in archive.items():
            if not isinstance(item, dict) or item.get("ranking_candidate") is not True:
                continue
            name = str(item.get("name") or code)
            fund_type = str(item.get("type") or "其他")
            if not _candidate_allowed(name):
                continue
            if int(_finite(item.get("_nav_series_count"), 0)) < MIN_HISTORY_POINTS and code not in current_lookup:
                continue
            metadata_by_code[str(code)] = {"code": str(code), **item}

        # Newly discovered foreground candidates may not have reached SQLite yet. Overlay them
        # without copying their long histories into the metadata universe.
        for code, item in current_lookup.items():
            if not _valid_fund_code(code):
                continue
            meta = {key: value for key, value in item.items() if key not in ("dates", "returns")}
            metadata_by_code[code] = {"code": code, **meta}

        if eligible_codes is not None:
            eligible = {str(code) for code in eligible_codes}
            metadata_by_code = {code: item for code, item in metadata_by_code.items() if code in eligible}

        candidate_codes = sorted(metadata_by_code)
        if len(candidate_codes) < DISPLAY_TOP_N:
            raise DataError(f"全市场持久候选仅 {len(candidate_codes)} 只，无法重排 Top{DISPLAY_TOP_N}")

        precomputed: dict[str, dict] = {}
        fee_imputation, fee_imputation_fallback = self.ranker._fee_imputation_by_bucket(
            list(metadata_by_code.values()), years,
        )
        total = len(candidate_codes)
        batch_size = max(1, math.ceil(total / max(1, int(os.cpu_count() or 1))))
        for offset in range(0, total, batch_size):
            batch = candidate_codes[offset:offset + batch_size]
            histories = self.history_repository.load_history_for_codes(batch)
            for code in batch:
                history = histories.get(code) if isinstance(histories.get(code), dict) else {}
                if not history:
                    current = current_lookup.get(code) or {}
                    history = {
                        "dates": list(current.get("dates") or []),
                        "returns": list(current.get("returns") or []),
                    }
                dates = history.get("dates") or []
                returns = history.get("returns") or []
                if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                    continue
                meta = metadata_by_code[code]
                fees = meta.get("fees") if meta.get("fees_verified") is True else None
                bucket = _asset_bucket(str(meta.get("name") or ""), str(meta.get("type") or ""))
                result = self.ranker.features(
                    returns, fees=fees, dates=dates, target_years=years,
                    history_context=meta,
                    unknown_transaction_cost=fee_imputation.get(bucket, fee_imputation_fallback),
                )
                if result:
                    precomputed[code] = {"vector": result[0], "stats": result[1]}
            progress(
                f"后台全市场特征重算 {min(offset + len(batch), total)}/{total}",
                PERCENT_SCALE * min(offset + len(batch), total) / max(1, total),
            )

        candidate_items = [metadata_by_code[code] for code in candidate_codes if code in precomputed]
        scored = self.ranker.score(
            candidate_items, self.store.model, feature_cache={},
            holding_years=years, precomputed_features=precomputed,
        )
        ranked = self._formal_boundary_ranked_band(scored)
        working_codes = [str(item.get("code") or "") for item in ranked if item.get("code")]
        histories = self.history_repository.load_history_for_codes(working_codes)
        working = []
        for code in working_codes:
            meta = metadata_by_code.get(code) or {}
            history = histories.get(code) if isinstance(histories.get(code), dict) else {}
            if not history:
                current = current_lookup.get(code) or {}
                history = {
                    "dates": list(current.get("dates") or []),
                    "returns": list(current.get("returns") or []),
                }
            if len(history.get("returns") or []) < MIN_HISTORY_POINTS:
                continue
            working.append({"code": code, **meta, **history})

        if len({_underlying_key(item) for item in working}) < DISPLAY_TOP_N:
            raise DataError("全市场分批重算后可用底层基金不足 100 个")
        with self.lock:
            self.funds = working
            self._candidate_pool_complete = False
            self.feature_cache.clear()
        return {
            "candidate_count": total,
            "feature_count": len(precomputed),
            "working_count": len(working),
        }

    def _prepare_refresh_priority_band(
        self, years: int, progress=lambda *_: None,
    ) -> tuple[list[dict], set[str]]:
        progress("计算基金详情复核范围", 0.0)
        return self._refresh_ranked_metadata_band(years, set(), progress)

    @staticmethod
    def _ranking_utility_ceiling(item: dict) -> float:
        """Conservative investment-quality ceiling for a ranking candidate."""
        utility = _finite((item or {}).get("final_ranking_utility"), float("nan"))
        if math.isfinite(utility):
            return _clamp(utility, 0.0, 1.0)
        # An unscored persisted candidate remains a challenger; missing public evidence must not
        # make a potentially stronger investment disappear from the ranking boundary search.
        return 1.0

    def _boundary_ranked_band(self, scored: list[dict]) -> list[dict]:
        """Top100 plus every candidate whose conservative utility ceiling can still reach 100th place."""
        ranked = _select_top_policy(scored, max(DISPLAY_TOP_N, len(scored)))
        if len(ranked) <= DISPLAY_TOP_N:
            return ranked
        top = ranked[:DISPLAY_TOP_N]
        boundary = _finite(top[-1].get("final_ranking_utility"), -sys.float_info.max)
        challengers = [
            item for item in ranked[DISPLAY_TOP_N:]
            if self._ranking_utility_ceiling(item) >= boundary
        ]
        return top + challengers

    def _formal_boundary_ranked_band(self, scored: list[dict]) -> list[dict]:
        """Candidates that can still reach the 100th *formal buyable* slot; if <100 qualify, keep the whole ranked pool."""
        ranked = _select_top_policy(scored, max(DISPLAY_TOP_N, len(scored)))
        if not ranked:
            return []
        formal = _select_formal_buy_candidates(ranked, DISPLAY_TOP_N)
        if len(formal) < DISPLAY_TOP_N:
            return ranked
        boundary = _finite(formal[-1].get("final_ranking_utility"), -sys.float_info.max)
        return [item for item in ranked if self._ranking_utility_ceiling(item) >= boundary]

    def _refresh_nav_challenger_codes(self, ranked_band: list[dict]) -> list[str]:
        """Return every code that can still reach the 100th formal-buy slot under the conservative utility ceiling."""
        ranked_band = list(ranked_band or [])
        formal = _select_formal_buy_candidates(ranked_band, DISPLAY_TOP_N)
        archive = self.history_repository.archive()
        with self.lock:
            current = {str(item.get("code") or ""): dict(item) for item in self.funds if item.get("code")}
        candidates: dict[str, dict] = {}
        for code, item in archive.items():
            code = str(code)
            if (
                isinstance(item, dict)
                and item.get("ranking_candidate") is True
                and _valid_fund_code(code)
                and _candidate_allowed(str(item.get("name") or code))
            ):
                candidates[code] = {"code": code, **item}
        for code, item in current.items():
            if _valid_fund_code(code) and _candidate_allowed(str(item.get("name") or code)):
                candidates[code] = {"code": code, **item}

        # If fewer than 100 funds currently satisfy formal buy gates, every remaining candidate
        # must be checked before claiming that the shorter list is complete.
        if len(formal) < DISPLAY_TOP_N:
            return sorted(candidates)

        boundary = _finite(formal[-1].get("final_ranking_utility"), -sys.float_info.max)
        qualifying_underlyings = {
            _underlying_key(item) for item in ranked_band
            if self._ranking_utility_ceiling(item) >= boundary
        }
        ceilings: dict[str, float] = {}
        grouped: dict[str, list[dict]] = {}
        for item in candidates.values():
            grouped.setdefault(_underlying_key(item), []).append(item)
        for underlying, rows in grouped.items():
            ceiling = max((self._ranking_utility_ceiling(row) for row in rows), default=-sys.float_info.max)
            ceilings[underlying] = ceiling
            if ceiling >= boundary:
                qualifying_underlyings.add(underlying)

        leading_codes = [
            str(item.get("code") or "") for item in ranked_band
            if item.get("code") and self._ranking_utility_ceiling(item) >= boundary
        ]
        remaining = [
            code for code, item in candidates.items()
            if _underlying_key(item) in qualifying_underlyings and code not in leading_codes
        ]
        remaining.sort(key=lambda code: (-ceilings.get(_underlying_key(candidates[code]), -sys.float_info.max), code))
        return list(dict.fromkeys(leading_codes + remaining))

    def _prepare_refresh_nav_scope(
        self, *, added: list[str], removed: list[str], priority_codes: list[str],
        availability: dict[str, dict] | None = None,
    ) -> tuple[bool, bool, list[str], dict[str, str]]:
        with self.lock:
            loaded_codes = [str(item.get("code") or "") for item in self.funds if item.get("code")]
            fund_types = {str(item.get("code") or ""): str(item.get("type") or "") for item in self.funds}
        today = _china_today()
        archive = self.history_repository.archive() if not self._candidate_pool_complete else {}

        def known_nav_is_fresh(item: dict) -> bool:
            latest_date = str(item.get("display_nav_date") or item.get("latest_date") or "")[:DATE_TEXT_LENGTH]
            latest_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
            freshness_row = {
                "nav_date": latest_date, "nav": latest_nav,
                "name": item.get("name"), "type": item.get("type"),
                "latest_sources": item.get("latest_sources"),
                "history_source": item.get("history_source"),
                "fund_data_source": item.get("fund_data_source"),
            }
            return FreshnessGate.is_fresh(freshness_row, today, str(item.get("type") or ""))

        if self._candidate_pool_complete:
            known_candidates = [item for item in self.funds if isinstance(item, dict)]
        else:
            known_candidates = [
                item for item in archive.values()
                if isinstance(item, dict) and item.get("ranking_candidate") is True
            ]
        stale_known_candidate = any(not known_nav_is_fresh(item) for item in known_candidates)
        full_due = bool(
            self._last_full_nav_refresh_at <= 0
            or bool(added or removed)
            or stale_known_candidate
        )
        lazy_full_refresh = bool(full_due and not self._candidate_pool_complete)
        if lazy_full_refresh:
            available_codes = {
                str(code) for code, row in (availability or {}).items()
                if _valid_fund_code(code)
                and _candidate_allowed(str((row or {}).get("name") or code))
            }
            persisted_codes = []
            for code, item in archive.items():
                code = str(code)
                if (
                    isinstance(item, dict)
                    and item.get("ranking_candidate") is True
                    and _valid_fund_code(code)
                    and (self.last_catalog_sync_degraded or not available_codes or code in available_codes)
                ):
                    persisted_codes.append(code)
                    fund_types.setdefault(code, str(item.get("type") or ""))
            request_codes = list(dict.fromkeys(persisted_codes + loaded_codes))
        else:
            request_codes = loaded_codes if full_due else list(priority_codes)
        if request_codes:
            for code in request_codes:
                if code not in fund_types and isinstance(archive.get(code), dict):
                    fund_types[code] = str((archive.get(code) or {}).get("type") or "")
        return full_due, lazy_full_refresh, request_codes, fund_types

    def _compose_refresh_status(
        self, *, full_due: bool, adaptive_boundary_refresh: bool, ranking_updated: bool,
        requested: int, boundary_rounds: int, returned_coverage: float, fresh_coverage: float,
        stale_count: int, display_updates: int, priority_count: int, priority_missing_count: int,
        boundary_stable: bool, calendar_state: dict, deferred_new: list[str], failed_new: list[str],
    ) -> str:
        """Describe refresh evidence separately from the atomic formal-ranking commit."""
        returned_text = _format_unrounded_number(returned_coverage, '%', scale=PERCENT_SCALE)
        fresh_text = _format_unrounded_number(fresh_coverage, '%', scale=PERCENT_SCALE)
        if ranking_updated and full_due:
            status = (
                f"全候选净值：返回 {returned_text} / 新鲜 {fresh_text} / 陈旧 {stale_count}；"
                f"界面净值已刷新 {display_updates} 只；Top {priority_count} 全部新鲜，历史序列已提交并重排"
            )
        elif ranking_updated and adaptive_boundary_refresh:
            status = (
                f"Top100+理论仍可入围候选 {requested} 只自适应复核（{boundary_rounds} 轮单调扩张）：返回 {returned_text} / 新鲜 {fresh_text} / "
                f"陈旧 {stale_count}；最终边界下已无未刷新候选能够进入 Top100，完整全池刷新仍由自动周期执行"
            )
        elif not full_due:
            status = (
                f"Top100+理论仍可入围候选 {requested} 只自适应复核：返回 {returned_text} / 新鲜 {fresh_text} / "
                f"陈旧 {stale_count}；界面净值已刷新 {display_updates} 只；"
                + ("候选边界已数学稳定" if boundary_stable else "候选边界未能证明稳定，保留 last-known-good 排名")
            )
        else:
            status = (
                f"全候选净值：返回 {returned_text} / 新鲜 {fresh_text} / 陈旧 {stale_count}；"
                f"界面净值已刷新 {display_updates} 只；"
            )
            if fresh_coverage < REFRESH_MIN_COVERAGE:
                threshold = _format_unrounded_number(REFRESH_MIN_COVERAGE, '%', scale=PERCENT_SCALE)
                status += f"低于排名原子门槛 {threshold}，历史序列和正式排名未提交"
            else:
                status += f"Top候选仍有 {priority_missing_count} 个不新鲜，历史序列和正式排名未提交"

        if calendar_state.get("reliable") is not True:
            status += (
                "；独立交易日历未能确认最新应有交易日，正式结果降级为 last-known-good"
                f"（{calendar_state.get('reason') or '未知原因'}）"
            )
        if self.last_catalog_sync_degraded:
            status += f"；公开基金目录本轮异常，沿用上一有效候选池（{self.last_catalog_sync_reason}）"
        if deferred_new:
            status += f"；新增候选暂缓 {len(deferred_new)} 只"
        if failed_new:
            status += f"；新增候选处理失败 {len(failed_new)} 只"
        return status

    def refresh_latest(
        self,
        holding_years: int | None = None,
        *,
        progress=lambda *_: None,
    ) -> dict:
        started = time.monotonic()
        phases = ("contract", "availability", "catalog", "metadata", "nav", "validate", "archive", "finalize")
        progress("检查数据源可用性", _phase_progress_value(phases, "contract"))
        self.ensure_source_contract(_nested_progress(progress, phases, "contract"), force=False)
        years = _expected_holding_years(holding_years, self.store.model)

        progress("获取最新基金目录", _phase_progress_value(phases, "availability"))
        availability = self._availability_snapshot()

        progress("同步基金候选池", _phase_progress_value(phases, "catalog"))
        added, removed, deferred_new, failed_new = self._sync_candidate_pool(availability)

        priority_band, fresh_metadata_codes = self._prepare_refresh_priority_band(
            years, _nested_progress(progress, phases, "metadata")
        )
        priority_codes = [str(item.get("code") or "") for item in priority_band]

        if len(priority_codes) < DISPLAY_TOP_N:
            self._persist_current()
            raise DataError(f"当前候选且历史数据充足的底层基金不足 {DISPLAY_TOP_N} 个")

        adaptive_scope_codes = self._refresh_nav_challenger_codes(priority_band)
        priority_codes = list(adaptive_scope_codes)
        full_due, lazy_full_refresh, request_codes, fund_types = self._prepare_refresh_nav_scope(
            added=added,
            removed=removed,
            priority_codes=adaptive_scope_codes,
            availability=availability,
        )
        today = _china_today()
        calendar_state = self.freshness_gate.refresh_independent_market_state(today, force=True)
        persisted_latest = {"updated_series": 0, "same_day_updates": 0, "pending_adjustments": 0}
        adaptive_boundary_refresh = not full_due
        boundary_stable = not adaptive_boundary_refresh
        boundary_rounds = 0

        def add_persisted_stats(values: dict) -> None:
            for key in tuple(persisted_latest):
                persisted_latest[key] += int(_finite((values or {}).get(key), 0))

        if adaptive_boundary_refresh:
            # The scope expands monotonically.  Each iteration re-ranks the complete fresh scope
            # and asks the exact utility ceiling again; termination is "no unseen candidate can
            # reach the new boundary", never a fixed number of challenger rounds.
            _, all_candidate_types = self._candidate_nav_universe()
            fund_types.update(all_candidate_types)
            requested_codes: list[str] = []
            requested_set: set[str] = set()
            all_rows: dict[str, dict] = {}
            fresh_rows: dict[str, dict] = {}
            stale_set: set[str] = set()
            failed_set: set[str] = set()
            pending = [code for code in request_codes if code not in requested_set]

            archive_phases = ("features", "metadata")
            def archive_progress(inner_phase):
                return lambda text, pct: progress(
                    text,
                    _phase_progress_value(
                        phases, "archive",
                        _phase_progress_value(
                            archive_phases, inner_phase,
                            _clamp(_finite(pct), 0.0, PERCENT_SCALE) / PERCENT_SCALE,
                        ) / PERCENT_SCALE,
                    ),
                )

            while pending and not _cancel_requested():
                boundary_rounds += 1
                batch = [code for code in pending if code not in requested_set]
                if not batch:
                    boundary_stable = True
                    break
                requested_codes.extend(batch)
                requested_set.update(batch)
                progress(
                    f"自适应刷新第 {boundary_rounds} 轮：获取新增理论可入围候选 {len(batch)} 只（累计 {len(requested_set)}）",
                    _phase_progress_value(phases, "nav"),
                )
                batch_report = self.source.latest_many(
                    batch, progress=_nested_progress(progress, phases, "nav"),
                )
                batch_rows = batch_report.get("rows") or {}
                _register_observed_market_rows(batch_rows, fund_types)
                all_rows.update(batch_rows)
                failed_set.update(str(code) for code in (batch_report.get("failed_codes") or []))
                failed_set.update(set(batch) - set(batch_rows))

                progress("检查净值日期与完整性", _phase_progress_value(phases, "validate"))
                batch_fresh, batch_stale = self._classify_latest_rows(batch_rows, fund_types, today)
                fresh_rows.update(batch_fresh)
                stale_set.update(batch_stale)
                progress("提交可证明仍可能入围候选的最新净值到 SQLite", _phase_progress_value(phases, "archive"))
                add_persisted_stats(
                    self.history_repository.commit_latest_rows(batch_fresh, codes=set(batch))
                )

                # Any missing/stale candidate in the mathematically necessary scope prevents
                # a proof of stability.  Keep the last-known-good ranking rather than guessing.
                if len(batch_fresh) != len(batch):
                    break

                self._rebuild_foreground_from_archive_features(
                    years, archive_progress("features"), eligible_codes=set(fresh_rows)
                )
                priority_band, fresh_metadata_codes = self._refresh_ranked_metadata_band(
                    years, fresh_metadata_codes, archive_progress("metadata")
                )
                priority_codes = [str(item.get("code") or "") for item in priority_band]
                expanded_scope = self._refresh_nav_challenger_codes(priority_band)
                pending = [code for code in expanded_scope if code not in requested_set]
                if not pending:
                    boundary_stable = True
                    break

            request_codes = requested_codes
            rows = all_rows
            requested = len(requested_set)
            received = len(all_rows)
            returned_coverage = received / max(1, requested)
            fresh_coverage = len(fresh_rows) / max(1, requested)
            stale_codes = sorted(stale_set)
            report = {
                "rows": all_rows, "requested": requested, "received": received,
                "failed_codes": sorted(failed_set),
            }
        else:
            progress(f"正在获取最新净值，共 {len(request_codes)} 只基金", _phase_progress_value(phases, "nav"))
            report = self.source.latest_many(
                request_codes, progress=_nested_progress(progress, phases, "nav"),
            )
            rows = report.get("rows") or {}
            _register_observed_market_rows(rows, fund_types)
            requested = int(report.get("requested", len(request_codes)))
            received = int(report.get("received", len(rows)))
            returned_coverage = received / max(1, requested)

            progress("检查净值日期与完整性", _phase_progress_value(phases, "validate"))
            fresh_rows, stale_codes = self._classify_latest_rows(rows, fund_types, today)
            fresh_coverage = len(fresh_rows) / max(1, requested)
            if lazy_full_refresh:
                progress("提交全市场最新净值到 SQLite", _phase_progress_value(phases, "archive"))
                add_persisted_stats(
                    self.history_repository.commit_latest_rows(fresh_rows, codes=set(request_codes))
                )
                if set(priority_codes) <= set(fresh_rows):
                    archive_phases = ("features", "metadata")
                    def archive_progress(inner_phase):
                        return lambda text, pct: progress(
                            text,
                            _phase_progress_value(
                                phases, "archive",
                                _phase_progress_value(
                                    archive_phases, inner_phase,
                                    _clamp(_finite(pct), 0.0, PERCENT_SCALE) / PERCENT_SCALE,
                                ) / PERCENT_SCALE,
                            ),
                        )
                    self._rebuild_foreground_from_archive_features(
                        years, archive_progress("features"), eligible_codes=set(fresh_rows)
                    )
                    priority_band, fresh_metadata_codes = self._refresh_ranked_metadata_band(
                        years, fresh_metadata_codes, archive_progress("metadata")
                    )
                    priority_codes = [str(item.get("code") or "") for item in priority_band]

        priority_missing = sorted(set(priority_codes) - set(fresh_rows))
        priority_complete = not priority_missing
        ranking_updated = bool(
            (full_due or adaptive_boundary_refresh)
            and priority_complete
            and boundary_stable
        )

        updated_series = int(persisted_latest.get("updated_series") or 0)
        resolved_adjustments = 0
        if ranking_updated and full_due:
            self.store.cache["last_full_nav_refresh_at"] = _now_iso()
        progress("刷新可见净值并检查排名门槛", _phase_progress_value(phases, "finalize"))

        with self.lock:
            display_updates = self._apply_latest_display_rows(self.funds, fresh_rows)
            if ranking_updated:
                updated_series += self._apply_latest_history_rows(self.funds, fresh_rows)
                resolved_adjustments = self._resolve_pending_adjustments(self.funds)
                updated_series += resolved_adjustments
            self._persist_current()
            # When the atomic full-ranking gate fails, this recomputes only from the prior
            # committed model/history while retaining the newly refreshed display NAV fields.
            results = self.rankings(holding_years=years)

        if ranking_updated and full_due:
            self._last_full_nav_refresh_at = time.monotonic()

        status = self._compose_refresh_status(
            full_due=full_due, adaptive_boundary_refresh=adaptive_boundary_refresh,
            ranking_updated=ranking_updated, requested=requested, boundary_rounds=boundary_rounds,
            returned_coverage=returned_coverage, fresh_coverage=fresh_coverage,
            stale_count=len(stale_codes), display_updates=display_updates,
            priority_count=len(priority_codes), priority_missing_count=len(priority_missing),
            boundary_stable=boundary_stable, calendar_state=calendar_state,
            deferred_new=deferred_new, failed_new=failed_new,
        )

        ranking_result, prediction_outcomes_updated, predictions_recorded = self._finalize_refresh_ranking(
            results, years,
            ranking_updated=ranking_updated,
            priority_codes=priority_codes,
            priority_missing=priority_missing,
            fresh_coverage=fresh_coverage,
            fresh_rows=fresh_rows,
            fresh_metadata_codes=fresh_metadata_codes,
        )

        progress("刷新完成", PERCENT_SCALE)
        return {
            "results": ranking_result.rows,
            "ranking_result": ranking_result,
            "status": status,
            "coverage": fresh_coverage,
            "returned_coverage": returned_coverage,
            "fresh_coverage": fresh_coverage,
            "stale_count": len(stale_codes),
            "stale_codes": sorted(stale_codes),
            "requested": requested,
            "received": received,
            "fresh_received": len(fresh_rows),
            "display_updates": display_updates,
            "failed_codes": report.get("failed_codes") or [],
            "priority_codes": sorted(priority_codes),
            "priority_missing_codes": priority_missing,
            "priority_complete": priority_complete,
            "ranking_updated": ranking_updated,
            "full_refresh": full_due,
            "new_codes": added,
            "removed_codes": removed,
            "deferred_new_codes": deferred_new,
            "failed_new_codes": failed_new,
            "catalog_sync_degraded": self.last_catalog_sync_degraded,
            "catalog_sync_reason": self.last_catalog_sync_reason,
            "metadata_checked_codes": sorted(fresh_metadata_codes),
            "updated_series": updated_series,
            "resolved_adjustments": resolved_adjustments,
            "prediction_outcomes_updated": prediction_outcomes_updated,
            "predictions_recorded": predictions_recorded,
            "elapsed_seconds": time.monotonic() - started,
        }



# ===== UI / 控制台 =====

class AppState:
    STARTING = "starting"
    BUILDING = "building"
    READY = "ready"
    REFRESHING = "refreshing"
    RETRY_WAIT = "retry_wait"
    ERROR = "error"


class ExclusiveOperation:
    IDLE = "idle"
    INITIAL = "initial"
    REFRESH = "refresh"
    MAINTENANCE = "maintenance"
    RETRAIN = "retrain"


class AnalysisOperationCoordinator:
    """Single owner for operations that may mutate AnalysisEngine/formal state."""
    def __init__(self):
        self._lock = threading.RLock()
        self._current = ExclusiveOperation.IDLE

    def try_begin(self, operation: str) -> bool:
        with self._lock:
            if self._current != ExclusiveOperation.IDLE:
                return False
            self._current = str(operation)
            return True

    def finish(self, operation: str) -> None:
        with self._lock:
            if self._current == str(operation):
                self._current = ExclusiveOperation.IDLE


class FundsApp:
    def __init__(self, root, tk, ttk):
        self.root, self.tk, self.ttk = root, tk, ttk
        _GLOBAL_STOP_EVENT.clear()
        self.engine = AnalysisEngine()
        # Lossless events (results/errors/done) remain queued. High-frequency progress is
        # coalesced separately so one slow UI tick cannot accumulate thousands of stale updates.
        self.events = queue.Queue()
        self._progress_lock = threading.Lock()
        self._latest_progress = None
        self.stop_event = _GLOBAL_STOP_EVENT
        self.workers = WorkerManager(self.stop_event)
        self.operation_coordinator = AnalysisOperationCoordinator()

        self.busy = False
        self.refreshing = False
        self.maintenance_running = False
        self.formal_results_ready = False
        self.basic_screening_ready = False
        self.app_state = AppState.STARTING

        self.refresh_policy = SmartRefreshPolicy()
        self.next_refresh = float("inf")
        self.next_maintenance = float("inf")
        self._disk_pressure_active = False
        self.current = []
        self._row_items = {}
        self._display_result_state = "preview"

        self.result_title = tk.StringVar(value=f"基金长期优选 · 最多 {DISPLAY_TOP_N} 只正式买入候选")
        self.status = tk.StringVar(value="正在准备基金排名")
        self.progress_value = tk.DoubleVar(value=0.0)
        self.progress_percent = tk.StringVar(value="0%")
        self.progress_detail = tk.StringVar(value="准备开始")
        self.elapsed_text = tk.StringVar(value="已用时 00:00")
        self.operation_started_at = None

        self.data_date = tk.StringVar(value="—")
        self.data_status = tk.StringVar(value="正在准备")
        self.data_status_detail = tk.StringVar(value="等待首次结果")
        self.ai_status = tk.StringVar(value="模型待载入")
        self.ai_background_status = tk.StringVar(value="结果优先，AI 增强稍后准备")
        self.clock = tk.StringVar(value="等待分析")
        self.refresh_reason = tk.StringVar(value="自动刷新将在分析完成后开始")
        self.last_update_text = tk.StringVar(value="最后更新 —")

        # Dashboard-first summary: show investment state before implementation details.
        self.top_pick_value = tk.StringVar(value="#1 —")
        self.top_pick_quality = tk.StringVar(value="—")
        self.top_pick_timing = tk.StringVar(value="—")
        self.top_pick_risk = tk.StringVar(value="—")
        self.overview_value = tk.StringVar(value=f"最多{DISPLAY_TOP_N}只")
        self.overview_target_ann = tk.StringVar(value="—")
        self.overview_avg_quality = tk.StringVar(value="—")
        self.overview_count = tk.StringVar(value="—")
        self.risk_value = tk.StringVar(value="风险结构")
        self.risk_distribution = tk.StringVar(value="—")
        self.risk_data_nature = tk.StringVar(value="公开数据推断")
        self.live_value = tk.StringVar(value="准备中")
        self.live_nav_date = tk.StringVar(value="—")
        self.live_next_analysis = tk.StringVar(value="—")
        self.live_review_state = tk.StringVar(value="等待复核")
        self.market_overview = tk.StringVar(value="LIVE · 等待正式买入候选数据")
        self._layout_mode = None
        self._resize_job = None

        self.loading_spinner = tk.StringVar(value="● ○ ○")
        self.error_title = tk.StringVar(value="暂时无法取得基金数据")
        self.error_message = tk.StringVar(value="程序会自动重试。")
        self.retry_text = tk.StringVar(value="")

        self.detail_title = tk.StringVar(value="选择一只基金查看详情")
        self.detail_meta = tk.StringVar(value="")
        self.detail_metrics = tk.StringVar(value="")

        self.initial_error_streak = 0
        self.initial_retry_job = None
        self.initial_retry_due_at = None
        self.schedule_started = False

        self._dependency_ready_at = None
        self._dependency_prepare_started = False
        self._dependency_prepare_finished = False
        self._dependency_prepare_job = None
        self._advanced_retrain_pending = False
        self._advanced_retrain_started = False
        self._background_retrain_reason = ""
        self._background_integrity_started = False

        self._ui_display_period_seconds = _display_refresh_period_seconds()
        self._ui_last_activity_at = time.monotonic()
        self._ui_event_interval_count = 0
        self._ui_event_interval_mean = 0.0
        self._ui_event_interval_m2 = 0.0
        self._ui_last_handler_seconds = 0.0

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(self._ui_poll_delay_milliseconds(), self._poll_events)
        self.root.after(UI_CLOCK_TICK_MILLISECONDS, self._tick)
        self._start_initial()

    # ---------- common UI state ----------

    @staticmethod
    def _format_elapsed(seconds: float) -> str:
        total = max(0, int(seconds))
        hours, rem = divmod(total, SECONDS_PER_HOUR)
        minutes, secs = divmod(rem, SECONDS_PER_MINUTE)
        if hours:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    @staticmethod
    def _friendly_error_message(exc_text: str) -> str:
        text = str(exc_text or "")
        lower = text.lower()
        messages = []
        if "契约" in text or "熔断" in text or "格式" in text:
            messages.append("主要数据源校验暂未通过")
        if "timed out" in lower or "timeout" in lower or "超时" in text:
            messages.append("备用数据源或网络响应超时")
        elif "网络请求失败" in text or "network" in lower or "urlopen" in lower:
            messages.append("暂时无法连接数据源")
        if "不足" in text and "基金" in text:
            messages.append("当前可安全用于排名的数据暂时不足")
        if not messages:
            messages.append("本次数据更新未完成")
        return "；".join(dict.fromkeys(messages))

    @staticmethod
    def _friendly_progress(text: str) -> tuple[str, str]:
        raw = re.sub(r"\s+", " ", str(text or "")).strip()
        if not raw:
            return "正在处理", ""
        if "阶段1结构盲选历史" in raw or "阶段2" in raw or "历史增量" in raw:
            return "下载基金历史数据", raw
        if "anchored walk-forward" in raw or "production_model" in raw:
            return "训练长期 AI 模型", "正在验证长期模型并更新本地模型"
        if "高级 AI" in raw and "补训" in raw:
            return "增强 AI 模型", raw
        if "基金详情" in raw or "申购状态" in raw:
            return "检查最新基金数据", raw
        if "目录" in raw or "数据源" in raw or "契约" in raw:
            return "检查数据源", raw
        if "最新净值" in raw or "净值日期" in raw or "新鲜" in raw:
            return "获取并复核最新净值", raw
        if "元数据" in raw or "费率" in raw or "基金信息" in raw:
            return "补充基金信息", raw
        if "结构" in raw or "候选池" in raw:
            return "整理基金候选池", raw
        if "Top100" in raw or "Top 100" in raw or "排名" in raw:
            return "生成基金正式候选", raw
        if "刷新完成" in raw:
            return "刷新完成", raw
        if "完成" in raw:
            return raw, ""
        # Let the widget's measured wrap width decide presentation; do not truncate by character count.
        return raw, ""

    def _set_progress(self, text: str, pct: float | None = None):
        title, detail = self._friendly_progress(text)
        structured_detail = self._sync_progress_metrics(text) if hasattr(self, "progress_metric_vars") else str(text or "")
        self.status.set(title)
        self.progress_detail.set(structured_detail or detail or title)
        if pct is None:
            self.progress_percent.set("—")
            if hasattr(self, "progress") and not getattr(self, "_progress_is_indeterminate", False):
                try:
                    self.progress.configure(mode="indeterminate")
                    self.progress.start()
                    self._progress_is_indeterminate = True
                except self.tk.TclError:
                    pass
            return
        value = max(0.0, min(PERCENT_SCALE, _finite(pct)))
        if hasattr(self, "progress") and getattr(self, "_progress_is_indeterminate", False):
            try:
                self.progress.stop()
                self.progress.configure(mode="determinate")
            except self.tk.TclError:
                pass
            self._progress_is_indeterminate = False
        self.progress_value.set(value)
        self.progress_percent.set(f"{_format_unrounded_number(value)}%")

    def _begin_operation(self, text: str, pct: float | None = 0.0, detail: str = ""):
        self._show_progress_panel(True)
        self.operation_started_at = time.monotonic()
        self.elapsed_text.set("已用时 00:00")
        self._set_progress(detail or text, pct)
        if detail:
            self.status.set(text)

    def _finish_operation(self, text: str | None = None, pct: float | None = None):
        if text is not None:
            self._set_progress(text, pct)
        elif pct is not None:
            self._set_progress(self.progress_detail.get(), pct)
        if pct is None and hasattr(self, "progress") and getattr(self, "_progress_is_indeterminate", False):
            try:
                self.progress.stop()
                self.progress.configure(mode="determinate")
            except self.tk.TclError:
                pass
            self._progress_is_indeterminate = False
        if self.operation_started_at is not None:
            elapsed = time.monotonic() - self.operation_started_at
            self.elapsed_text.set(f"已用时 {self._format_elapsed(elapsed)}")
        self.operation_started_at = None

    def _set_app_state(self, state: str):
        self.app_state = state
        if hasattr(self, "progress_area"):
            self._show_progress_panel(state in (AppState.BUILDING, AppState.REFRESHING))

    def _show_content(self, mode: str):
        frame = {
            "table": self.table_frame,
            "loading": self.loading_frame,
            "error": self.error_frame,
        }.get(mode, self.loading_frame)
        frame.tkraise()

    # ---------- UI ----------

    def _configure_ui_styles(self):
        try:
            self.root.iconname(APP_NAME)
        except self.tk.TclError:
            pass
        style = self.ttk.Style(self.root)
        import tkinter.font as tkfont
        base_font = tkfont.nametofont("TkDefaultFont").copy()
        text_font = tkfont.nametofont("TkTextFont").copy()
        heading_font = tkfont.nametofont("TkHeadingFont").copy()
        for candidate in (base_font, text_font, heading_font):
            try:
                candidate.configure(family="Microsoft YaHei UI")
            except self.tk.TclError:
                pass
        bold_font = base_font.copy(); bold_font.configure(weight="bold")
        heading_bold = heading_font.copy(); heading_bold.configure(weight="bold")
        line_height = max(1, int(base_font.metrics("linespace") or 1))
        descent = max(1, int(base_font.metrics("descent") or 1))
        self._ui_line_height = line_height
        self._ui_gap = descent
        self._ui_bold_font = bold_font
        theme_background = style.lookup("TFrame", "background")
        if theme_background:
            try:
                self.root.configure(background=theme_background)
            except self.tk.TclError:
                pass
        style.configure(".", font=base_font)
        style.configure("Title.TLabel", font=heading_bold)
        style.configure("CardTitle.TLabel", font=bold_font)
        style.configure("CardValue.TLabel", font=heading_bold)
        style.configure("StatusLive.TLabel", font=bold_font)
        style.configure("DetailTitle.TLabel", font=heading_bold)
        style.configure("DetailValue.TLabel", font=bold_font)
        style.configure("ProgressTitle.TLabel", font=bold_font)
        style.configure("ProgressPercent.TLabel", font=bold_font)
        style.configure("LoadingTitle.TLabel", font=heading_bold)
        style.configure("LoadingSpinner.TLabel", font=heading_bold)
        style.configure("ErrorTitle.TLabel", font=heading_bold)
        style.configure("TButton", padding=(line_height, descent))
        style.configure("Treeview", rowheight=line_height + descent)
        style.configure("Treeview.Heading", padding=(descent, descent), font=bold_font)
        return text_font

    def _build_ui_header(self):
        self.outer = self.ttk.Frame(self.root, style="Root.TFrame", padding=(self._ui_line_height, self._ui_gap, self._ui_line_height, self._ui_gap))
        self.outer.pack(fill="both", expand=True)
        header = self.ttk.Frame(self.outer, style="Root.TFrame")
        header.pack(fill="x")
        titles = self.ttk.Frame(header, style="Root.TFrame")
        titles.pack(side="left", fill="x", expand=True)
        self.ttk.Label(titles, textvariable=self.result_title, style="Title.TLabel").pack(anchor="w")
        self.ttk.Label(titles, text="长期综合排名 · 结果、风险与变化一屏掌握", style="Sub.TLabel").pack(anchor="w", pady=(self._ui_gap, 0))
        self.header_status_label = self.ttk.Label(header, textvariable=self.last_update_text, style="HeaderMeta.TLabel")
        self.header_status_label.pack(side="right", anchor="e")

    def _build_ui_summary(self):
        self.cards_frame = self.ttk.Frame(self.outer, style="Root.TFrame")
        self.cards_frame.pack(fill="x", pady=(self._ui_line_height, self._ui_gap))
        self.summary_cards = []
        self._summary_card_static_widths = None

        card_specs = (
            (
                "当前第一", self.top_pick_value,
                (("相对长期质量", self.top_pick_quality), ("相对当前择时", self.top_pick_timing), ("风险", self.top_pick_risk)),
            ),
            (
                "正式候选概览", self.overview_value,
                (("目标年化中位", self.overview_target_ann), ("平均长期质量", self.overview_avg_quality), ("基金数量", self.overview_count)),
            ),
            (
                "风险结构", self.risk_value,
                (("低 / 中 / 高", self.risk_distribution), ("数据性质", self.risk_data_nature)),
            ),
            (
                "实时状态", self.live_value,
                (("净值日期", self.live_nav_date), ("下次分析", self.live_next_analysis), ("在线复核", self.live_review_state)),
            ),
        )
        for title, value_var, fields in card_specs:
            card = self.ttk.Frame(self.cards_frame, style="Card.TFrame", padding=(self._ui_line_height, self._ui_gap))
            card.columnconfigure(1, weight=1)
            self.ttk.Label(card, text=title, style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w")
            self.ttk.Label(card, textvariable=value_var, style="CardValue.TLabel").grid(
                row=1, column=0, columnspan=2, sticky="w", pady=(self._ui_gap, self._ui_gap)
            )
            for offset, (field_title, field_var) in enumerate(fields):
                row = offset + 2
                self.ttk.Label(card, text=field_title, style="CardSub.TLabel").grid(
                    row=row, column=0, sticky="w", pady=(0, self._ui_gap)
                )
                self.ttk.Label(card, textvariable=field_var, style="CardSub.TLabel", anchor="e").grid(
                    row=row, column=1, sticky="e", padx=(self._ui_line_height, 0), pady=(0, self._ui_gap)
                )
            self.summary_cards.append(card)

        self.overview_bar = self.ttk.Frame(self.outer, style="Status.TFrame", padding=(self._ui_line_height, self._ui_gap))
        self.overview_bar.pack(fill="x", pady=(0, self._ui_gap))
        self.ttk.Label(self.overview_bar, text="● LIVE", style="StatusLive.TLabel").pack(side="left", padx=(0, self._ui_line_height))
        self.overview_label = self.ttk.Label(self.overview_bar, textvariable=self.market_overview, style="StatusMeta.TLabel", justify="left")
        self.overview_label.pack(side="left", fill="x", expand=True)
        self.system_meta_label = self.ttk.Label(self.overview_bar, textvariable=self.ai_status, style="StatusMeta.TLabel")
        self.system_meta_label.pack(side="right", padx=(self._ui_line_height, 0))

    def _build_ui_table(self, font):
        self.content_container = self.ttk.Frame(self.outer, style="Card.TFrame")
        self.content_container.pack(fill="both", expand=True)
        self.content_container.rowconfigure(0, weight=1)
        self.content_container.columnconfigure(0, weight=1)
        self.table_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.table_frame.grid(row=0, column=0, sticky="nsew")
        self.table_frame.rowconfigure(0, weight=1)
        self.table_frame.columnconfigure(0, weight=1)
        self.table_wrap = self.ttk.Frame(self.table_frame, style="Card.TFrame", padding=(self._ui_gap, self._ui_gap, 0, self._ui_gap))
        self.table_wrap.grid(row=0, column=0, sticky="nsew")
        self.table_wrap.rowconfigure(0, weight=1)
        self.table_wrap.columnconfigure(0, weight=1)

        columns = ("rank", "fund_name", "fund_code", "type", "quality", "timing", "risk", "target_ann", "nav")
        headings = {
            "rank": "排名 / 变化", "fund_name": "基金名称", "fund_code": "基金代码", "type": "类型",
            "quality": "相对长期质量", "timing": "相对当前择时", "risk": "风险", "target_ann": "目标期限年化", "nav": "最新净值",
        }
        self.tree = self.ttk.Treeview(self.table_wrap, columns=columns, show="headings", selectmode="browse")
        try:
            import tkinter.font as tkfont
            style = self.ttk.Style(self.tree)
            heading_font_name = style.lookup("Treeview.Heading", "font") or "TkHeadingFont"
            heading_font = tkfont.Font(font=heading_font_name)
            pad = max(1, int(heading_font.metrics("linespace")))
            initial_width = {column: max(1, heading_font.measure(headings[column]) + pad) for column in columns}
        except (self.tk.TclError, ImportError):
            initial_width = {column: 1 for column in columns}
        for column in columns:
            self.tree.heading(column, text=headings[column], anchor="center")
            self.tree.column(
                column,
                width=initial_width[column],
                minwidth=initial_width[column],
                anchor="center",
                stretch=False,
            )

        self.vscrollbar = self.ttk.Scrollbar(self.table_wrap, orient="vertical", command=self.tree.yview)
        self.hscrollbar = self.ttk.Scrollbar(self.table_wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=self.vscrollbar.set, xscrollcommand=self.hscrollbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.vscrollbar.grid(row=0, column=1, sticky="ns")
        self.hscrollbar.grid(row=1, column=0, sticky="ew")
        self.tree.tag_configure("top1", font=self._ui_bold_font)
        self.tree.bind("<<TreeviewSelect>>", self._update_detail_panel)
        self.tree.bind("<Configure>", lambda _event: self._schedule_table_resize(), add="+")
        self._build_ui_detail(font)

    def _build_ui_detail(self, font):
        self.detail_frame = self.ttk.Frame(self.table_frame, style="Detail.TFrame", padding=(self._ui_line_height, self._ui_gap))
        self.detail_frame.grid(row=0, column=1, sticky="nsew", padx=(self._ui_line_height, 0))
        self.detail_frame.columnconfigure(0, weight=1)
        self.detail_labels = []
        title_label = self.ttk.Label(self.detail_frame, textvariable=self.detail_title, style="DetailTitle.TLabel", justify="left", width=1)
        title_label.grid(row=0, column=0, sticky="ew")
        meta_label = self.ttk.Label(self.detail_frame, textvariable=self.detail_meta, style="DetailMeta.TLabel", justify="left", width=1)
        meta_label.grid(row=1, column=0, sticky="ew", pady=(self._ui_gap, self._ui_gap))
        self.detail_labels.extend([title_label, meta_label])

        self.detail_metrics_frame = self.ttk.Frame(self.detail_frame, style="Detail.TFrame")
        self.detail_metrics_frame.grid(row=2, column=0, sticky="ew")
        self.detail_metrics_frame.columnconfigure(1, weight=1)
        self.detail_metric_vars = {}
        metric_specs = (
            ("quality", "相对长期质量"), ("timing", "相对当前择时"),
            ("target_ann", "目标期限年化"), ("drawdown", "目标期限回撤"),
            ("risk", "风险"), ("nav", "最新净值"),
            ("return_volatility_ratio", "目标收益/波动"), ("history_years", "可用历史年数"),
            ("percentile", "同类百分位"), ("consistency", "模型稳定"),
            ("nav_date", "净值日期"), ("cost", "目标持有成本"),
        )
        for row, (key, title) in enumerate(metric_specs):
            variable = self.tk.StringVar(value="—")
            self.detail_metric_vars[key] = variable
            title_widget = self.ttk.Label(self.detail_metrics_frame, text=title, style="DetailMeta.TLabel")
            value_widget = self.ttk.Label(self.detail_metrics_frame, textvariable=variable, style="DetailValue.TLabel", anchor="e")
            title_widget.grid(row=row, column=0, sticky="w", pady=self._ui_gap)
            value_widget.grid(row=row, column=1, sticky="e", padx=(self._ui_line_height, 0), pady=self._ui_gap)
        self.detail_frame.bind("<Configure>", self._resize_detail_wrap, add="+")

    def _build_ui_states_and_progress(self):
        self.loading_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.loading_frame.grid(row=0, column=0, sticky="nsew")
        loading_center = self.ttk.Frame(self.loading_frame, style="Card.TFrame")
        loading_center.place(relx=PROBABILITY_MIDPOINT, rely=PROBABILITY_MIDPOINT, anchor="center")
        self.ttk.Label(loading_center, textvariable=self.loading_spinner, style="LoadingSpinner.TLabel").pack()
        self.ttk.Label(loading_center, text="正在准备基金排名", style="LoadingTitle.TLabel").pack(pady=(self._ui_line_height, self._ui_gap))
        self.ttk.Label(loading_center, textvariable=self.status, style="LoadingBody.TLabel").pack()
        self.ttk.Label(loading_center, textvariable=self.progress_percent, style="CardValue.TLabel").pack(pady=(self._ui_gap, self._ui_gap))
        self.ttk.Label(loading_center, text="首次分析可能需要一些时间，结果会分阶段出现", style="LoadingBody.TLabel").pack()
        self.ttk.Label(loading_center, textvariable=self.elapsed_text, style="LoadingBody.TLabel").pack(pady=(self._ui_gap, 0))

        self.error_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.error_frame.grid(row=0, column=0, sticky="nsew")
        error_center = self.ttk.Frame(self.error_frame, style="Card.TFrame")
        error_center.place(relx=PROBABILITY_MIDPOINT, rely=PROBABILITY_MIDPOINT, anchor="center")
        self.ttk.Label(error_center, textvariable=self.error_title, style="ErrorTitle.TLabel").pack()
        self.error_body_label = self.ttk.Label(error_center, textvariable=self.error_message, style="ErrorBody.TLabel", justify="center")
        self.error_body_label.pack(pady=(self._ui_line_height, self._ui_gap), fill="x")
        error_center.bind("<Configure>", lambda event: self.error_body_label.configure(wraplength=max(1, event.width)), add="+")
        self.ttk.Label(error_center, textvariable=self.retry_text, style="LoadingBody.TLabel").pack(pady=(0, self._ui_line_height))

        self.progress_area = self.ttk.Frame(self.outer, style="Card.TFrame", padding=(self._ui_line_height, self._ui_gap))
        self.progress_area.pack(fill="x", pady=(self._ui_gap, 0))
        progress_header = self.ttk.Frame(self.progress_area, style="Card.TFrame")
        progress_header.pack(fill="x")
        self.ttk.Label(progress_header, textvariable=self.status, style="ProgressTitle.TLabel").pack(side="left")
        self.ttk.Label(progress_header, textvariable=self.progress_percent, style="ProgressPercent.TLabel").pack(side="right")
        self.progress = self.ttk.Progressbar(self.progress_area, variable=self.progress_value, maximum=PERCENT_SCALE, mode="determinate")
        self.progress.pack(fill="x", pady=(self._ui_gap, self._ui_gap))
        detail_row = self.ttk.Frame(self.progress_area, style="Card.TFrame")
        detail_row.pack(fill="x")
        self.progress_detail_label = self.ttk.Label(detail_row, textvariable=self.progress_detail, style="ProgressDetail.TLabel", justify="left")
        self.progress_detail_label.pack(side="left", fill="x", expand=True)
        self.progress_elapsed_label = self.ttk.Label(detail_row, textvariable=self.elapsed_text, style="ProgressDetail.TLabel")
        self.progress_elapsed_label.pack(side="right", padx=(self._ui_line_height, 0))

        self.progress_metrics_frame = self.ttk.Frame(self.progress_area, style="Card.TFrame")
        self.progress_metrics_frame.pack(fill="x", pady=(self._ui_gap, 0))
        self.progress_metric_vars = {}
        self.progress_metric_widgets = []
        for key, title in (
            ("stage", "阶段"), ("market", "全市场"), ("handled", "本阶段已处理"),
            ("valid", "有效"), ("rate", "速度"), ("eta", "预计还需"),
            ("concurrency", "并发"), ("cpu", "CPU"), ("memory", "内存"),
        ):
            variable = self.tk.StringVar(value="—")
            self.progress_metric_vars[key] = variable
            cell = self.ttk.Frame(self.progress_metrics_frame, style="Card.TFrame")
            cell.columnconfigure(0, weight=0)
            cell.columnconfigure(1, weight=0)
            self.ttk.Label(cell, text=title, style="ProgressDetail.TLabel").grid(row=0, column=0, sticky="e")
            self.ttk.Label(cell, textvariable=variable, style="ProgressDetail.TLabel", anchor="w").grid(
                row=0, column=1, sticky="w", padx=(self._ui_gap, 0)
            )
            self.progress_metric_widgets.append(cell)
        self.progress_area.bind("<Configure>", self._resize_progress_wrap, add="+")
        self.progress_area.bind("<Configure>", lambda _event: self._layout_progress_metrics(), add="+")

    def _build_ui(self):
        self.root.title(APP_NAME)
        self._configure_initial_window()
        font = self._configure_ui_styles()
        self._build_ui_header()
        self._build_ui_summary()
        self._build_ui_table(font)
        self._build_ui_states_and_progress()
        self.root.bind("<Configure>", self._on_window_resize, add="+")
        self.root.after_idle(lambda: self._apply_responsive_layout(self.root.winfo_width(), self.root.winfo_height()))
        self._show_content("loading")
        self._set_app_state(AppState.STARTING)
        self._show_progress_panel(False)


    def _configure_initial_window(self):
        self.root.update_idletasks()
        if os.name == "nt":
            try:
                self.root.state("zoomed")
                return
            except self.tk.TclError:
                pass
        sw = max(1, int(self.root.winfo_screenwidth() or 1))
        sh = max(1, int(self.root.winfo_screenheight() or 1))
        self.root.geometry(f"{sw}x{sh}+0+0")

    def _on_window_resize(self, event):
        if event.widget is not self.root:
            return
        if self._resize_job is not None:
            try:
                self.root.after_cancel(self._resize_job)
            except self.tk.TclError:
                pass
        width, height = int(event.width), int(event.height)
        def apply_resize(w=width, h=height):
            self._resize_job = None
            self._apply_responsive_layout(w, h)
        self._resize_job = self.root.after_idle(apply_resize)

    def _apply_responsive_layout(self, width, height):
        self._resize_job = None
        self.root.update_idletasks()
        content_width = max(1, int(self.content_container.winfo_width() or width))
        table_minimum = sum(max(1, int(self.tree.column(column, "minwidth"))) for column in self.tree["columns"])
        if not hasattr(self, "_detail_static_minimum"):
            self._detail_static_minimum = max(
                1, int(self.detail_metrics_frame.winfo_reqwidth() or 1),
                int(self._ui_line_height * max(1, len("目标期限年化"))),
            )
        detail_minimum = self._detail_static_minimum
        mode = "side" if content_width >= table_minimum + detail_minimum else "stacked"

        # Summary-card wrapping depends only on the window and the initial static card structure.
        # Live fund names/numbers never change the one-row/two-row decision.
        for card in self.summary_cards:
            card.grid_forget()
        for column in range(len(self.summary_cards)):
            self.cards_frame.columnconfigure(column, weight=0, uniform="")
        cards_width = max(1, int(self.cards_frame.winfo_width() or width))
        if self._summary_card_static_widths is None:
            self._summary_card_static_widths = tuple(max(1, int(card.winfo_reqwidth() or 1)) for card in self.summary_cards)
        requested = self._summary_card_static_widths
        one_row = sum(requested) <= cards_width
        columns = len(self.summary_cards) if one_row else max(1, int(math.floor(math.sqrt(len(self.summary_cards)))))
        for column in range(columns):
            self.cards_frame.columnconfigure(column, weight=1, uniform="summary")
        for index, card in enumerate(self.summary_cards):
            row, column = divmod(index, columns)
            card.grid(row=row, column=column, sticky="nsew")

        if mode != self._layout_mode:
            self.detail_frame.grid_forget()
            self.table_frame.rowconfigure(0, weight=1)
            self.table_frame.rowconfigure(1, weight=0)
            self.table_frame.columnconfigure(0, weight=1)
            self.table_frame.columnconfigure(1, weight=0)
            if mode == "side":
                self.detail_frame.grid(row=0, column=1, sticky="nsew", padx=(self._ui_gap, 0))
            else:
                self.detail_frame.grid(row=1, column=0, sticky="ew", pady=(self._ui_gap, 0))
            self.detail_frame.grid_propagate(True)
            self._layout_mode = mode

        # Hide only secondary system metadata when it cannot coexist with the live overview;
        # the investment explanation itself is never hidden in any responsive mode.
        overview_width = max(1, int(self.overview_bar.winfo_width() or width))
        overview_need = int(self.overview_label.winfo_reqwidth() or 1) + int(self.system_meta_label.winfo_reqwidth() or 1)
        if overview_need > overview_width:
            self.system_meta_label.pack_forget()
        elif not self.system_meta_label.winfo_manager():
            self.system_meta_label.pack(side="right")
        self._resize_table_columns()
        self._resize_detail_wrap()
        if hasattr(self, "_layout_progress_metrics"):
            self._layout_progress_metrics()
        live_label_width = sum(int(widget.winfo_reqwidth() or 0) for widget in self.overview_bar.pack_slaves() if widget is not self.overview_label)
        self.overview_label.configure(wraplength=max(1, overview_width - live_label_width))

    def _schedule_table_resize(self):
        job = getattr(self, "_table_resize_job", None)
        if job is not None:
            try:
                self.root.after_cancel(job)
            except self.tk.TclError:
                pass
        self._table_resize_job = self.root.after(50, self._resize_table_columns)

    def _resize_table_columns(self, _event=None):
        if not hasattr(self, "tree"):
            return
        self._table_resize_job = None
        width = max(1, int(self.tree.winfo_width() or 1))
        columns = list(self.tree["columns"])
        if not columns:
            return
        try:
            import tkinter.font as tkfont
            style = self.ttk.Style(self.tree)
            body_font_name = style.lookup("Treeview", "font") or "TkDefaultFont"
            heading_font_name = style.lookup("Treeview.Heading", "font") or "TkHeadingFont"
            body_font = tkfont.Font(font=body_font_name)
            heading_font = tkfont.Font(font=heading_font_name)
            pad = max(1, int(max(body_font.metrics("linespace"), heading_font.metrics("linespace"))))
            measured = {}
            minimums = {}
            rows = self.tree.get_children("")
            for position, column in enumerate(columns):
                heading = str(self.tree.heading(column, "text") or "")
                heading_width = heading_font.measure(heading) + pad
                content_width = heading_width
                for item_id in rows:
                    values = self.tree.item(item_id, "values") or ()
                    if position < len(values):
                        content_width = max(content_width, body_font.measure(str(values[position])) + pad)
                minimums[column] = max(1, heading_width)
                measured[column] = max(minimums[column], content_width)
        except (self.tk.TclError, ImportError):
            minimums = {column: max(1, int(self.tree.column(column, "minwidth"))) for column in columns}
            measured = dict(minimums)

        targets = dict(measured)
        required = sum(targets.values())
        if required < width:
            weights = {
                "rank": 0.8,
                "fund_name": 3.0,
                "fund_code": 1.1,
                "type": 1.3,
                "quality": 1.2,
                "timing": 1.2,
                "risk": 0.8,
                "target_ann": 1.4,
                "nav": 1.1,
            }
            spare = width - required
            total_weight = sum(max(0.0, weights.get(column, 1.0)) for column in columns) or 1.0
            allocated = 0
            for index, column in enumerate(columns):
                if index == len(columns) - 1:
                    extra = spare - allocated
                else:
                    extra = int(spare * max(0.0, weights.get(column, 1.0)) / total_weight)
                    allocated += extra
                targets[column] += max(0, extra)
        # If content exceeds the viewport, keep measured widths and let the horizontal scrollbar
        # preserve every cell's text instead of silently truncating it.
        for column in columns:
            self.tree.column(
                column,
                minwidth=measured[column],
                width=max(measured[column], targets[column]),
                anchor="center",
                stretch=False,
            )

    def _resize_detail_wrap(self, event=None):
        if not hasattr(self, "detail_labels"):
            return
        width = max(1, int(getattr(event, "width", 0) or self.detail_frame.winfo_width() or 1))
        for label in self.detail_labels:
            try:
                label.configure(wraplength=width)
            except self.tk.TclError:
                pass

    def _resize_progress_wrap(self, event=None):
        if not hasattr(self, "progress_detail_label"):
            return
        width = max(1, int(getattr(event, "width", 0) or self.progress_area.winfo_width() or 1))
        elapsed_width = max(0, int(getattr(self, "progress_elapsed_label", self.progress_detail_label).winfo_reqwidth() or 0))
        self.progress_detail_label.configure(wraplength=max(1, width - elapsed_width))

    def _sync_progress_metrics(self, text: str) -> str:
        raw = re.sub(r"\s+", " ", str(text or "")).strip()
        if not hasattr(self, "progress_metric_vars"):
            return raw
        values = {key: "—" for key in self.progress_metric_vars}

        stage_match = re.search(r"(阶段\d+/\d+[^·；]*|全量历史扫描|全市场历史扫描|长期模型阶段|结构阶段)", raw)
        if stage_match:
            values["stage"] = stage_match.group(1).strip()
        market_match = re.search(r"全市场\s+(\d+\s*/\s*\d+)", raw)
        if market_match:
            values["market"] = market_match.group(1).replace(" ", "")
        handled_match = re.search(r"本阶段已(?:处理|续跑)\s+(\d+\s*/\s*\d+)", raw)
        if handled_match:
            values["handled"] = handled_match.group(1).replace(" ", "")
        valid_match = re.search(r"有效\s+(\d+)", raw)
        if valid_match:
            values["valid"] = valid_match.group(1)
        rate_match = re.search(r"([^·；\s]+)只/秒", raw)
        if rate_match:
            values["rate"] = f"{rate_match.group(1)} 只/秒"
        eta_match = re.search(r"本阶段预计还需\s+([^·；]+)", raw)
        if eta_match:
            values["eta"] = eta_match.group(1).strip()
        concurrency_match = re.search(r"并发\s*(\d+)", raw)
        if concurrency_match:
            values["concurrency"] = concurrency_match.group(1)
        cpu_match = re.search(r"CPU空闲\s*([^·；]+)", raw)
        if cpu_match:
            values["cpu"] = f"空闲 {cpu_match.group(1).strip()}"
        memory_match = re.search(r"内存余量\s*([^·；]+)", raw)
        if memory_match:
            values["memory"] = f"余量 {memory_match.group(1).strip()}"
        for key, value in values.items():
            self.progress_metric_vars[key].set(value)

        recognized = any(value != "—" for value in values.values())
        if not recognized:
            return raw
        # Keep only descriptive text that is not already represented by a dedicated metric cell.
        pieces = [piece.strip() for piece in re.split(r"\s*[·；]\s*", raw) if piece.strip()]
        metric_tokens = (
            "全市场 ", "本阶段已处理", "本阶段已续跑", "有效 ", "只/秒",
            "本阶段预计还需", "并发", "CPU空闲", "内存余量", "实时资源自动调节",
        )
        descriptive = [
            piece for piece in pieces
            if not any(token in piece for token in metric_tokens)
            and not re.match(r"阶段\d+/\d+", piece)
        ]
        if descriptive:
            return "；".join(descriptive)
        return values.get("stage") if values.get("stage") != "—" else "实时指标已拆分显示"

    def _layout_progress_metrics(self):
        if not hasattr(self, "progress_metric_widgets") or not self.progress_metric_widgets:
            return
        try:
            self.root.update_idletasks()
        except self.tk.TclError:
            return
        width = max(1, int(self.progress_metrics_frame.winfo_width() or self.progress_area.winfo_width() or 1))
        requested = tuple(
            max(1, int(widget.winfo_reqwidth() or 1))
            for widget in self.progress_metric_widgets
        )
        if max(requested, default=1) <= 1:
            self.root.after_idle(self._layout_progress_metrics)
            return

        def required_width(column_count):
            column_widths = [0] * column_count
            for index, widget_width in enumerate(requested):
                column = index % column_count
                column_widths[column] = max(column_widths[column], widget_width)
            # Match the real grid padding below so the chosen column count never overcommits width.
            padding = self._ui_line_height * max(0, 2 * column_count - 1)
            return sum(column_widths) + padding

        columns = 1
        for candidate in range(1, len(requested) + 1):
            if required_width(candidate) <= width:
                columns = candidate
            else:
                break
        for widget in self.progress_metric_widgets:
            widget.grid_forget()
        for column in range(len(self.progress_metric_widgets)):
            self.progress_metrics_frame.columnconfigure(column, weight=0, uniform="")
        for index, widget in enumerate(self.progress_metric_widgets):
            row, column = divmod(index, columns)
            widget.grid(
                row=row,
                column=column,
                sticky="w",
                padx=(0 if column == 0 else self._ui_line_height, self._ui_line_height),
                pady=(0, self._ui_gap),
            )

    def _show_progress_panel(self, visible):
        if not hasattr(self, "progress_area"):
            return
        # Reserve this area permanently so starting/finishing a refresh never moves the table.
        if not self.progress_area.winfo_manager():
            self.progress_area.pack(fill="x", pady=(self._ui_gap, 0))
        self._layout_progress_metrics()

    def _sync_live_status(self):
        if not hasattr(self, "live_value"):
            return
        if self.refreshing:
            self.live_value.set("刷新中")
        elif self._display_result_state == "current_verified":
            self.live_value.set("● 数据在线")
        elif self._display_result_state == "last_known_good" and self.formal_results_ready:
            self.live_value.set("上次有效结果")
        elif self._display_result_state == "basic_screening" and self.basic_screening_ready:
            self.live_value.set("基础筛选")
        elif self.app_state == AppState.RETRY_WAIT:
            self.live_value.set("等待重试")
        else:
            self.live_value.set(str(self.data_status.get() or "准备中"))
        date = str(self.data_date.get() or "—")
        clock = str(self.clock.get() or "—")
        self.live_nav_date.set(date)
        self.live_next_analysis.set(clock)
        if self.refreshing:
            self.live_review_state.set("复核中")
        elif self._display_result_state == "current_verified":
            self.live_review_state.set("已通过")
        elif self._display_result_state == "last_known_good" and self.formal_results_ready:
            self.live_review_state.set("在线复核未完成")
        elif self._display_result_state == "basic_screening" and self.basic_screening_ready:
            self.live_review_state.set("严格 PIT 待成熟")
        elif self.app_state == AppState.RETRY_WAIT:
            self.live_review_state.set("自动重试")
        else:
            self.live_review_state.set("等待复核")

    def _update_dashboard_summary(self, results, previous_ranks=None):
        results = list(results or [])
        if not results:
            self.market_overview.set("LIVE · 暂无可展示结果")
            return
        previous_ranks = previous_ranks or {}
        top = results[0]
        quality = _finite(top.get("LongTermQualityScore"), float("nan"))
        timing = _finite(top.get("EntryTimingScore"), float("nan"))
        top_code = str(top.get("code") or "—")
        self.top_pick_value.set(f"#1 {top_code}")
        q_text = _format_unrounded_number(quality)
        t_text = _format_unrounded_number(timing)
        self.top_pick_quality.set(q_text)
        self.top_pick_timing.set(t_text)
        self.top_pick_risk.set(str(top.get("risk") or "—"))

        target_ann_values, qualities = [], []
        risk_counts = {"低": 0, "中": 0, "高": 0}
        up = down = new = same = 0
        for rank, item in enumerate(results, 1):
            stats = item.get("stats") or {}
            target_ann = _finite(stats.get("return_target_ann"), float("nan"))
            if math.isfinite(target_ann):
                target_ann_values.append(target_ann)
            q = _finite(item.get("LongTermQualityScore"), float("nan"))
            if math.isfinite(q):
                qualities.append(q)
            risk = str(item.get("risk") or "")
            if "低" in risk:
                risk_counts["低"] += 1
            elif "高" in risk:
                risk_counts["高"] += 1
            else:
                risk_counts["中"] += 1
            old_rank = previous_ranks.get(str(item.get("code")))
            if old_rank is None:
                new += 1
            else:
                delta = old_rank - rank
                if delta > 0:
                    up += 1
                elif delta < 0:
                    down += 1
                else:
                    same += 1

        median_target_ann = statistics.median(target_ann_values) if target_ann_values else float("nan")
        avg_quality = statistics.mean(qualities) if qualities else float("nan")
        ann_text = _format_unrounded_number(median_target_ann, "%", signed=True, scale=PERCENT_SCALE)
        quality_text = _format_unrounded_number(avg_quality)
        self.overview_value.set(f"Top{len(results)}")
        self.overview_target_ann.set(ann_text)
        self.overview_avg_quality.set(quality_text)
        self.overview_count.set(f"{len(results)} 只")
        self.risk_value.set("风险结构")
        self.risk_distribution.set(f"{risk_counts['低']} / {risk_counts['中']} / {risk_counts['高']}")
        self.risk_data_nature.set("公开数据推断")
        self.market_overview.set(
            f"Top{len(results)}    ↑ {up}    ↓ {down}    NEW {new}"
        )
        self._sync_live_status()

    # ---------- dependency preparation ----------

    def _ensure_dependency_prepare_started(self):
        if _storage_survival_mode_active():
            self.ai_background_status.set("磁盘空间保护 · 暂停 AI 依赖准备")
            return
        if self._dependency_prepare_started or self.stop_event.is_set():
            return
        self._dependency_prepare_started = True
        self.ai_background_status.set("AI 增强组件：后台准备中")
        self._start_dependency_prepare()

    def _start_dependency_prepare(self):
        """Prepare optional AI backends only after the first usable ranking is visible."""
        def worker():
            try:
                before = _load_install_settings()
                before_target = _active_dependency_dir(before)
                before_required = bool(before.get("lightgbm") is True or before.get("advanced_tree") is True)
                before_ok = False
                if before_required and before_target is not None:
                    before_ok, _ = _dependency_import_probe(before_target, before)
                settings = _configure_hardware_adaptive(
                    force=False,
                    allow_install=True,
                    status_callback=lambda text: self.events.put(("dependency_progress", text)),
                )
                after_target = _active_dependency_dir(settings)
                pending_target = _pending_dependency_dir(settings, require_import_probe=True)
                after_required = bool(settings.get("lightgbm") is True or settings.get("advanced_tree") is True)
                after_ok = False
                training_target = None
                if pending_target is not None:
                    training_target = pending_target
                    after_ok = True
                    detail = "新 AI 依赖 manifest/ABI/安装后文件树/import 已核验；GUI 不热切 DLL，空闲后由独立训练进程立即使用"
                elif after_required and after_target is not None:
                    after_ok, detail = _dependency_import_probe(after_target, settings)
                    if after_ok:
                        training_target = after_target
                else:
                    detail = "标准库后端"
                became_ready = bool(
                    after_required and after_ok and training_target is not None
                    and (not before_ok or before_target != training_target)
                )
                self.events.put(("dependency_ready", became_ready, _now_iso(), detail))
            except Exception as exc:
                _record_diagnostic("dependency-background", exc)
                self.events.put(("dependency_failed", f"{type(exc).__name__}: {exc}"))
            finally:
                self.events.put(("dependency_prepare_done",))

        self.workers.start(target=worker, name="ai-dependency-prepare")

    def _maybe_start_advanced_retrain(self):
        if (
            not self._advanced_retrain_pending
            or self._advanced_retrain_started
            or self.busy
            or self.refreshing
            or self.maintenance_running
            or self.stop_event.is_set()
            or _storage_survival_mode_active()
        ):
            return
        if not self.operation_coordinator.try_begin(ExclusiveOperation.RETRAIN):
            return
        requested_reason = str(self._background_retrain_reason or "")
        training_dir = _preferred_training_dependency_dir()
        if not requested_reason and not _model_missed_dependency_ready(self.engine.store.model, self._dependency_ready_at, training_dir):
            self._advanced_retrain_pending = False
            self.operation_coordinator.finish(ExclusiveOperation.RETRAIN)
            self.ai_background_status.set("AI 增强组件已就绪 · 当前模型无需重复训练")
            return
        self._advanced_retrain_pending = False
        self._advanced_retrain_started = True
        self._background_retrain_reason = ""
        self.busy = True
        if requested_reason:
            self.ai_background_status.set("正式结果已可用 · AI 正在后台训练")
        else:
            self.ai_background_status.set("AI 增强组件：正在用本地历史补训")
        holding_years = None

        def worker():
            try:
                previous_model = dict(self.engine.store.model)
                model = self.engine.retrain_model_from_current_history(
                    lambda text, pct: self.events.put(("dependency_retrain_progress", text, pct)),
                    reason=requested_reason or "advanced-ai-became-ready-after-model-training",
                )
                if model.get("strict_pit_production") is not True and model.get("shadow_candidate_available") is True:
                    basic = self.engine.basic_screening_result(holding_years, "shadow challenger 已完成 AI/GPU 训练；严格 PIT 尚未成熟，继续使用基础筛选")
                    self.events.put(("shadow_candidate_ready", basic))
                    return
                gate = self.engine._final_freshness_gate(
                    holding_years,
                    lambda text, pct: self.events.put(("dependency_retrain_progress", text, pct)),
                )
                if not gate.get("ok"):
                    self.engine.store.model = previous_model
                    self.engine.feature_cache.clear()
                    raise DataError("AI 新模型未通过最终净值/历史数据门控")
                ranking_result = self.engine._commit_verified_top100(
                    self.engine._last_verified_rows, holding_years, gate,
                    model=model, rollback_model=previous_model,
                )
                self.events.put(("advanced_retrain_results", ranking_result))
            except Exception as exc:
                _record_diagnostic("advanced-ai-retrain", exc)
                fallback = self.engine.result_for_display(holding_years)
                self.events.put(("dependency_retrain_error", f"{type(exc).__name__}: {exc}", fallback))
            finally:
                self.events.put(("advanced_retrain_done",))

        self.workers.start(target=worker, name="advanced-ai-retrain")

    def _start_background_integrity_verification(self) -> None:
        if self._background_integrity_started or self.stop_event.is_set() or _storage_survival_mode_active():
            return
        self._background_integrity_started = True

        def worker():
            try:
                LocalStore.check_cache_integrity()
            except Exception as exc:
                _record_diagnostic("background-sqlite-integrity", exc)
            try:
                settings = _load_install_settings()
                active_dependency = _active_dependency_dir(settings)
                if active_dependency is None:
                    return
                ok, detail, _manifest = _verify_dependency_generation(
                    active_dependency, settings, require_import_probe=True,
                    force_tree_rehash=True, force_import_probe=True,
                )
                if not ok:
                    def disable_invalid_dependency(current_settings):
                        if str(current_settings.get("active_dependency_dir") or "") == active_dependency.name:
                            current_settings["active_dependency_dir"] = ""
                        current_settings["dependency_install_status"] = "background-full-verify-failed"
                        current_settings["dependency_install_error"] = str(detail)
                    _update_install_settings(disable_invalid_dependency)
                    try:
                        sys.path.remove(str(active_dependency))
                    except ValueError:
                        pass
                    _record_diagnostic("background-dependency-integrity", detail, "ImportVerifyFailed")
            except Exception as exc:
                _record_diagnostic("background-dependency-integrity", exc)

        self.workers.start(target=worker, name="background-integrity-verify")

    # ---------- maintenance ----------

    def _schedule_objective_maintenance(self, *, immediate: bool = False) -> None:
        """Schedule only from an observed trigger or the next persisted cohort maturity."""
        if _storage_survival_mode_active():
            self.next_maintenance = float("inf")
            return
        if immediate:
            self.next_maintenance = min(self.next_maintenance, time.monotonic())
            return
        candidates = []
        maturity_at = self.engine.store.next_prediction_maturity_at()
        if maturity_at is not None:
            candidates.append(maturity_at.astimezone(CHINA_TZ))
        contract_at = self.engine.next_source_contract_recheck_at()
        if contract_at is not None:
            candidates.append(contract_at.astimezone(CHINA_TZ))
        shadow_at = _parse_iso((self.engine.store.model or {}).get("shadow_candidate_trained_at"))
        if shadow_at is not None and (self.engine.store.model or {}).get("shadow_candidate_available") is True:
            if shadow_at.tzinfo is None:
                shadow_at = shadow_at.replace(tzinfo=CHINA_TZ)
            candidates.append(shadow_at.astimezone(CHINA_TZ) + _dt.timedelta(days=SHADOW_STRICT_PIT_RECHECK_DAYS))
        if not candidates:
            self.next_maintenance = float("inf")
            return
        now_cn = _dt.datetime.now(tz=CHINA_TZ)
        delay = max(0.0, (min(candidates) - now_cn).total_seconds())
        self.next_maintenance = time.monotonic() + delay

    def _maybe_start_maintenance(self):
        if _storage_survival_mode_active():
            _storage_survival_recheck()
            return
        if self.maintenance_running or self.busy or self.refreshing or not (self.formal_results_ready or self.basic_screening_ready) or self.stop_event.is_set():
            return
        if not self.operation_coordinator.try_begin(ExclusiveOperation.MAINTENANCE):
            return
        self.maintenance_running = True
        holding_years = None

        def worker():
            try:
                status = self.engine.maintenance_status()
                if status.get("survival_mode"):
                    self.events.put(("maintenance_checked", status))
                    return
                if status.get("due"):
                    if not (self._dependency_prepare_started and not self._dependency_prepare_finished):
                        _configure_hardware_adaptive(force=False, allow_install=True)
                    self.events.put((
                        "maintenance_progress",
                        f"后台维护：模型 {_format_unrounded_number(status.get('model_age_days', 0))} 天 · 候选池变化 {_format_unrounded_number(status.get('availability_change_ratio', 0), '%', scale=PERCENT_SCALE)}",
                    ))
                    rebuild_outcome = self.engine.rebuild(
                        lambda text, pct: self.events.put(("maintenance_progress_value", text, pct)),
                        force=False,
                        quick_holding_years=holding_years,
                    )
                    ranking_result = self.engine.result_for_display(holding_years)
                    if ranking_result is None:
                        ranking_result = rebuild_outcome.get("basic_screening_result")
                    if ranking_result is None:
                        raise DataError("后台维护后没有可用的正式排名快照或基础筛选结果")
                    self.events.put(("maintenance_results", ranking_result, status))
                    if rebuild_outcome.get("background_retrain_required"):
                        self.events.put((
                            "background_retrain_requested",
                            rebuild_outcome.get("background_retrain_reason") or "maintenance-model-refresh",
                        ))
                else:
                    self.events.put(("maintenance_checked", status))
            except concurrent.futures.CancelledError:
                pass
            except Exception as exc:
                _record_diagnostic("maintenance", exc)
                self.events.put(("maintenance_error", f"{type(exc).__name__}: {exc}"))
            finally:
                self.events.put(("maintenance_done",))

        self.workers.start(target=worker, name="objective-maintenance")

    # ---------- initial analysis / refresh ----------

    def _cancel_initial_retry(self):
        self.initial_retry_due_at = None
        if self.initial_retry_job is not None:
            try:
                self.root.after_cancel(self.initial_retry_job)
            except self.tk.TclError:
                pass
            self.initial_retry_job = None

    def _schedule_initial_retry(self):
        if _storage_survival_mode_active():
            self.initial_retry_due_at = None
            self.retry_text.set("磁盘空间恢复后自动继续")
            return
        if self.stop_event.is_set() or self.formal_results_ready or self.basic_screening_ready:
            return
        self.initial_error_streak += 1
        delay = _objective_retry_delay(self.initial_error_streak)
        self._cancel_initial_retry()
        self.initial_retry_due_at = time.monotonic() + delay
        self.retry_text.set(f"{delay} 秒后自动重试 · 重试 {self.initial_error_streak}")
        self.data_status.set("等待重试")
        self.data_status_detail.set(f"{delay} 秒后自动重试")
        self.status.set("基金数据暂时不可用，程序将自动重试")
        self.progress_value.set(0)
        self.progress_percent.set("—")
        self.progress_detail.set(f"将在 {delay} 秒后自动重新连接数据源，无需操作")
        self.clock.set("等待重试")
        self.refresh_reason.set("首次数据获取未完成 · 自动重新连接")
        self.initial_retry_job = self.root.after(int(round(delay * MILLISECONDS_PER_SECOND)), self._retry_initial_if_needed)
        self._set_app_state(AppState.RETRY_WAIT)

    def _retry_initial_if_needed(self):
        self.initial_retry_job = None
        self.initial_retry_due_at = None
        if (
            not (self.formal_results_ready or self.basic_screening_ready)
            and not self.busy
            and not self.refreshing
            and not self.stop_event.is_set()
        ):
            self._start_initial(force_rebuild=True, force_source_probe=False)

    def _start_initial(self, force_rebuild: bool = False, force_source_probe: bool = False):
        if self.busy or self.refreshing or self.maintenance_running or self.stop_event.is_set():
            return
        if not self.operation_coordinator.try_begin(ExclusiveOperation.INITIAL):
            return
        _begin_http_generation()
        self._cancel_initial_retry()
        self.busy = True
        self._set_app_state(AppState.BUILDING)
        self._begin_operation("正在准备基金排名" if not force_rebuild else "正在重新分析", None, "读取本地数据并检查基金数据源")
        if not (self.formal_results_ready or self.basic_screening_ready):
            self._show_content("loading")
            self.data_status.set("正在分析")
            self.data_status_detail.set("结果会分阶段出现")
            self.retry_text.set("")

        holding_years = None

        def worker():
            try:
                if _storage_survival_mode_active():
                    ranking_result = self.engine.result_for_display(holding_years)
                    if ranking_result is None:
                        raise StorageError("用户选择目录空间不足，已进入只读保护，但当前没有可显示的 last-known-good 正式结果")
                    self.events.put(("results", ranking_result, "磁盘空间保护 · 只读显示最近一次有效正式结果"))
                    return
                # Displayability and freshness are deliberately separate. The formal snapshot is
                # recovered before any current-session NAV gate can reject stale local histories.
                cached_result = self.engine.result_for_display(holding_years)
                if cached_result is not None:
                    self.events.put(("cached_results", cached_result))
                    self._post_progress("已显示上次有效正式结果，正在检查最新数据…", 0.0)
                self.engine.load_cached(holding_years, allow_stale=True)

                needs_model_retrain = bool(self.engine.store.model.get("force_retrain_reason"))
                needs_rebuild = bool(
                    force_rebuild or cached_result is None or needs_model_retrain
                )
                label = "分析完成 · 已保留最近一次可用正式结果"

                if needs_rebuild:
                    try:
                        self.engine.ensure_source_contract(force=force_source_probe)
                    except DataError as exc:
                        _record_diagnostic("initial-source-check", exc)
                        self._post_progress("数据源检查异常，正在尝试备用方案", 0.0)
                    rebuild_outcome = self.engine.rebuild(
                        lambda text, pct: self._post_progress(text, pct),
                        force=force_rebuild,
                        quick_holding_years=holding_years,
                        preview_callback=(
                            (lambda result: self.events.put(("preview_results", result)))
                            if cached_result is None else None
                        ),
                    )
                    ranking_result = self.engine.result_for_display(holding_years)
                    if ranking_result is None:
                        ranking_result = rebuild_outcome.get("basic_screening_result")
                    if ranking_result is None:
                        raise DataError("最终门控未通过，且尚无可回退的正式快照或基础筛选结果")
                    if ranking_result.state == "current_verified":
                        label = f"分析完成 · 当前 {len(ranking_result.rows)} 只满足正式买入条件"
                    elif ranking_result.state == "basic_screening":
                        label = "分析完成 · 长期历史证据不足，当前使用基础筛选（非正式买入结论）"
                    else:
                        label = "分析完成 · 已保留最近一次有效正式结果"
                else:
                    try:
                        outcome = self.engine.refresh_latest(
                            holding_years,
                            progress=lambda text, pct: self._post_progress(text, pct),
                        )
                        ranking_result = outcome["ranking_result"]
                        if ranking_result.state == "current_verified":
                            label = "上次有效正式结果已完成最新净值与排名边界复核"
                        else:
                            label = "已显示上次有效正式结果 · 当前复核覆盖不足"
                    except Exception as exc:
                        _record_diagnostic("initial-cached-freshness", exc)
                        ranking_result = self.engine.result_for_display(holding_years)
                        if ranking_result is None:
                            raise
                        label = "已显示上次有效正式结果 · 当前在线复核未完成"

                self.events.put(("results", ranking_result, label))
                if needs_rebuild and rebuild_outcome.get("background_retrain_required"):
                    self.events.put((
                        "background_retrain_requested",
                        rebuild_outcome.get("background_retrain_reason") or "initial-model-training",
                    ))
            except Exception as exc:
                _record_diagnostic("initial-analysis", exc)
                fallback = self.engine.result_for_display(holding_years)
                if fallback is not None:
                    self.events.put(("results", fallback, "已显示上次有效正式结果 · 当前在线复核失败，程序将自动重试"))
                else:
                    self.events.put(("error", str(exc)))
            finally:
                self.events.put(("done",))

        self.workers.start(target=worker, name="initial-analysis")

    def _start_refresh(self):
        if self.stop_event.is_set():
            return
        if _storage_survival_mode_active():
            if _storage_survival_recheck():
                self.next_refresh = float("inf")
                self.clock.set("只读保护")
                self.refresh_reason.set("磁盘空间不足 · 保留 last-known-good，空间恢复后自动继续")
                self.data_status.set("● 只读 last-known-good")
                self.data_status_detail.set("停止训练与非必要历史扩充；无需额外操作")
                return
            self._start_initial(force_rebuild=True, force_source_probe=False)
            return
        if self.refreshing or self.busy or self.maintenance_running:
            return

        if not self.formal_results_ready:
            self._start_initial(force_rebuild=True, force_source_probe=False)
            return
        if not self.operation_coordinator.try_begin(ExclusiveOperation.REFRESH):
            return
        _begin_http_generation()

        self.refreshing = True
        self._set_app_state(AppState.REFRESHING)
        self.data_status.set("正在刷新")
        self.data_status_detail.set("当前列表保留，完成后自动更新")
        self.clock.set("刷新中…")
        self.refresh_reason.set("正在根据市场、数据源与候选边界自适应复核")
        self._begin_operation(
            "正在检查最新基金数据", 0.0,
            "自动刷新：复核数据源、基金详情、净值新鲜度与排名边界",
        )

        holding_years = None

        def worker():
            started = time.monotonic()
            try:
                outcome = self.engine.refresh_latest(
                    holding_years,
                    progress=lambda text, pct: self._post_progress(text, pct),
                )
                self.events.put(("refresh_results", outcome))
            except Exception as exc:
                self.events.put(("refresh_error", str(exc), time.monotonic() - started))
            finally:
                self.events.put(("refresh_done",))

        self.workers.start(target=worker, name="latest-refresh")

    # ---------- results / details ----------

    def _render(self, result: RankingResult):
        if not isinstance(result, RankingResult):
            raise DataError("UI 只接受带验证状态的 RankingResult")
        results = list(result.rows or [])
        state = result.state
        self._display_result_state = state
        formal = state in {"last_known_good", "current_verified"}
        if formal:
            results = _validate_formal_results(results)
            self.formal_results_ready = True
            self.basic_screening_ready = False
            self.result_title.set(f"基金长期优选 · 当前 {len(results)} 只满足正式买入条件（最多 {DISPLAY_TOP_N} 只）")
        elif state == "basic_screening":
            self.basic_screening_ready = True
            self.result_title.set(f"基金长期优选 · 基础筛选 {len(results)} 只（非正式买入结论）")
        else:
            self.result_title.set(f"基金长期优选 · 分析中预览 Top{len(results)}")

        # Preserve selection and old ranks before replacing current rows.
        selected_code = getattr(self, "_selected_code", None)
        selected = self.tree.selection()
        if selected:
            selected_item = self._row_items.get(selected[0])
            if selected_item:
                selected_code = selected_item.get("code")
        previous_ranks = {
            str(item.get("code")): rank
            for rank, item in enumerate(self.current, 1)
            if item.get("code") is not None
        }

        self.current = results
        self._row_items = {}
        target_years = _model_target_years(self.engine.store.model)
        try:
            self.tree.heading("target_ann", text=f"{target_years}年目标年化")
        except self.tk.TclError:
            pass
        self._show_content("table")
        for child in self.tree.get_children():
            self.tree.delete(child)

        latest_dates = []
        selected_id = None
        for rank, item in enumerate(results, 1):
            stats = item.get("stats") or {}
            nav = item.get("display_nav", item.get("latest_nav"))
            nav_value = _finite(nav, float("nan"))
            nav_decimals = item.get("display_nav_decimals", item.get("latest_nav_decimals"))
            nav_text = _format_published_number(nav_value, nav_decimals)
            date = item.get("display_nav_date") or item.get("latest_date") or ((item.get("dates") or [""])[-1])
            if date:
                latest_dates.append(str(date)[:DATE_TEXT_LENGTH])
            target_ann = _finite(stats.get("return_target_ann"), float("nan"))
            target_ann_text = _format_unrounded_number(target_ann, "%", signed=True, scale=PERCENT_SCALE)
            quality = f"{item.get('long_term_quality', '—')} {_format_unrounded_number(item.get('LongTermQualityScore'))}"
            timing = f"{item.get('timing_view', '—')} {_format_unrounded_number(item.get('EntryTimingScore'))}"
            row_id = f"fund_{item.get('code', rank)}_{rank}"

            old_rank = previous_ranks.get(str(item.get("code")))
            if old_rank is None:
                change_text = "NEW"
            else:
                delta = old_rank - rank
                if delta > 0:
                    change_text = f"↑{delta}"
                elif delta < 0:
                    change_text = f"↓{abs(delta)}"
                else:
                    change_text = "—"
            rank_text = f"★ {rank}  {change_text}" if rank == 1 else f"{rank}  {change_text}"

            tags = ("top1",) if rank == 1 else ()
            self.tree.insert(
                "",
                "end",
                iid=row_id,
                values=(
                    rank_text,
                    item.get("name", "—"),
                    item.get("code", "—"),
                    item.get("asset_class", item.get("type", "—")),
                    quality,
                    timing,
                    item.get("risk", "—"),
                    target_ann_text,
                    nav_text,
                ),
                tags=tags,
            )
            self._row_items[row_id] = item
            if item.get("code") == selected_code:
                selected_id = row_id

        if selected_id is None and self.tree.get_children():
            selected_id = self.tree.get_children()[0]
        if selected_id:
            self.tree.selection_set(selected_id)
            self.tree.focus(selected_id)
            self.tree.see(selected_id)
            self._update_detail_panel()

        preview = state == "preview" or bool(results and any(item.get("preliminary_history_preview") is True for item in results))
        latest_date = max(latest_dates) if latest_dates else "—"
        self.data_date.set(latest_date)

        if state == "basic_screening":
            self.data_status.set("基础筛选（非正式）")
            self.data_status_detail.set("长期历史证据不足或严格 PIT 尚未成熟；不输出正式买入结论")
        elif preview and not formal:
            self.data_status.set("分析中预览（非正式）")
            self.data_status_detail.set("正式买入最终门控尚未通过；不作为最终结果")
        elif state == "current_verified":
            self.data_status.set(f"● 当前正式买入候选 {len(results)} 只")
            self.data_status_detail.set("本轮净值与排名边界已复核")
        else:
            self.data_status.set(f"● 上次有效正式买入候选 {len(results)} 只")
            self.data_status_detail.set("当前在线门控未通过或尚未完成 · 正式快照保持不变")

        model = self.engine.store.model if isinstance(self.engine.store.model, dict) else {}
        trained = str(model.get("trained_at") or "—")[:DATE_TEXT_LENGTH]
        if model.get("ai_enabled"):
            self.ai_status.set("AI增强")
        else:
            self.ai_status.set("基础模型")
        if not self._dependency_prepare_started:
            self.ai_background_status.set(f"训练 {trained} · {int(_finite(model.get('universe_size'), 0))} 只底层基金")

        self.last_update_text.set(_dt.datetime.now().astimezone().strftime("更新 %H:%M"))
        self._update_dashboard_summary(results, previous_ranks)
        self._resize_table_columns()

    def _update_detail_panel(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return
        item = self._row_items.get(selected[0])
        if not item:
            return
        self._selected_code = item.get("code")
        stats = item.get("stats") or {}
        code = str(item.get("code") or "")
        name = str(item.get("name") or "—")
        asset = str(item.get("asset_class", item.get("type", "—")) or "—")
        wrapper = str(item.get("wrapper") or "普通")
        self.detail_title.set(name)
        self.detail_meta.set(
            f"基金代码    {code}\n"
            f"资产类型    {asset}\n"
            f"份额类别    {wrapper}\n"
            f"模型目标    {_model_target_years(self.engine.store.model)}年\n"
            f"买入判断    {item.get('buy_view') or '仅作相对排名参考'}"
        )

        target_ann = _finite(stats.get("return_target_ann"), float("nan"))
        target_drawdown = _finite(stats.get("max_drawdown_target"), float("nan"))
        return_volatility_ratio = _finite(stats.get("zero_baseline_return_volatility"), float("nan"))
        history_years = _finite(stats.get("history_years"), float("nan"))
        quality = _finite(item.get("LongTermQualityScore"), float("nan"))
        timing = _finite(item.get("EntryTimingScore"), float("nan"))
        consistency = _finite(item.get("model_consistency"), float("nan"))
        percentile = _finite(item.get("category_percentile"), float("nan"))
        nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
        nav_date = str(item.get("display_nav_date") or item.get("latest_date") or "—")[:DATE_TEXT_LENGTH]
        cost = _share_class_cost(item, item.get("selected_holding_years") or _model_target_years(self.engine.store.model)) if item.get("fees_verified") else None

        def pct(value):
            return _format_unrounded_number(value, "%", signed=True, scale=PERCENT_SCALE)
        def number(value, suffix=""):
            return _format_unrounded_number(value, suffix)

        nav_decimals = item.get("display_nav_decimals", item.get("latest_nav_decimals"))
        values = {
            "quality": number(quality),
            "timing": number(timing),
            "target_ann": pct(target_ann),
            "drawdown": pct(target_drawdown),
            "return_volatility_ratio": number(return_volatility_ratio),
            "history_years": number(history_years, "年"),
            "percentile": number(percentile, "%"),
            "consistency": number(consistency, "/100"),
            "risk": str(item.get("risk") or "—"),
            "nav": _format_published_number(nav, nav_decimals),
            "nav_date": nav_date,
            "cost": _format_unrounded_number(cost, "%", scale=PERCENT_SCALE) if cost is not None else "费率待确认",
        }
        for key, value in values.items():
            var = self.detail_metric_vars.get(key)
            if var is not None:
                var.set(value)
        self.detail_metrics.set("")

    # ---------- event loop ----------

    def _post_progress(self, text, pct) -> None:
        with self._progress_lock:
            self._latest_progress = (str(text), None if pct is None else _finite(pct))

    def _take_latest_progress(self):
        with self._progress_lock:
            latest = self._latest_progress
            self._latest_progress = None
        return latest

    def _ui_poll_delay_milliseconds(self) -> int:
        now = time.monotonic()
        resolution = time.get_clock_info("monotonic").resolution
        floor = max(resolution, self._ui_display_period_seconds, self._ui_last_handler_seconds)
        if self._ui_event_interval_count > 0:
            deviation = math.sqrt(self._ui_event_interval_m2 / max(1, self._ui_event_interval_count - 1)) if self._ui_event_interval_count > 1 else 0.0
            observed = self._ui_event_interval_mean + deviation
            floor = max(floor, observed)
        idle_elapsed = max(0.0, now - self._ui_last_activity_at)
        clock_period = UI_CLOCK_TICK_MILLISECONDS / MILLISECONDS_PER_SECOND
        adaptive = min(clock_period, max(floor, idle_elapsed))
        return max(1, int(math.ceil(adaptive * MILLISECONDS_PER_SECOND)))

    def _poll_events(self):
        handler_started = time.monotonic()
        latest_progress = self._take_latest_progress()
        event_activity = 1 if latest_progress is not None else 0
        if latest_progress is not None:
            self._set_progress(latest_progress[0], latest_progress[1])
        try:
            for _ in range(DISPLAY_TOP_N):
                event = self.events.get_nowait()
                event_activity += 1
                kind = event[0]

                if kind == "progress":
                    self._set_progress(event[1], event[2])

                elif kind == "cached_results":
                    self._start_background_integrity_verification()
                    self._render(event[1])
                    self._show_content("table")
                    self.data_status.set("本地结果已显示")
                    self.data_status_detail.set("正在后台检查最新数据")
                    self._set_progress("已显示上次结果，正在检查最新数据…", 0.0)

                elif kind == "preview_results":
                    self._start_background_integrity_verification()
                    if not (self.formal_results_ready or self.basic_screening_ready):
                        self._render(event[1])
                        self._show_content("table")
                        self._set_progress("阶段1预览已显示 · 全市场扫描继续进行", self.progress_value.get())

                elif kind == "results":
                    self._start_background_integrity_verification()
                    self._render(event[1])
                    self.initial_error_streak = 0
                    self._cancel_initial_retry()
                    self.retry_text.set("")
                    self._finish_operation(event[2], PERCENT_SCALE)
                    self._set_app_state(AppState.READY)
                    if _storage_survival_mode_active():
                        self.next_refresh = float("inf")
                        self.next_maintenance = float("inf")
                        self.schedule_started = True
                        self.clock.set("只读保护")
                        self.refresh_reason.set("磁盘空间不足 · 保留 last-known-good，空间恢复后自动继续")
                        self.data_status.set("● 只读 last-known-good")
                        self.data_status_detail.set("停止训练与非必要全市场历史扩充；无需额外操作")
                        self.ai_background_status.set("磁盘空间保护 · 暂停训练与依赖准备")
                    else:
                        if not self.schedule_started:
                            if event[1].state == "basic_screening":
                                self.next_refresh = float("inf")
                                self.refresh_reason.set("基础筛选模式 · 等待严格 PIT 成熟度自动复查")
                            else:
                                delay = self.refresh_policy.initial_delay(event[1].rows)
                                self.next_refresh = time.monotonic() + delay
                            self.schedule_started = True
                        current_model = self.engine.store.model if isinstance(self.engine.store.model, dict) else {}
                        self._schedule_objective_maintenance(
                            immediate=current_model.get("schema_fingerprint") != MODEL_SCHEMA_FINGERPRINT
                        )
                        if not self._dependency_prepare_started:
                            self._dependency_prepare_job = self.root.after_idle(self._ensure_dependency_prepare_started)

                elif kind == "refresh_results":
                    outcome = event[1]
                    self._render(outcome["ranking_result"])
                    delay = self.refresh_policy.on_success(outcome)
                    self.next_refresh = time.monotonic() + delay
                    self.refresh_reason.set(self.refresh_policy.last_reason)
                    self._finish_operation("刷新完成", PERCENT_SCALE)
                    self.progress_detail.set(outcome["status"])
                    maintenance_signal = bool(
                        outcome.get("new_codes")
                        or outcome.get("removed_codes")
                        or int(_finite(outcome.get("prediction_outcomes_updated"), 0)) > 0
                    )
                    self._schedule_objective_maintenance(immediate=maintenance_signal)
                    self._set_app_state(AppState.READY)

                elif kind == "error":
                    raw = event[1]
                    _record_diagnostic("ui-initial-error", raw, "InitialAnalysisError")
                    friendly = self._friendly_error_message(raw)
                    if not (self.formal_results_ready or self.basic_screening_ready):
                        self.error_title.set("暂时无法取得基金数据")
                        self.error_message.set(f"{friendly}。程序会自动重试，不需要额外操作。")
                        self._show_content("error")
                        self._finish_operation("本次分析未完成")
                        self._schedule_initial_retry()
                    else:
                        delay = self.refresh_policy.on_error(0.0)
                        self.next_refresh = time.monotonic() + delay
                        self._show_content("table")
                        self.data_status.set("● 保留上次数据")
                        self.data_status_detail.set("本次更新未完成 · 稍后自动再试")
                        self._finish_operation("本次更新未完成")
                        self.progress_detail.set(f"已保留上次结果 · {friendly}")
                        self._set_app_state(AppState.ERROR)

                elif kind == "refresh_error":
                    raw = event[1]
                    _record_diagnostic("ui-refresh-error", raw, "RefreshError")
                    delay = self.refresh_policy.on_error(event[2] if len(event) > 2 else 0.0)
                    self.next_refresh = time.monotonic() + delay
                    self.refresh_reason.set(self.refresh_policy.last_reason)
                    self._show_content("table")
                    self.data_status.set("● 保留上次数据")
                    self.data_status_detail.set("本轮刷新未完成 · 已安排自动再试")
                    self._finish_operation("本轮刷新未完成")
                    self.progress_detail.set(f"已保留上次数据 · {self._friendly_error_message(raw)}")
                    self._set_app_state(AppState.ERROR)

                elif kind == "background_retrain_requested":
                    self._background_retrain_reason = str(event[1] or "scheduled-model-retrain")
                    self._advanced_retrain_pending = True
                    self.ai_background_status.set("正式结果已可用 · AI 后台训练待开始")

                elif kind == "done":
                    self.busy = False
                    self.operation_coordinator.finish(ExclusiveOperation.INITIAL)
                    self._maybe_start_advanced_retrain()

                elif kind == "refresh_done":
                    self.refreshing = False
                    self.operation_coordinator.finish(ExclusiveOperation.REFRESH)
                    if self.app_state == AppState.REFRESHING:
                        self._set_app_state(AppState.READY if (self.formal_results_ready or self.basic_screening_ready) else AppState.ERROR)
                    self._maybe_start_advanced_retrain()

                elif kind == "dependency_progress":
                    text = re.sub(r"\s+", " ", str(event[1])).strip()
                    self.ai_background_status.set("AI 增强组件：" + text)

                elif kind == "dependency_ready":
                    became_ready, ready_at, detail = bool(event[1]), event[2], event[3]
                    self._dependency_ready_at = ready_at
                    if became_ready:
                        self._advanced_retrain_pending = True
                        self.ai_background_status.set("AI 增强组件已就绪 · 等待空闲时自动补训")
                        self._maybe_start_advanced_retrain()
                    else:
                        self.ai_background_status.set(f"AI 增强组件已检查 · {str(detail)}")

                elif kind == "dependency_failed":
                    self.ai_background_status.set("AI 增强组件准备失败 · 已继续使用现有模型")

                elif kind == "dependency_prepare_done":
                    self._dependency_prepare_finished = True

                elif kind == "dependency_retrain_progress":
                    pct = max(0.0, min(PERCENT_SCALE, _finite(event[2])))
                    title, _detail = self._friendly_progress(event[1])
                    self.ai_background_status.set(f"{title} · {_format_unrounded_number(pct)}%")

                elif kind == "shadow_candidate_ready":
                    if len(event) > 1 and isinstance(event[1], RankingResult):
                        self._render(event[1])
                    self.ai_background_status.set("shadow challenger 已训练 · 严格 PIT 成熟前不用于正式买入结论")

                elif kind == "advanced_retrain_results":
                    self._render(event[1])
                    self.ai_background_status.set("AI 增强补训完成 · 当前正式排名已切换到严格 PIT 新模型")

                elif kind == "dependency_retrain_error":
                    if len(event) > 2 and isinstance(event[2], RankingResult):
                        self._render(event[2])
                    self.ai_background_status.set("AI 增强补训未完成 · 已保留当前有效模型与正式快照")

                elif kind == "advanced_retrain_done":
                    self.busy = False
                    self._advanced_retrain_started = False
                    self.operation_coordinator.finish(ExclusiveOperation.RETRAIN)
                    if (self.formal_results_ready or self.basic_screening_ready) and not self.refreshing and not self.maintenance_running:
                        self._set_app_state(AppState.READY)
                    self._maybe_start_advanced_retrain()

                elif kind == "maintenance_progress":
                    self._begin_operation("正在进行后台维护", 0, event[1])

                elif kind == "maintenance_progress_value":
                    self._set_progress("后台维护 · " + str(event[1]), event[2])

                elif kind == "maintenance_results":
                    self._render(event[1])
                    info = event[2]
                    self._finish_operation("后台维护完成", PERCENT_SCALE)
                    self.progress_detail.set(f"模型与历史数据已更新 · 候选池变化 {_format_unrounded_number(info.get('availability_change_ratio', 0), '%', scale=PERCENT_SCALE)}")

                elif kind == "maintenance_checked":
                    info = event[1]
                    self.progress_detail.set(f"后台检查完成 · 模型 {_format_unrounded_number(info.get('model_age_days', 0))} 天 · 候选池变化 {_format_unrounded_number(info.get('availability_change_ratio', 0), '%', scale=PERCENT_SCALE)}")

                elif kind == "maintenance_error":
                    self.progress_detail.set("后台维护未完成 · 已保留当前有效模型与结果")

                elif kind == "maintenance_done":
                    self.maintenance_running = False
                    self.operation_coordinator.finish(ExclusiveOperation.MAINTENANCE)
                    self._schedule_objective_maintenance()
                    if (self.formal_results_ready or self.basic_screening_ready) and not self.refreshing and not self.busy:
                        self._set_app_state(AppState.READY)
                    self._maybe_start_advanced_retrain()

        except queue.Empty:
            pass
        handler_finished = time.monotonic()
        self._ui_last_handler_seconds = max(time.get_clock_info("monotonic").resolution, handler_finished - handler_started)
        if event_activity > 0:
            interval = max(time.get_clock_info("monotonic").resolution, handler_finished - self._ui_last_activity_at)
            self._ui_event_interval_count += 1
            delta = interval - self._ui_event_interval_mean
            self._ui_event_interval_mean += delta / self._ui_event_interval_count
            self._ui_event_interval_m2 += delta * (interval - self._ui_event_interval_mean)
            self._ui_last_activity_at = handler_finished
        if not self.stop_event.is_set():
            self.root.after(self._ui_poll_delay_milliseconds(), self._poll_events)

    def _tick(self):
        now = time.monotonic()
        was_survival = _storage_survival_mode_active()
        if was_survival:
            still_survival = _storage_survival_recheck()
            if still_survival:
                self.next_refresh = float("inf")
                self.next_maintenance = float("inf")
                self.clock.set("只读保护")
                self.refresh_reason.set("磁盘空间不足 · last-known-good 只读服务")
            elif not self.busy and not self.refreshing and not self.maintenance_running:
                self.schedule_started = False
                self.ai_background_status.set("可用空间已恢复 · 正在恢复正常分析")
                self.root.after_idle(lambda: self._start_initial(force_rebuild=True, force_source_probe=False))

        if self.operation_started_at is not None:
            self.elapsed_text.set(f"已用时 {self._format_elapsed(now - self.operation_started_at)}")

        if self.app_state == AppState.BUILDING and not (self.formal_results_ready or self.basic_screening_ready):
            spinner_frames = ("● ○ ○", "○ ● ○", "○ ○ ●")
            index = int(now) % len(spinner_frames)
            self.loading_spinner.set(spinner_frames[index])

        if self.initial_retry_due_at is not None and not (self.formal_results_ready or self.basic_screening_ready):
            remaining_retry = max(0, int(math.ceil(self.initial_retry_due_at - now)))
            self.retry_text.set(f"{remaining_retry} 秒后自动重试 · 重试 {self.initial_error_streak}")
            self.data_status.set("等待重试")
            self.data_status_detail.set(f"{remaining_retry} 秒后自动重试")

        if math.isfinite(self.next_refresh):
            remaining = max(0.0, self.next_refresh - now)
            self.clock.set(f"{_human_seconds(remaining)}后")
            self.refresh_reason.set(self.refresh_policy.last_reason)
            if remaining <= 0 and not self.refreshing and not self.busy and not self.maintenance_running:
                self.next_refresh = float("inf")
                self._start_refresh()
        else:
            if self.refreshing:
                self.clock.set("刷新中…")
            elif self.app_state == AppState.RETRY_WAIT:
                self.clock.set("等待重试")
            else:
                self.clock.set("等待分析")

        live_resources = _runtime_resource_snapshot()
        disk_pressure = live_resources.get("disk_pressure") is True
        if disk_pressure and not self._disk_pressure_active and not _storage_survival_mode_active():
            self._schedule_objective_maintenance(immediate=True)
        self._disk_pressure_active = disk_pressure

        if (
            now >= self.next_maintenance
            and not self.maintenance_running
            and not self.busy
            and not self.refreshing
            and (self.formal_results_ready or self.basic_screening_ready)
        ):
            self.next_maintenance = float("inf")
            self._maybe_start_maintenance()

        self._sync_live_status()
        if not self.stop_event.is_set():
            self.root.after(UI_CLOCK_TICK_MILLISECONDS, self._tick)

    def close(self):
        if self.stop_event.is_set():
            return
        try:
            self.root.withdraw()
        except self.tk.TclError:
            pass
        self.stop_event.set()
        self.next_refresh = float("inf")
        self.next_maintenance = float("inf")
        self._cancel_initial_retry()
        if self._dependency_prepare_job is not None:
            try:
                self.root.after_cancel(self._dependency_prepare_job)
            except self.tk.TclError:
                pass
        _terminate_child_processes()
        _terminate_training_processes()
        # One absolute deadline covers both cooperative worker unwind and the final storage-lock
        # rendezvous. Daemon workers that are unexpectedly stuck must never make close infinite.
        shutdown_deadline = time.monotonic() + _windows_hung_app_timeout_seconds()
        remaining_workers = self.workers.shutdown(deadline=shutdown_deadline)
        if remaining_workers:
            _record_diagnostic("gui-close", f"continuing close with {remaining_workers} daemon worker(s) past deadline", "ShutdownDeadline")
        remaining = max(0.0, shutdown_deadline - time.monotonic())
        storage_acquired = _STORAGE_COMMIT_LOCK.acquire(timeout=remaining)
        if storage_acquired:
            _STORAGE_COMMIT_LOCK.release()
        else:
            _record_diagnostic("gui-close", "storage commit lock still held at shutdown deadline; continuing GUI close", "ShutdownDeadline")
        try:
            self.root.destroy()
        except self.tk.TclError:
            pass


def _run_prebind_invariant_self_checks() -> None:
    """Pure/memory-only invariants; intentionally run before the user chooses any writable folder."""
    writable_paths = (
        BASE_DIR, CACHE_PATH, CACHE_ROLLBACK_PATH, MODEL_PATH, MODEL_ROLLBACK_PATH, SETTINGS_PATH,
        DEPS_DIR, DEPS_TMP_DIR, DEPS_BACKUP_DIR, RUNTIME_TMP_DIR,
    )
    if RUNTIME_FOLDER_BOUND or any(path is not None for path in writable_paths):
        raise DataError("内部不变量失败：用户绑定目录之前出现了应用持久化路径")

    cp314 = DEPENDENCY_PROFILES.get("3.14") or ()
    if not cp314 or cp314[0] != _DEPENDENCY_MODERN:
        raise DataError("内部不变量失败：CPython 3.14 native AI 固定依赖 profile 缺失")
    required_cp314_wheels = {
        "numpy-2.5.2-cp314-cp314-win_amd64.whl",
        "scipy-1.18.1-cp314-cp314-win_amd64.whl",
        "lightgbm-4.7.0-py3-none-win_amd64.whl",
        "xgboost_cpu-3.4.1-py3-none-win_amd64.whl",
        "xgboost-3.4.1-py3-none-win_amd64.whl",
    }
    if not required_cp314_wheels.issubset(TRUSTED_WHEEL_SHA256):
        raise DataError("内部不变量失败：CPython 3.14 wheel SHA256 白名单不完整")
    if MAX_VERIFIED_NATIVE_ML_PYTHON != (3, 14) or "3.14" not in DEPENDENCY_PROFILES:
        raise DataError("内部不变量失败：native ML 已验证 CPython 上限与依赖 profile 不一致")

    # A long calendar span with only two observations must never masquerade as high-quality history.
    sparse = AdaptiveRanker.features(
        [0.0, 0.10], dates=["2025-01-01", "2026-01-01"], target_years=1,
    )
    if sparse is not None:
        raise DataError("内部不变量失败：两点一年稀疏净值历史仍通过正式模型特征门控")

    dense_dates = []
    cursor = _dt.date(2025, 1, 1)
    dense_finish = _dt.date(2026, 1, 2)
    while cursor <= dense_finish:
        if cursor.weekday() < MARKET_WEEKDAYS_PER_WEEK:
            dense_dates.append(cursor.isoformat())
        cursor += _dt.timedelta(days=1)
    dense_returns = [0.0] * len(dense_dates)
    unknown_fee_features = AdaptiveRanker.features(
        dense_returns, fees=None, dates=dense_dates, target_years=1,
        unknown_transaction_cost=UNKNOWN_TRANSACTION_COST_FALLBACK,
    )
    zero_fee_features = AdaptiveRanker.features(
        dense_returns,
        fees={"purchase_fee": 0.0, "redemption_schedule": [{"lower_days": 0, "upper_days": float("inf"), "rate": 0.0}]},
        dates=dense_dates, target_years=1,
    )
    if not unknown_fee_features or not zero_fee_features:
        raise DataError("内部不变量失败：稠密历史费率特征自检无法构造")
    unknown_stats, zero_stats = unknown_fee_features[1], zero_fee_features[1]
    if (
        unknown_stats.get("fee_evidence_known") is not False
        or _finite(unknown_stats.get("model_transaction_cost"), 0.0) <= 0.0
        or zero_stats.get("fee_evidence_known") is not True
        or _finite(zero_stats.get("model_transaction_cost"), 1.0) != 0.0
    ):
        raise DataError("内部不变量失败：未知费率仍可能获得零成本待遇或费率证据标记错误")

    base_dimensions = len(AdaptiveRanker.BASE_FEATURE_NAMES)
    scale_probe = [[0.0] * base_dimensions for _ in range(3)]
    return_index = AdaptiveRanker.BASE_FEATURE_NAMES.index("return_target_ann")
    scale_probe[0][return_index], scale_probe[1][return_index], scale_probe[2][return_index] = 0.02, 0.20, 0.10
    scaled_probe = AdaptiveRanker._scale_feature_rows(scale_probe, ["债券", "主动权益", "主动权益"])
    within_return_index = base_dimensions + return_index
    if (
        any(len(row) != len(AdaptiveRanker.FEATURE_NAMES) for row in scaled_probe)
        or not scaled_probe[1][return_index] > scaled_probe[2][return_index] > scaled_probe[0][return_index]
        or scaled_probe[0][within_return_index] != 0.0
        or not scaled_probe[1][within_return_index] > scaled_probe[2][within_return_index]
        or scaled_probe[0][-len(MODEL_ASSET_BUCKETS):] == scaled_probe[1][-len(MODEL_ASSET_BUCKETS):]
    ):
        raise DataError("内部不变量失败：全市场绝对特征、类内百分位或资产类别编码未同时保留")

    catastrophic_candidate = {"windows": 3, "rank_ic_median": 0.10, "top100_excess_return": 0.01, "max_oos_drawdown": 0.30}
    catastrophic_reference = {"windows": 3, "rank_ic_median": 0.20, "top100_excess_return": 0.02, "max_oos_drawdown": 0.20}
    non_dominating_reference = {"windows": 3, "rank_ic_median": 0.20, "top100_excess_return": 0.02, "max_oos_drawdown": 0.35}
    if (
        AdaptiveRanker._untouched_catastrophic_dominance(catastrophic_candidate, catastrophic_reference) is not True
        or AdaptiveRanker._untouched_catastrophic_dominance(catastrophic_candidate, non_dominating_reference) is not False
    ):
        raise DataError("内部不变量失败：untouched 单向灾难性 veto 规则不稳定")

    # The current SQLite contract itself must no longer encode the retired investment profile dimension.
    memory_db = sqlite3.connect(":memory:")
    try:
        _ensure_cache_schema(memory_db)
        for table in (
            "formal_ranking", "ranking_predictions", "prediction_outcomes",
            "prediction_long_term_summary", "prediction_cohort_archive",
        ):
            columns = {str(row[1]) for row in memory_db.execute(f"PRAGMA table_info({table})")}
            if "profile" in columns:
                raise DataError(f"内部不变量失败：{table} 仍包含无效 profile 维度")
    finally:
        memory_db.close()

    # Exercise the upgrade path itself: neutral legacy data must win duplicate retired-profile rows.
    legacy_db = sqlite3.connect(":memory:")
    try:
        legacy_db.execute(
            "CREATE TABLE formal_ranking (profile TEXT NOT NULL,holding_years INTEGER NOT NULL,rank INTEGER NOT NULL,"
            "fund_code TEXT NOT NULL,model_version INTEGER NOT NULL,validated_at TEXT NOT NULL,validation_json TEXT NOT NULL,"
            "payload_json TEXT NOT NULL,PRIMARY KEY(profile,holding_years,rank),UNIQUE(profile,holding_years,fund_code))"
        )
        legacy_db.execute(
            "INSERT INTO formal_ranking VALUES(?,?,?,?,?,?,?,?)",
            ("激进", 5, 1, "000001", 1, "2026-09-02", "{}", '{"legacy":"other"}'),
        )
        legacy_db.execute(
            "INSERT INTO formal_ranking VALUES(?,?,?,?,?,?,?,?)",
            ("均衡", 5, 1, "000002", 2, "2026-09-03", "{}", '{"legacy":"neutral"}'),
        )
        _ensure_cache_schema(legacy_db)
        legacy_columns = {str(row[1]) for row in legacy_db.execute("PRAGMA table_info(formal_ranking)")}
        migrated = legacy_db.execute(
            "SELECT fund_code,model_version,payload_json FROM formal_ranking WHERE holding_years=5 AND rank=1"
        ).fetchone()
        if "profile" in legacy_columns or not migrated or str(migrated[0]) != "000002" or int(migrated[1]) != 2:
            raise DataError("内部不变量失败：旧 ranking profile schema 未安全折叠到单一策略")
    finally:
        legacy_db.close()


def _run_bound_invariant_self_checks() -> None:
    """Fast no-network checks for freshness, absolute gating, path isolation, rollback and share de-duplication."""
    root = _require_runtime_folder()
    _assert_isolated_app_path(root / ".BestFunds_invariant_probe.tmp")
    escaped = False
    try:
        _assert_isolated_app_path(root.parent / ".BestFunds_escape_probe.tmp")
    except StorageError:
        escaped = True
    if not escaped:
        raise DataError("内部不变量失败：绑定后应用写路径可越出 BASE_DIR")

    stale_gate = FreshnessGate()
    stale_gate.set_market_state_for_test({
        "reliable": True, "source": "self-check-independent-calendar",
        "as_of_date": "2026-09-03", "expected_latest_session": "2026-09-03",
        "checked_at": _now_iso(), "reason": "self-check",
    })
    stale_rows = {
        "000001": {"nav_date": "2026-09-02", "nav": 1.0},
        "000002": {"nav_date": "2026-09-02", "nav": 1.0},
    }
    if stale_gate.filter_latest(stale_rows, _dt.date(2026, 9, 3), {"000001": "股票型", "000002": "混合型"}):
        raise DataError("内部不变量失败：两个净值源共同滞后仍被判为 current fresh")

    bad_item = {
        "stats": {
            "return_target_ann": -0.10, "rolling_target_worst": -0.25,
            "positive_months": 0.40, "history_years": 10.0,
        }
    }
    strong_model_evidence = {
        "full_pipeline_oos": {"windows": 4}, "historical_universe_known_coverage": 1.0,
        "strict_pit_production": True,
    }
    AdaptiveRanker()._apply_investability_views(
        bad_item, strong_model_evidence, 3, None,
        qindex=9, tindex=9, quality_count=10, timing_count=10, hot=False,
    )
    if bad_item.get("absolute_investability") is not False or "长期核心持有" in str(bad_item.get("buy_view") or ""):
        raise DataError("内部不变量失败：绝对表现很差的候选仍得到长期核心持有结论")

    fee_pending_item = {
        "fees_verified": False,
        "availability_status": "public_open",
        "stats": {
            "return_target_ann": 0.10, "rolling_target_worst": 0.02,
            "positive_months": 0.60, "history_years": 10.0,
        },
    }
    AdaptiveRanker()._apply_investability_views(
        fee_pending_item, strong_model_evidence, 3, None,
        qindex=9, tindex=9, quality_count=10, timing_count=10, hot=False,
    )
    if (
        fee_pending_item.get("absolute_investability") is not False
        or fee_pending_item.get("buy_view") != "长期质量较高，费率尚未完整核验，暂不输出正式买入结论"
    ):
        raise DataError("内部不变量失败：未核验费率仍可获得正式长期核心持有结论")

    fee_verified_item = {
        "fees_verified": True,
        "availability_status": "public_open",
        "stats": dict(fee_pending_item["stats"]),
    }
    AdaptiveRanker()._apply_investability_views(
        fee_verified_item, strong_model_evidence, 3, None,
        qindex=9, tindex=9, quality_count=10, timing_count=10, hot=False,
    )
    if fee_verified_item.get("buy_view") != "长期核心持有条件满足":
        raise DataError("内部不变量失败：已核验费率且绝对门控通过的核心候选无法获得长期核心持有结论")

    unknown_purchase_item = {
        "fees_verified": True, "availability_status": "unknown",
        "stats": dict(fee_pending_item["stats"]),
    }
    AdaptiveRanker()._apply_investability_views(
        unknown_purchase_item, strong_model_evidence, 3, None,
        qindex=9, tindex=9, quality_count=10, timing_count=10, hot=False,
    )
    if (
        unknown_purchase_item.get("absolute_investability") is not False
        or "长期核心持有条件满足" in str(unknown_purchase_item.get("buy_view") or "")
        or "可分批买入" in str(unknown_purchase_item.get("buy_view") or "")
    ):
        raise DataError("内部不变量失败：未知申购状态仍可获得正式买入结论")

    formal_probe = _select_formal_buy_candidates([
        {"code": "000001", "underlying_fund_id": "one", "absolute_investability": True, "availability_status": "public_open"},
        {"code": "000002", "underlying_fund_id": "two", "absolute_investability": False, "availability_status": "public_open"},
        {"code": "000003", "underlying_fund_id": "three", "absolute_investability": True, "availability_status": "unknown"},
        {"code": "000004", "underlying_fund_id": "four", "absolute_investability": True, "availability_status": "limited_purchasable"},
    ], DISPLAY_TOP_N)
    if [row.get("code") for row in formal_probe] != ["000001", "000004"]:
        raise DataError("内部不变量失败：正式结果仍会强行填入绝对门控/申购门控未通过的基金")
    _validate_formal_results(formal_probe)

    dedup_rows = _select_top_policy([
        {"code": "000001", "underlying_fund_id": "same", "absolute_investability": False},
        {"code": "000002", "underlying_fund_id": "same", "absolute_investability": False},
        {"code": "000003", "underlying_fund_id": "other", "absolute_investability": False},
    ], 2)
    if len(dedup_rows) != 2 or len({_underlying_key(item) for item in dedup_rows}) != 2:
        raise DataError("内部不变量失败：同一基金不同份额未正确去重")

    saved_models = []
    old_model = {"generation": "old"}
    new_model = {"generation": "new"}
    def fake_save_model(model):
        saved_models.append(dict(model))
    def failing_snapshot():
        raise StorageError("self-check deliberate snapshot failure")
    try:
        _commit_upgrade_with_rollback(
            fake_save_model, failing_snapshot, new_model, old_model,
            upgrade_requested=True, diagnose=False,
        )
    except StorageError:
        pass
    else:
        raise DataError("内部不变量失败：模型升级失败未向上传播")
    if saved_models != [new_model, old_model]:
        raise DataError("内部不变量失败：模型升级失败没有恢复旧模型")


def _validate_runtime(*, formal=False) -> list[tuple[str, str]]:
    """Validate only capabilities that determine whether the production runtime can operate safely."""
    _require_runtime_folder()
    checks: list[tuple[str, str]] = []

    runtime_minor = tuple(sys.version_info[:2])
    if not _runtime_python_supported():
        raise DataError(
            f"基础运行环境需要 CPython {_supported_python_text()}；当前为 "
            f"{sys.implementation.name} {runtime_minor[0]}.{runtime_minor[1]}"
        )
    if struct.calcsize("P") * BITS_PER_BYTE != X64_POINTER_BITS:
        raise DataError("需要 64 位 Python")
    capability_ok, capability_detail = _base_runtime_capability_probe()
    if not capability_ok:
        raise DataError(f"基础运行能力测试未通过：{capability_detail}")
    native_note = "native AI wheel/hash profile 可用" if _native_ml_runtime_supported() else "无 native AI profile，禁用 native ML 自动安装并使用纯 Python 已验证模型"
    checks.append(("OK", f"CPython {runtime_minor[0]}.{runtime_minor[1]} / 64-bit ABI；{capability_detail}；{native_note}"))

    if os.name == "nt":
        version = sys.getwindowsversion()
        machine = platform.machine().upper()
        if version.major < WINDOWS_11_NT_MAJOR_VERSION or version.build < WINDOWS_11_MIN_BUILD or machine not in {"AMD64", "X86_64"}:
            raise DataError("正式环境要求 Windows 11 x64（AMD64）")
        checks.append(("OK", "Windows 11 x64 / AMD64"))
    else:
        if formal:
            raise DataError("正式环境要求 Windows 11 x64")
        checks.append(("SKIP", f"Windows 11 x64（当前测试环境为 {platform.system()}）"))

    try:
        _validate_app_path_isolation()
    except StorageError as exc:
        raise DataError(str(exc)) from exc
    checks.append(("OK", "全部应用可写路径 resolve 后仍位于用户选择目录，且无 symlink/junction/reparse point"))

    if _storage_survival_mode_active():
        checks.append(("OK", "磁盘空间保护：跳过非必要写入探针，仅提供 last-known-good 只读服务"))
    else:
        probe_path = BASE_DIR / ".BestFunds_write_test.tmp"
        probe_payload = b"ok"
        try:
            _atomic_bytes(probe_path, probe_payload)
            if probe_path.read_bytes() != probe_payload:
                raise OSError("write verification failed")
        except (OSError, StorageError) as exc:
            raise DataError(f"用户选择的文件夹不可写或路径隔离失败：{BASE_DIR}\n{exc}") from exc
        finally:
            try:
                probe_path.unlink(missing_ok=True)
            except OSError:
                pass
        checks.append(("OK", "用户选择的文件夹可写 + 原子写入"))

    try:
        LocalStore.check_cache_fast_integrity()
    except (sqlite3.Error, OSError, StorageError, DataError) as exc:
        raise DataError(f"用户选择目录内 SQLite 不可用：{exc}") from exc
    checks.append(("OK", f"SQLite 快速启动检查通过；完整 quick_check 后台执行；存储策略 {SQLITE_STORAGE_PROFILE} / {SQLITE_JOURNAL_MODE}+{SQLITE_NORMAL_SYNCHRONOUS}"))

    settings = _load_install_settings()
    active_dependency = _active_dependency_dir(settings)
    if active_dependency is not None:
        ok, detail, _manifest = _verify_dependency_generation(
            active_dependency, settings, require_import_probe=False, force_tree_rehash=False, force_import_probe=False
        )
        if not ok:
            raise DataError(f"本地 AI 依赖快速完整性验证失败：{detail}")
        checks.append(("OK", "本地 AI 依赖 manifest / wheel 固定清单 / 文件树快速签名通过；完整 SHA-256 + import probe 后台复核"))
    else:
        checks.append(("OK", "尚未激活 native AI 依赖；纯 Python 模型可运行，后续仅安装批准且完整性验证通过的 wheel"))

    cuda_probe = _cached_nvidia_cuda_probe() or _nvidia_cuda_probe()
    if cuda_probe.get("available") is True:
        gpu_count = len([row for row in (cuda_probe.get("gpus") or []) if isinstance(row, dict)])
        checks.append(("OK", f"NVIDIA/CUDA 能力探测通过：{gpu_count} 个可用设备"))
    else:
        checks.append(("SKIP", "未探测到可用 NVIDIA/CUDA；程序保持 CPU/纯 Python 可运行并不启用 GPU 增强"))
    return checks


def _isolated_subprocess_cwd() -> Path:
    _require_runtime_folder()
    return _ensure_isolated_app_dir(RUNTIME_TMP_DIR)


def _writable_environment_paths() -> dict[str, Path]:
    """Return every common writable home/cache location, all rooted below the selected folder."""
    _require_runtime_folder()
    cache_root = _ensure_isolated_app_dir(BASE_DIR / ".BestFunds_cache")
    home_root = _ensure_isolated_app_dir(cache_root / "home")
    return {
        "HOME": home_root,
        "USERPROFILE": home_root,
        "APPDATA": home_root / "AppData" / "Roaming",
        "LOCALAPPDATA": home_root / "AppData" / "Local",
        "TEMP": RUNTIME_TMP_DIR,
        "TMP": RUNTIME_TMP_DIR,
        "TMPDIR": RUNTIME_TMP_DIR,
        "PIP_CACHE_DIR": cache_root / "pip",
        "XDG_CACHE_HOME": cache_root,
        "XDG_CONFIG_HOME": home_root / ".config",
        "XDG_DATA_HOME": home_root / ".local" / "share",
        "XDG_STATE_HOME": home_root / ".local" / "state",
        "NUMBA_CACHE_DIR": cache_root / "numba",
        "CUDA_CACHE_PATH": cache_root / "cuda",
        "JOBLIB_TEMP_FOLDER": RUNTIME_TMP_DIR,
        "MPLCONFIGDIR": cache_root / "matplotlib",
    }


def _bind_writable_environment(env: dict[str, str]) -> dict[str, str]:
    """Bind every write-capable user/home/cache variable to the selected folder for parent and children."""
    paths = _writable_environment_paths()
    for key, value in paths.items():
        env[key] = str(_ensure_isolated_app_dir(Path(value)))
    home_root = Path(paths["HOME"])
    if os.name == "nt" and home_root.drive:
        env["HOMEDRIVE"] = home_root.drive
        env["HOMEPATH"] = str(home_root)[len(home_root.drive):] or os.sep
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONNOUSERSITE"] = "1"
    return env


def _isolated_subprocess_env() -> dict[str, str]:
    """Minimal subprocess environment plus the same writable-location binding used by the parent."""
    _require_runtime_folder()
    env: dict[str, str] = {}
    exact_passthrough = {
        "SYSTEMROOT", "WINDIR", "COMSPEC", "PATH", "PATHEXT", "OS", "SystemDrive",
        "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER", "PROCESSOR_LEVEL", "PROCESSOR_REVISION",
        "NUMBER_OF_PROCESSORS", "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE",
        "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "all_proxy", "no_proxy",
    }
    hardware_prefixes = ("CUDA", "NVIDIA", "NV", "OMP", "MKL", "OPENBLAS")
    for key, value in os.environ.items():
        upper = key.upper()
        if key in exact_passthrough or any(upper.startswith(prefix) for prefix in hardware_prefixes):
            env[key] = value
    return _bind_writable_environment(env)


def _apply_isolated_subprocess_env() -> None:
    env = _isolated_subprocess_env()
    os.environ.clear()
    os.environ.update(env)
    os.chdir(_isolated_subprocess_cwd())
    sys.dont_write_bytecode = True
    tempfile.tempdir = str(RUNTIME_TMP_DIR)


def _bind_runtime_folder(
    folder: Path, *, folder_is_data_dir: bool = False, promote_pending: bool = True, activate_dependencies: bool = True
) -> None:
    """Bind all writable state beneath selected_folder/BestFundsData; children may bind without promotion/activation."""
    global BASE_DIR, CACHE_PATH, CACHE_ROLLBACK_PATH, MODEL_PATH, MODEL_ROLLBACK_PATH, SETTINGS_PATH
    global DEPS_DIR, DEPS_TMP_DIR, DEPS_BACKUP_DIR, RUNTIME_TMP_DIR, RUNTIME_FOLDER_BOUND
    global SQLITE_JOURNAL_MODE, SQLITE_NORMAL_SYNCHRONOUS, SQLITE_STORAGE_PROFILE
    requested = Path(folder)
    if _path_is_reparse_or_symlink(requested):
        raise StorageError(f"拒绝把符号链接/junction/reparse point 作为应用根目录：{requested}")
    resolved_requested = requested.resolve()
    base = resolved_requested if folder_is_data_dir else (resolved_requested / APP_DATA_DIRNAME)
    if _path_is_reparse_or_symlink(base):
        raise StorageError(f"拒绝使用符号链接/junction/reparse point 作为应用数据目录：{base}")
    BASE_DIR = Path(os.path.abspath(str(base)))
    RUNTIME_FOLDER_BOUND = True
    _ensure_isolated_app_dir(BASE_DIR)
    CACHE_PATH = BASE_DIR / "BestFunds_cache.sqlite3"
    CACHE_ROLLBACK_PATH = BASE_DIR / "BestFunds_cache.rollback.sqlite3"
    MODEL_PATH = BASE_DIR / "BestFunds_AI.json"
    MODEL_ROLLBACK_PATH = BASE_DIR / "BestFunds_AI.rollback.json"
    SETTINGS_PATH = BASE_DIR / "BestFunds_Settings.json"
    DEPS_DIR = BASE_DIR / "BestFunds_deps"
    DEPS_TMP_DIR = BASE_DIR / "BestFunds_deps.tmp"
    DEPS_BACKUP_DIR = BASE_DIR / "BestFunds_deps.rollback"
    RUNTIME_TMP_DIR = BASE_DIR / ".BestFunds_runtime"
    if os.name == "nt":
        drive = resolved_requested.drive.upper()
        try:
            drive_type = int(ctypes.windll.kernel32.GetDriveTypeW(f"{drive}\\")) if re.fullmatch(r"[A-Z]:", drive) else 0
        except Exception:
            drive_type = 0
        if drive_type == WINDOWS_FIXED_DRIVE_TYPE:
            SQLITE_JOURNAL_MODE = "WAL"
            SQLITE_NORMAL_SYNCHRONOUS = "NORMAL"
            SQLITE_STORAGE_PROFILE = "fixed-local"
        else:
            SQLITE_JOURNAL_MODE = "DELETE"
            SQLITE_NORMAL_SYNCHRONOUS = "FULL"
            SQLITE_STORAGE_PROFILE = "portable-or-mapped"
    else:
        SQLITE_JOURNAL_MODE = "WAL"
        SQLITE_NORMAL_SYNCHRONOUS = "NORMAL"
        SQLITE_STORAGE_PROFILE = "non-windows-test"
    # Validate all pre-existing app-owned files/dirs before creating or writing anything.
    _validate_app_path_isolation()
    _ensure_isolated_app_dir(RUNTIME_TMP_DIR)
    _bind_writable_environment(os.environ)
    sys.dont_write_bytecode = True
    tempfile.tempdir = str(RUNTIME_TMP_DIR)
    # From this point onward, Python-level mutations fail closed outside BASE_DIR.
    # Spawned training workers execute this same binding path and install the same barrier.
    _install_runtime_write_audit()
    # Never inherit a legacy or previous-generation dependency sys.path entry. The verified
    # generation for this bound data root is added explicitly below (or later by a train child).
    for entry in list(sys.path):
        try:
            candidate = Path(entry)
        except (TypeError, ValueError):
            continue
        if candidate.name == "BestFunds_deps" or candidate.name.startswith(DEPS_DIR_PREFIX):
            try:
                sys.path.remove(entry)
            except ValueError:
                pass
    if promote_pending:
        _promote_pending_dependency_dir()
    if activate_dependencies:
        _bootstrap_local_dependency_path()




def _verify_wheel_member_path_budget(wheel_dir: Path, target_dir: Path) -> tuple[bool, str]:
    """Check exact approved wheel member paths before pip extracts anything."""
    if os.name != "nt":
        return True, "non-Windows validation host"
    target = Path(os.path.abspath(str(target_dir)))
    longest = 0
    for wheel in sorted(wheel_dir.glob("*.whl")):
        try:
            with zipfile.ZipFile(wheel, "r") as archive:
                for info in archive.infolist():
                    raw_name = str(info.filename or "")
                    parts = [part for part in raw_name.replace("\\", "/").split("/") if part not in ("", ".")]
                    if any(part == ".." for part in parts):
                        return False, f"wheel 包含越界路径：{wheel.name}: {raw_name}"
                    destination = target.joinpath(*parts)
                    path_length = len(os.path.abspath(str(destination)))
                    longest = max(longest, path_length)
                    if path_length >= WINDOWS_LEGACY_MAX_PATH:
                        return False, (
                            f"所选目录对批准 wheel 过深：{wheel.name} 的成员路径将达到 {path_length} 字符"
                        )
        except (OSError, zipfile.BadZipFile, ValueError) as exc:
            return False, f"无法检查 wheel 解包路径：{wheel.name}: {exc}"
    return True, f"批准 wheel 最长实际解包路径 {longest} < Win32 MAX_PATH"

def _first_reparse_component(path: Path) -> Path | None:
    """Return the first existing reparse/symlink component from drive root through path."""
    absolute = Path(os.path.abspath(str(path)))
    chain = list(reversed(absolute.parents)) + [absolute]
    for component in chain:
        if os.path.lexists(str(component)) and _path_is_reparse_or_symlink(component):
            return component
    return None


def _choose_non_system_folder() -> Path:
    """Normal Windows startup asks exactly one user choice: an existing folder on a non-system drive."""
    if os.name != "nt":
        return Path(__file__).resolve().parent
    import tkinter as tk
    from tkinter import filedialog, messagebox
    system_drive = str(os.environ.get("SystemDrive") or Path(os.environ.get("SystemRoot", r"C:\Windows")).drive or "C:").upper()
    chooser = tk.Tk()
    chooser.withdraw()
    try:
        try:
            chooser.attributes("-topmost", True)
        except tk.TclError:
            pass
        while True:
            selected = filedialog.askdirectory(parent=chooser, title="选择非系统盘文件夹", mustexist=True)
            if not selected:
                raise SystemExit(0)
            selected_path = Path(os.path.abspath(selected))
            reparse_component = _first_reparse_component(selected_path)
            if reparse_component is not None:
                messagebox.showerror(
                    APP_NAME,
                    f"所选路径经过符号链接/junction/reparse point：{reparse_component}。\n请选择从盘符根到目标目录全部为普通目录的路径。",
                    parent=chooser,
                )
                continue
            try:
                folder = selected_path.resolve(strict=True)
            except OSError as exc:
                messagebox.showerror(APP_NAME, f"无法安全解析这个文件夹：{exc}", parent=chooser)
                continue
            drive = folder.drive.upper()
            if not re.fullmatch(r"[A-Z]:", drive) or drive == system_drive:
                messagebox.showerror(APP_NAME, "请选择非系统盘文件夹。", parent=chooser)
                continue
            # Keep selection side-effect free. Writable-path binding and the atomic write probe
            # run only after _bind_runtime_folder() has rooted every writable environment path here.
            return folder
    finally:
        try:
            chooser.destroy()
        except Exception:
            pass


def _set_windows_dpi():
    if os.name != "nt":
        return
    # Prefer Per-Monitor V2 so Tk receives correct scaling on mixed-DPI Windows 11 displays.
    try:
        context = ctypes.c_void_p(WINDOWS_PER_MONITOR_AWARE_V2_CONTEXT)
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(context):
            return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(WINDOWS_PROCESS_PER_MONITOR_DPI_AWARE)
        return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(WINDOWS_PROCESS_SYSTEM_DPI_AWARE)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def _show_startup_error(message: str) -> None:
    """Show startup failures without a traceback; use native Windows UI if Tk itself is unavailable."""
    text = str(message or "未知启动错误")
    try:
        import tkinter as tk
        from tkinter import messagebox
        owner = tk.Tk()
        owner.withdraw()
        try:
            owner.attributes("-topmost", True)
        except tk.TclError:
            pass
        try:
            messagebox.showerror(APP_NAME, text, parent=owner)
        finally:
            owner.destroy()
        return
    except Exception:
        pass
    if os.name == "nt":
        try:
            ctypes.windll.user32.MessageBoxW(None, text, APP_NAME, WINDOWS_MESSAGEBOX_ICONERROR)
            return
        except Exception:
            pass
    print(text, file=sys.stderr)


def main() -> int:
    try:
        runtime_minor = tuple(sys.version_info[:2])
        if not _runtime_python_supported():
            raise DataError(
                f"基础运行环境需要 CPython {_supported_python_text()}；"
                f"当前为 {sys.implementation.name} {runtime_minor[0]}.{runtime_minor[1]}。"
            )
        _run_prebind_invariant_self_checks()
        _set_windows_dpi()
        selected_folder = _choose_non_system_folder()
        _bind_runtime_folder(selected_folder)
        _run_bound_invariant_self_checks()
        _cleanup_stale_runtime_files()
        if _objective_disk_pressure(_selected_folder_free_bytes()):
            _set_storage_survival_mode(True)
        _RESOURCE_CONTROLLER.start()
        # First paint never waits for pip; under disk pressure even hardware/settings writes are deferred.
        if not _storage_survival_mode_active():
            _configure_hardware_adaptive(force=False, allow_install=False)
        _validate_runtime(formal=(os.name == "nt"))
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
        FundsApp(root, tk, ttk)
        root.mainloop()
        return 0
    except SystemExit:
        raise
    except ImportError as exc:
        _show_startup_error(f"启动失败：当前 Python 缺少 Tk 图形界面组件：{exc}")
        return 2
    except Exception as exc:
        _show_startup_error(f"启动失败：{exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
