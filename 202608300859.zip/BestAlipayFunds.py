                       
from __future__ import annotations

# ===== 标准库 / 全局配置 =====
import concurrent.futures
import ctypes
import datetime as _dt
import base64
import bisect
import calendar
import gzip
import hashlib
import hmac
import html
import io
import importlib
import json
import math
import platform
import struct
import os
import queue
import random
import sqlite3
import re
import statistics
import subprocess
import sys
import threading
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


APP_NAME = "Best Alipay Funds"
VERSION = "16.3.0"
LATEST_TIMEOUT = 4.0
LATEST_ATTEMPTS = 2
LATEST_BATCH_SIZE = 50
MIN_HISTORY_POINTS = 757
MIN_PYTHON = (3, 10)
BASE_DIR = Path(__file__).resolve().parent
CACHE_PATH = BASE_DIR / "BestAlipayFunds_cache.sqlite3"
CACHE_ROLLBACK_PATH = BASE_DIR / "BestAlipayFunds_cache.rollback.sqlite3"
MODEL_PATH = BASE_DIR / "BestAlipayFunds_AI.json"
ALIPAY_FILE_PATH = BASE_DIR / "BestAlipayFunds_AlipayAvailability.json"
SETTINGS_PATH = BASE_DIR / "BestAlipayFunds_Settings.json"
DEPS_DIR = BASE_DIR / "BestAlipayFunds_deps"
DEPS_TMP_DIR = BASE_DIR / "BestAlipayFunds_deps.tmp"
DEPS_BACKUP_DIR = BASE_DIR / "BestAlipayFunds_deps.rollback"  # legacy cleanup only; active dirs are versioned
DEPS_DIR_PREFIX = "BestAlipayFunds_deps_"
MODEL_ROLLBACK_PATH = BASE_DIR / "BestAlipayFunds_AI.rollback.json"
RUNTIME_TMP_DIR = BASE_DIR / ".BestAlipayFunds_runtime"
NAV_REVISION_WINDOW = 120
SETTINGS_SCHEMA_VERSION = 4
LOCAL_DEPENDENCY_PINS = (
    {
        "numpy": "numpy==2.5.2",
        "scipy": "scipy==1.18.0",
        "lightgbm": "lightgbm==4.7.0",
        "xgboost_cpu": "xgboost-cpu==3.4.1",
        "xgboost_gpu": "xgboost==3.4.1",
    }
    if sys.version_info >= (3, 12)
    else {
        "numpy": "numpy==2.2.6",
        "scipy": "scipy==1.15.3",
        "lightgbm": "lightgbm==4.7.0",
        "xgboost_cpu": "xgboost-cpu==3.4.1",
        "xgboost_gpu": "xgboost==3.4.1",
    }
)
QUICK_START_REPRESENTATIVES = 80
DISPLAY_TOP_N = 100

# Process-wide cancellation used by GUI workers, HTTP retries and long-running pip subprocesses.
_GLOBAL_STOP_EVENT = threading.Event()
_ACTIVE_CHILD_PROCESSES: set[subprocess.Popen] = set()
_ACTIVE_CHILD_LOCK = threading.Lock()

def _cancel_requested() -> bool:
    return _GLOBAL_STOP_EVENT.is_set()

def _sleep_interruptible(seconds: float) -> bool:
    return _GLOBAL_STOP_EVENT.wait(max(0.0, float(seconds)))

def _terminate_child_processes() -> None:
    with _ACTIVE_CHILD_LOCK:
        processes = list(_ACTIVE_CHILD_PROCESSES)
    for proc in processes:
        try:
            if proc.poll() is None:
                proc.terminate()
        except OSError:
            pass
    deadline = time.monotonic() + 1.5
    for proc in processes:
        try:
            remaining = max(0.0, deadline - time.monotonic())
            proc.wait(timeout=remaining)
        except Exception:
            try:
                if proc.poll() is None:
                    proc.kill()
            except OSError:
                pass

def _run_process_cancellable(command: list[str], *, timeout: float, env=None) -> subprocess.CompletedProcess:
    """Run a child while continuously draining stdout/stderr so PIPE buffers cannot deadlock pip."""
    if _cancel_requested():
        raise concurrent.futures.CancelledError("程序正在退出")
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    with _ACTIVE_CHILD_LOCK:
        _ACTIVE_CHILD_PROCESSES.add(proc)
    started = time.monotonic()
    try:
        while True:
            if _cancel_requested():
                try:
                    proc.terminate()
                except OSError:
                    pass
                try:
                    proc.communicate(timeout=1.5)
                except Exception:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    try:
                        proc.communicate(timeout=1.0)
                    except Exception:
                        pass
                raise concurrent.futures.CancelledError("程序正在退出")
            elapsed = time.monotonic() - started
            if elapsed >= timeout:
                try:
                    proc.terminate()
                    proc.communicate(timeout=1.5)
                except Exception:
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    try:
                        proc.communicate(timeout=1.0)
                    except Exception:
                        pass
                raise subprocess.TimeoutExpired(command, timeout)
            try:
                stdout, stderr = proc.communicate(timeout=min(0.35, max(0.05, timeout - elapsed)))
                return subprocess.CompletedProcess(command, proc.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                continue
    finally:
        with _ACTIVE_CHILD_LOCK:
            _ACTIVE_CHILD_PROCESSES.discard(proc)


_STORAGE_COMMIT_LOCK = threading.RLock()


class WorkerManager:
    """Track top-level GUI workers so shutdown stops new work and waits for existing workers to unwind."""
    def __init__(self, stop_event: threading.Event):
        self.stop_event = stop_event
        self._threads: set[threading.Thread] = set()
        self._lock = threading.Lock()
        self._accepting = True

    def start(self, *, name: str, target) -> threading.Thread | None:
        with self._lock:
            if not self._accepting or self.stop_event.is_set():
                return None

        def runner():
            try:
                target()
            finally:
                with self._lock:
                    self._threads.discard(threading.current_thread())

        thread = threading.Thread(target=runner, name=name, daemon=False)
        with self._lock:
            if not self._accepting or self.stop_event.is_set():
                return None
            self._threads.add(thread)
        thread.start()
        return thread

    def shutdown(self) -> None:
        with self._lock:
            self._accepting = False
            threads = list(self._threads)
        for thread in threads:
            if thread is threading.current_thread():
                continue
            thread.join()


# Optional AI packages are intentionally loaded only from a script-local, versioned target directory.
# Bootstrap only reads Settings.json; it never modifies the user's global Python environment.
def _bootstrap_local_dependency_path() -> None:
    target = None
    try:
        raw = json.loads(SETTINGS_PATH.read_text(encoding="utf-8")) if SETTINGS_PATH.is_file() else {}
        name = str(raw.get("active_dependency_dir") or "") if isinstance(raw, dict) else ""
        if name.startswith(DEPS_DIR_PREFIX) and Path(name).name == name:
            candidate = BASE_DIR / name
            if candidate.is_dir():
                target = candidate
    except (OSError, ValueError, TypeError):
        target = None
    if target is None and DEPS_DIR.is_dir():  # backward-compatible one-time legacy activation
        target = DEPS_DIR
    if target is not None:
        text = str(target)
        if text not in sys.path:
            sys.path.insert(0, text)

if os.name != "nt":
    _bootstrap_local_dependency_path()
ALIPAY_MAX_AGE_SECONDS = 30 * 60
DEFAULT_RISK_FREE_RATE = 0.015
OOS_DEPLOYMENT_WINDOWS = 6
OOS_UNTOUCHED_TEST_WINDOWS = 4
MIN_OOS_GATE_WINDOWS = 4
MIN_TREE_DEPLOYMENT_WINDOWS = 2
UNIVERSE_EXPERT_ONLY_COVERAGE = 0.25
UNIVERSE_COMPLEX_ML_COVERAGE = 0.60
DEPLOYMENT_MIN_RANKIC_UPLIFT = 0.02
DEPLOYMENT_MIN_QUALITY_UPLIFT = 0.005
DEPLOYMENT_BOOTSTRAP_LOWER_FLOOR = -0.01
REFRESH_MIN_COVERAGE = 0.97
LATEST_PRIORITY_COUNT = DISPLAY_TOP_N
HISTORY_YEARS = 18
CACHE_VERSION = 18
MODEL_VERSION = 18
AVAILABILITY_SCHEMA_VERSION = 5
MIN_AVAILABILITY_FUNDS = DISPLAY_TOP_N + 50
MAX_AVAILABILITY_FUTURE_SKEW_SECONDS = 5 * 60
MODEL_RETRAIN_DAYS = 7
MAINTENANCE_CHECK_SECONDS = 24 * 60 * 60
MODEL_UNIVERSE_CHANGE_THRESHOLD = 0.05
MAX_HTTP_RESPONSE_BYTES = 16 * 1024 * 1024
MAX_HTTP_DECOMPRESSED_BYTES = 64 * 1024 * 1024
TARGET_HALF_YEAR_DAYS = 183
TARGET_ONE_YEAR_DAYS = 365
TARGET_THREE_YEAR_DAYS = 1096
TARGET_FIVE_YEAR_DAYS = 1826
MIN_HALF_YEAR_OBSERVATIONS = 100
MIN_ONE_YEAR_OBSERVATIONS = 200
MIN_THREE_YEAR_OBSERVATIONS = 600
MIN_FIVE_YEAR_OBSERVATIONS = 1000
TARGET_SPECS = (
    {"name":"3y-core-75", "horizon":"3y", "weights":{"6m":0.08,"1y":0.17,"3y":0.75}},
    {"name":"3y-core-85", "horizon":"3y", "weights":{"6m":0.05,"1y":0.10,"3y":0.85}},
    {"name":"5y-core-80", "horizon":"5y", "weights":{"6m":0.04,"1y":0.08,"3y":0.48,"5y":0.40}},
    {"name":"5y-core-90", "horizon":"5y", "weights":{"6m":0.02,"1y":0.05,"3y":0.48,"5y":0.45}},
)
LONG_TERM_BLEND_CANDIDATES = (0.75, 0.80, 0.85, 0.90)
METADATA_ENRICH_CANDIDATES = 500
HISTORY_CHECKPOINT_BATCH = 75
ASSET_MODEL_MIN_SAMPLES = 90
GLOBAL_ASSET_BLEND = 0.35
ASSET_SPECIFIC_BLEND = 0.65
FULL_NAV_REFRESH_SECONDS = 20 * 60
AVAILABILITY_REFRESH_SECONDS = 30 * 60
FRESH_NAV_MAX_MARKET_SESSIONS = 1
FINAL_FRESHNESS_COVERAGE = 0.95
FINAL_FRESHNESS_CANDIDATES = 120
PIT_RATING_MIN_UNIVERSE_COVERAGE = 0.25
PIT_RATING_MIN_OOS_WINDOWS = 4
SOURCE_CONTRACT_PROBES = ("000001", "110022", "161725")
SOURCE_CONTRACT_RECHECK_SECONDS = 6 * 60 * 60
SOURCE_CIRCUIT_HALF_OPEN_SECONDS = 6 * 60 * 60
SOURCE_PARSE_FAILURE_LIMIT = 3
HISTORY_PAGE_SIZE = 500
HISTORY_MAX_PAGES = 64
SINA_CATALOG_MAX_PAGES = 100
PURCHASE_UNAVAILABLE_STATUSES = frozenset({"purchase_suspended", "closed", "confirmed_unavailable", "high_probability_unavailable", "unavailable"})
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)

CHINA_TZ = _dt.timezone(_dt.timedelta(hours=8))


def _china_today() -> _dt.date:
    """Single China-market calendar date entry point; independent of the Windows local timezone."""
    return _dt.datetime.now(tz=CHINA_TZ).date()


def _availability_max_age_seconds(now: _dt.datetime | None = None) -> int:
    now_cn = (now or _dt.datetime.now(tz=CHINA_TZ)).astimezone(CHINA_TZ)
    minute = now_cn.hour * 60 + now_cn.minute
    if now_cn.weekday() >= 5:
        return 6 * 60 * 60
    if 9 * 60 <= minute < 23 * 60:
        return ALIPAY_MAX_AGE_SECONDS
    return 4 * 60 * 60


def _human_seconds(seconds: float) -> str:
    seconds = max(0, int(math.ceil(seconds)))
    if seconds < 60:
        return f"{seconds}秒"
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}分{seconds:02d}秒" if seconds else f"{minutes}分钟"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}小时{minutes:02d}分"


class SmartRefreshPolicy:

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.error_streak = 0
        self.low_coverage_streak = 0
        self.stable_streak = 0
        self.last_delay = 0.0
        self.last_reason = "等待首次分析"

    @staticmethod
    def _latest_date(results: list[dict] | None) -> str:
        dates = [str(item.get("latest_date") or "")[:10] for item in (results or [])]
        dates = [value for value in dates if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value)]
        return max(dates, default="")

    @staticmethod
    def _phase(now: _dt.datetime) -> tuple[str, float, float]:
        now = now.astimezone(CHINA_TZ)
        minute = now.hour * 60 + now.minute
        if now.weekday() >= 5:
            return "周末低活跃", 1800.0, 3600.0
        if 15 * 60 <= minute < 23 * 60:
            return "收盘净值披露", 300.0, 900.0
        if 9 * 60 <= minute < 15 * 60:
            return "交易时段", 600.0, 1200.0
        if 7 * 60 + 30 <= minute < 9 * 60:
            return "开盘前", 900.0, 1800.0
        return "低活跃时段", 1800.0, 3600.0


    @classmethod
    def _nav_pending(cls, results: list[dict] | None, now: _dt.datetime) -> bool:
        now_cn = now.astimezone(CHINA_TZ)
        if now_cn.weekday() >= 5 or now_cn.hour < 15:
            return False
        latest = cls._latest_date(results)
        return bool(latest and latest < now_cn.date().isoformat())

    def _jitter(self, seconds: float, spread: float = 0.08) -> float:
        return max(20.0, seconds * self.rng.uniform(1.0 - spread, 1.0 + spread))

    def _finish(self, seconds: float, reason: str, elapsed: float = 0.0) -> float:
        if elapsed > 0:
            seconds = max(seconds, min(900.0, elapsed * 6.0))
        self.last_delay = self._jitter(_clamp(seconds, 60.0, 3600.0))
        self.last_reason = reason
        return self.last_delay

    def initial_delay(self, results: list[dict] | None, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        phase, base, cap = self._phase(now)
        if self._nav_pending(results, now):
            base = min(base, 300.0)
            reason = f"{phase}·等待今日净值"
        else:
            reason = phase
        return self._finish(min(base, cap), reason)

    def on_success(self, outcome: dict, now: _dt.datetime | None = None) -> float:
        now = now or _dt.datetime.now(tz=CHINA_TZ)
        self.error_streak = 0
        coverage = _finite(outcome.get("coverage"), 0.0)
        elapsed = _finite(outcome.get("elapsed_seconds"), 0.0)
        results = outcome.get("results") or []
        changed = int(outcome.get("updated_series") or 0)
        pool_changes = len(outcome.get("new_codes") or []) + len(outcome.get("removed_codes") or [])

        if coverage < REFRESH_MIN_COVERAGE or outcome.get("ranking_updated") is False:
            self.low_coverage_streak += 1
            self.stable_streak = 0
            delay = min(1200.0, 180.0 * (2 ** min(self.low_coverage_streak - 1, 3)))
            detail = "Top候选不完整" if outcome.get("priority_complete") is False else f"覆盖率{coverage:.1%}"
            return self._finish(delay, f"{detail}·自适应退避重试", elapsed)

        self.low_coverage_streak = 0
        if pool_changes:
            self.stable_streak = 0
            return self._finish(180.0, f"可购池变化{pool_changes}项·快速复核", elapsed)
        if changed:
            self.stable_streak = 0
            delay = 300.0 if self._nav_pending(results, now) else 600.0
            return self._finish(delay, f"发现{changed}个新净值·快速复核", elapsed)

        self.stable_streak += 1
        phase, base, cap = self._phase(now)
        pending = self._nav_pending(results, now)
        if pending:
            base, cap = min(base, 300.0), min(cap, 900.0)
            reason = f"{phase}·今日净值待披露"
        else:
            if phase == "收盘净值披露":
                base = max(base, 600.0)
            reason = f"{phase}·数据稳定"
        multiplier = min(2.6, 1.0 + 0.28 * max(0, self.stable_streak - 1))
        return self._finish(min(cap, base * multiplier), reason, elapsed)

    def on_error(self, elapsed: float = 0.0) -> float:
        self.error_streak += 1
        self.low_coverage_streak = 0
        self.stable_streak = 0
        delay = min(1800.0, 180.0 * (2 ** min(self.error_streak - 1, 4)))
        return self._finish(delay, f"网络/数据失败×{self.error_streak}·指数退避", elapsed)



class DataError(RuntimeError):
    pass


class NetworkError(DataError):
    """Transient transport/HTTP failure; callers may retry or use a fallback source."""


class ContractError(DataError):
    """Remote payload shape/semantics no longer satisfy the adapter contract."""


class ParseError(DataError):
    """Received content could not be parsed according to the expected source format."""


class StorageError(DataError):
    """Local persistence or isolation failure."""


class ModelError(DataError):
    """Optional model backend/training failure."""


def _typed_source_error(exc: BaseException, context: str) -> DataError:
    """Map adapter-boundary failures to an explicit long-running source error class."""
    if isinstance(exc, DataError):
        return exc
    if isinstance(exc, (urllib.error.URLError, TimeoutError, ConnectionError)):
        return NetworkError(f"{context}: {type(exc).__name__}: {exc}")
    if isinstance(exc, (json.JSONDecodeError, UnicodeError, TypeError, ValueError, KeyError, IndexError, AttributeError, AssertionError)):
        return ParseError(f"{context}: {type(exc).__name__}: {exc}")
    # At a remote-adapter boundary an unexpected exception must not be silently treated
    # as a harmless network fallback: record it as parser/program contract failure so
    # repeated occurrences trip the circuit breaker and become visible in diagnostics.
    return ParseError(f"{context}: unexpected {type(exc).__name__}: {exc}")


def _now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _parse_iso(value: str | None) -> _dt.datetime | None:
    if not value:
        return None
    try:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        return _dt.datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def _finite(value, default=0.0) -> float:
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _compound(values) -> float:
    total = 1.0
    for value in values:
        total *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
    return total - 1.0


def _max_drawdown(values) -> float:
    wealth = 1.0
    peak = 1.0
    worst = 0.0
    for value in values:
        wealth *= max(0.01, 1.0 + _clamp(_finite(value), -0.95, 3.0))
        peak = max(peak, wealth)
        worst = min(worst, wealth / peak - 1.0)
    return worst


def _pearson(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = sum((x - mx) ** 2 for x in xs)
    dy = sum((y - my) ** 2 for y in ys)
    if dx <= 1e-15 or dy <= 1e-15:
        return 0.0
    return numerator / math.sqrt(dx * dy)


def _spearman(xs, ys) -> float:
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    return _pearson(_rank_scale(xs), _rank_scale(ys))


def _median(values, default=0.0) -> float:
    clean = [_finite(v, float("nan")) for v in values]
    clean = [v for v in clean if math.isfinite(v)]
    return statistics.median(clean) if clean else default


def _chunks(values, size):
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _rate(value, default=0.0) -> float:
    return _clamp(_finite(value, default), 0.0, 0.25)


def _risk_free_rate() -> float:
    return _clamp(_finite(os.environ.get("BEST_ALIPAY_RISK_FREE_RATE"), DEFAULT_RISK_FREE_RATE), -0.02, 0.08)


def _asset_bucket(name: str, fund_type: str) -> str:
    text = f"{name} {fund_type}".upper()
    if "QDII" in text or "海外" in text or any(word in text for word in ("纳斯达克", "标普", "全球", "恒生", "美国")):
        return "QDII/海外"
    coarse = _coarse_type(fund_type)
    if coarse == "债券":
        return "债券"
    if coarse == "指数":
        return "指数"
    if coarse in ("股票", "混合"):
        return "主动权益"
    return "其他"



def _holding_costs(fees: dict | None) -> dict:
    """Return explicit transaction-vs-embedded cost semantics.

    transaction_cost_* is purchase + redemption only. total_share_class_cost_* adds
    annual management/custody/sales-service costs. Legacy holding_cost_* aliases are
    retained only so old caches can be migrated without breaking a first launch.
    """
    if not isinstance(fees, dict):
        output = {"annual_cost": None, "embedded_annual_cost": None, "purchase_cost": None}
        for years in (3, 5, 10):
            output[f"transaction_cost_{years}y"] = None
            output[f"total_share_class_cost_{years}y"] = None
            output[f"holding_cost_{years}y"] = None
        return output

    def known_rate(key: str):
        value = fees.get(key)
        if value is None:
            return None
        return _rate(value)

    purchase = known_rate("purchase_fee")
    embedded_parts = [known_rate(key) for key in (
        "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
    )]
    embedded_annual = sum(embedded_parts) if all(value is not None for value in embedded_parts) else None
    costs = {}
    for years in (3, 5, 10):
        redemption = known_rate(f"redemption_fee_{years}y")
        transaction = purchase + redemption if purchase is not None and redemption is not None else None
        total = transaction + years * embedded_annual if transaction is not None and embedded_annual is not None else None
        costs[f"transaction_cost_{years}y"] = transaction
        costs[f"total_share_class_cost_{years}y"] = total
        costs[f"holding_cost_{years}y"] = transaction  # legacy cache alias
    costs["annual_cost"] = embedded_annual
    costs["embedded_annual_cost"] = embedded_annual
    costs["purchase_cost"] = purchase
    return costs


def _expected_holding_years(value=None) -> int:
    try:
        years = int(value if value is not None else os.environ.get("BEST_ALIPAY_HOLDING_YEARS", "5"))
    except (TypeError, ValueError):
        years = 5
    return years if years in (3, 5, 10) else 5


def _share_class_cost(fund: dict, years: int) -> float:
    years = _expected_holding_years(years)
    if fund.get("fees_verified") is not True:
        return float("inf")
    fees = fund.get("fees") if isinstance(fund.get("fees"), dict) else {}
    required = (
        "purchase_fee", "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
        f"redemption_fee_{years}y",
    )
    if any(fees.get(key) is None for key in required):
        return float("inf")
    total = fund.get(f"total_share_class_cost_{years}y")
    if total is None:
        total = _holding_costs(fees).get(f"total_share_class_cost_{years}y")
    if total is None:
        return float("inf")
    return _clamp(_finite(total), 0.0, 3.0)



def _underlying_key(fund: dict) -> str:
    explicit = str(
        fund.get("underlying_fund_id") or fund.get("master_code")
        or fund.get("primary_code") or ""
    ).strip().casefold()
    if explicit:
        return explicit if explicit.startswith(("id:", "name:", "code:")) else "id:" + explicit
    base = _base_name(str(fund.get("name") or ""))
    wrapper = _wrapper_type(str(fund.get("type") or ""))
    return f"name:{base.casefold()}|{wrapper}" if base else "code:" + str(fund.get("code") or "")


def _validate_formal_results(results: list[dict]) -> list[dict]:
    rows = list(results or [])
    if len(rows) != DISPLAY_TOP_N:
        raise DataError(f"正式结果必须恰好 {DISPLAY_TOP_N} 只，当前只有 {len(rows)} 只")
    underlying = {_underlying_key(item) for item in rows}
    if "" in underlying or len(underlying) != DISPLAY_TOP_N:
        raise DataError(f"正式 Top{DISPLAY_TOP_N} 存在重复或缺失的底层基金标识")
    return rows


def _add_years(day: _dt.date, years: int) -> _dt.date:
    try:
        return day.replace(year=day.year + years)
    except ValueError:
        return day.replace(year=day.year + years, day=28)


def _years_before(day: _dt.date, years: int) -> _dt.date:
    return _add_years(day, -years)


def _mean_new_moon_jde(k: int) -> float:
    """Meeus-style new-moon approximation; no finite holiday-year table is required."""
    t = k / 1236.85
    t2, t3, t4 = t * t, t * t * t, t * t * t * t
    jde = 2451550.09765 + 29.530588853 * k + 0.0001337 * t2 - 0.000000150 * t3 + 0.00000000073 * t4
    e = 1.0 - 0.002516 * t - 0.0000074 * t2
    m = math.radians((2.5534 + 29.10535670 * k - 0.0000014 * t2 - 0.00000011 * t3) % 360.0)
    mp = math.radians((201.5643 + 385.81693528 * k + 0.0107582 * t2 + 0.00001238 * t3 - 0.000000058 * t4) % 360.0)
    f = math.radians((160.7108 + 390.67050284 * k - 0.0016118 * t2 - 0.00000227 * t3 + 0.000000011 * t4) % 360.0)
    omega = math.radians((124.7746 - 1.56375580 * k + 0.0020672 * t2 + 0.00000215 * t3) % 360.0)
    correction = (
        -0.40720 * math.sin(mp) + 0.17241 * e * math.sin(m) + 0.01608 * math.sin(2 * mp)
        + 0.01039 * math.sin(2 * f) + 0.00739 * e * math.sin(mp - m)
        - 0.00514 * e * math.sin(mp + m) + 0.00208 * e * e * math.sin(2 * m)
        - 0.00111 * math.sin(mp - 2 * f) - 0.00057 * math.sin(mp + 2 * f)
        + 0.00056 * e * math.sin(2 * mp + m) - 0.00042 * math.sin(3 * mp)
        + 0.00042 * e * math.sin(m + 2 * f) + 0.00038 * e * math.sin(m - 2 * f)
        - 0.00024 * e * math.sin(2 * mp - m) - 0.00017 * math.sin(omega)
        - 0.00007 * math.sin(mp + 2 * m) + 0.00004 * math.sin(2 * mp - 2 * f)
        + 0.00004 * math.sin(3 * m) + 0.00003 * math.sin(mp + m - 2 * f)
        + 0.00003 * math.sin(2 * mp + 2 * f) - 0.00003 * math.sin(mp + m + 2 * f)
        + 0.00003 * math.sin(mp - m + 2 * f) - 0.00002 * math.sin(mp - m - 2 * f)
        - 0.00002 * math.sin(3 * mp + m) + 0.00002 * math.sin(4 * mp)
    )
    return jde + correction


def _estimated_lunar_new_year(year: int) -> _dt.date | None:
    """Estimate CNY as the second new moon after the previous December solstice window."""
    try:
        epoch = _dt.datetime(1970, 1, 1, tzinfo=_dt.timezone.utc)
        solstice_window = _dt.datetime(year - 1, 12, 20, tzinfo=_dt.timezone.utc)
        solstice_jd = 2440587.5 + (solstice_window - epoch).total_seconds() / 86400.0
        k0 = int(math.floor((solstice_jd - 2451550.09765) / 29.530588853)) - 1
        moons = []
        for k in range(k0, k0 + 6):
            instant = epoch + _dt.timedelta(days=_mean_new_moon_jde(k) - 2440587.5)
            china_day = instant.astimezone(CHINA_TZ).date()
            if _dt.date(year - 1, 12, 20) < china_day <= _dt.date(year, 3, 1):
                moons.append(china_day)
        moons = sorted(set(moons))
        candidate = moons[1] if len(moons) >= 2 else None
        lower, upper = _dt.date(year, 1, 21), _dt.date(year, 2, 20)
        if candidate and lower <= candidate <= upper:
            return candidate
        # Rare leap-month years can push New Year to the following new moon (for example 2034).
        for alternate in moons[2:]:
            if lower <= alternate <= upper:
                return alternate
    except (OverflowError, ValueError):
        return None
    return None


# Actual fund NAV observation dates are the primary, persisted trading calendar.
# The algorithmic holiday heuristic is used only when current observations do not yet bracket the interval.
_OBSERVED_MARKET_SESSIONS: set[str] = set()
_OBSERVED_MARKET_SESSION_LOCK = threading.RLock()


def _register_observed_market_sessions(dates) -> None:
    valid = {
        str(value)[:10] for value in (dates or [])
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(value)[:10])
    }
    if not valid:
        return
    with _OBSERVED_MARKET_SESSION_LOCK:
        _OBSERVED_MARKET_SESSIONS.update(valid)


def _observed_market_sessions(start_exclusive: _dt.date, finish_inclusive: _dt.date) -> int | None:
    if finish_inclusive <= start_exclusive:
        return 0
    with _OBSERVED_MARKET_SESSION_LOCK:
        if not _OBSERVED_MARKET_SESSIONS:
            return None
        first = min(_OBSERVED_MARKET_SESSIONS)
        last = max(_OBSERVED_MARKET_SESSIONS)
        start_text, finish_text = start_exclusive.isoformat(), finish_inclusive.isoformat()
        # Require the cached observation calendar to bracket the requested interval.
        if first > start_text or last < finish_text:
            return None
        count = sum(start_text < day <= finish_text for day in _OBSERVED_MARKET_SESSIONS)
    # Guard against a sparse/corrupted local calendar; if density is implausibly low,
    # fall back to the heuristic rather than silently treating missing rows as holidays.
    weekday_count = sum(
        1 for offset in range(1, (finish_inclusive - start_exclusive).days + 1)
        if (start_exclusive + _dt.timedelta(days=offset)).weekday() < 5
    )
    if weekday_count >= 3 and count < max(1, int(weekday_count * 0.45)):
        return None
    return count


def _probable_china_market_holiday(day: _dt.date) -> bool:
    if day.weekday() >= 5:
        return True
    if (day.month, day.day) in {(1, 1)} or (day.month == 4 and 4 <= day.day <= 6):
        return True
    if day.month == 5 and day.day <= 5:
        return True
    if day.month == 10 and day.day <= 7:
        return True
    lunar_new_year = _estimated_lunar_new_year(day.year)
    if lunar_new_year and lunar_new_year - _dt.timedelta(days=2) <= day <= lunar_new_year + _dt.timedelta(days=7):
        return True
    return False


def _expected_market_sessions(start_exclusive: _dt.date, finish_inclusive: _dt.date) -> int:
    observed = _observed_market_sessions(start_exclusive, finish_inclusive)
    if observed is not None:
        return observed
    if finish_inclusive <= start_exclusive:
        return 0
    count = 0
    day = start_exclusive + _dt.timedelta(days=1)
    while day <= finish_inclusive:
        count += int(not _probable_china_market_holiday(day))
        day += _dt.timedelta(days=1)
    return count


def _age_seconds(iso_value: str | None) -> float:
    stamp = _parse_iso(iso_value)
    if stamp is None or stamp.tzinfo is None:
        return float("inf")
    return max(0.0, (_dt.datetime.now().astimezone() - stamp.astimezone()).total_seconds())


def _rank_scale(values) -> list[float]:
    count = len(values)
    if count <= 1:
        return [0.0] * count
    order = sorted(range(count), key=lambda i: (_finite(values[i]), i))
    result = [0.0] * count
    start = 0
    while start < count:
        end = start + 1
        current = _finite(values[order[start]])
        while end < count and abs(_finite(values[order[end]]) - current) < 1e-12:
            end += 1
        average_rank = (start + end - 1) / 2.0
        scaled = 2.0 * average_rank / (count - 1) - 1.0
        for position in range(start, end):
            result[order[position]] = scaled
        start = end
    return result


def _path_is_reparse_or_symlink(path: Path) -> bool:
    """True for symlinks and Windows reparse points (including junctions)."""
    path = Path(path)
    try:
        if path.is_symlink():
            return True
        if not os.path.lexists(str(path)):
            return False
        attrs = int(getattr(os.lstat(path), "st_file_attributes", 0) or 0)
        return bool(attrs & 0x400)  # FILE_ATTRIBUTE_REPARSE_POINT
    except (OSError, ValueError):
        # If an existing app-owned path cannot be inspected safely, fail closed at callers.
        return os.path.lexists(str(path))


def _assert_isolated_app_path(path: Path, base: Path | None = None) -> Path:
    """Resolve every existing component and reject any escape/reparse point under the app root."""
    root = Path(base if base is not None else BASE_DIR).resolve()
    target = Path(os.path.abspath(str(path)))
    try:
        relative = target.relative_to(root)
    except ValueError as exc:
        raise StorageError(f"应用可写路径越出用户选择目录：{target}") from exc
    current = root
    for part in relative.parts:
        current = current / part
        if not os.path.lexists(str(current)):
            continue
        if _path_is_reparse_or_symlink(current):
            raise StorageError(f"拒绝使用符号链接/junction/reparse point 作为应用可写路径：{current}")
        try:
            resolved = current.resolve(strict=True)
        except OSError as exc:
            raise StorageError(f"无法安全解析应用可写路径：{current}: {exc}") from exc
        if resolved != root and root not in resolved.parents:
            raise StorageError(f"应用可写路径解析后越出用户选择目录：{current} -> {resolved}")
    return target


def _ensure_isolated_app_dir(path: Path) -> Path:
    target = _assert_isolated_app_path(path)
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise StorageError(f"无法在用户选择目录创建应用文件夹：{target}: {exc}") from exc
    _assert_isolated_app_path(target)
    if not target.is_dir():
        raise StorageError(f"应用目录不是普通文件夹：{target}")
    return target


def _app_owned_paths() -> list[Path]:
    paths = [
        CACHE_PATH, CACHE_ROLLBACK_PATH,
        Path(str(CACHE_PATH) + "-wal"), Path(str(CACHE_PATH) + "-shm"), Path(str(CACHE_PATH) + "-journal"),
        Path(str(CACHE_ROLLBACK_PATH) + "-wal"), Path(str(CACHE_ROLLBACK_PATH) + "-shm"), Path(str(CACHE_ROLLBACK_PATH) + "-journal"),
        MODEL_PATH, MODEL_ROLLBACK_PATH,
        ALIPAY_FILE_PATH, SETTINGS_PATH, DEPS_DIR, DEPS_TMP_DIR,
        DEPS_BACKUP_DIR, RUNTIME_TMP_DIR, BASE_DIR / ".BestAlipayFunds_cache",
        BASE_DIR / "BestAlipayFunds_wheels.tmp",
    ]
    try:
        paths.extend(BASE_DIR.glob(DEPS_DIR_PREFIX + "*"))
    except OSError:
        pass
    return list(dict.fromkeys(Path(value) for value in paths))


def _validate_app_path_isolation() -> None:
    for path in _app_owned_paths():
        _assert_isolated_app_path(path)


def _atomic_bytes(path: Path, data: bytes) -> None:
    path = _assert_isolated_app_path(Path(path))
    _assert_isolated_app_path(path.parent)
    descriptor, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        # Re-validate immediately before replacement so a concurrently introduced
        # junction/symlink cannot redirect the final write outside the selected root.
        _assert_isolated_app_path(path.parent)
        _assert_isolated_app_path(path)
        os.replace(temp, path)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def _write_json(path: Path, payload) -> None:
    raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    _atomic_bytes(path, raw)


def _read_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError, TypeError):
        return default


def _default_install_settings() -> dict:
    return {
        "schema_version": SETTINGS_SCHEMA_VERSION,
        "install_mode": "adaptive",
        "lightgbm": False,
        "advanced_tree": False,
        "xgboost_distribution": "xgboost_cpu",
        "xgboost_device": "cpu",
        "cuda_failure_fingerprint": "",
        "cuda_failure_at": "",
        "cuda_failure_reason": "",
        "auto_update_model": True,
        "dependency_pins": dict(LOCAL_DEPENDENCY_PINS),
        "dependency_install_status": "not-configured",
        "active_dependency_dir": "",
        "pending_dependency_dir": "",
        "diagnostics": {},
        "configured_at": "",
        "hardware_fingerprint": "",
        "hardware_profile": {},
        "adaptive_tier": "unknown",
        "ml_threads": 1,
        "network_workers": 4,
        "history_workers_max": 6,
        "quick_start_representatives": QUICK_START_REPRESENTATIVES,
        "metadata_enrich_candidates": METADATA_ENRICH_CANDIDATES,
    }


_SETTINGS_LOCK = threading.RLock()


def _load_install_settings() -> dict:
    with _SETTINGS_LOCK:
        raw = _read_json(SETTINGS_PATH, {})
        settings = _default_install_settings()
        if isinstance(raw, dict):
            settings.update(raw)
        if int(_finite(settings.get("schema_version"), -1)) != SETTINGS_SCHEMA_VERSION:
            return _default_install_settings()
        return settings


def _save_install_settings(settings: dict) -> None:
    with _SETTINGS_LOCK:
        payload = _default_install_settings()
        payload.update(settings or {})
        payload["schema_version"] = SETTINGS_SCHEMA_VERSION
        payload["install_mode"] = "adaptive"
        payload["dependency_pins"] = dict(LOCAL_DEPENDENCY_PINS)
        payload["configured_at"] = payload.get("configured_at") or _now_iso()
        _write_json(SETTINGS_PATH, payload)


def _record_diagnostic(component: str, detail, error_type: str | None = None) -> None:
    """Persist diagnostics without prompting the user or breaking the main workflow."""
    try:
        settings = _load_install_settings()
        diagnostics = dict(settings.get("diagnostics") or {})
        if isinstance(detail, BaseException):
            error_type = error_type or type(detail).__name__
            message = str(detail)
        else:
            message = str(detail)
        diagnostics[str(component)] = {
            "at": _now_iso(),
            "type": str(error_type or "Info"),
            "message": message[:1200],
        }
        # Keep the file bounded while retaining the most recently updated components.
        if len(diagnostics) > 12:
            ordered = sorted(diagnostics.items(), key=lambda kv: str((kv[1] or {}).get("at") or ""), reverse=True)[:12]
            diagnostics = dict(ordered)
        settings["diagnostics"] = diagnostics
        _save_install_settings(settings)
    except Exception:
        pass


def _diagnostic_status_text() -> str:
    diagnostics = _load_install_settings().get("diagnostics") or {}
    if not isinstance(diagnostics, dict) or not diagnostics:
        return "诊断状态：最近没有记录到关键路径异常。"
    rows = []
    for component, item in sorted(diagnostics.items(), key=lambda kv: str((kv[1] or {}).get("at") or ""), reverse=True)[:6]:
        item = item if isinstance(item, dict) else {}
        stamp = str(item.get("at") or "—")[:19].replace("T", " ")
        rows.append(f"{component} · {item.get('type') or 'Error'} · {stamp} · {item.get('message') or '—'}")
    return "诊断状态（最近关键事件）：\n" + "\n".join(rows)


def _model_missed_dependency_ready(model: dict, dependency_ready_at: str | None, active_dir: Path | None) -> bool:
    """True when the persisted/current model cannot prove it trained against the dependency generation that just became ready."""
    if active_dir is None or not dependency_ready_at:
        return False
    ready_at = _parse_iso(dependency_ready_at)
    trained_at = _parse_iso(model.get("trained_at")) if isinstance(model, dict) else None
    if ready_at is None:
        return False
    if trained_at is None:
        return True
    if trained_at.tzinfo is None:
        trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
    if ready_at.tzinfo is None:
        ready_at = ready_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
    trained_dir = str((model or {}).get("training_dependency_dir") or "")
    return trained_at < ready_at or trained_dir != active_dir.name


def _windows_memory_status() -> tuple[int, int]:
    if os.name != "nt":
        return 0, 0
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]
    state = MEMORYSTATUSEX(); state.dwLength = ctypes.sizeof(state)
    try:
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
            return int(state.ullTotalPhys), int(state.ullAvailPhys)
    except Exception:
        pass
    return 0, 0


def _portable_memory_status() -> tuple[int, int]:
    total, available = _windows_memory_status()
    if total > 0:
        return total, available
    try:
        page = int(os.sysconf("SC_PAGE_SIZE")); pages = int(os.sysconf("SC_PHYS_PAGES"))
        avail_pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        return page * pages, page * avail_pages
    except (AttributeError, OSError, ValueError):
        return 0, 0


def _windows_gpu_summary() -> list[dict]:
    if os.name != "nt":
        return []
    command = [
        "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
        "$ErrorActionPreference='SilentlyContinue'; "
        "Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress"
    ]
    try:
        completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4, check=False)
        if completed.returncode != 0 or not completed.stdout.strip():
            return []
        payload = json.loads(completed.stdout.lstrip("\ufeff"))
        rows = payload if isinstance(payload, list) else [payload]
        result = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            result.append({
                "name": str(row.get("Name") or "")[:160],
                "adapter_ram_bytes": max(0, int(_finite(row.get("AdapterRAM"), 0))),
                "driver": str(row.get("DriverVersion") or "")[:80],
            })
        return result
    except Exception:
        return []


def _nvidia_cuda_probe() -> dict:
    if os.name != "nt":
        return {"available": False, "max_vram_mib": 0, "gpus": []}
    commands = [
        ["nvidia-smi.exe", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader,nounits"],
        ["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader,nounits"],
    ]
    for command in commands:
        try:
            completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=4, check=False)
            if completed.returncode != 0:
                continue
            rows = []
            for line in completed.stdout.splitlines():
                parts = [part.strip() for part in line.split(",")]
                if len(parts) < 2:
                    continue
                try:
                    memory_mib = max(0, int(float(parts[1])))
                except ValueError:
                    memory_mib = 0
                rows.append({"name": parts[0][:160], "memory_mib": memory_mib, "driver": (parts[2] if len(parts) > 2 else "")[:80]})
            if rows:
                return {"available": True, "max_vram_mib": max(row["memory_mib"] for row in rows), "gpus": rows}
        except Exception:
            continue
    return {"available": False, "max_vram_mib": 0, "gpus": []}


def _detect_hardware_profile() -> dict:
    import shutil
    logical = max(1, int(os.cpu_count() or 1))
    total_ram, available_ram = _portable_memory_status()
    try:
        disk = shutil.disk_usage(BASE_DIR)
        free_disk = int(disk.free)
    except OSError:
        free_disk = 0
    gpus = _windows_gpu_summary()
    nvidia_cuda = _nvidia_cuda_probe()
    cpu_name = platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", "") or platform.machine()
    profile = {
        "detected_at": _now_iso(),
        "platform": platform.system(),
        "machine": platform.machine(),
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_bits": struct.calcsize("P") * 8,
        "cpu_name": str(cpu_name)[:200],
        "logical_cpus": logical,
        "total_ram_bytes": int(total_ram),
        "available_ram_bytes": int(available_ram),
        "free_disk_bytes": int(free_disk),
        "gpus": gpus,
        "nvidia_cuda": nvidia_cuda,
    }
    stable = {
        "platform": profile["platform"], "machine": profile["machine"], "python": f"{sys.version_info.major}.{sys.version_info.minor}",
        "python_bits": profile["python_bits"], "cpu_name": profile["cpu_name"], "logical_cpus": logical,
        "total_ram_gib": round(total_ram / (1024**3), 1) if total_ram else 0.0,
        "gpu_names": [row.get("name", "") for row in gpus],
        "gpu_drivers": [row.get("driver", "") for row in gpus],
        "nvidia_cuda": bool(nvidia_cuda.get("available")),
        "nvidia_vram_mib": int(_finite(nvidia_cuda.get("max_vram_mib"), 0)),
        "nvidia_gpu_driver_fingerprint": [
            (row.get("name", ""), row.get("driver", ""), int(_finite(row.get("memory_mib"), 0)))
            for row in (nvidia_cuda.get("gpus") or []) if isinstance(row, dict)
        ],
    }
    profile["fingerprint"] = hashlib.sha256(json.dumps(stable, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:24]
    return profile


def _adaptive_settings_for_hardware(profile: dict) -> dict:
    gib = 1024 ** 3
    logical = max(1, int(_finite(profile.get("logical_cpus"), 1)))
    total_gib = _finite(profile.get("total_ram_bytes"), 0) / gib
    avail_gib = _finite(profile.get("available_ram_bytes"), 0) / gib
    disk_gib = _finite(profile.get("free_disk_bytes"), 0) / gib
    cuda_info = profile.get("nvidia_cuda") if isinstance(profile.get("nvidia_cuda"), dict) else {}
    cuda_vram_gib = _finite(cuda_info.get("max_vram_mib"), 0) / 1024.0
    # Total RAM determines what can be installed; available RAM throttles what runs right now.
    if total_gib and (total_gib < 5.5 or logical <= 2 or disk_gib and disk_gib < 2.5):
        tier = "constrained"
    elif total_gib >= 24 and logical >= 12 and (not disk_gib or disk_gib >= 8):
        tier = "max-performance"
    elif total_gib >= 12 and logical >= 8 and (not disk_gib or disk_gib >= 5):
        tier = "performance"
    else:
        tier = "balanced"

    lightgbm = bool((not total_gib or total_gib >= 6) and logical >= 3 and (not disk_gib or disk_gib >= 3))
    advanced_tree = bool(sys.version_info >= (3, 12) and (not total_gib or total_gib >= 8) and logical >= 4 and (not disk_gib or disk_gib >= 4))
    if tier == "constrained":
        lightgbm = False; advanced_tree = False

    cuda_ready = bool(
        advanced_tree and cuda_info.get("available") is True and cuda_vram_gib >= 6
        and (not total_gib or total_gib >= 12) and (not avail_gib or avail_gib >= 5)
        and (not disk_gib or disk_gib >= 6)
    )
    xgboost_distribution = "xgboost_gpu" if cuda_ready else "xgboost_cpu"
    xgboost_device = "cuda" if cuda_ready else "cpu"

    memory_pressure = bool(total_gib and avail_gib and avail_gib / max(total_gib, 0.1) < 0.22)
    reserve = 2 if logical >= 6 else 1
    ml_cap = {"constrained": 1, "balanced": 4, "performance": 8, "max-performance": 12}[tier]
    ml_threads = max(1, min(ml_cap, max(1, logical - reserve)))
    if memory_pressure:
        ml_threads = max(1, min(ml_threads, 2))

    network_cap = {"constrained": 3, "balanced": 6, "performance": 9, "max-performance": 12}[tier]
    network_workers = max(2, min(network_cap, max(2, logical // 2 + 2)))
    history_cap = {"constrained": 3, "balanced": 7, "performance": 10, "max-performance": 12}[tier]
    history_workers = max(2, min(history_cap, logical if logical < 6 else logical - 1))
    if memory_pressure:
        network_workers = min(network_workers, 4); history_workers = min(history_workers, 4)

    quick = {"constrained": 48, "balanced": 80, "performance": 120, "max-performance": 160}[tier]
    enrich = {"constrained": 140, "balanced": 240, "performance": 320, "max-performance": 420}[tier]
    return {
        "install_mode": "adaptive",
        "adaptive_tier": tier,
        "lightgbm": lightgbm,
        "advanced_tree": advanced_tree,
        "xgboost_distribution": xgboost_distribution,
        "xgboost_device": xgboost_device,
        "cuda_vram_gib": round(cuda_vram_gib, 1),
        "auto_update_model": True,
        "ml_threads": ml_threads,
        "network_workers": network_workers,
        "history_workers_max": history_workers,
        "quick_start_representatives": quick,
        "metadata_enrich_candidates": enrich,
        "model_complexity": max({"constrained": 1, "balanced": 2, "performance": 3, "max-performance": 4}[tier], 4 if cuda_ready else 1),
        "memory_pressure_at_start": memory_pressure,
    }


def _adaptive_worker_count(kind: str, default: int, upper: int | None = None) -> int:
    settings = _load_install_settings()
    key = "history_workers_max" if kind == "history" else "network_workers"
    value = max(1, int(_finite(settings.get(key), default)))
    if upper is not None:
        value = min(value, max(1, int(upper)))
    return value


def _adaptive_ml_threads() -> int:
    return max(1, int(_finite(_load_install_settings().get("ml_threads"), 1)))


def _adaptive_limit(key: str, default: int, minimum: int = 1) -> int:
    return max(minimum, int(_finite(_load_install_settings().get(key), default)))


def _adaptive_model_complexity() -> int:
    return max(1, min(4, int(_finite(_load_install_settings().get("model_complexity"), 2))))


def _adaptive_boost_rounds(requested: int) -> int:
    factor = {1: 0.75, 2: 1.0, 3: 1.20, 4: 1.35}[_adaptive_model_complexity()]
    return max(40, int(round(max(40, int(requested)) * factor)))

def _active_dependency_dir(settings: dict | None = None) -> Path | None:
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    name = str(settings.get("active_dependency_dir") or "")
    if name.startswith(DEPS_DIR_PREFIX) and Path(name).name == name:
        candidate = BASE_DIR / name
        try:
            _assert_isolated_app_path(candidate)
        except StorageError:
            return None
        if candidate.is_dir():
            return candidate
    if DEPS_DIR.is_dir():  # legacy directory from <=15.0
        try:
            _assert_isolated_app_path(DEPS_DIR)
        except StorageError:
            return None
        return DEPS_DIR
    return None


def _activate_local_dependencies() -> Path | None:
    target = _active_dependency_dir()
    if target is None:
        return None
    text = str(target)
    if text not in sys.path:
        sys.path.insert(0, text)
    importlib.invalidate_caches()
    return target


def _pending_dependency_dir(settings: dict | None = None) -> Path | None:
    settings = settings if isinstance(settings, dict) else _load_install_settings()
    name = str(settings.get("pending_dependency_dir") or "")
    if not (name.startswith(DEPS_DIR_PREFIX) and Path(name).name == name):
        return None
    candidate = BASE_DIR / name
    try:
        _assert_isolated_app_path(candidate)
    except StorageError:
        return None
    return candidate if candidate.is_dir() else None


def _promote_pending_dependency_dir() -> bool:
    """Activate a verified dependency generation only on a fresh process start."""
    settings = _load_install_settings()
    pending = _pending_dependency_dir(settings)
    if pending is None:
        if settings.get("pending_dependency_dir"):
            settings["pending_dependency_dir"] = ""
            _save_install_settings(settings)
        return False
    ok, detail = _dependency_import_probe(pending, settings)
    if not ok:
        settings["dependency_install_status"] = "pending-verify-failed"
        settings["dependency_install_error"] = str(detail)[:1200]
        settings["pending_dependency_dir"] = ""
        _save_install_settings(settings)
        _record_diagnostic("dependency-pending-activate", detail, "ImportVerifyFailed")
        return False
    previous = _active_dependency_dir(settings)
    settings["active_dependency_dir"] = pending.name
    settings["pending_dependency_dir"] = ""
    settings["dependency_install_status"] = "activated-on-process-start:" + str(detail)[:500]
    settings["dependency_activated_at"] = _now_iso()
    settings.pop("dependency_install_error", None)
    _save_install_settings(settings)
    _cleanup_stale_dependency_dirs(pending, (previous,) if previous is not None else ())
    return True


def _cleanup_stale_dependency_dirs(active: Path | None, protected: tuple[Path, ...] = ()) -> None:
    """Best-effort cleanup only for inactive versioned dirs; Windows-locked dirs are left for a later run."""
    import shutil
    keep = {Path(value).resolve() for value in protected if value is not None}
    if active is not None:
        keep.add(active.resolve())
    try:
        candidates = [path for path in BASE_DIR.glob(DEPS_DIR_PREFIX + "*") if path.is_dir() and not path.name.endswith(".tmp")]
    except OSError:
        return
    for path in candidates:
        try:
            _assert_isolated_app_path(path)
            if _path_is_reparse_or_symlink(path):
                _record_diagnostic("dependency-cleanup", f"refused reparse point: {path}", "StorageError")
                continue
            if path.resolve() in keep or str(path) in sys.path:
                continue
            shutil.rmtree(path)
        except (OSError, StorageError):
            continue


def _model_auto_update_enabled() -> bool:
    settings = _load_install_settings()
    return settings.get("auto_update_model") is not False


def _dependency_import_probe(target: Path, settings: dict) -> tuple[bool, str]:
    names = ["numpy"]
    if settings.get("lightgbm") is True:
        names.append("lightgbm")
    if settings.get("advanced_tree") is True:
        names.append("xgboost")
    probe = (
        "import importlib, json, pathlib, sys; "
        f"target=pathlib.Path({str(target)!r}).resolve(); "
        f"names={names!r}; "
        "sys.path.insert(0, str(target)); "
        "mods=[importlib.import_module(n) for n in names]; "
        "paths={m.__name__:str(pathlib.Path(getattr(m,'__file__','')).resolve()) for m in mods}; "
        "bad=[n for n,p in paths.items() if target not in pathlib.Path(p).parents]; "
        "assert not bad, 'nonlocal imports: '+','.join(bad); "
        "print(json.dumps({'versions':{m.__name__:getattr(m,'__version__','unknown') for m in mods},'paths':paths}))"
    )
    env = dict(os.environ)
    env["PYTHONNOUSERSITE"] = "1"
    completed = subprocess.run([sys.executable, "-I", "-S", "-c", probe], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=90, check=False, env=env)
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout or "import probe failed").strip()[-1200:]
    return True, completed.stdout.strip()


def _ensure_pip_available() -> tuple[bool, str]:
    """Probe pip only. Never run ensurepip because that can modify the user's Python installation."""
    try:
        probe = subprocess.run(
            [sys.executable, "-m", "pip", "--version"], stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, timeout=30, check=False,
        )
    except Exception as exc:
        return False, f"pip probe failed without modifying global Python: {type(exc).__name__}: {exc}"[-1000:]
    if probe.returncode == 0:
        return True, (probe.stdout or "pip available").strip()
    detail = (probe.stderr or probe.stdout or "pip unavailable").strip()[-900:]
    return False, "pip 不可用；按零全局修改策略使用标准库模型。" + (" " + detail if detail else "")


def _verify_downloaded_wheels_against_pypi(wheel_dir: Path, packages: list[str]) -> tuple[bool, str, dict[str, str]]:
    """Verify every downloaded binary against the SHA-256 digest published by PyPI JSON metadata."""
    requested = {}
    for spec in packages:
        if "==" not in spec:
            return False, f"依赖未固定版本：{spec}", {}
        name, version = spec.split("==", 1)
        requested[name.lower().replace("_", "-")] = version
    wheels = sorted(wheel_dir.glob("*.whl"))
    if len(wheels) < len(requested):
        return False, f"wheel 数量异常：{len(wheels)} < {len(requested)}", {}
    verified = {}
    metadata_cache = {}
    for name, version in requested.items():
        url = f"https://pypi.org/pypi/{urllib.parse.quote(name)}/{urllib.parse.quote(version)}/json"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
            if len(raw) > 4 * 1024 * 1024:
                return False, f"PyPI 元数据过大：{name}", {}
            payload = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            return False, f"无法取得 PyPI SHA-256 元数据：{name}=={version}: {exc}", {}
        by_filename = {}
        for row in payload.get("urls") or []:
            filename = str(row.get("filename") or "")
            digest = str((row.get("digests") or {}).get("sha256") or "").lower()
            if filename and re.fullmatch(r"[0-9a-f]{64}", digest):
                by_filename[filename] = digest
        metadata_cache[(name, version)] = by_filename
    for wheel in wheels:
        filename = wheel.name
        matches = []
        for (name, version), by_filename in metadata_cache.items():
            if filename in by_filename:
                matches.append((name, version, by_filename[filename]))
        if not matches:
            return False, f"下载了未在固定 PyPI 发布清单中的 wheel：{filename}", {}
        name, version, expected = matches[0]
        actual = hashlib.sha256(wheel.read_bytes()).hexdigest().lower()
        if not hmac.compare_digest(actual, expected):
            return False, f"SHA-256 校验失败：{filename}", {}
        verified[filename] = actual
    represented = {name for filename in verified for (name, version), listing in metadata_cache.items() if filename in listing}
    missing = sorted(set(requested) - represented)
    if missing:
        return False, "固定依赖未全部下载/校验：" + ",".join(missing), {}
    return True, f"已核验 {len(verified)} 个 wheel 的 PyPI SHA-256", verified


def _install_local_dependencies(settings: dict, status_callback=None) -> tuple[bool, str]:
    packages = []
    if settings.get("lightgbm") is True:
        packages.extend((LOCAL_DEPENDENCY_PINS["numpy"], LOCAL_DEPENDENCY_PINS["scipy"], LOCAL_DEPENDENCY_PINS["lightgbm"]))
    if settings.get("advanced_tree") is True:
        if sys.version_info < (3, 12):
            settings["advanced_tree"] = False
        else:
            xgb_key = str(settings.get("xgboost_distribution") or "xgboost_cpu")
            if xgb_key not in {"xgboost_cpu", "xgboost_gpu"}:
                xgb_key = "xgboost_cpu"
            packages.extend((LOCAL_DEPENDENCY_PINS["numpy"], LOCAL_DEPENDENCY_PINS["scipy"], LOCAL_DEPENDENCY_PINS[xgb_key]))
    packages = list(dict.fromkeys(packages))
    if not packages:
        settings["dependency_install_status"] = "minimal-standard-library-only"
        _save_install_settings(settings)
        return True, "硬件自适应：当前采用标准库轻量后端"

    pip_ok, pip_detail = _ensure_pip_available()
    if not pip_ok:
        settings["dependency_install_status"] = "pip-unavailable-fallback-minimal"
        settings["dependency_install_error"] = pip_detail
        settings["lightgbm"] = False
        settings["advanced_tree"] = False
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", pip_detail, "PipUnavailable")
        return False, "pip 不可用；未运行 ensurepip、未修改全局 Python，已自动使用标准库模型。"

    import shutil
    wheel_dir = BASE_DIR / "BestAlipayFunds_wheels.tmp"
    previous_active = _active_dependency_dir(settings)
    install_seed = json.dumps({
        "packages": packages, "python": list(sys.version_info[:3]), "machine": platform.machine(),
        "xgboost_device": settings.get("xgboost_device"), "nonce": time.time_ns(),
    }, sort_keys=True, ensure_ascii=True)
    install_id = hashlib.sha256(install_seed.encode("utf-8")).hexdigest()[:12]
    final_dir = BASE_DIR / f"{DEPS_DIR_PREFIX}{install_id}"
    for safe_path in (DEPS_TMP_DIR, wheel_dir, final_dir):
        _assert_isolated_app_path(safe_path)

    for path in (DEPS_TMP_DIR, wheel_dir):
        try:
            if path.exists():
                shutil.rmtree(path)
        except OSError as exc:
            settings["dependency_install_status"] = f"prepare-failed:{type(exc).__name__}"
            settings["dependency_install_error"] = str(exc)[:1200]
            _save_install_settings(settings)
            _record_diagnostic("dependency-install", exc)
            return False, f"无法准备本地 AI 临时目录：{exc}"
    try:
        DEPS_TMP_DIR.mkdir(parents=True, exist_ok=False)
        wheel_dir.mkdir(parents=True, exist_ok=False)
    except OSError as exc:
        settings["dependency_install_status"] = f"deps-dir-failed:{type(exc).__name__}"
        settings["dependency_install_error"] = str(exc)[:1200]
        _save_install_settings(settings)
        _record_diagnostic("dependency-install", exc)
        return False, f"无法创建本地 AI 临时目录：{exc}"

    package_names = [value.split("==",1)[0] for value in packages]
    if status_callback:
        status_callback("后台下载固定版本 wheel：" + " / ".join(package_names) + "；随后自动做 SHA-256 校验…")
    download_command = [
        sys.executable, "-m", "pip", "download", "--disable-pip-version-check", "--quiet",
        "--only-binary=:all:", "--no-deps", "--no-cache-dir", "--dest", str(wheel_dir), *packages,
    ]
    try:
        downloaded = _run_process_cancellable(download_command, timeout=900)
        if downloaded.returncode != 0:
            detail = (downloaded.stderr or downloaded.stdout or "pip download failed").strip()[-1200:]
            settings["dependency_install_status"] = "download-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "DownloadFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "本地 AI 二进制依赖下载失败；程序将自动使用原有依赖或纯 Python 模型。"
        ok_hash, hash_detail, verified_hashes = _verify_downloaded_wheels_against_pypi(wheel_dir, packages)
        if not ok_hash:
            settings["dependency_install_status"] = "sha256-verify-failed"
            settings["dependency_install_error"] = hash_detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", hash_detail, "HashVerifyFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "本地 AI wheel 的 SHA-256 校验失败或无法确认；已拒绝安装并自动降级。"
        if status_callback:
            status_callback(hash_detail + "；正在离线安装到用户选择的文件夹内版本化目录…")
        install_command = [
            sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--quiet",
            "--no-index", "--no-cache-dir", "--find-links", str(wheel_dir), "--target", str(DEPS_TMP_DIR), *packages,
        ]
        installed = _run_process_cancellable(install_command, timeout=900)
        if installed.returncode != 0:
            detail = (installed.stderr or installed.stdout or "pip install failed").strip()[-1200:]
            settings["dependency_install_status"] = "install-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "InstallFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "校验后的本地 AI 依赖安装失败；程序将自动使用原有依赖或纯 Python 模型。"
        if status_callback:
            status_callback("安装完成；正在隔离验证 NumPy / SciPy / LightGBM / XGBoost…")
        ok, detail = _dependency_import_probe(DEPS_TMP_DIR, settings)
        if not ok:
            settings["dependency_install_status"] = "verify-failed"
            settings["dependency_install_error"] = detail
            _save_install_settings(settings); _record_diagnostic("dependency-install", detail, "ImportVerifyFailed")
            shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
            return False, "本地 AI 依赖验证失败；未触碰当前激活目录，程序会自动降级。"
        if status_callback:
            status_callback("验证通过；新版本将在下次启动时激活，避免当前进程热切换 native DLL…")
        os.replace(DEPS_TMP_DIR, final_dir)
        _assert_isolated_app_path(final_dir)
        settings = _load_install_settings() | settings
        settings["pending_dependency_dir"] = final_dir.name
        settings["dependency_install_status"] = "installed-pending-next-start-sha256:" + detail[:500]
        settings["dependency_wheel_sha256"] = verified_hashes
        settings["dependency_staged_at"] = _now_iso()
        settings.pop("dependency_install_error", None)
        _save_install_settings(settings)
        # Never prepend the newly installed native stack to sys.path in this process.
        # Keep both the current active generation and the pending generation until restart promotion.
        _cleanup_stale_dependency_dirs(previous_active, (final_dir,))
        shutil.rmtree(wheel_dir, ignore_errors=True)
        return True, "本地 AI 依赖已核验并暂存；下次启动自动激活，当前进程继续使用已加载版本。"
    except Exception as exc:
        shutil.rmtree(DEPS_TMP_DIR, ignore_errors=True); shutil.rmtree(wheel_dir, ignore_errors=True)
        settings["dependency_install_status"] = f"exception:{type(exc).__name__}"
        settings["dependency_install_error"] = str(exc)[:1200]
        _save_install_settings(settings); _record_diagnostic("dependency-install", exc)
        return False, "本地 AI 安装出现异常；当前激活目录未被替换，程序将自动降级继续运行。"


def _configure_hardware_adaptive(force: bool = False, status_callback=None, allow_install: bool = True) -> dict:
    """Zero-interaction hardware adaptation. No installation choice is ever shown to the user."""
    profile = _detect_hardware_profile()
    desired = _adaptive_settings_for_hardware(profile)
    current = _load_install_settings()
    fingerprint_changed = current.get("hardware_fingerprint") != profile.get("fingerprint")
    cuda_failure_same_hardware = bool(
        current.get("cuda_failure_fingerprint")
        and current.get("cuda_failure_fingerprint") == profile.get("fingerprint")
    )
    if cuda_failure_same_hardware and desired.get("xgboost_device") == "cuda":
        # A CUDA training failure is sticky for the current GPU+driver fingerprint.
        # Do not repeatedly retry on every training cycle; a driver/GPU fingerprint change clears it.
        desired["xgboost_device"] = "cpu"
        desired["cuda_backoff_active"] = True
    dependency_selection_changed = any(
        current.get(key) != desired.get(key) for key in ("lightgbm", "advanced_tree", "xgboost_distribution")
    )
    pins_changed = current.get("dependency_pins") != dict(LOCAL_DEPENDENCY_PINS)

    settings = dict(current)
    if fingerprint_changed:
        for key in ("cuda_failure_fingerprint", "cuda_failure_at", "cuda_failure_reason", "cuda_backoff_active"):
            settings.pop(key, None)
    settings.update(desired)
    settings["hardware_profile"] = profile
    settings["hardware_fingerprint"] = profile.get("fingerprint", "")
    settings["last_hardware_scan_at"] = _now_iso()
    _save_install_settings(settings)
    active_target = _activate_local_dependencies()
    pending_target = _pending_dependency_dir(settings)
    # Never remove a verified generation staged for the next process start.
    _cleanup_stale_dependency_dirs(active_target, (pending_target,) if pending_target is not None else ())

    required = []
    if settings.get("lightgbm") is True:
        required.append("lightgbm")
    if settings.get("advanced_tree") is True:
        required.append("xgboost")
    deps_ok = True
    if required:
        active_target = _active_dependency_dir(settings)
        deps_ok, _detail = _dependency_import_probe(active_target, settings) if active_target is not None else (False, "local dependency directory missing")

    status_text = str(current.get("dependency_install_status") or "")
    failed_before = any(token in status_text for token in ("failed", "unavailable", "exception"))
    retry_due = True
    if failed_before and not (force or fingerprint_changed or pins_changed):
        try:
            attempted = _parse_iso(str(current.get("last_dependency_attempt_at") or ""))
            retry_due = not attempted or (_dt.datetime.now(tz=CHINA_TZ) - attempted.astimezone(CHINA_TZ)).total_seconds() >= 24 * 3600
        except Exception:
            retry_due = True

    need_install = bool(allow_install and required and pending_target is None and (force or dependency_selection_changed or pins_changed or not deps_ok) and retry_due)
    if need_install:
        settings["last_dependency_attempt_at"] = _now_iso()
        _save_install_settings(settings)
        if status_callback:
            status_callback(f"硬件自适应：{settings['adaptive_tier']}，正在自动准备本地 AI 依赖…")
        ok, message = _install_local_dependencies(settings, status_callback=status_callback)
        settings = _load_install_settings()
        settings["last_adaptive_install_ok"] = bool(ok)
        settings["last_adaptive_install_message"] = str(message)[:500]
        _save_install_settings(settings)
    elif required and pending_target is not None:
        settings["dependency_install_status"] = "installed-pending-next-start"
        settings["dependency_install_error"] = "新 native AI 依赖已核验并暂存；为避免当前进程热切换 DLL，将在下次启动自动激活。"
        _save_install_settings(settings)
    elif required and not deps_ok and not allow_install:
        settings["dependency_install_status"] = "deferred-background-install"
        settings["dependency_install_error"] = "GUI 已先启动；高级 AI 依赖将在应用工作线程中自动准备。若本轮训练先完成，会在依赖就绪后自动补训。"
        _save_install_settings(settings)
    elif required and not deps_ok and not retry_due:
        settings["lightgbm"] = False
        settings["advanced_tree"] = False
        settings["dependency_install_status"] = "adaptive-backoff-after-failed-install"
        settings["dependency_install_error"] = "上一轮本地 AI 依赖安装失败；24 小时退避期内自动使用纯 Python AI。"
        _save_install_settings(settings)
    elif not required:
        settings["dependency_install_status"] = "adaptive-standard-library-fallback"
        _save_install_settings(settings)
    else:
        settings["dependency_install_status"] = settings.get("dependency_install_status") or "adaptive-local-dependencies-ready"
        _save_install_settings(settings)

    _activate_local_dependencies()
    return _load_install_settings()


def _record_cuda_failure(exc: BaseException) -> None:
    """Persist CUDA fallback against the current hardware/driver fingerprint."""
    try:
        settings = _load_install_settings()
        fingerprint = str(settings.get("hardware_fingerprint") or "")
        settings["cuda_failure_fingerprint"] = fingerprint
        settings["cuda_failure_at"] = _now_iso()
        settings["cuda_failure_reason"] = f"{type(exc).__name__}: {exc}"[:1200]
        settings["cuda_backoff_active"] = True
        settings["xgboost_device"] = "cpu"
        _save_install_settings(settings)
        _record_diagnostic("xgboost-cuda", exc, "ModelError")
    except Exception:
        pass


def _decode_response(raw: bytes, charset: str | None) -> str:
    candidates = [charset, "utf-8-sig", "utf-8", "gb18030"]
    for candidate in candidates:
        if not candidate:
            continue
        try:
            return raw.decode(candidate)
        except (LookupError, UnicodeDecodeError):
            pass
    return raw.decode("utf-8", errors="replace")


def _read_response_limited(response, limit: int = MAX_HTTP_RESPONSE_BYTES) -> bytes:
    try:
        content_length = int(response.headers.get("Content-Length") or 0)
    except (TypeError, ValueError):
        content_length = 0
    if content_length > limit:
        raise NetworkError(f"网络响应声明大小 {content_length} 字节，超过安全上限 {limit} 字节")
    raw = response.read(limit + 1)
    if len(raw) > limit:
        raise NetworkError(f"网络响应超过安全上限 {limit} 字节")
    return raw


def _safe_gzip_decompress(raw: bytes, limit: int = MAX_HTTP_DECOMPRESSED_BYTES) -> bytes:
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode="rb") as handle:
            decoded = handle.read(limit + 1)
    except (OSError, EOFError) as exc:
        raise ParseError(f"gzip 响应损坏：{exc}") from exc
    if len(decoded) > limit:
        raise ParseError(f"gzip 解压结果超过安全上限 {limit} 字节")
    return decoded


class _DomainTokenBucket:
    """Small per-domain token bucket to avoid turning concurrency into self-inflicted throttling."""
    def __init__(self, rate: float, capacity: float):
        self.rate = max(0.25, float(rate))
        self.capacity = max(1.0, float(capacity))
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self.penalty_until = 0.0
        self.lock = threading.Lock()

    def acquire(self) -> None:
        while True:
            with self.lock:
                now = time.monotonic()
                effective_rate = self.rate * (0.35 if now < self.penalty_until else 1.0)
                self.tokens = min(self.capacity, self.tokens + (now - self.updated) * effective_rate)
                self.updated = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return
                wait = (1.0 - self.tokens) / max(0.25, effective_rate)
            time.sleep(min(0.35, max(0.01, wait)))

    def penalize(self, seconds: float = 20.0) -> None:
        with self.lock:
            self.tokens = min(self.tokens, 0.25)
            self.penalty_until = max(self.penalty_until, time.monotonic() + max(2.0, seconds))


_DOMAIN_BUCKETS: dict[str, _DomainTokenBucket] = {}
_DOMAIN_BUCKETS_LOCK = threading.Lock()


def _domain_bucket(url: str) -> _DomainTokenBucket:
    host = (urllib.parse.urlsplit(url).hostname or "unknown").lower()
    with _DOMAIN_BUCKETS_LOCK:
        bucket = _DOMAIN_BUCKETS.get(host)
        if bucket is None:
            # Sina HTML fallback is deliberately gentler; Eastmoney public APIs can tolerate somewhat more parallelism.
            rate, capacity = ((3.0, 3.0) if "sina" in host else (7.0, 6.0))
            bucket = _DOMAIN_BUCKETS[host] = _DomainTokenBucket(rate, capacity)
        return bucket


class _PinnedRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, allowed_hosts: set[str] | frozenset[str]):
        super().__init__()
        self.allowed_hosts = {str(host).strip().lower() for host in allowed_hosts if str(host).strip()}

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        host = (parsed.hostname or "").lower()
        if parsed.scheme.lower() != "https" or host not in self.allowed_hosts:
            raise urllib.error.HTTPError(
                req.full_url, code,
                f"已阻止携带受信请求头跳转到白名单外地址：{newurl}", headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


# ===== HTTP / 限流 =====

def _http_text(
    url: str,
    *,
    data: dict | None = None,
    referer: str = "https://fund.eastmoney.com/",
    timeout: float = 9.0,
    attempts: int = 2,
    headers_extra: dict | None = None,
    allowed_redirect_hosts: set[str] | frozenset[str] | None = None,
    max_response_bytes: int = MAX_HTTP_RESPONSE_BYTES,
) -> str:
    parsed_url = urllib.parse.urlsplit(url)
    initial_host = (parsed_url.hostname or "").lower()
    if parsed_url.scheme.lower() != "https" or not initial_host:
        raise NetworkError(f"金融数据源必须使用有效 HTTPS 地址：{url}")
    if allowed_redirect_hosts is None:
        allowed_redirect_hosts = frozenset({initial_host})
    else:
        allowed_redirect_hosts = frozenset(str(host).strip().lower() for host in allowed_redirect_hosts if str(host).strip())
        if initial_host not in allowed_redirect_hosts:
            raise NetworkError(f"金融数据源初始域名 {initial_host} 不在固定白名单")
    encoded = None
    if data is not None:
        encoded = urllib.parse.urlencode(data).encode("utf-8")
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json,text/javascript,*/*;q=0.8",
        "Accept-Encoding": "gzip",
        "Referer": referer,
        "Cache-Control": "no-cache",
        "X-Requested-With": "XMLHttpRequest",
    }
    if encoded is not None:
        headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    if headers_extra:
        headers.update({str(k): str(v) for k, v in headers_extra.items() if v is not None})
    last_error = None
    bucket = _domain_bucket(url)
    for attempt in range(attempts):
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        try:
            bucket.acquire()
            request = urllib.request.Request(url, data=encoded, headers=headers)
            opener = urllib.request.build_opener(_PinnedRedirectHandler(allowed_redirect_hosts))
            with opener.open(request, timeout=timeout) as response:
                raw = _read_response_limited(response, max_response_bytes)
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    raw = _safe_gzip_decompress(raw)
                return _decode_response(raw, response.headers.get_content_charset())
        except (OSError, urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            last_error = exc
            if isinstance(exc, urllib.error.HTTPError) and exc.code == 429:
                bucket.penalize(30.0)
            elif isinstance(exc, (TimeoutError, urllib.error.URLError)):
                bucket.penalize(6.0)
            if attempt + 1 < attempts:
                if _sleep_interruptible(0.35 * (attempt + 1) + random.random() * 0.2):
                    raise concurrent.futures.CancelledError("程序正在退出")
    raise NetworkError(f"网络请求失败：{last_error}")


def _http_json(url: str, **kwargs):
    text = _http_text(url, **kwargs)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
        raise ParseError(f"数据格式无法识别：{exc}") from exc


def _wrapper_type(value: str) -> str:
    text = (value or "").upper()
    if "QDII" in text or "海外" in text:
        return "QDII"
    if "FOF" in text or "基金中基金" in text:
        return "FOF"
    return "普通"


def _coarse_type(value: str) -> str:
    text = value or "其他"
    if "债" in text:
        return "债券"
    if "指数" in text or "ETF" in text.upper():
        return "指数"
    if "股票" in text:
        return "股票"
    if "混合" in text:
        return "混合"
    if _wrapper_type(text) == "FOF":
        return "混合"
    if _wrapper_type(text) == "QDII":
        return "指数" if "指数" in text else "股票"
    return "其他"


def _base_name(name: str) -> str:
    value = re.sub(r"[（(](人民币|前端|后端|场外)[）)]", "", name or "")
    value = re.sub(r"(?:ETF)?联接基金?([AC])?$", "联接", value, flags=re.I)
    value = re.sub(r"(?:人民币)?[A-EH-IY]类?$", "", value, flags=re.I)
    value = re.sub(r"[\s·\-_（）()]", "", value)
    return value


def _share_preference(name: str) -> int:
    compact = (name or "").strip().upper()
    if re.search(r"A类?$", compact):
        return 4
    if re.search(r"C类?$", compact):
        return 3
    if re.search(r"[BDEHIY]类?$", compact):
        return 2
    return 3


def _theme(name: str) -> str:
    groups = {
        "医药医疗": ("医药", "医疗", "生物", "创新药"),
        "科技半导体": ("科技", "半导体", "芯片", "软件", "计算机", "人工智能", "机器人"),
        "新能源": ("新能源", "光伏", "电池", "汽车"),
        "消费": ("消费", "白酒", "食品", "家电"),
        "周期资源": ("煤炭", "有色", "钢铁", "资源", "化工", "黄金"),
        "军工": ("军工", "国防", "航天"),
        "金融地产": ("金融", "银行", "证券", "地产"),
        "海外": ("全球", "海外", "美国", "纳斯达克", "标普", "港股", "恒生"),
    }
    for label, words in groups.items():
        if any(word in (name or "") for word in words):
            return label
    return "宽基/全市场"


def _candidate_allowed(name: str, fund_type: str) -> bool:
    text = f"{name} {fund_type}".upper()
    blocked = (
        "货币", "理财", "同业存单", "REIT", "封闭", "定期开放", "定开",
        "后端", "分级", "杠杆", "商品", "原油", "白银",
    )
    if any(word.upper() in text for word in blocked):
        return False
    if not re.fullmatch(r"[\s\S]{2,80}", name or ""):
        return False
    return _coarse_type(fund_type) != "其他"


def _public_availability_signals(item: dict) -> set[str]:
    signals = {str(value) for value in (item.get("availability_public_signals") or []) if str(value)}
    status_text = re.sub(r"\s+", "", str(item.get("public_purchase_status") or ""))
    purchase_blocked = any(word in status_text for word in ("暂停申购", "终止申购", "封闭期", "暂停交易", "清盘", "终止运作")) and "暂停大额申购" not in status_text
    if any(word in status_text for word in ("开放申购", "可申购", "开放")) and not purchase_blocked:
        signals.add("public-purchase-open")
    if any(word in status_text for word in ("暂停大额申购", "限制大额申购", "限购", "大额申购上限")):
        signals.add("public-purchase-limited")
    catalog_sources = {str(value) for value in (item.get("catalog_sources") or []) if str(value)}
    if len(catalog_sources) >= 2 or int(_finite(item.get("public_catalog_confirmations"), 0)) >= 2:
        signals.add("multi-public-catalog")
    latest_sources = {str(value) for value in (item.get("latest_sources") or []) if str(value)}
    if len(latest_sources) >= 2 or int(_finite(item.get("latest_public_confirmations"), 0)) >= 2:
        signals.add("multi-source-latest-nav")
    latest_text = str(item.get("latest_date") or item.get("display_nav_date") or "")[:10]
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", latest_text):
        try:
            if _expected_market_sessions(_dt.date.fromisoformat(latest_text), _china_today()) <= 5:
                signals.add("recent-nav-active")
        except ValueError:
            pass
    return signals


def _purchase_evidence_score(item: dict) -> int:
    """Evidence score, not a calibrated probability. Only signed Alipay evidence is 100/100."""
    status = str(item.get("availability_status") or ("confirmed_purchasable" if item.get("availability_declared") is True else "unknown"))
    if status in PURCHASE_UNAVAILABLE_STATUSES:
        return 0
    if status == "confirmed_purchasable":
        return 100
    signals = _public_availability_signals(item)
    confirmations = max(int(_finite(item.get("availability_public_confirmations"), 0)), len(signals))
    if status == "limited_purchasable" or "public-purchase-limited" in signals:
        return 55
    if "public-purchase-open" in signals and confirmations >= 3:
        return 80
    if "public-purchase-open" in signals or confirmations >= 2 or status == "public_open":
        return 60
    if status == "redemption_suspended":
        return 35
    return 30


def _alipay_availability_confidence(item: dict) -> int:
    """Backward-compatible internal alias. The value is an evidence score, never a probability."""
    return _purchase_evidence_score(item)


def _purchase_evidence_label(item: dict) -> str:
    status = str(item.get("availability_status") or "unknown")
    score = _purchase_evidence_score(item)
    if status == "confirmed_purchasable":
        return "支付宝已确认 · 证据100/100"
    if status == "limited_purchasable":
        return f"公开可购证据 {score}/100 · 限购"
    if status == "redemption_suspended":
        return f"公开可购证据 {score}/100 · 赎回受限"
    if status in PURCHASE_UNAVAILABLE_STATUSES:
        return "公开证据：不可申购"
    if score >= 75:
        level = "强"
    elif score >= 55:
        level = "中"
    else:
        level = "弱"
    return f"公开可购证据 {level} · {score}/100"



def _valuation_entry_signal(item: dict) -> float:
    """Small current-entry signal; zero when no public index valuation percentile is available."""
    if _asset_bucket(item.get("name", ""), item.get("type", "")) not in {"指数", "QDII/海外"}:
        return 0.0
    features = item.get("product_features") if isinstance(item.get("product_features"), dict) else {}
    values = []
    for key in ("pe_percentile", "pb_percentile"):
        value = _finite(features.get(key), float("nan"))
        if math.isfinite(value):
            values.append(1.0 - 2.0 * _clamp(value, 0.0, 1.0))
    for key in ("dividend_yield_percentile", "equity_risk_premium_percentile"):
        value = _finite(features.get(key), float("nan"))
        if math.isfinite(value):
            values.append(2.0 * _clamp(value, 0.0, 1.0) - 1.0)
    return _clamp(statistics.fmean(values), -1.0, 1.0) if values else 0.0


def _product_integrity_score(item: dict) -> float:
    """Metadata/product completeness score used only as a modest ranking adjustment."""
    score = 55.0
    if item.get("fees_verified") is True:
        score += 18.0
    if str(item.get("fund_company") or "").strip():
        score += 8.0
    if str(item.get("benchmark") or item.get("index_code") or "").strip():
        score += 6.0
    if item.get("product_features"):
        score += 6.0
    if str(item.get("fund_manager") or "").strip():
        score += 4.0
    if str(item.get("metadata_checked_at") or "").strip():
        score += 3.0
    return _clamp(score, 0.0, 100.0)


def _model_evidence_factor(model: dict, item: dict) -> tuple[float, dict]:
    """Shrink confidence when historical universe/OOS/freshness evidence is weak."""
    universe_cov = _clamp(_finite(model.get("historical_universe_known_coverage"), 0.0), 0.0, 1.0)
    availability_cov = _clamp(_finite(model.get("historical_availability_coverage"), 0.0), 0.0, 1.0)
    metrics = model.get("full_pipeline_oos") or model.get("untouched_test_oos") or model.get("validation_metrics") or {}
    windows = max(0, int(_finite(metrics.get("windows"), 0)))
    windows_factor = _clamp(windows / 8.0, 0.40, 1.0)
    dispersion = abs(_finite(metrics.get("rank_ic_std"), 0.0))
    if dispersion <= 1e-12:
        median = _finite(metrics.get("rank_ic_median"), 0.0)
        p25 = _finite(metrics.get("rank_ic_p25"), median)
        dispersion = abs(median - p25)
    dispersion_factor = _clamp(1.0 - dispersion / 0.45, 0.45, 1.0)
    latest_text = str(item.get("latest_date") or ((item.get("dates") or [""])[-1] if item.get("dates") else ""))[:10]
    freshness_factor = 0.72
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", latest_text):
        try:
            sessions = _expected_market_sessions(_dt.date.fromisoformat(latest_text), _china_today())
            freshness_factor = 1.0 if sessions <= 1 else 0.94 if sessions <= 3 else 0.86 if sessions <= 5 else 0.72
        except ValueError:
            pass
    coverage_factor = 0.65 * universe_cov + 0.35 * availability_cov
    evidence = 0.35 * coverage_factor + 0.25 * windows_factor + 0.20 * dispersion_factor + 0.20 * freshness_factor
    # Missing historical dead-fund coverage must materially reduce evidence rather than merely print a warning.
    factor = _clamp(0.52 + 0.48 * evidence, 0.50, 1.0)
    # First-run/current-universe-only backtests can look deceptively strong. Until the local historical
    # universe archive has meaningful coverage, cap visible model evidence at 50-60/100.
    if universe_cov < 0.25:
        factor = min(factor, 0.50)
    elif universe_cov < 0.60:
        factor = min(factor, 0.60)
    elif universe_cov < 0.85:
        factor = min(factor, 0.78)
    details = {
        "historical_universe_known_coverage": round(universe_cov, 4),
        "historical_availability_coverage": round(availability_cov, 4),
        "oos_windows": windows,
        "rank_ic_dispersion": round(dispersion, 4),
        "freshness_factor": round(freshness_factor, 4),
        "factor": round(factor, 4),
    }
    return factor, details


# ===== 支付宝可购证据 =====

class AlipayAvailabilitySource:

    SCHEMA = "best-alipay-funds-availability-v5"

                                                                                                 
                                                                                                
                                                                                                   
                                                   
    DEFAULT_URL = ""
    PUBLIC_RSA_KEYS: dict[str, tuple[int, int]] = {}
    DEFAULT_PUBLIC_HOSTS: frozenset[str] = frozenset()

    def __init__(self):
        self.last_snapshot_state: dict = {}

    @staticmethod
    def _payload_time(payload: dict) -> str:
        return str(payload.get("generated_at") or payload.get("declared_at") or payload.get("verified_at") or "")

    @staticmethod
    def _canonical_signature_bytes(payload: dict) -> bytes:
        unsigned = dict(payload)
        unsigned.pop("signature", None)
        return json.dumps(unsigned, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

    @staticmethod
    def _verify_rsa_sha256(signature_b64: str, message: bytes, n: int, e: int = 65537) -> bool:
        try:
            signature = base64.b64decode(signature_b64, validate=True)
            size = (int(n).bit_length() + 7) // 8
            if size < 128 or len(signature) != size:
                return False
            em = pow(int.from_bytes(signature, "big"), int(e), int(n)).to_bytes(size, "big")
            digest_info = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(message).digest()
            padding_len = size - len(digest_info) - 3
            expected = b"\x00\x01" + b"\xff" * padding_len + b"\x00" + digest_info
            return padding_len >= 8 and hmac.compare_digest(em, expected)
        except (ValueError, TypeError, OverflowError):
            return False

    @classmethod
    def _trusted_url(cls) -> tuple[str, bool, frozenset[str]]:
        custom = os.environ.get("BEST_ALIPAY_AVAILABILITY_URL", "").strip()
        url = custom or cls.DEFAULT_URL
        if not url:
            return "", False, frozenset()
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme.lower() != "https" or not parsed.hostname:
            raise DataError("可信支付宝可购状态源必须是有效 HTTPS 地址")
        host = parsed.hostname.lower()
        is_public = not bool(custom)
        if is_public:
            allowed = set(cls.DEFAULT_PUBLIC_HOSTS)
            default_host = urllib.parse.urlsplit(cls.DEFAULT_URL).hostname if cls.DEFAULT_URL else None
            if default_host:
                allowed.add(default_host.lower())
            if not allowed or host not in allowed:
                raise DataError(f"内置公共可购源域名 {host} 不在发行版固定白名单")
        else:
            configured = {
                h.strip().lower() for h in os.environ.get("BEST_ALIPAY_AVAILABILITY_HOSTS", "").split(",") if h.strip()
            }
                                                                                                 
                                                                                           
            allowed = configured or {host}
            if host not in allowed:
                raise DataError(f"私有可购状态源域名 {host} 不在固定白名单中")
        return url, is_public, frozenset(allowed)

    def _write_snapshot(self, payload: dict) -> None:
        try:
            _write_json(ALIPAY_FILE_PATH, payload)
        except OSError as exc:
            raise DataError(f"无法在脚本同目录写入可购状态快照：{exc}") from exc

    @staticmethod
    def _dt_aware(value: str, field: str) -> _dt.datetime:
        stamp = _parse_iso(value)
        if stamp is None:
            raise DataError(f"可购状态源缺少合法 {field}")
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.timezone.utc)
        return stamp

    def _verify_signature(self, payload: dict, *, public_source: bool) -> None:
        source_id = str(payload.get("source_id") or "").strip()
        alg = str(payload.get("signature_alg") or "").strip().lower()
        signature = str(payload.get("signature") or "").strip()
        message = self._canonical_signature_bytes(payload)
        if not signature:
            raise DataError("可购状态缺少数字签名，已拒绝")
        if alg == "rsa-sha256":
            key_tuple = self.PUBLIC_RSA_KEYS.get(source_id)
            if key_tuple is None and not public_source:
                n_text = os.environ.get("BEST_ALIPAY_AVAILABILITY_RSA_N", "").strip()
                e_text = os.environ.get("BEST_ALIPAY_AVAILABILITY_RSA_E", "65537").strip()
                if n_text:
                    try:
                        key_tuple = (int(n_text, 0), int(e_text, 0))
                    except ValueError as exc:
                        raise DataError("私有可购状态 RSA 公钥参数无效") from exc
            if key_tuple is None:
                scope = "发行版内置" if public_source else "受信"
                raise DataError(f"可购状态源 {source_id} 没有{scope} RSA 公钥")
            if not self._verify_rsa_sha256(signature, message, *key_tuple):
                raise DataError("可购状态 RSA-SHA256 签名校验失败")
            return
        if alg == "hmac-sha256" and not public_source:
            key = os.environ.get("BEST_ALIPAY_AVAILABILITY_HMAC_KEY", "")
            if not key:
                raise DataError("私有 HMAC 可购源缺少 BEST_ALIPAY_AVAILABILITY_HMAC_KEY")
            expected = hmac.new(key.encode("utf-8"), message, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature.lower(), expected):
                raise DataError("可购状态 HMAC-SHA256 签名校验失败")
            return
        if public_source:
            raise DataError("发行版公共可购源必须使用 RSA-SHA256 非对称签名")
        raise DataError(f"不支持或不允许的可购状态签名算法：{alg or 'missing'}")

    def _validate_payload(self, payload: dict, *, require_fresh: bool = True, public_source: bool = False) -> dict:
        if not isinstance(payload, dict):
            raise DataError("可购状态数据必须是 JSON object")
        if payload.get("schema") != self.SCHEMA or int(_finite(payload.get("schema_version"), -1)) != AVAILABILITY_SCHEMA_VERSION:
            raise DataError(f"可购状态 schema 必须是 {self.SCHEMA} / version {AVAILABILITY_SCHEMA_VERSION}")
        source_id = str(payload.get("source_id") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9._:-]{3,100}", source_id):
            raise DataError("可购状态源缺少合法 source_id")
        try:
            sequence = int(payload.get("sequence"))
        except (TypeError, ValueError) as exc:
            raise DataError("可购状态源缺少合法 sequence") from exc
        if sequence < 1:
            raise DataError("可购状态 sequence 必须 >= 1")
        generated_at = str(payload.get("generated_at") or "")
        expires_at = str(payload.get("expires_at") or "")
        generated = self._dt_aware(generated_at, "generated_at")
        expires = self._dt_aware(expires_at, "expires_at")
        now = _dt.datetime.now().astimezone()
        generated_local = generated.astimezone(now.tzinfo)
        expires_local = expires.astimezone(now.tzinfo)
        if generated_local > now + _dt.timedelta(seconds=MAX_AVAILABILITY_FUTURE_SKEW_SECONDS):
            raise DataError("可购状态 generated_at 比本机时间超前超过 5 分钟")
        if expires <= generated:
            raise DataError("可购状态 expires_at 必须晚于 generated_at")
        if expires - generated > _dt.timedelta(hours=24):
            raise DataError("可购状态有效期超过 24 小时，拒绝过宽可信窗口")

                                                                                 
        self._verify_signature(payload, public_source=public_source)
        if payload.get("declared") is not True and payload.get("verified") is not True:
            raise DataError("可购状态源没有明确声明 declared/verified=true")
        if require_fresh:
            if now > expires_local:
                raise DataError(f"可购状态已于 {expires_at} 过期")
            max_age = _availability_max_age_seconds(now)
            if _age_seconds(generated_at) > max_age:
                raise DataError(f"可购状态 generated_at 已超过当前时段可信窗口 {max_age // 60} 分钟")

        rows = payload.get("funds")
        if not isinstance(rows, list):
            raise DataError("可购状态 funds 必须是数组")
        seen = set(); purchasable_count = 0
        for index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise DataError(f"可购状态 funds[{index}] 不是对象")
            code = str(row.get("code") or "")
            if not re.fullmatch(r"\d{6}", code):
                raise DataError(f"可购状态包含非法基金代码：{code!r}")
            if code in seen:
                raise DataError(f"可购状态基金代码重复：{code}")
            seen.add(code)
            if row.get("purchasable") is not True:
                continue
            if row.get("declared") is not True and row.get("verified") is not True:
                raise DataError(f"{code} 标为 purchasable 但未声明 declared/verified=true")
            item_time = str(row.get("declared_at") or row.get("verified_at") or generated_at)
            item_stamp = self._dt_aware(item_time, f"{code}.declared_at")
            if item_stamp.astimezone(now.tzinfo) > now + _dt.timedelta(seconds=MAX_AVAILABILITY_FUTURE_SKEW_SECONDS):
                raise DataError(f"{code} 声明时间超前超过 5 分钟")
            if require_fresh and item_stamp > expires:
                raise DataError(f"{code} 声明时间晚于清单 expires_at")
            if require_fresh and _age_seconds(item_time) > _availability_max_age_seconds(now):
                raise DataError(f"{code} 可购声明本身已超过当前时段可信窗口")
            purchasable_count += 1
        if purchasable_count < MIN_AVAILABILITY_FUNDS:
            raise DataError(f"可信可购状态源仅声明 {purchasable_count} 个当前可购具体份额，低于最低 {MIN_AVAILABILITY_FUNDS} 个")
        return payload

    @staticmethod
    def _rollback_guard(new_payload: dict, old_payload: dict) -> None:
        if not isinstance(old_payload, dict):
            return
        if str(new_payload.get("source_id") or "") != str(old_payload.get("source_id") or ""):
            return
        try:
            new_seq, old_seq = int(new_payload.get("sequence")), int(old_payload.get("sequence"))
        except (TypeError, ValueError):
            return
        if new_seq < old_seq:
            raise DataError(f"检测到可购清单 sequence 回滚：{new_seq} < {old_seq}")
        if new_seq == old_seq and AlipayAvailabilitySource._canonical_signature_bytes(new_payload) != AlipayAvailabilitySource._canonical_signature_bytes(old_payload):
            raise DataError("相同 sequence 对应不同可购清单内容，已拒绝")

    def _stale_summary(self, local: dict, *, public_source: bool) -> str:
        try:
            stale = self._validate_payload(local, require_fresh=False, public_source=public_source)
            rows = sum(1 for r in stale.get("funds") or [] if isinstance(r, dict) and r.get("purchasable") is True)
            return (
                f"已保留最后一份验签成功的历史缓存：source_id={stale.get('source_id')}，"
                f"sequence={stale.get('sequence')}，generated_at={stale.get('generated_at')}，"
                f"expires_at={stale.get('expires_at')}，当时可购 {rows} 个份额。"
                "该缓存仅供历史参考，不代表当前支付宝可购。"
            )
        except Exception as exc:
            return f"本地历史快照也无法通过签名/结构校验：{exc}"

    def _load_payload(self) -> tuple[dict, bool]:
        url, is_public, allowed_hosts = self._trusted_url()
        local = _read_json(ALIPAY_FILE_PATH, {})
        if url:
            token = os.environ.get("BEST_ALIPAY_AVAILABILITY_TOKEN", "").strip()
            headers = {"Authorization": f"Bearer {token}"} if token else {}
            try:
                downloaded = _http_json(url, referer="https://open.alipay.com/", timeout=LATEST_TIMEOUT,
                                        attempts=LATEST_ATTEMPTS, headers_extra=headers,
                                        allowed_redirect_hosts=allowed_hosts)
                validated = self._validate_payload(downloaded, require_fresh=True, public_source=is_public)
                                                                                                   
                                                                           
                try:
                    old_valid = self._validate_payload(local, require_fresh=False, public_source=is_public)
                except Exception:
                    old_valid = {}
                self._rollback_guard(validated, old_valid)
                self._write_snapshot(validated)
                self.last_snapshot_state = {"current": True, "source_id": validated.get("source_id"),
                                            "generated_at": validated.get("generated_at"), "expires_at": validated.get("expires_at"),
                                            "sequence": validated.get("sequence"), "origin": "online"}
                return validated, is_public
            except Exception as online_exc:
                try:
                    validated = self._validate_payload(local, require_fresh=True, public_source=is_public)
                    self.last_snapshot_state = {"current": True, "source_id": validated.get("source_id"),
                                                "generated_at": validated.get("generated_at"), "expires_at": validated.get("expires_at"),
                                                "sequence": validated.get("sequence"), "origin": "verified-cache"}
                    return validated, is_public
                except Exception:
                    stale = self._stale_summary(local, public_source=is_public)
                    self.last_snapshot_state = {"current": False, "historical_only": stale}
                    raise DataError(f"可信在线可购状态源不可用，且没有仍在有效期内的验签快照：{online_exc}\n{stale}") from online_exc

                                                                                                     
                                                                            
        stale = self._stale_summary(local, public_source=True)
        self.last_snapshot_state = {"current": False, "historical_only": stale}
        raise DataError(
            "未取得可信的支付宝当前可购买基金份额，程序不会把公开全市场候选冒充成支付宝可购基金。\n"
            "截至本发行版构建时，公开资料没有提供一个无需机构 app_id/权限、可覆盖支付宝全量当前可购份额的官方公共 API；"
            "因此发行版不会伪造默认地址或把第三方全市场申购状态冒充成支付宝可购。\n"
            "要实现真正开箱即用，发行维护方必须发布并运营 HTTPS 签名清单，然后把 DEFAULT_URL、固定域名白名单和对应 RSA 公钥写入发行版。\n"
            + stale
        )

    @staticmethod
    def _normalize_fee_row(row: dict) -> dict:
        fees = row.get("fees") if isinstance(row.get("fees"), dict) else {}
        output = {}
        for key in (
            "purchase_fee", "management_fee_annual", "custody_fee_annual",
            "sales_service_fee_annual", "redemption_fee_3y", "redemption_fee_5y", "redemption_fee_10y",
        ):
            value = fees.get(key)
            if value is None and key.startswith("redemption_fee_"):
                value = fees.get("redemption_fee")
            output[key] = None if value is None else _rate(value)
        output["purchase_fee_standard"] = output.get("purchase_fee")
        output["purchase_fee_channel_estimate"] = (
            _rate(fees.get("purchase_fee_channel_estimate"))
            if fees.get("purchase_fee_channel_estimate") is not None else None
        )
        return output


    def snapshot(self) -> dict[str, dict]:
        payload, is_public = self._load_payload()
        payload = self._validate_payload(payload, require_fresh=True, public_source=is_public)
        declared_at = str(payload.get("generated_at") or "")
        evidence = str(payload.get("evidence") or "signed-source-declaration")
        source_id = str(payload.get("source_id") or "")
        output = {}
        for row in payload.get("funds") or []:
            if row.get("purchasable") is not True:
                continue
            code = str(row.get("code") or "")
            item_time = str(row.get("declared_at") or row.get("verified_at") or declared_at)
            fees = self._normalize_fee_row(row)
            output[code] = {
                "code": code,
                "name": str(row.get("name") or "").strip(),
                "type": str(row.get("type") or "").strip(),
                "share_class": str(row.get("share_class") or "").strip(),
                "availability_declared": True,
                "availability_status": "confirmed_purchasable",
                "availability_note": "支付宝可购：签名清单已确认",
                "fund_data_source": "东方财富基金公开数据（净值）",
                "availability_declared_at": item_time,
                "availability_generated_at": declared_at,
                "availability_expires_at": str(payload.get("expires_at") or ""),
                "availability_sequence": int(payload.get("sequence") or 0),
                "availability_signature_alg": str(payload.get("signature_alg") or ""),
                "availability_source": str(payload.get("source") or "signed-external"),
                "availability_source_id": source_id,
                "availability_evidence": evidence,
                "availability_schema_version": AVAILABILITY_SCHEMA_VERSION,
                "fees_verified": row.get("fees_verified") is True and all(
                    fees.get(key) is not None for key in (
                        "purchase_fee", "management_fee_annual", "custody_fee_annual",
                        "sales_service_fee_annual", "redemption_fee_3y", "redemption_fee_5y", "redemption_fee_10y",
                    )
                ),
                "fees": fees,
                "fees_history": row.get("fees_history") if isinstance(row.get("fees_history"), list) else [],
                "available_from": str(row.get("available_from") or "")[:10],
                "available_to": str(row.get("available_to") or "")[:10],
                "availability_history": row.get("availability_history") if isinstance(row.get("availability_history"), list) else [],
                "product_features": row.get("product_features") if isinstance(row.get("product_features"), dict) else {},
                "product_features_history": row.get("product_features_history") if isinstance(row.get("product_features_history"), list) else [],
                "benchmark": str(row.get("benchmark") or "").strip(),
                "index_code": str(row.get("index_code") or "").strip(),
                "fund_company": str(row.get("fund_company") or "").strip(),
                "theme": str(row.get("theme") or "").strip(),
            }
            output[code].update(_holding_costs(fees if output[code]["fees_verified"] else None))
        if len(output) < DISPLAY_TOP_N:
            raise DataError(f"当前可信可购状态源仅返回 {len(output)} 个具体份额，无法生成 Top {DISPLAY_TOP_N}")
        return output


# ===== 数据源适配器 =====

class EastMoneySource:
    LIST_URL = "https://fund.eastmoney.com/js/fundcode_search.js"
    HISTORY_URL = "https://api.fund.eastmoney.com/f10/lsjz"
    PING_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
    MOBILE_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"
    SINA_VERIFY_URL = "https://money.finance.sina.com.cn/fund/go.php/vAkFundInfo_JJGLR/q/{code}.phtml"
    BASIC_URL = "https://fundf10.eastmoney.com/jbgk_{code}.html"
    FEE_URL = "https://fundf10.eastmoney.com/jjfl_{code}.html"

    def all_funds(self) -> list[dict]:
        text = _http_text(self.LIST_URL)
        start, end = text.find("["), text.rfind("]")
        if start < 0 or end <= start:
            raise ContractError("基金清单接口返回异常")
        try:
            rows = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise ParseError("基金清单解析失败") from exc
        funds = []
        for row in rows:
            if not isinstance(row, list) or len(row) < 4 or not re.fullmatch(r"\d{6}", str(row[0])):
                continue
            funds.append({"code": str(row[0]), "name": str(row[2]), "type": str(row[3])})
        return funds

    def public_fallback_universe(self, limit: int | None = None) -> dict[str, dict]:
                                                                                            
                                                                                                   
        chosen = sorted(
            (row for row in self.all_funds() if _candidate_allowed(row.get("name", ""), row.get("type", ""))),
            key=lambda row: int(row.get("code") or 999999),
        )
        observed = _now_iso()
        output = {}
        for row in chosen:
            code = row["code"]
            output[code] = {
                **row,
                "availability_declared": False,
                "availability_status": "unknown",
                "availability_declared_at": "",
                "availability_generated_at": observed,
                "availability_expires_at": "",
                "availability_sequence": 0,
                "availability_signature_alg": "",
                "availability_source": "东方财富基金公开基金清单（非支付宝）",
                "availability_source_id": "eastmoney-public-fallback",
                "availability_evidence": "未取得支付宝可购证明；仅确认公开基金数据存在",
                "availability_note": "支付宝可购状态未知（不会因此排除；下单前需在支付宝确认）",
                "availability_schema_version": 0,
                "fund_data_source": "东方财富基金公开基金清单/历史净值",
                "fees_verified": False, "fees": {}, "fees_history": [],
                "available_from": "", "available_to": "", "availability_history": [],
                "share_class": "", "product_features": {}, "product_features_history": [],
                "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
                **_holding_costs({}),
            }
        if len(output) < 25:
            raise DataError(f"公开基金候选池仅 {len(output)} 个，无法进行长期分析")
        return output

    @staticmethod
    def structural_prefilter(availability: dict[str, dict], limit: int | None = None) -> dict[str, dict]:
        rows = []
        for code, row in availability.items():
            name = str(row.get("name") or "")
            fund_type = str(row.get("type") or "")
            status = str(row.get("availability_status") or "unknown")
            if status in PURCHASE_UNAVAILABLE_STATUSES:
                continue
            if not _candidate_allowed(name, fund_type):
                continue
            if row.get("termination_date"):
                continue
            rows.append((code, row))
        rows.sort(key=lambda pair: pair[0])
        if limit is not None:
            rows = rows[:max(0, int(limit))]
        return dict(rows)

    @staticmethod
    def _strip_html(value: str) -> str:
        value = re.sub(r"<script[\s\S]*?</script>|<style[\s\S]*?</style>", " ", value or "", flags=re.I)
        value = re.sub(r"<[^>]+>", " ", value)
        return re.sub(r"\s+", " ", html.unescape(value)).strip()

    @classmethod
    def _parse_basic_metadata(cls, text: str) -> dict:
        def cell(*labels: str) -> str:
            for label in labels:
                patterns = (
                    rf">\s*{re.escape(label)}\s*</(?:th|td)>\s*<(?:td|th)[^>]*>([\s\S]*?)</(?:td|th)>",
                    rf"{re.escape(label)}\s*</[^>]+>\s*<(?:td|th)[^>]*>([\s\S]*?)</(?:td|th)>",
                )
                for pattern in patterns:
                    match = re.search(pattern, text or "", flags=re.I)
                    if match:
                        value = cls._strip_html(match.group(1))
                        if value:
                            return value
            return ""

        company = cell("基金管理人", "管理人")
        benchmark = cell("业绩比较基准")
        tracking = cell("跟踪标的", "标的指数")
        inception_raw = cell("成立日期/规模", "成立日期")
        termination_raw = cell("终止日期", "清盘日期")
        size_raw = cell("基金规模") or inception_raw
        purchase_status = cell("申购状态", "申购赎回状态")
        tracking_error_raw = cell("跟踪误差", "年化跟踪误差")
        manager_raw = cell("基金经理", "现任基金经理")
        manager_tenure_raw = cell("任职时间", "任职年限")
        objective_match = re.search(
            r"(?:投资目标|投资方向)\s*</[^>]+>\s*(?:<[^>]+>)*([\s\S]{0,1200}?)(?=<h\d|</div>)",
            text or "", flags=re.I,
        )
        objective = cls._strip_html(objective_match.group(1)) if objective_match else ""
        inception_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", inception_raw)
        termination_match = re.search(r"\d{4}[-年]\d{1,2}[-月]\d{1,2}", termination_raw)

        def normalized_date(match) -> str:
            if not match:
                return ""
            value = match.group(0).replace("年", "-").replace("月", "-").replace("日", "")
            try:
                return _dt.date.fromisoformat("-".join(f"{int(x):02d}" if i else x for i, x in enumerate(value.split("-")))).isoformat()
            except ValueError:
                return ""

        no_tracking = any(word in tracking for word in ("无跟踪标的", "不适用", "--", "暂无"))
        index_code = "" if no_tracking else tracking
        public_theme = _theme(" ".join(value for value in (tracking, objective) if value))
        if public_theme == "宽基/全市场":
            public_theme = ""
        size_match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*亿元", size_raw)
        te_match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*%", tracking_error_raw)
        product_features = {}
        if size_match:
            product_features["fund_size_billion"] = float(size_match.group(1)) / 10.0
        if te_match:
            product_features["tracking_error_annual"] = _rate(float(te_match.group(1)) / 100.0)
        plain = cls._strip_html(text or "")
        tenure_text = " ".join(value for value in (manager_tenure_raw, manager_raw, plain) if value)
        tenure_match = re.search(r"(?:任职时间|任职年限|任职以来)[^0-9]{0,24}([0-9]+(?:\.[0-9]+)?)\s*年", tenure_text)
        if tenure_match:
            product_features["manager_tenure_years"] = _clamp(float(tenure_match.group(1)), 0.0, 40.0)
        manager_names = []
        for value in re.findall(r"(?:基金经理|现任基金经理)[：:]?\s*([\u4e00-\u9fa5·]{2,12})", plain):
            if value not in manager_names:
                manager_names.append(value)
        if manager_raw:
            product_features["manager_name"] = manager_raw
        if manager_names:
            # 这里只记录当前公开页可证实的经理信息；历史换帅次数必须依赖后续历史快照累积，不能用今天页面回填历史。
            product_features["manager_count_current"] = len(manager_names)
        if public_theme:
            product_features["style_label"] = public_theme
        valuation_patterns = {
            "pe_percentile": r"(?:PE|市盈率)[^。；;]{0,80}(?:历史)?百分位[^0-9]{0,12}([0-9]+(?:\.[0-9]+)?)\s*%",
            "pb_percentile": r"(?:PB|市净率)[^。；;]{0,80}(?:历史)?百分位[^0-9]{0,12}([0-9]+(?:\.[0-9]+)?)\s*%",
            "dividend_yield_percentile": r"(?:股息率|股息)[^。；;]{0,80}(?:历史)?百分位[^0-9]{0,12}([0-9]+(?:\.[0-9]+)?)\s*%",
            "equity_risk_premium_percentile": r"(?:风险溢价|ERP)[^。；;]{0,80}(?:历史)?百分位[^0-9]{0,12}([0-9]+(?:\.[0-9]+)?)\s*%",
        }
        for key, pattern in valuation_patterns.items():
            match = re.search(pattern, plain, flags=re.I)
            if match:
                product_features[key] = _clamp(float(match.group(1)) / 100.0, 0.0, 1.0)
        equity_match = re.search(r"(?:股票|权益)(?:资产)?[^0-9%]{0,40}(?:占基金资产|仓位|比例)[^0-9%]{0,20}([0-9]+(?:\.[0-9]+)?)\s*%", objective + " " + plain)
        if equity_match:
            product_features["equity_exposure"] = _clamp(float(equity_match.group(1)) / 100.0, 0.0, 1.0)
        return {
            "fund_company": company,
            "benchmark": benchmark,
            "index_code": index_code,
            "theme": public_theme,
            "inception_date": normalized_date(inception_match),
            "termination_date": normalized_date(termination_match),
            "public_purchase_status": purchase_status,
            "fund_manager": manager_raw,
            "product_features": product_features,
            "metadata_source": "东方财富基金档案公开结构化页面",
            "metadata_checked_at": _now_iso(),
        }

    @classmethod
    def _parse_fee_schedule(cls, text: str) -> dict:
        plain = cls._strip_html(text)

        def labelled_rate(label: str) -> float | None:
            match = re.search(rf"{re.escape(label)}[^0-9%]{{0,40}}([0-9]+(?:\.[0-9]+)?)\s*%", plain)
            if match:
                return _rate(float(match.group(1)) / 100.0)
            explicit_zero = re.search(rf"{re.escape(label)}[^。；;]{{0,40}}(?:0(?:\.0+)?\s*%|不收取|免收|免费)", plain)
            return 0.0 if explicit_zero else None

        def segment_after(label: str) -> str:
            position = (text or "").find(label)
            return (text or "")[position:position + 24000] if position >= 0 else ""

        purchase = None
        purchase_channel_estimate = None
        for row in re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", segment_after("申购费率"), flags=re.I):
            row_text = cls._strip_html(row)
            rates = [float(value) / 100.0 for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if rates and any(word in row_text for word in ("小于", "以下", "万元", "申购")):
                purchase = max(rates)  # 标准费率：不再把最低折扣当确定成本
                purchase_channel_estimate = min(rates)
                break
        if purchase is None and re.search(r"申购费率[^。；;]{0,80}(?:0(?:\.0+)?\s*%|不收取|免收)", plain):
            purchase = 0.0
            purchase_channel_estimate = 0.0

        def duration_bounds(row_text: str) -> tuple[float, float]:
            lower, upper = 0.0, float("inf")
            units = {"天":1.0, "日":1.0, "月":30.4369, "年":365.2425}
            for pattern, kind in (
                (r"(?:大于等于|不少于|≥)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "lower"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:及|或)?以上", "lower"),
                (r"(?:小于|少于|<)([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)", "upper"),
                (r"([0-9]+(?:\.[0-9]+)?)\s*(天|日|月|年)(?:以内|以下)", "upper"),
            ):
                for value, unit in re.findall(pattern, row_text):
                    days = float(value) * units[unit]
                    if kind == "lower":
                        lower = max(lower, days)
                    else:
                        upper = min(upper, days)
            return lower, upper

        redemption_rows = []
        for row in re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", segment_after("赎回费率"), flags=re.I):
            row_text = cls._strip_html(row)
            rates = [float(value) / 100.0 for value in re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*%", row_text)]
            if not rates and any(word in row_text for word in ("不收取", "免收")):
                rates = [0.0]
            if not rates or not any(unit in row_text for unit in ("天", "日", "月", "年", "以上", "以下")):
                continue
            lower, upper = duration_bounds(row_text)
            redemption_rows.append((lower, upper, min(rates)))

        fees = {
            "purchase_fee": purchase,
            "purchase_fee_standard": purchase,
            "purchase_fee_channel_estimate": purchase_channel_estimate,
            "management_fee_annual": labelled_rate("管理费率"),
            "custody_fee_annual": labelled_rate("托管费率"),
            "sales_service_fee_annual": labelled_rate("销售服务费率"),
        }
        for years in (3, 5, 10):
            days = years * 365.2425
            matching = [rate for lower, upper, rate in redemption_rows if lower <= days < upper]
            fees[f"redemption_fee_{years}y"] = min(matching) if matching else None

        required = (
            "purchase_fee", "management_fee_annual", "custody_fee_annual", "sales_service_fee_annual",
            "redemption_fee_3y", "redemption_fee_5y", "redemption_fee_10y",
        )
        verified_fields = {key: fees.get(key) is not None for key in required}
        complete = all(verified_fields.values())
        normalized = {key: (None if value is None else _rate(value)) for key, value in fees.items()}
        return {
            "fees": normalized,
            "fees_verified": complete,
            "fee_schedule_complete": complete,
            "fee_field_verified": verified_fields,
            "fees_source": "东方财富公开费率表（支付宝下单前仍需复核）",
            **_holding_costs(normalized if complete else None),
        }


    def basic_metadata(self, code: str) -> dict:
        text = _http_text(
            self.BASIC_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
            timeout=5.0, attempts=1,
        )
        result = self._parse_basic_metadata(text)
        try:
            fee_text = _http_text(
                self.FEE_URL.format(code=code), referer=f"https://fund.eastmoney.com/{code}.html",
                timeout=5.0, attempts=1,
            )
            result.update(self._parse_fee_schedule(fee_text))
        except DataError:
            pass
        return result

    def metadata_many(self, funds: list[dict]) -> dict[str, dict]:
        targets = [fund for fund in funds if re.fullmatch(r"\d{6}", str(fund.get("code") or ""))]
        output = {}
        if not targets:
            return output
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", 6, len(targets)), thread_name_prefix="fund-meta") as pool:
            future_map = {pool.submit(self.basic_metadata, str(fund["code"])): str(fund["code"]) for fund in targets}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    output[code] = future.result()
                except Exception:
                    output[code] = {"metadata_source": "公开基金档案暂不可用", "metadata_checked_at": _now_iso()}
        return output

    def candidates(self, availability: dict[str, dict], progress=lambda *_: None) -> list[dict]:
                                                                                                  
                                                                                                
        progress("读取基金全集并与当前可购声明求交集", 6)
        market = {item["code"]: item for item in self.all_funds()}
        selected = []
        for code, verified in availability.items():
            meta = market.get(code, {})
            name = verified.get("name") or meta.get("name") or code
            fund_type = verified.get("type") or meta.get("type") or "其他"
            if not _candidate_allowed(name, fund_type):
                continue
            selected.append({**meta, **verified, "code": code, "name": name, "type": fund_type})
        selected.sort(key=lambda item: item["code"])
        if len(selected) < 25:
            raise DataError(f"当前声明可购且可用于长期量化分析的份额仅 {len(selected)} 个，样本不足")
        return selected

    @staticmethod
    def _history_rows(payload) -> tuple[list[dict], int]:
        if not isinstance(payload, dict):
            return [], 0
        data = payload.get("Data")
        if isinstance(data, dict):
            rows = data.get("LSJZList") or []
            total = int(_finite(data.get("TotalCount"), len(rows)))
            return rows, total
        rows = payload.get("Datas") or []
        total = int(_finite(payload.get("TotalCount"), len(rows)))
        return rows, total

    @staticmethod
    def _history_row_date(row: dict) -> str:
        return str((row or {}).get("FSRQ") or (row or {}).get("PDATE") or "")[:10]

    def _mobile_history_pages(self, code: str, start: _dt.date) -> list[dict]:
        """Fetch mobile history page-by-page until the requested horizon or TotalCount is exhausted."""
        collected: dict[str, dict] = {}
        total_hint = None
        start_text = start.isoformat()
        for page in range(1, HISTORY_MAX_PAGES + 1):
            params = {
                "FCODE": code, "pageIndex": page, "pageSize": HISTORY_PAGE_SIZE, "plat": "Android",
                "appType": "ttjj", "product": "EFund", "version": "6.2.4",
                "deviceid": "best-alipay-funds-local",
            }
            payload = _http_json(f"{self.MOBILE_BASE}/FundMNHisNetList?" + urllib.parse.urlencode(params), attempts=1)
            if not isinstance(payload, dict) or not (isinstance(payload.get("Datas"), list) or isinstance(payload.get("Data"), dict)):
                raise ContractError(f"{code} 东方财富移动历史 payload 契约异常")
            rows, total = self._history_rows(payload)
            if total > 0:
                total_hint = max(int(total_hint or 0), int(total))
            if not rows:
                break
            valid_page_dates = []
            for index, row in enumerate(rows):
                if not isinstance(row, dict):
                    continue
                day = self._history_row_date(row)
                if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                    collected[day] = row
                    valid_page_dates.append(day)
                else:
                    collected[f"page:{page}:row:{index}"] = row
            if valid_page_dates and min(valid_page_dates) <= start_text:
                break
            if total_hint and page * HISTORY_PAGE_SIZE >= total_hint:
                break
            if len(rows) < HISTORY_PAGE_SIZE and not total_hint:
                break
        return [row for key, row in collected.items() if not key.startswith("page:") or isinstance(row, dict)]

    def _web_history_pages(self, code: str, start: _dt.date, end: _dt.date) -> list[dict]:
        """Fetch EastMoney f10 history without assuming one huge page is accepted forever."""
        collected: dict[str, dict] = {}
        total_hint = None
        for page in range(1, HISTORY_MAX_PAGES + 1):
            params = {
                "fundCode": code, "pageIndex": page, "pageSize": HISTORY_PAGE_SIZE,
                "startDate": start.isoformat(), "endDate": end.isoformat(), "_": int(time.time() * 1000),
            }
            payload = _http_json(
                self.HISTORY_URL + "?" + urllib.parse.urlencode(params),
                referer="https://fundf10.eastmoney.com/", attempts=1,
            )
            if not isinstance(payload, dict) or not isinstance(payload.get("Data"), dict):
                raise ContractError(f"{code} 东方财富 F10 历史 payload 契约异常")
            rows, total = self._history_rows(payload)
            if total > 0:
                total_hint = max(int(total_hint or 0), int(total))
            if not rows:
                break
            before = len(collected)
            for index, row in enumerate(rows):
                if not isinstance(row, dict):
                    continue
                day = self._history_row_date(row)
                key = day if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day) else f"page:{page}:row:{index}"
                collected[key] = row
            if total_hint and len([key for key in collected if not key.startswith("page:")]) >= total_hint:
                break
            if len(rows) < HISTORY_PAGE_SIZE and not total_hint:
                break
            if len(collected) == before:
                break
        return list(collected.values())

    @staticmethod
    def _normalize_history(rows: list[dict]) -> dict:
        clean = []
        for row in rows:
            date = str(row.get("FSRQ") or "")[:10]
            nav = _finite(row.get("DWJZ"), float("nan"))
            accumulated = _finite(row.get("LJJZ"), float("nan"))
            event = str(row.get("FHFCZ") or row.get("unitMoney") or "").strip()
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or not math.isfinite(nav) or nav <= 0:
                continue
            change_raw = row.get("JZZZL")
            change = None if change_raw in (None, "", "--") else _finite(change_raw) / 100.0
            clean.append((date, nav, accumulated if math.isfinite(accumulated) and accumulated > 0 else None, change, event))
        clean.sort(key=lambda item: item[0])
        clean = list({item[0]: item for item in clean}.values())
        dates, returns = [], []
        previous_nav = None
        previous_accumulated = None
        provider_fallbacks = corporate_actions = accumulated_confirmations = 0

        def cash_dividend(text: str) -> float:
            if not text:
                return 0.0
                                                                 
            match = re.search(r"每\s*(10)?\s*份[^0-9]{0,12}(?:派|分红|现金)[^0-9]{0,8}([0-9]+(?:\.[0-9]+)?)", text)
            if match:
                amount = _finite(match.group(2), 0.0)
                return amount / 10.0 if match.group(1) else amount
            match = re.search(r"(?:派现金|现金分红)[^0-9]{0,6}([0-9]+(?:\.[0-9]+)?)", text)
            return _finite(match.group(1), 0.0) if match else 0.0

        for date, nav, accumulated, reported, event in clean:
            dates.append(date)
            if previous_nav is None:
                value = 0.0
            else:
                mechanical = nav / previous_nav - 1.0
                accumulated_move = None
                if accumulated is not None and previous_accumulated is not None and previous_accumulated > 0:
                    accumulated_move = accumulated / previous_accumulated - 1.0
                dividend = cash_dividend(event)
                event_flag = bool(event and event not in ("--", "暂无分红"))
                lggj_support = (
                    reported is not None and accumulated_move is not None and -0.8 < reported < 2.0
                    and abs(reported - accumulated_move) <= 0.006
                    and abs(reported - mechanical) >= 0.015
                )
                if dividend > 0:
                    value = (nav + dividend) / previous_nav - 1.0
                    corporate_actions += 1
                    if reported is not None and abs(value - reported) <= 0.006:
                        accumulated_confirmations += int(accumulated_move is not None)
                elif reported is not None and -0.8 < reported < 2.0 and abs(reported - mechanical) <= 0.0035:
                                                                                               
                    value = mechanical
                elif reported is not None and -0.8 < reported < 2.0 and (event_flag or lggj_support):
                                                                                                     
                                                                                                   
                                                                                       
                    value = reported
                    corporate_actions += 1
                    provider_fallbacks += 1
                    accumulated_confirmations += int(lggj_support)
                else:
                    value = mechanical
            returns.append(_clamp(value, -0.8, 2.0))
            previous_nav = nav
            if accumulated is not None:
                previous_accumulated = accumulated
        _register_observed_market_sessions(dates)
        return {
            "dates": dates, "returns": returns,
            "latest_nav": clean[-1][1] if clean else None,
            "latest_date": clean[-1][0] if clean else "",
            "return_basis": "adjusted-unit-nav+explicit-corporate-actions",
            "return_provider_fallbacks": provider_fallbacks,
            "return_corporate_actions": corporate_actions,
            "return_accumulated_confirmations": accumulated_confirmations,
        }

    def _ping_history(self, code: str, start: _dt.date) -> dict:
        params = urllib.parse.urlencode({"v": int(time.time() * 1000)})
        text = _http_text(
            self.PING_URL.format(code=code) + "?" + params,
            referer=f"https://fund.eastmoney.com/{code}.html", attempts=1,
        )
        match = re.search(r"var\s+Data_netWorthTrend\s*=\s*(\[[\s\S]*?\])\s*;", text)
        if not match:
            raise ParseError(f"{code} 走势图数据结构缺失")
        try:
            source_rows = json.loads(match.group(1))
        except json.JSONDecodeError:
            source_rows = []
            for object_text in re.findall(r"\{[^{}]*\}", match.group(1)):
                x_match = re.search(r'["\']?x["\']?\s*:\s*(\d+)', object_text)
                y_match = re.search(r'["\']?y["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                r_match = re.search(r'["\']?equityReturn["\']?\s*:\s*(-?\d+(?:\.\d+)?)', object_text)
                if x_match and y_match:
                    source_rows.append({
                        "x": int(x_match.group(1)), "y": float(y_match.group(1)),
                        "equityReturn": float(r_match.group(1)) if r_match else None,
                        "unitMoney": "",
                    })
        rows = []
        for row in source_rows:
            try:
                day = _dt.datetime.fromtimestamp(float(row.get("x")) / 1000.0, tz=_dt.timezone.utc).date()
            except (TypeError, ValueError, OSError, OverflowError):
                continue
            if day < start:
                continue
            rows.append({"FSRQ": day.isoformat(), "DWJZ": row.get("y"), "JZZZL": row.get("equityReturn"), "FHFCZ": row.get("unitMoney")})
        result = self._normalize_history(rows)
        if len(result["dates"]) < 450:
            raise DataError(f"{code} 走势图历史不足")
        name_match = re.search(r"var\s+fS_name\s*=\s*['\"]([^'\"]+)['\"]", text)
        if name_match:
            result["name"] = name_match.group(1).strip()
        return result

    def history(self, code: str) -> dict:
        today = _china_today()
        start = today - _dt.timedelta(days=366 * HISTORY_YEARS + 60)
        errors = []
        try:
            return self._ping_history(code, start)
        except DataError as exc:
            errors.append(str(exc))
        try:
            rows = self._mobile_history_pages(code, start)
            rows = [row for row in rows if not self._history_row_date(row) or self._history_row_date(row) >= start.isoformat()]
            result = self._normalize_history(rows)
            if len(result["dates"]) >= 450:
                return result
            errors.append(f"移动历史仅 {len(result['dates'])} 条")
        except DataError as exc:
            errors.append(str(exc))
        try:
            rows = self._web_history_pages(code, start, today)
            result = self._normalize_history(rows)
            if len(result["dates"]) >= 450:
                return result
            errors.append(f"F10历史仅 {len(result['dates'])} 条")
        except DataError as exc:
            errors.append(str(exc))
        raise DataError(f"{code} 历史净值不足或暂不可用：{'；'.join(errors[-3:]) or '数据不足'}")

    def update_history(self, code: str, cached: dict) -> dict:
        dates = [str(day)[:10] for day in (cached.get("dates") or [])]
        returns = list(cached.get("returns") or [])
        if len(dates) < MIN_HISTORY_POINTS or len(dates) != len(returns):
            return self.history(code)
        try:
            parsed_dates = [_dt.date.fromisoformat(day) for day in dates]
        except ValueError:
            return self.history(code)
        if parsed_dates != sorted(parsed_dates):
            return self.history(code)

        today = _china_today()
        # Keep one anchor observation before the revision window. _normalize_history() must
        # emit 0.0 for its first row because it has no prior NAV, so only rows after that
        # anchor are safe to overwrite in the cached return series.
        anchor_index = max(0, len(dates) - NAV_REVISION_WINDOW - 1)
        revision_start = parsed_dates[anchor_index]
        try:
            rows = self._web_history_pages(code, revision_start, today)
            incremental = self._normalize_history(rows)
            inc_dates = list(incremental.get("dates") or [])
            inc_returns = list(incremental.get("returns") or [])
            if len(inc_dates) < 2 or len(inc_dates) != len(inc_returns):
                raise ParseError(f"{code} 修订窗口历史不足，无法安全覆盖缓存")

            merged = dict(zip(dates, returns))
            replace_from = inc_dates[1]
            # Replace the overlap, rather than append-only. This also removes a stale date
            # if the provider later retracts/corrects an erroneous observation in the window.
            replace_to = inc_dates[-1]
            for day in [value for value in merged if replace_from <= value <= replace_to]:
                merged.pop(day, None)
            for day, value in zip(inc_dates[1:], inc_returns[1:]):
                merged[day] = value

            ordered_dates = sorted(merged)
            latest_date = str(incremental.get("latest_date") or ordered_dates[-1])[:10]
            latest_nav = (
                incremental.get("latest_nav")
                if incremental.get("latest_date") == latest_date
                else cached.get("latest_nav")
            )
            result = {
                "dates": ordered_dates,
                "returns": [merged[day] for day in ordered_dates],
                "latest_nav": latest_nav,
                "latest_date": latest_date,
                "return_basis": incremental.get("return_basis") or cached.get("return_basis"),
                "return_provider_fallbacks": incremental.get("return_provider_fallbacks", cached.get("return_provider_fallbacks", 0)),
                "return_corporate_actions": incremental.get("return_corporate_actions", cached.get("return_corporate_actions", 0)),
                "return_accumulated_confirmations": incremental.get("return_accumulated_confirmations", cached.get("return_accumulated_confirmations", 0)),
                "history_revision_window": NAV_REVISION_WINDOW,
            }
            _register_observed_market_sessions(ordered_dates)
            return result
        except NetworkError:
            # A transient window request may still be recoverable via ping/mobile/full-history fallbacks.
            return self.history(code)

    def latest(self, codes: list[str], *, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS) -> dict[str, dict]:
        if not codes:
            return {}
        params = {
            "pageIndex": 1, "pageSize": max(10, len(codes)), "plat": "Android",
            "appType": "ttjj", "product": "EFund", "Version": "6.2.4",
            "deviceid": "best-alipay-funds-local", "Fcodes": ",".join(codes),
        }
        payload = _http_json(
            f"{self.MOBILE_BASE}/FundMNFInfo?" + urllib.parse.urlencode(params),
            attempts=attempts, timeout=timeout,
        )
        if not isinstance(payload, dict) or not isinstance(payload.get("Datas"), list):
            raise ContractError("东方财富最新净值 payload 缺少 Datas 数组")
        output = {}
        for row in payload.get("Datas") or []:
            code = str(row.get("FCODE") or "")
            if code not in codes:
                continue
            nav = _finite(row.get("NAV"), float("nan"))
            nav_date = str(row.get("PDATE") or "")[:10]
            if not math.isfinite(nav) or nav <= 0 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", nav_date):
                continue
            output[code] = {
                "code": code, "name": str(row.get("SHORTNAME") or "").strip(),
                "nav": nav,
                "day_change": _finite(row.get("NAVCHGRT"), float("nan")),
                "nav_date": nav_date,
            }
        if len(codes) >= 2 and not output:
            raise ContractError("东方财富最新净值字段未解析出任何请求基金")
        return output

    def latest_many(self, codes: list[str], progress=lambda *_: None) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if re.fullmatch(r"\d{6}", str(code))))
        if not codes:
            progress("东方财富最新净值 0/0", 100)
            return {"rows": {}, "requested": 0, "received": 0, "failed_codes": [], "errors": []}
        output = {}
        errors = []
        fatal_contract_errors = []
        failed_batches = []
        batches = list(_chunks(codes, LATEST_BATCH_SIZE))
        workers = _adaptive_worker_count("network", 6, len(batches))
        completed = 0
        progress(f"东方财富最新净值 0/{len(codes)}", 0)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="latest") as pool:
            future_map = {
                pool.submit(self.latest, batch, timeout=LATEST_TIMEOUT, attempts=LATEST_ATTEMPTS): batch
                for batch in batches
            }
            for future in concurrent.futures.as_completed(future_map):
                batch = future_map[future]
                try:
                    output.update(future.result())
                except Exception as exc:
                    failed_batches.extend(batch)
                    errors.append(str(exc))
                    if isinstance(exc, (ParseError, ContractError)):
                        fatal_contract_errors.append(exc)
                finally:
                    completed += len(batch)
                    progress(
                        f"东方财富最新净值 {min(completed, len(codes))}/{len(codes)} · 已取得 {len(output)}",
                        100.0 * min(completed, len(codes)) / max(1, len(codes)),
                    )
        if fatal_contract_errors and not output:
            raise fatal_contract_errors[0]
        missing = [code for code in codes if code not in output]
        failed_codes = list(dict.fromkeys(failed_batches + missing))
        return {
            "rows": output,
            "requested": len(codes),
            "received": len(output),
            "failed_codes": failed_codes,
            "errors": errors,
        }


    def _sina_verify_one(self, item: dict) -> dict:
        code = str(item.get("code") or "")
        if not re.fullmatch(r"\d{6}", code):
            return {"ok": False, "reason": "invalid-code"}
        try:
            text = _http_text(
                self.SINA_VERIFY_URL.format(code=code), referer="https://finance.sina.com.cn/fund/",
                timeout=3.5, attempts=1,
            )
            normalized = re.sub(r"\s+", " ", text)
            code_ok = code in normalized
            name = str(item.get("name") or "").strip()
                                                                                                
                                                                           
            stem = re.sub(r"[A-HI-ZＡ-Ｚ]$", "", name, flags=re.I).strip()
            stem = re.sub(r"[（）()\s·•]", "", stem)
            name_ok = (not stem) or stem[:6] in re.sub(r"[（）()\s·•]", "", normalized)
            company = re.sub(r"基金管理有限公司$|基金管理$|基金$", "", str(item.get("fund_company") or "")).strip()
            company_ok = (not company) or company[:4] in normalized
            nav_match = re.search(r"(?:最新净值|昨日净值)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)", normalized)
            sina_nav = _finite(nav_match.group(1), float("nan")) if nav_match else float("nan")
            local_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
                                                                                                   
                                                                  
            nav_ratio = abs(sina_nav / local_nav - 1.0) if math.isfinite(sina_nav) and math.isfinite(local_nav) and local_nav > 0 else None
            nav_ok = nav_ratio is None or nav_ratio <= 0.25
            return {
                "ok": bool(code_ok and name_ok and nav_ok and company_ok), "code_ok": bool(code_ok), "name_ok": bool(name_ok),
                "company_ok": bool(company_ok),
                "nav_ok": bool(nav_ok), "sina_nav": sina_nav if math.isfinite(sina_nav) else None,
                "nav_relative_diff": nav_ratio, "source": "新浪财经基金中心",
                "url_kind": "money.finance.sina.com.cn/fund",
            }
        except Exception as exc:
            return {"ok": False, "reason": str(exc)[:160], "source": "新浪财经基金中心"}

    def cross_verify_top10(self, items: list[dict]) -> dict:
        rows = list(items[:10])
        if not rows:
            return {"verified": 0, "requested": 0, "source": "新浪财经基金中心"}
        verified = 0; details = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", 5, len(rows)), thread_name_prefix="sina-verify") as pool:
            future_map = {pool.submit(self._sina_verify_one, item): item for item in rows}
            for future in concurrent.futures.as_completed(future_map):
                item = future_map[future]
                try:
                    result = future.result()
                except Exception as exc:
                    result = {"ok": False, "reason": str(exc)[:160], "source": "新浪财经基金中心"}
                details[item["code"]] = result
                if result.get("ok"):
                    verified += 1
        for item in rows:
            result = details.get(item["code"], {})
            item["independent_source_verified"] = result.get("ok") is True
            item["metadata_cross_verified"] = result.get("company_ok") is True
            item["independent_source"] = "新浪财经基金中心"
            item["independent_source_nav"] = result.get("sina_nav")
            item["independent_source_note"] = result.get("reason") or ("代码/名称/净值证据一致" if result.get("ok") else "交叉核验不完整")
        return {"verified": verified, "requested": len(rows), "source": "新浪财经基金中心", "details": details}


class SecondarySource:
    """Sina public-fund adapter. It is a real fallback path, not just a final Top10 badge."""
    CATALOG_URL = "https://vip.stock.finance.sina.com.cn/fund_center/data/jsonp.php/IO.XSRV2.CallbackList['best']/NetValueReturn_Service.NetValueReturnOpen"
    HISTORY_URL = "https://stock.finance.sina.com.cn/fundInfo/view/FundInfo_LSJZ.php?symbol={code}&page={page}"
    INFO_URL = "https://stock.finance.sina.com.cn/fundInfo/view/FundInfo_XGFG.php?symbol={code}"

    @staticmethod
    def _walk_dicts(value):
        if isinstance(value, dict):
            yield value
            for child in value.values():
                yield from SecondarySource._walk_dicts(child)
        elif isinstance(value, list):
            for child in value:
                yield from SecondarySource._walk_dicts(child)

    @staticmethod
    def _fund_from_row(row: dict) -> dict | None:
        code = ""
        for key in ("symbol", "code", "fundcode", "fcode", "scode"):
            value = str(row.get(key) or "")
            match = re.search(r"(?<!\d)(\d{6})(?!\d)", value)
            if match:
                code = match.group(1); break
        if not code:
            return None
        name = next((str(row.get(key) or "").strip() for key in ("name", "sname", "fundname", "shortname") if str(row.get(key) or "").strip()), "")
        if not name:
            return None
        fund_type = next((str(row.get(key) or "").strip() for key in ("type", "typename", "fundtype", "type2") if str(row.get(key) or "").strip()), "公开基金")
        return {"code": code, "name": name, "type": fund_type}

    @staticmethod
    def _catalog_total_hint(payload) -> int | None:
        candidates = []
        for row in SecondarySource._walk_dicts(payload):
            for key in ("total", "totalcount", "totalCount", "TotalCount", "recordcount", "recordCount"):
                if key not in row:
                    continue
                try:
                    value = int(float(row.get(key)))
                except (TypeError, ValueError):
                    continue
                if 25 <= value <= 500000:
                    candidates.append(value)
        return max(candidates) if candidates else None

    def all_funds(self) -> list[dict]:
        output = {}
        empty_pages = 0
        for page in range(1, SINA_CATALOG_MAX_PAGES + 1):
            params = {"page": page, "num": 500, "sort": "form_year", "asc": 0, "ccode": "", "type2": 0, "type3": ""}
            payload = _http_json(
                self.CATALOG_URL + "?" + urllib.parse.urlencode(params),
                referer="https://vip.stock.finance.sina.com.cn/fund_center/", timeout=7.0, attempts=2,
            )
            page_codes = set()
            for row in self._walk_dicts(payload):
                item = self._fund_from_row(row)
                if item:
                    output[item["code"]] = item
                    page_codes.add(item["code"])
            total_hint = self._catalog_total_hint(payload)
            if not page_codes:
                empty_pages += 1
            else:
                empty_pages = 0
            if total_hint and len(output) >= total_hint:
                break
            if empty_pages >= 2:
                break
        else:
            _record_diagnostic(
                "sina-catalog-pagination",
                f"reached safety page cap={SINA_CATALOG_MAX_PAGES}, parsed={len(output)}",
                "ContractWarning",
            )
        if len(output) < 25:
            raise ContractError(f"新浪公开基金目录仅解析到 {len(output)} 个基金")
        return sorted(output.values(), key=lambda row: row["code"])

    @staticmethod
    def _history_rows_from_html(text: str) -> list[tuple[str, float, float | None]]:
        rows = []
        for block in re.findall(r"<tr[^>]*>([\s\S]*?)</tr>", text or "", flags=re.I):
            plain = EastMoneySource._strip_html(block)
            match = re.search(r"(20\d{2}|19\d{2})[/-](\d{1,2})[/-](\d{1,2})\s+([0-9]+(?:\.[0-9]+)?)\s+([0-9]+(?:\.[0-9]+)?)\s+([+-]?[0-9]+(?:\.[0-9]+)?)\s*%", plain)
            if not match:
                continue
            day = f"{int(match.group(1)):04d}-{int(match.group(2)):02d}-{int(match.group(3)):02d}"
            rows.append((day, float(match.group(4)), float(match.group(6)) / 100.0))
        return rows

    def history(self, code: str) -> dict:
        collected = {}
        # Forty pages is about 800 trading-day observations: enough for the minimum 3y gate.
        # It intentionally avoids thousands of fallback HTTP calls per fund if the primary provider is down.
        for page in range(1, 41):
            text = _http_text(self.HISTORY_URL.format(code=code, page=page), referer="https://finance.sina.com.cn/fund/", timeout=6.0, attempts=2)
            rows = self._history_rows_from_html(text)
            if not rows:
                if page == 1:
                    raise ParseError(f"新浪历史净值页面未解析到 {code}")
                break
            before = len(collected)
            for day, nav, growth in rows:
                collected[day] = (nav, growth)
            if len(collected) == before:
                break
            if len(collected) >= max(MIN_HISTORY_POINTS, 820):
                break
        if len(collected) < MIN_HISTORY_POINTS:
            raise DataError(f"新浪历史净值 {code} 仅 {len(collected)} 条，低于长期分析门槛")
        dates = sorted(collected)
        returns = []
        prev_nav = None
        for day in dates:
            nav, growth = collected[day]
            value = growth if growth is not None else (nav / prev_nav - 1.0 if prev_nav and prev_nav > 0 else 0.0)
            returns.append(_clamp(_finite(value), -0.95, 3.0))
            prev_nav = nav
        latest_day = dates[-1]
        latest_nav = collected[latest_day][0]
        _register_observed_market_sessions(dates)
        return {"dates": dates, "returns": returns, "latest_nav": latest_nav, "latest_date": latest_day, "history_source": "新浪财经基金历史净值"}

    def latest_one(self, code: str) -> dict | None:
        text = _http_text(self.INFO_URL.format(code=code), referer="https://finance.sina.com.cn/fund/", timeout=4.5, attempts=1)
        plain = EastMoneySource._strip_html(text)
        date_match = re.search(r"截止日期[：:]?\s*(20\d{2})[/-](\d{1,2})[/-](\d{1,2})", plain)
        nav_match = re.search(r"单位净值[：:]?\s*([0-9]+(?:\.[0-9]+)?)", plain)
        if not date_match or not nav_match:
            raise ParseError(f"新浪最新净值页面字段未匹配：{code}")
        day = f"{int(date_match.group(1)):04d}-{int(date_match.group(2)):02d}-{int(date_match.group(3)):02d}"
        change_match = re.search(r"净值增长率[：:]?\s*([+-]?[0-9]+(?:\.[0-9]+)?)\s*%", plain)
        return {"code": code, "nav": float(nav_match.group(1)), "nav_date": day, "day_change": (_finite(change_match.group(1)) if change_match else float("nan")), "source": "新浪财经基金中心"}

    def latest_many(self, codes: list[str], limit: int | None = None, progress=lambda *_: None) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if re.fullmatch(r"\d{6}", str(code))))
        if limit is not None:
            codes = codes[:max(0, int(limit))]
        output, errors, fatal_contract_errors = {}, [], []
        if not codes:
            progress("新浪最新净值 0/0", 100)
            return {"rows": {}, "requested": 0, "received": 0, "failed_codes": [], "errors": []}
        workers = _adaptive_worker_count("network", 4, len(codes))
        completed = 0
        progress(f"新浪最新净值 0/{len(codes)}", 0)
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="sina-latest") as pool:
            future_map = {pool.submit(self.latest_one, code): code for code in codes}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    row = future.result()
                    if row:
                        output[code] = row
                except Exception as exc:
                    errors.append(f"{code}:{exc}")
                    if isinstance(exc, (ParseError, ContractError)):
                        fatal_contract_errors.append(exc)
                finally:
                    completed += 1
                    progress(
                        f"新浪最新净值 {completed}/{len(codes)} · 已取得 {len(output)}",
                        100.0 * completed / max(1, len(codes)),
                    )
        if fatal_contract_errors and not output:
            raise fatal_contract_errors[0]
        missing = [code for code in codes if code not in output]
        return {"rows": output, "requested": len(codes), "received": len(output), "failed_codes": missing, "errors": errors}

    def basic_metadata(self, code: str) -> dict:
        text = _http_text(self.INFO_URL.format(code=code), referer="https://finance.sina.com.cn/fund/", timeout=5.0, attempts=1)
        plain = EastMoneySource._strip_html(text)
        def capture(*patterns):
            for pattern in patterns:
                match = re.search(pattern, plain)
                if match:
                    return re.sub(r"\s+", " ", match.group(1)).strip()
            return ""
        purchase = capture(r"申购状态[：:]?\s*([^\s|]{2,24})", r"交易状态[：:]?\s*([^\s|]{2,24})")
        company = capture(r"(?:基金管理人|基金管理公司|管理人)[：:]?\s*([^|]{2,40}?基金(?:管理)?有限公司)")
        manager = capture(r"基金经理[：:]?\s*([\u4e00-\u9fa5·、]{2,30})")
        if not any((purchase, company, manager)):
            raise ParseError(f"新浪基金档案关键字段未解析：{code}")
        return {"fund_company": company, "fund_manager": manager, "public_purchase_status": purchase, "metadata_source_secondary": "新浪财经基金中心", "metadata_checked_at_secondary": _now_iso()}


class FundDataSource:
    """Two-adapter facade with automatic source degradation and independent public evidence."""
    _parse_fee_schedule = staticmethod(EastMoneySource._parse_fee_schedule)
    _history_rows = staticmethod(EastMoneySource._history_rows)
    _normalize_history = staticmethod(EastMoneySource._normalize_history)
    _strip_html = staticmethod(EastMoneySource._strip_html)

    def __init__(self):
        self.primary = EastMoneySource()
        self.secondary = SecondarySource()
        self.source_health = {"primary": 1.0, "secondary": 1.0}
        self.source_degraded = {"primary": False, "secondary": False}
        self.source_contract = {"checked": False, "details": {}}
        self.source_circuit = {
            key: {"state": "CLOSED", "parse_failures": 0, "opened_at": 0.0, "next_probe_at": 0.0, "last_error": ""}
            for key in ("primary", "secondary")
        }
        self._contract_checked_monotonic = 0.0
        self._catalog_cache: list[dict] | None = None
        self._catalog_cache_at = 0.0

    def __getattr__(self, name):
        return getattr(self.primary, name)

    @staticmethod
    def _contract_row_valid(row: dict) -> bool:
        code = str(row.get("code") or "")
        name = str(row.get("name") or "").strip()
        return bool(re.fullmatch(r"\d{6}", code) and 1 < len(name) <= 100)

    def _open_source_circuit(self, key: str, reason: str) -> None:
        now = time.monotonic()
        state = self.source_circuit[key]
        state.update({
            "state": "OPEN",
            "opened_at": now,
            "next_probe_at": now + SOURCE_CIRCUIT_HALF_OPEN_SECONDS,
            "last_error": str(reason)[:500],
        })
        self.source_degraded[key] = True
        self.source_health[key] = min(self.source_health.get(key, 1.0), 0.20)
        self._catalog_cache = None
        _record_diagnostic(f"source-circuit-{key}", reason, "ContractError")

    def _close_source_circuit(self, key: str) -> None:
        state = self.source_circuit[key]
        state.update({"state": "CLOSED", "parse_failures": 0, "opened_at": 0.0, "next_probe_at": 0.0, "last_error": ""})
        self.source_degraded[key] = False
        self.source_health[key] = max(self.source_health.get(key, 0.0), 0.65)

    def _note_source_failure(self, key: str, exc: BaseException) -> None:
        if not isinstance(exc, (ParseError, ContractError)):
            return
        state = self.source_circuit[key]
        if state.get("state") == "OPEN":
            return
        state["parse_failures"] = int(state.get("parse_failures") or 0) + 1
        state["last_error"] = f"{type(exc).__name__}: {exc}"[:500]
        _record_diagnostic(f"source-parse-{key}", exc)
        if state["parse_failures"] >= SOURCE_PARSE_FAILURE_LIMIT:
            self._open_source_circuit(
                key,
                f"连续 {state['parse_failures']} 次 Contract/Parse 失败：{state['last_error']}",
            )

    def _note_source_success(self, key: str) -> None:
        state = self.source_circuit[key]
        if state.get("state") == "CLOSED":
            state["parse_failures"] = 0
            state["last_error"] = ""

    def startup_contract_test(self, force: bool = False, progress=lambda *_: None) -> dict:
        now = time.monotonic()
        periodic_due = (
            not self.source_contract.get("checked")
            or now - self._contract_checked_monotonic >= SOURCE_CONTRACT_RECHECK_SECONDS
        )
        half_open_due = any(
            state.get("state") == "OPEN" and now >= float(state.get("next_probe_at") or 0.0)
            for state in self.source_circuit.values()
        )
        parse_triggered = any(
            int(state.get("parse_failures") or 0) >= SOURCE_PARSE_FAILURE_LIMIT
            for state in self.source_circuit.values()
        )
        if not (force or periodic_due or half_open_due or parse_triggered):
            progress("数据源检查已使用近期安全结果", 100)
            return dict(self.source_contract)

        details = {}
        validated_catalogs = []
        source_pairs = (("primary", self.primary, "东方财富"), ("secondary", self.secondary, "新浪"))
        for source_index, (key, adapter, source_label) in enumerate(source_pairs):
            source_start = source_index * 50.0
            progress(f"检查{source_label}基金目录", source_start + 2)
            circuit = self.source_circuit[key]
            if circuit.get("state") == "OPEN" and now < float(circuit.get("next_probe_at") or 0.0) and not force:
                remaining = max(0, int(float(circuit.get("next_probe_at") or 0.0) - now))
                details[key] = {
                    "degraded": True, "state": "OPEN",
                    "note": f"熔断中，约 {remaining // 60} 分钟后进入 HALF_OPEN 探测",
                }
                continue
            if circuit.get("state") == "OPEN":
                circuit["state"] = "HALF_OPEN"

            received_but_invalid = False
            contract_reached = False
            catalog = None
            notes = []
            try:
                catalog = adapter.all_funds()
                contract_reached = True
                progress(f"检查{source_label}目录字段", source_start + 14)
                valid = [row for row in catalog if isinstance(row, dict) and self._contract_row_valid(row)]
                present = [code for code in SOURCE_CONTRACT_PROBES if any(str(row.get("code")) == code for row in valid)]
                if len(valid) < 100 or len(present) < 2:
                    received_but_invalid = True
                    notes.append(f"目录契约异常 valid={len(valid)} probes={len(present)}")
                else:
                    try:
                        progress(f"检查{source_label}最新净值字段", source_start + 20)
                        latest = adapter.latest_many(
                            present[:3],
                            progress=lambda text, pct, base=source_start: progress(
                                text, base + 20.0 + 10.0 * _clamp(_finite(pct), 0.0, 100.0) / 100.0
                            ),
                        )
                        rows = latest.get("rows") or {}
                        valid_latest = 0
                        for _code, row in rows.items():
                            nav = _finite(row.get("nav"), float("nan")); day = str(row.get("nav_date") or "")[:10]
                            if math.isfinite(nav) and nav > 0 and re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                                try:
                                    if -2 <= (_china_today() - _dt.date.fromisoformat(day)).days <= 40:
                                        valid_latest += 1
                                except ValueError:
                                    pass
                        if valid_latest < max(1, len(present[:3]) - 1):
                            received_but_invalid = True
                            notes.append(f"最新净值契约异常 {valid_latest}/{len(present[:3])}")
                    except (ParseError, ContractError) as exc:
                        received_but_invalid = True
                        notes.append(f"最新净值契约异常:{type(exc).__name__}")
                    except (NetworkError, OSError) as exc:
                        notes.append(f"最新净值暂不可达:{type(exc).__name__}")
                    except Exception as exc:
                        received_but_invalid = True
                        notes.append(f"最新净值程序解析异常:{type(exc).__name__}")
                        _record_diagnostic(f"contract-latest-{key}", exc)
                    progress(f"检查{source_label}基金信息字段", source_start + 34)
                    try:
                        meta = adapter.basic_metadata(present[0])
                        metadata_stamp = isinstance(meta, dict) and (meta.get("metadata_checked_at") or meta.get("metadata_checked_at_secondary"))
                        metadata_signal = isinstance(meta, dict) and any(
                            meta.get(field) for field in ("fund_company", "fund_manager", "public_purchase_status", "benchmark", "inception_date")
                        )
                        if not metadata_stamp or not metadata_signal:
                            received_but_invalid = True
                            notes.append("元数据契约异常")
                    except (ParseError, ContractError) as exc:
                        received_but_invalid = True
                        notes.append(f"元数据契约异常:{type(exc).__name__}")
                    except (NetworkError, OSError) as exc:
                        notes.append(f"元数据暂不可达:{type(exc).__name__}")
                    except Exception as exc:
                        received_but_invalid = True
                        notes.append(f"元数据程序解析异常:{type(exc).__name__}")
                        _record_diagnostic(f"contract-metadata-{key}", exc)
            except (ParseError, ContractError) as exc:
                contract_reached = True
                received_but_invalid = True
                notes.append(f"目录契约异常:{type(exc).__name__}")
            except (NetworkError, OSError) as exc:
                notes.append(f"目录暂不可达:{type(exc).__name__}")
            except Exception as exc:
                contract_reached = True
                received_but_invalid = True
                notes.append(f"目录程序解析异常:{type(exc).__name__}")
                _record_diagnostic(f"contract-catalog-{key}", exc)

            if received_but_invalid:
                self._open_source_circuit(key, "；".join(notes) or "契约异常")
            elif contract_reached:
                self._close_source_circuit(key)
            elif circuit.get("state") == "HALF_OPEN":
                # Network outage during HALF_OPEN is not parser drift; retry sooner without reopening forever.
                circuit["state"] = "OPEN"
                circuit["next_probe_at"] = now + min(60 * 60, SOURCE_CIRCUIT_HALF_OPEN_SECONDS)
                self.source_degraded[key] = True

            details[key] = {
                "degraded": self.source_degraded[key],
                "state": self.source_circuit[key].get("state"),
                "parse_failures": int(self.source_circuit[key].get("parse_failures") or 0),
                "note": "；".join(notes) or "契约通过",
            }
            if contract_reached and not received_but_invalid and isinstance(catalog, list):
                validated_catalogs.append((key, catalog))
            progress(
                f"{source_label}数据源检查" + ("通过" if not self.source_degraded[key] else "已降级"),
                source_start + 48,
            )

        # Reuse the directory payload already fetched during the contract check.
        # This avoids downloading the full catalog a second time during first-build.
        if validated_catalogs:
            merged = {}
            source_labels = {"primary": "东方财富", "secondary": "新浪财经"}
            for key, rows in validated_catalogs:
                source_name = source_labels.get(key, key)
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    code = str(row.get("code") or "")
                    if not re.fullmatch(r"\d{6}", code):
                        continue
                    item = merged.setdefault(code, {"code": code, "name": "", "type": ""})
                    if not item.get("name") and row.get("name"):
                        item["name"] = row.get("name")
                    if not item.get("type") and row.get("type"):
                        item["type"] = row.get("type")
                    sources = set(item.get("catalog_sources") or [])
                    sources.add(source_name)
                    item["catalog_sources"] = sorted(sources)
            for item in merged.values():
                item["public_catalog_confirmations"] = len(item.get("catalog_sources") or [])
                item["availability_public_signals"] = (["multi-public-catalog"] if item["public_catalog_confirmations"] >= 2 else [])
            if len(merged) >= 25:
                self._catalog_cache = [dict(row) for row in sorted(merged.values(), key=lambda row: row["code"])]
                self._catalog_cache_at = time.monotonic()

        self._contract_checked_monotonic = now
        self.source_contract = {"checked": True, "details": details, "checked_at": _now_iso()}
        if all(self.source_degraded.values()):
            raise ContractError("东方财富与新浪的数据格式契约均异常/熔断，拒绝让疑似错字段进入模型；将按 HALF_OPEN 周期自动复探")
        progress("数据源检查完成", 100)
        return dict(self.source_contract)

    @staticmethod
    def structural_prefilter(availability: dict[str, dict], limit: int | None = None) -> dict[str, dict]:
        return EastMoneySource.structural_prefilter(availability, limit)

    def all_funds(self) -> list[dict]:
        if self._catalog_cache is not None and time.monotonic() - self._catalog_cache_at < 20 * 60:
            return [dict(row) for row in self._catalog_cache]
        primary_rows = secondary_rows = []
        errors = []
        try:
            if self.source_degraded.get("primary"):
                raise ContractError("东方财富源已因格式契约异常熔断")
            primary_rows = self.primary.all_funds()
            self._note_source_success("primary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, "东方财富目录")
            if exc is not raw_exc: _record_diagnostic("source-primary-catalog", exc)
            self._note_source_failure("primary", exc)
            self.source_health["primary"] *= 0.35; errors.append(f"东方财富目录:{exc}")
        try:
            if self.source_degraded.get("secondary"):
                raise ContractError("新浪源已因格式契约异常熔断")
            secondary_rows = self.secondary.all_funds()
            self._note_source_success("secondary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, "新浪目录")
            if exc is not raw_exc: _record_diagnostic("source-secondary-catalog", exc)
            self._note_source_failure("secondary", exc)
            self.source_health["secondary"] *= 0.50; errors.append(f"新浪目录:{exc}")
        if not primary_rows and not secondary_rows:
            raise DataError("双基金目录均不可用：" + "；".join(errors))
        merged = {}
        for source_name, rows in (("东方财富", primary_rows), ("新浪财经", secondary_rows)):
            for row in rows:
                code = str(row.get("code") or "")
                if not re.fullmatch(r"\d{6}", code):
                    continue
                item = merged.setdefault(code, {"code": code, "name": "", "type": ""})
                if not item.get("name") and row.get("name"):
                    item["name"] = row.get("name")
                if not item.get("type") and row.get("type"):
                    item["type"] = row.get("type")
                sources = set(item.get("catalog_sources") or [])
                sources.add(source_name); item["catalog_sources"] = sorted(sources)
        for item in merged.values():
            item["public_catalog_confirmations"] = len(item.get("catalog_sources") or [])
            item["availability_public_signals"] = (["multi-public-catalog"] if item["public_catalog_confirmations"] >= 2 else [])
        if len(merged) < 25:
            raise DataError(f"双源合并基金目录仅 {len(merged)} 个")
        result = sorted(merged.values(), key=lambda row: row["code"])
        self._catalog_cache = [dict(row) for row in result]
        self._catalog_cache_at = time.monotonic()
        return result

    def public_fallback_universe(self, limit: int | None = None) -> dict[str, dict]:
        chosen = sorted((row for row in self.all_funds() if _candidate_allowed(row.get("name", ""), row.get("type", ""))), key=lambda row: int(row.get("code") or 999999))
        if limit is not None:
            chosen = chosen[:max(0, int(limit))]
        observed = _now_iso(); output = {}
        for row in chosen:
            code = row["code"]
            output[code] = {**row, "availability_declared": False, "availability_status": "unknown", "availability_declared_at": "", "availability_generated_at": observed, "availability_expires_at": "", "availability_sequence": 0, "availability_signature_alg": "", "availability_source": "公开基金多信号候选（非支付宝官方）", "availability_source_id": "public-multisignal-fallback", "availability_evidence": "支付宝签名证据未知；公开目录/申购/净值活跃度将分别计分", "availability_note": "支付宝证据未知；将用公开申购状态、在售活跃度和跨渠道存在性分层", "availability_schema_version": 0, "fund_data_source": "东方财富 + 新浪财经公开基金数据", "fees_verified": False, "fees": {}, "fees_history": [], "available_from": "", "available_to": "", "availability_history": [], "share_class": "", "product_features": {}, "product_features_history": [], "benchmark": "", "index_code": "", "fund_company": "", "theme": "", **_holding_costs({})}
        if len(output) < 25:
            raise DataError(f"公开基金候选池仅 {len(output)} 个，无法进行长期分析")
        return output

    def history(self, code: str) -> dict:
        try:
            if self.source_degraded.get("primary"):
                raise ContractError("东方财富源已熔断")
            result = self.primary.history(code)
            self._note_source_success("primary")
            result["history_source"] = "东方财富基金历史净值"
            return result
        except Exception as raw_primary_exc:
            primary_exc = _typed_source_error(raw_primary_exc, f"{code} 东方财富历史")
            if primary_exc is not raw_primary_exc: _record_diagnostic("source-primary-history", primary_exc)
            self._note_source_failure("primary", primary_exc)
            self.source_health["primary"] *= 0.92
            try:
                if self.source_degraded.get("secondary"):
                    raise ContractError("新浪源已熔断")
                result = self.secondary.history(code)
                self._note_source_success("secondary")
                result["history_fallback_reason"] = str(primary_exc)[:200]
                return result
            except Exception as raw_secondary_exc:
                secondary_exc = _typed_source_error(raw_secondary_exc, f"{code} 新浪历史")
                if secondary_exc is not raw_secondary_exc: _record_diagnostic("source-secondary-history", secondary_exc)
                self._note_source_failure("secondary", secondary_exc)
                self.source_health["secondary"] *= 0.92
                raise DataError(f"{code} 双历史源失败：东方财富={primary_exc}；新浪={secondary_exc}") from raw_secondary_exc

    @staticmethod
    def _merge_history_revision(cached: dict, revision: dict) -> dict:
        dates = [str(day)[:10] for day in (cached.get("dates") or [])]
        returns = list(cached.get("returns") or [])
        inc_dates = [str(day)[:10] for day in (revision.get("dates") or [])]
        inc_returns = list(revision.get("returns") or [])
        if len(dates) != len(returns) or len(inc_dates) < 2 or len(inc_dates) != len(inc_returns):
            raise ParseError("备用历史修订窗口无法安全合并")
        merged = dict(zip(dates, returns))
        replace_from = inc_dates[1]
        replace_to = inc_dates[-1]
        for day in [value for value in merged if replace_from <= value <= replace_to]:
            merged.pop(day, None)
        for day, value in zip(inc_dates[1:], inc_returns[1:]):
            merged[day] = value
        ordered = sorted(merged)
        cached_latest = str(cached.get("latest_date") or (dates[-1] if dates else ""))[:10]
        revision_latest = str(revision.get("latest_date") or inc_dates[-1])[:10]
        latest_date = max(cached_latest, revision_latest)
        latest_nav = revision.get("latest_nav") if revision_latest >= cached_latest else cached.get("latest_nav")
        return {
            "dates": ordered,
            "returns": [merged[day] for day in ordered],
            "latest_date": latest_date,
            "latest_nav": latest_nav,
            "history_revision_window": max(NAV_REVISION_WINDOW, len(inc_dates) - 1),
        }

    def update_history(self, code: str, cached: dict) -> dict:
        try:
            if self.source_degraded.get("primary"):
                raise ContractError("东方财富源已熔断")
            result = self.primary.update_history(code, cached)
            self._note_source_success("primary")
            result["history_source"] = "东方财富基金历史净值"
            return result
        except Exception as raw_primary_exc:
            primary_exc = _typed_source_error(raw_primary_exc, f"{code} 东方财富增量历史")
            if primary_exc is not raw_primary_exc: _record_diagnostic("source-primary-update-history", primary_exc)
            self._note_source_failure("primary", primary_exc)
            self.source_health["primary"] *= 0.96
            if self.source_degraded.get("secondary"):
                raise DataError(f"{code} 增量历史主源失败且备用源已熔断：{primary_exc}") from primary_exc
            try:
                secondary_history = self.secondary.history(code)
                self._note_source_success("secondary")
                result = self._merge_history_revision(cached, secondary_history)
                result["history_source"] = "新浪财经基金历史净值（重叠窗口合并）"
                result["history_fallback_reason"] = str(primary_exc)[:200]
                return result
            except Exception as raw_secondary_exc:
                secondary_exc = _typed_source_error(raw_secondary_exc, f"{code} 新浪增量历史")
                if secondary_exc is not raw_secondary_exc: _record_diagnostic("source-secondary-update-history", secondary_exc)
                self._note_source_failure("secondary", secondary_exc)
                raise DataError(f"{code} 增量历史双源失败：东方财富={primary_exc}；新浪={secondary_exc}") from raw_secondary_exc

    @staticmethod
    def _merge_latest_rows(primary: dict, secondary: dict) -> dict:
        output = dict(primary or secondary or {})
        sources = []
        if primary: sources.append("东方财富")
        if secondary: sources.append("新浪财经")
        output["latest_sources"] = sources
        output["latest_public_confirmations"] = len(sources)
        if primary and secondary:
            pnav, snav = _finite(primary.get("nav"), float("nan")), _finite(secondary.get("nav"), float("nan"))
            if math.isfinite(pnav) and math.isfinite(snav) and pnav > 0:
                output["latest_cross_source_relative_diff"] = abs(snav / pnav - 1.0)
        return output

    def latest_many(self, codes: list[str], progress=lambda *_: None) -> dict:
        codes = list(dict.fromkeys(str(code) for code in codes if re.fullmatch(r"\d{6}", str(code))))
        progress(f"获取最新净值 0/{len(codes)}", 0)
        try:
            if self.source_degraded.get("primary"):
                raise ContractError("东方财富源已熔断")
            primary_result = self.primary.latest_many(
                codes,
                progress=lambda text, pct: progress(text, 0.72 * _clamp(_finite(pct), 0.0, 100.0)),
            )
            self._note_source_success("primary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, "东方财富最新净值")
            if exc is not raw_exc: _record_diagnostic("source-primary-latest", exc)
            self._note_source_failure("primary", exc)
            primary_result = {"rows": {}, "requested": len(codes), "received": 0, "failed_codes": codes, "errors": [str(exc)]}
            progress("主要净值源暂不可用，正在切换备用源", 72)
        primary_rows = primary_result.get("rows") or {}
        # Cross-check a bounded representative set; if primary misses codes, those are first in line for secondary takeover.
        missing = [code for code in codes if code not in primary_rows]
        secondary_targets = list(dict.fromkeys(missing + codes[:20]))[:60]
        try:
            if self.source_degraded.get("secondary"):
                raise ContractError("新浪源已熔断")
            secondary_result = self.secondary.latest_many(
                secondary_targets,
                progress=lambda text, pct: progress(
                    text,
                    72.0 + 0.28 * _clamp(_finite(pct), 0.0, 100.0),
                ),
            )
            self._note_source_success("secondary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, "新浪最新净值")
            if exc is not raw_exc: _record_diagnostic("source-secondary-latest", exc)
            self._note_source_failure("secondary", exc)
            secondary_result = {"rows": {}, "requested": len(secondary_targets), "received": 0, "failed_codes": secondary_targets, "errors": [str(exc)]}
        secondary_rows = secondary_result.get("rows") or {}
        merged = {}
        for code in codes:
            if code in primary_rows or code in secondary_rows:
                merged[code] = self._merge_latest_rows(primary_rows.get(code), secondary_rows.get(code))
        failed = [code for code in codes if code not in merged]
        progress(f"最新净值已取得 {len(merged)}/{len(codes)}", 100)
        return {"rows": merged, "requested": len(codes), "received": len(merged), "failed_codes": failed, "errors": list(primary_result.get("errors") or []) + list(secondary_result.get("errors") or [])}

    def latest(self, codes: list[str], **_kwargs) -> dict[str, dict]:
        return self.latest_many(codes)["rows"]

    def basic_metadata(self, code: str) -> dict:
        primary = secondary = {}
        try:
            if self.source_degraded.get("primary"):
                raise ContractError("东方财富源已熔断")
            primary = self.primary.basic_metadata(code)
            self._note_source_success("primary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, f"{code} 东方财富元数据")
            if exc is not raw_exc: _record_diagnostic("source-primary-metadata", exc)
            self._note_source_failure("primary", exc); self.source_health["primary"] *= 0.98
        try:
            if self.source_degraded.get("secondary"):
                raise ContractError("新浪源已熔断")
            secondary = self.secondary.basic_metadata(code)
            self._note_source_success("secondary")
        except Exception as raw_exc:
            exc = _typed_source_error(raw_exc, f"{code} 新浪元数据")
            if exc is not raw_exc: _record_diagnostic("source-secondary-metadata", exc)
            self._note_source_failure("secondary", exc); self.source_health["secondary"] *= 0.98
        if not primary and not secondary:
            raise DataError(f"{code} 双元数据源均不可用")
        output = dict(primary or {})
        for key, value in secondary.items():
            if value and not output.get(key): output[key] = value
        statuses = [str(value.get("public_purchase_status") or "") for value in (primary, secondary) if value]
        # Purchase-side restrictions must not be conflated with redemption-only restrictions or large-purchase limits.
        def _public_status_is_open(text: str) -> bool:
            normalized = re.sub(r"\s+", "", str(text or ""))
            purchase_blocked = (
                ("暂停申购" in normalized and "暂停大额申购" not in normalized)
                or "终止申购" in normalized
                or any(word in normalized for word in ("封闭期", "基金清盘", "终止运作", "基金终止"))
            )
            return any(word in normalized for word in ("开放申购", "可申购", "开放")) and not purchase_blocked
        open_count = sum(_public_status_is_open(text) for text in statuses)
        signals = set(output.get("availability_public_signals") or [])
        if open_count: signals.add("public-purchase-open")
        if len(statuses) >= 2: signals.add("multi-public-metadata")
        output["availability_public_signals"] = sorted(signals)
        output["availability_public_confirmations"] = len(signals)
        output["metadata_sources"] = [name for name, value in (("东方财富", primary), ("新浪财经", secondary)) if value]
        output["public_purchase_status_secondary"] = str(secondary.get("public_purchase_status") or "")
        return output

    def metadata_many(self, funds: list[dict]) -> dict[str, dict]:
        targets = [fund for fund in funds if re.fullmatch(r"\d{6}", str(fund.get("code") or ""))]
        output = {}
        failures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=_adaptive_worker_count("network", 6, max(1, len(targets))), thread_name_prefix="dual-fund-meta") as pool:
            future_map = {pool.submit(self.basic_metadata, str(fund["code"])): str(fund["code"]) for fund in targets}
            for future in concurrent.futures.as_completed(future_map):
                code = future_map[future]
                try:
                    output[code] = future.result()
                except Exception as exc:
                    failures.append(f"{code}:{type(exc).__name__}:{exc}")
        if failures:
            _record_diagnostic("metadata-many", f"{len(failures)} failures; last={failures[-1]}", "MetadataBatchError")
        return output

    def cross_verify_top10(self, items: list[dict]) -> dict:
        rows = list(items[:10]); details = {}; verified = 0
        if self.source_degraded.get("secondary"):
            for item in rows:
                item["independent_source_verified"] = False
                item["independent_source"] = "新浪财经基金中心"
                item["independent_source_note"] = "新浪源契约检查已熔断，本轮不使用其交叉证据"
            return {"verified": 0, "requested": len(rows), "source": "新浪财经基金中心（已熔断）", "details": {}}
        secondary = self.secondary.latest_many([item["code"] for item in rows]) if rows else {"rows": {}}
        sec_rows = secondary.get("rows") or {}
        for item in rows:
            sec = sec_rows.get(item["code"])
            ok = False
            if sec:
                local_nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan")); snav = _finite(sec.get("nav"), float("nan"))
                ok = math.isfinite(local_nav) and math.isfinite(snav) and local_nav > 0 and abs(snav / local_nav - 1.0) <= 0.25
                sources = set(item.get("latest_sources") or []); sources.add("新浪财经"); item["latest_sources"] = sorted(sources)
                item["latest_public_confirmations"] = len(sources)
                signals = _public_availability_signals(item); item["availability_public_signals"] = sorted(signals)
                item["availability_public_confirmations"] = len(signals)
            item["independent_source_verified"] = ok
            item["independent_source"] = "新浪财经基金中心"
            item["independent_source_nav"] = sec.get("nav") if sec else None
            item["independent_source_note"] = "最新净值交叉证据一致" if ok else "新浪最新净值交叉证据不完整"
            details[item["code"]] = {"ok": ok, "source": "新浪财经基金中心", "sina_nav": sec.get("nav") if sec else None}
            verified += int(ok)
        return {"verified": verified, "requested": len(rows), "source": "新浪财经基金中心", "details": details}



# ===== 本地存储 =====

class LocalStore:
    def __init__(self):
        self.cache = self._load_cache()
        self.model = self._load_model()

    @staticmethod
    def _quarantine_cache(reason: str) -> None:
        """Atomically move a corrupt SQLite database aside inside the selected folder."""
        _assert_isolated_app_path(CACHE_PATH)
        _assert_isolated_app_path(CACHE_ROLLBACK_PATH)
        pairs = [
            (CACHE_PATH, CACHE_ROLLBACK_PATH),
            (Path(str(CACHE_PATH) + "-wal"), Path(str(CACHE_ROLLBACK_PATH) + "-wal")),
            (Path(str(CACHE_PATH) + "-shm"), Path(str(CACHE_ROLLBACK_PATH) + "-shm")),
            (Path(str(CACHE_PATH) + "-journal"), Path(str(CACHE_ROLLBACK_PATH) + "-journal")),
        ]
        for source, target in pairs:
            _assert_isolated_app_path(source)
            _assert_isolated_app_path(target)
            if not os.path.lexists(str(source)):
                continue
            try:
                if os.path.lexists(str(target)):
                    if _path_is_reparse_or_symlink(target):
                        raise StorageError(f"SQLite rollback 路径不是普通文件：{target}")
                    target.unlink()
                os.replace(source, target)
            except (OSError, StorageError) as exc:
                raise StorageError(f"SQLite 损坏库隔离失败：{source} -> {target}: {exc}") from exc
        _record_diagnostic("sqlite-recovery", reason, "StorageError")

    @staticmethod
    def _open_checked_cache(timeout: float, *, quick_check: bool = True) -> sqlite3.Connection:
        """Open SQLite; reserve the expensive quick_check for startup/maintenance, not every checkpoint."""
        last_error = None
        for attempt in range(2):
            connection = None
            try:
                _assert_isolated_app_path(CACHE_PATH)
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-wal"))
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-shm"))
                _assert_isolated_app_path(Path(str(CACHE_PATH) + "-journal"))
                connection = sqlite3.connect(CACHE_PATH, timeout=timeout)
                if quick_check:
                    rows = connection.execute("PRAGMA quick_check").fetchall()
                    messages = [str(row[0]) for row in rows if row]
                    if not messages or any(message.lower() != "ok" for message in messages):
                        raise sqlite3.DatabaseError("PRAGMA quick_check: " + "; ".join(messages[:8]))
                return connection
            except (sqlite3.Error, OSError, StorageError) as exc:
                last_error = exc
                if connection is not None:
                    try:
                        connection.close()
                    except sqlite3.Error:
                        pass
                if attempt == 0 and os.path.lexists(str(CACHE_PATH)):
                    LocalStore._quarantine_cache(f"{type(exc).__name__}: {exc}")
                    continue
                break
        raise StorageError(f"SQLite 自检/恢复失败：{CACHE_PATH}: {last_error}") from last_error

    @staticmethod
    def _load_cache() -> dict:
        empty = {"version": CACHE_VERSION, "updated_at": None, "funds": {}, "fund_master": {}}
        try:
            connection = LocalStore._open_checked_cache(timeout=20)
            connection.row_factory = sqlite3.Row
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=NORMAL")
                connection.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS runtime_state (
                        key TEXT PRIMARY KEY,
                        value_json TEXT NOT NULL
                    );
                    CREATE TABLE IF NOT EXISTS fund_master (
                        code TEXT PRIMARY KEY,
                        payload_json TEXT NOT NULL
                    );
                    CREATE TABLE IF NOT EXISTS nav_returns (
                        code TEXT NOT NULL,
                        nav_date TEXT NOT NULL,
                        daily_return REAL NOT NULL,
                        PRIMARY KEY (code, nav_date)
                    );
                    CREATE INDEX IF NOT EXISTS idx_nav_returns_code_date ON nav_returns(code, nav_date);
                    CREATE TABLE IF NOT EXISTS market_sessions (
                        session_date TEXT PRIMARY KEY
                    );
                    CREATE TABLE IF NOT EXISTS metadata (
                        code TEXT PRIMARY KEY,
                        payload_json TEXT NOT NULL
                    );
                    CREATE TABLE IF NOT EXISTS availability_history (
                        code TEXT NOT NULL,
                        span_from TEXT NOT NULL,
                        span_to TEXT NOT NULL DEFAULT '',
                        purchasable INTEGER NOT NULL,
                        payload_json TEXT NOT NULL,
                        PRIMARY KEY (code, span_from, span_to, purchasable)
                    );
                    """
                )
                state = {}
                for row in connection.execute("SELECT key, value_json FROM runtime_state"):
                    try:
                        state[row["key"]] = json.loads(row["value_json"])
                    except (TypeError, json.JSONDecodeError):
                        pass
                legacy_version = state.get("version")
                pragma_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                version_mismatch = (
                    (legacy_version not in (None, CACHE_VERSION))
                    or (pragma_version not in (0, CACHE_VERSION))
                )
                if version_mismatch:
                    # CACHE_VERSION is a data-contract version, not merely a read hint. Purge in one transaction
                    # so stale rows can never reappear after a later UPSERT/append.
                    with connection:
                        for table in ("metadata", "nav_returns", "market_sessions", "fund_master", "availability_history", "runtime_state"):
                            connection.execute(f"DELETE FROM {table}")
                        connection.execute(
                            "INSERT INTO runtime_state(key,value_json) VALUES('version',?)",
                            (json.dumps(CACHE_VERSION),),
                        )
                        connection.execute(f"PRAGMA user_version={CACHE_VERSION}")
                    return empty
                if pragma_version == 0:
                    with connection:
                        connection.execute(f"PRAGMA user_version={CACHE_VERSION}")
                funds = {}
                for row in connection.execute("SELECT code, payload_json FROM metadata"):
                    try:
                        payload = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    funds[row["code"]] = payload if isinstance(payload, dict) else {}
                persisted_sessions = [row[0] for row in connection.execute("SELECT session_date FROM market_sessions ORDER BY session_date")]
                _register_observed_market_sessions(persisted_sessions)
                by_code = {}
                for row in connection.execute(
                    "SELECT code, nav_date, daily_return FROM nav_returns ORDER BY code, nav_date"
                ):
                    dates, returns = by_code.setdefault(row["code"], ([], []))
                    dates.append(row["nav_date"])
                    returns.append(float(row["daily_return"]))
                for code, (dates, returns) in by_code.items():
                    _register_observed_market_sessions(dates)
                    funds.setdefault(code, {})
                    funds[code]["dates"] = dates
                    funds[code]["returns"] = returns
                for row in connection.execute(
                    "SELECT code, payload_json FROM availability_history ORDER BY code, span_from, span_to"
                ):
                    try:
                        span = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    funds.setdefault(row["code"], {})
                    funds[row["code"]].setdefault("availability_history", []).append(span)
                master = {}
                for row in connection.execute("SELECT code, payload_json FROM fund_master"):
                    try:
                        payload = json.loads(row["payload_json"])
                    except json.JSONDecodeError:
                        continue
                    if isinstance(payload, dict):
                        master[row["code"]] = payload
                return {
                    "version": CACHE_VERSION,
                    "updated_at": state.get("updated_at"),
                    "funds": funds,
                    "fund_master": master,
                }
            finally:
                connection.close()
        except StorageError:
            raise
        except (OSError, sqlite3.Error, ValueError, TypeError) as exc:
            _record_diagnostic("sqlite-load", exc)
            return empty


    @staticmethod
    def check_cache_integrity() -> None:
        connection = LocalStore._open_checked_cache(timeout=30, quick_check=True)
        connection.close()

    @staticmethod
    def default_model() -> dict:
            return {
                "version": MODEL_VERSION,
                "trained_at": None,
                "feature_names": AdaptiveRanker.FEATURE_NAMES,
                "linear_weights": [0.0] * len(AdaptiveRanker.FEATURE_NAMES),
                "nonlinear_models": [],
                "asset_models": {},
                "asset_model_blend": {"global": GLOBAL_ASSET_BLEND, "asset_specific": ASSET_SPECIFIC_BLEND},
                "component_weights": {"expert": 1.0, "linear": 0.0, "nonlinear": 0.0, "external": 0.0, "tree2": 0.0},
                "optional_ml": None,
                "optional_tree2": None,
                "optional_ml_status": "not-trained",
                "optional_tree2_status": "not-trained",
                "validation_ic": 0.0,
                "model_quality": 0.0,
                "validation_metrics": {},
                "full_pipeline_oos": {},
                "untouched_test_oos": {},
                "candidate_deployment_oos": {},
                "baseline_deployment_oos": {},
                "deployment_gate": {"passed": False, "reason": "not-trained"},
                "expert_development_oos": {},
                "training_samples": 0,
                "tuning_samples": 0,
                "deployment_validation_samples": 0,
                "universe_size": 0,
                "historical_availability_coverage": 0.0,
                "historical_universe_known_coverage": 0.0,
                "historical_availability_used_for_model_selection": False,
                "ai_enabled": False,
                "model_status": "expert-fallback",
                "baseline_mode": "expert",
                "baseline_metrics": {},
                "split_boundaries": {},
                "universe_codes": [],
                "selection_dataset": "development selects; independent deployment validation gates; non-overlapping untouched audit reports only; production refit after freeze",
                "evaluation_model": {},
                "production_model": {},
                "survivorship_bias": True,
                "long_term_blend": 0.80,
                "target_spec": {},
                "engine": "anchored walk-forward long-horizon target search + LongTermQuality/EntryTiming + diversified Top10",
            }


    @staticmethod
    def _model_payload_valid(model) -> bool:
        return bool(
            isinstance(model, dict)
            and model.get("version") == MODEL_VERSION
            and model.get("feature_names") == AdaptiveRanker.FEATURE_NAMES
            and len(model.get("linear_weights") or []) == len(AdaptiveRanker.FEATURE_NAMES)
        )

    def _load_model(self) -> dict:
        _assert_isolated_app_path(MODEL_PATH)
        _assert_isolated_app_path(MODEL_ROLLBACK_PATH)
        primary = _read_json(MODEL_PATH, None) if MODEL_PATH.exists() else None
        if self._model_payload_valid(primary):
            return primary

        rollback = _read_json(MODEL_ROLLBACK_PATH, None) if MODEL_ROLLBACK_PATH.exists() else None
        if self._model_payload_valid(rollback):
            model = dict(rollback)
            model["force_retrain_reason"] = "model-primary-recovered-from-last-known-good"
            try:
                _write_json(MODEL_PATH, model)
            except (OSError, StorageError) as exc:
                raise StorageError(f"无法从 last-known-good 恢复 AI：{MODEL_PATH}\n{exc}") from exc
            _record_diagnostic("model-recovery", "primary model invalid; restored last-known-good", "ModelRecovery")
            return model

        model = self.default_model()
        if MODEL_PATH.exists() or MODEL_ROLLBACK_PATH.exists():
            model["force_retrain_reason"] = "model-schema-or-json-invalid"
        try:
            _write_json(MODEL_PATH, model)
        except (OSError, StorageError) as exc:
            raise StorageError(f"无法在用户选择目录创建默认 AI：{MODEL_PATH}\n{exc}") from exc
        return model

    def save_cache(self, dirty_codes: set[str] | None = None) -> None:
        """Persist either the whole cache or only changed fund codes.

        Checkpoint callers pass dirty_codes so persistence stays O(changes) instead of
        rescanning every historical fund on each wave.
        """
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        selected_codes = None if dirty_codes is None else {str(code) for code in dirty_codes if str(code)}
        try:
            connection = LocalStore._open_checked_cache(timeout=30, quick_check=False)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=NORMAL")
                # LocalStore.__init__ creates the schema. Keep IF NOT EXISTS here as a cheap
                # recovery guard, but do not run quick_check or full-table scans at checkpoints.
                connection.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS runtime_state (key TEXT PRIMARY KEY, value_json TEXT NOT NULL);
                    CREATE TABLE IF NOT EXISTS fund_master (code TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
                    CREATE TABLE IF NOT EXISTS nav_returns (
                        code TEXT NOT NULL, nav_date TEXT NOT NULL, daily_return REAL NOT NULL,
                        PRIMARY KEY (code, nav_date)
                    );
                    CREATE INDEX IF NOT EXISTS idx_nav_returns_code_date ON nav_returns(code, nav_date);
                    CREATE TABLE IF NOT EXISTS market_sessions (session_date TEXT PRIMARY KEY);
                    CREATE TABLE IF NOT EXISTS metadata (code TEXT PRIMARY KEY, payload_json TEXT NOT NULL);
                    CREATE TABLE IF NOT EXISTS availability_history (
                        code TEXT NOT NULL, span_from TEXT NOT NULL, span_to TEXT NOT NULL DEFAULT '',
                        purchasable INTEGER NOT NULL, payload_json TEXT NOT NULL,
                        PRIMARY KEY (code, span_from, span_to, purchasable)
                    );
                    """
                )
                state_row = connection.execute("SELECT value_json FROM runtime_state WHERE key='version'").fetchone()
                try:
                    persisted_version = json.loads(state_row[0]) if state_row else None
                except (TypeError, json.JSONDecodeError):
                    persisted_version = None
                pragma_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                if persisted_version not in (None, CACHE_VERSION) or pragma_version not in (0, CACHE_VERSION):
                    with _STORAGE_COMMIT_LOCK, connection:
                        for table in ("metadata", "nav_returns", "market_sessions", "fund_master", "availability_history", "runtime_state"):
                            connection.execute(f"DELETE FROM {table}")
                        connection.execute(f"PRAGMA user_version={CACHE_VERSION}")

                cache_funds = self.cache.get("funds") or {}
                if selected_codes is None:
                    target_codes = set(cache_funds)
                    nav_rows = connection.execute(
                        "SELECT code, COUNT(*), MAX(nav_date) FROM nav_returns GROUP BY code"
                    )
                    metadata_rows = connection.execute("SELECT code,payload_json FROM metadata")
                else:
                    target_codes = set(selected_codes) & set(cache_funds)
                    if target_codes:
                        placeholders = ",".join("?" for _ in target_codes)
                        params = tuple(sorted(target_codes))
                        nav_rows = connection.execute(
                            f"SELECT code, COUNT(*), MAX(nav_date) FROM nav_returns WHERE code IN ({placeholders}) GROUP BY code",
                            params,
                        )
                        metadata_rows = connection.execute(
                            f"SELECT code,payload_json FROM metadata WHERE code IN ({placeholders})",
                            params,
                        )
                    else:
                        nav_rows = []
                        metadata_rows = []

                nav_state = {
                    row[0]: {"count": int(row[1]), "max_date": str(row[2] or "")}
                    for row in nav_rows
                }
                existing_metadata = {}
                for row in metadata_rows:
                    try:
                        payload = json.loads(row[1])
                        existing_metadata[row[0]] = payload if isinstance(payload, dict) else {}
                    except (TypeError, json.JSONDecodeError):
                        existing_metadata[row[0]] = {}

                with _STORAGE_COMMIT_LOCK, connection:
                    if _cancel_requested():
                        raise concurrent.futures.CancelledError("程序正在退出")
                    connection.execute(f"PRAGMA user_version={CACHE_VERSION}")
                    connection.executemany(
                        "INSERT INTO runtime_state(key,value_json) VALUES(?,?) "
                        "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
                        [
                            ("version", json.dumps(CACHE_VERSION)),
                            ("updated_at", json.dumps(self.cache.get("updated_at"))),
                        ],
                    )
                    with _OBSERVED_MARKET_SESSION_LOCK:
                        observed_sessions = sorted(_OBSERVED_MARKET_SESSIONS)
                    if observed_sessions:
                        connection.executemany(
                            "INSERT OR IGNORE INTO market_sessions(session_date) VALUES(?)",
                            [(day,) for day in observed_sessions],
                        )

                    for code in sorted(target_codes):
                        item = cache_funds.get(code)
                        if not isinstance(item, dict):
                            continue
                        dates = item.get("dates") or []
                        returns = item.get("returns") or []
                        nav_structure_signature = hashlib.sha256(json.dumps({
                            "return_basis": item.get("return_basis"),
                            "corporate_actions": item.get("return_corporate_actions"),
                            "accumulated_confirmations": item.get("return_accumulated_confirmations"),
                            "provider_fallbacks": item.get("return_provider_fallbacks"),
                        }, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()
                        if len(dates) == len(returns) and dates:
                            previous = existing_metadata.get(code) or {}
                            db_state = nav_state.get(code) or {"count": 0, "max_date": ""}
                            anchor_changed = False
                            previous_anchor_date = str(previous.get("_nav_anchor_date") or "")[:10]
                            previous_anchor_signature = str(previous.get("_nav_anchor_signature") or "")
                            if previous_anchor_date and previous_anchor_signature:
                                normalized_dates = [str(day)[:10] for day in dates]
                                anchor_end = bisect.bisect_right(normalized_dates, previous_anchor_date)
                                if anchor_end <= 0 or normalized_dates[anchor_end - 1] != previous_anchor_date:
                                    anchor_changed = True
                                else:
                                    current_anchor_signature = hashlib.sha256(json.dumps(
                                        [(str(day)[:10], round(float(ret), 15)) for day, ret in zip(dates[:anchor_end], returns[:anchor_end])],
                                        separators=(",", ":"), ensure_ascii=True,
                                    ).encode("utf-8")).hexdigest()
                                    anchor_changed = not hmac.compare_digest(current_anchor_signature, previous_anchor_signature)
                            rewrite_full = bool(db_state["count"]) and (
                                not previous.get("_nav_structure_signature")
                                or previous.get("_nav_structure_signature") != nav_structure_signature
                                or anchor_changed
                                or str(dates[-1])[:10] < db_state["max_date"]
                                or len(dates) < db_state["count"]
                            )
                            if not db_state["count"]:
                                start_at = 0
                            elif rewrite_full:
                                connection.execute("DELETE FROM nav_returns WHERE code=?", (code,))
                                start_at = 0
                            else:
                                start_at = max(0, len(dates) - NAV_REVISION_WINDOW)
                            connection.executemany(
                                "INSERT INTO nav_returns(code,nav_date,daily_return) VALUES(?,?,?) "
                                "ON CONFLICT(code,nav_date) DO UPDATE SET daily_return=excluded.daily_return",
                                [(code, str(day)[:10], float(ret)) for day, ret in zip(dates[start_at:], returns[start_at:])],
                            )

                        metadata = {
                            key: value for key, value in item.items()
                            if key not in ("dates", "returns", "availability_history")
                        }
                        metadata["_nav_structure_signature"] = nav_structure_signature
                        metadata["_nav_series_count"] = len(dates) if len(dates) == len(returns) else 0
                        if len(dates) == len(returns) and len(dates) > NAV_REVISION_WINDOW:
                            anchor_end = len(dates) - NAV_REVISION_WINDOW
                            metadata["_nav_anchor_date"] = str(dates[anchor_end - 1])[:10]
                            metadata["_nav_anchor_signature"] = hashlib.sha256(json.dumps(
                                [(str(day)[:10], round(float(ret), 15)) for day, ret in zip(dates[:anchor_end], returns[:anchor_end])],
                                separators=(",", ":"), ensure_ascii=True,
                            ).encode("utf-8")).hexdigest()
                        else:
                            metadata["_nav_anchor_date"] = ""
                            metadata["_nav_anchor_signature"] = ""
                        connection.execute(
                            "INSERT INTO metadata(code,payload_json) VALUES(?,?) "
                            "ON CONFLICT(code) DO UPDATE SET payload_json=excluded.payload_json",
                            (code, json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))),
                        )

                        for span in item.get("availability_history") or []:
                            if not isinstance(span, dict):
                                continue
                            start_date = str(span.get("from") or "")[:10]
                            finish_date = str(span.get("to") or "")[:10]
                            if not start_date:
                                continue
                            connection.execute(
                                "INSERT OR REPLACE INTO availability_history"
                                "(code,span_from,span_to,purchasable,payload_json) VALUES(?,?,?,?,?)",
                                (
                                    code, start_date, finish_date,
                                    1 if span.get("purchasable", True) is True else 0,
                                    json.dumps(span, ensure_ascii=False, separators=(",", ":")),
                                ),
                            )

                    master_rows = self.cache.get("fund_master") or {}
                    master_codes = set(master_rows) if selected_codes is None else (set(selected_codes) & set(master_rows))
                    for code in sorted(master_codes):
                        item = master_rows.get(code)
                        if isinstance(item, dict):
                            connection.execute(
                                "INSERT INTO fund_master(code,payload_json) VALUES(?,?) "
                                "ON CONFLICT(code) DO UPDATE SET payload_json=excluded.payload_json",
                                (code, json.dumps(item, ensure_ascii=False, separators=(",", ":"))),
                            )

                if selected_codes is None:
                    try:
                        connection.execute("PRAGMA wal_checkpoint(PASSIVE)")
                    except sqlite3.Error:
                        pass
            finally:
                connection.close()
        except (OSError, sqlite3.Error, StorageError) as exc:
            raise StorageError(
                f"无法在用户选择目录写入 SQLite 缓存：{CACHE_PATH}\n{exc}"
            ) from exc


    def save_model(self, model: dict) -> None:
        if not self._model_payload_valid(model):
            raise ModelError("拒绝保存不满足当前模型契约的 AI payload")
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        try:
            _assert_isolated_app_path(MODEL_PATH)
            _assert_isolated_app_path(MODEL_ROLLBACK_PATH)
            with _STORAGE_COMMIT_LOCK:
                if _cancel_requested():
                    raise concurrent.futures.CancelledError("程序正在退出")
                current = _read_json(MODEL_PATH, None) if MODEL_PATH.exists() else None
                if self._model_payload_valid(current):
                    _atomic_bytes(MODEL_ROLLBACK_PATH, MODEL_PATH.read_bytes())
                _write_json(MODEL_PATH, model)
        except (OSError, StorageError) as exc:
            raise StorageError(f"无法在用户选择目录写入 AI：{MODEL_PATH}\n{exc}") from exc
        self.model = model


# ===== 排名器 / AI =====

def _loaded_modules_are_local(active_dir: Path, names: tuple[str, ...]) -> bool:
    """Refuse a native stack if a top-level module was already loaded from outside the active local generation."""
    try:
        root = active_dir.resolve()
    except OSError:
        return False
    for name in names:
        module = sys.modules.get(name)
        if module is None:
            continue
        path_text = str(getattr(module, "__file__", "") or "")
        if not path_text:
            return False
        try:
            if root not in Path(path_text).resolve().parents:
                return False
        except OSError:
            return False
    return True


class AdaptiveRanker:
    FEATURE_NAMES = [
        "return_6m", "return_1y", "return_3y_ann", "sharpe_3y", "sortino_3y",
        "calmar_3y", "drawdown_quality", "volatility_quality", "worst_year",
        "positive_months", "trend_quality", "tail_quality", "stability_quality",
        "recovery_quality", "transaction_cost_3y_quality", "transaction_cost_5y_quality",
        "transaction_cost_10y_quality",
        "return_5y_ann", "return_7y_ann", "return_10y_ann", "drawdown_5y_quality",
        "rolling_3y_worst", "rolling_5y_worst", "recovery_time_quality", "ulcer_quality",
        "bear_stress_quality", "regime_stability_quality", "long_evidence_strength",
    ]
    EXPERT_WEIGHTS = [
        0.28, 0.42, 0.55, 0.68, 0.52, 0.58, 0.78, 0.40, 0.55,
        0.34, 0.22, 0.42, 0.46, 0.22, 0.24, 0.38, 0.34,
        0.95, 0.72, 0.52, 0.88, 0.74, 0.82, 0.48, 0.62, 0.55, 0.58, 0.70,
    ]
    NONLINEAR_SEEDS = (20260816, 27182818, 31415926)
    LIGHTGBM_DEV_GRID = (
        {"learning_rate":0.050,"num_leaves":7,"max_depth":3,"lambda_l1":0.05,"lambda_l2":0.8},
        {"learning_rate":0.035,"num_leaves":15,"max_depth":5,"lambda_l1":0.15,"lambda_l2":1.2},
        {"learning_rate":0.025,"num_leaves":31,"max_depth":5,"lambda_l1":0.30,"lambda_l2":2.0},
    )
    XGBOOST_DEV_GRID = (
        {"eta":0.050,"max_depth":3,"min_child_weight":3.0,"lambda":0.8,"alpha":0.05},
        {"eta":0.035,"max_depth":5,"min_child_weight":4.0,"lambda":1.2,"alpha":0.10},
        {"eta":0.025,"max_depth":5,"min_child_weight":6.0,"lambda":2.0,"alpha":0.20},
    )

    @classmethod
    def _adaptive_nonlinear_seeds(cls):
        complexity = _adaptive_model_complexity()
        extras = (16180339, 14142135)
        if complexity <= 1:
            return cls.NONLINEAR_SEEDS[:2]
        if complexity == 2:
            return cls.NONLINEAR_SEEDS
        if complexity == 3:
            return cls.NONLINEAR_SEEDS + extras[:1]
        return cls.NONLINEAR_SEEDS + extras

    @classmethod
    def _adaptive_lightgbm_grid(cls):
        complexity = _adaptive_model_complexity()
        grid = list(cls.LIGHTGBM_DEV_GRID)
        if complexity >= 3:
            grid.append({"learning_rate":0.020,"num_leaves":47,"max_depth":6,"lambda_l1":0.40,"lambda_l2":2.8})
        if complexity >= 4:
            grid.append({"learning_rate":0.015,"num_leaves":63,"max_depth":7,"lambda_l1":0.55,"lambda_l2":3.5})
        return tuple(grid)

    @classmethod
    def _adaptive_xgboost_grid(cls):
        complexity = _adaptive_model_complexity()
        grid = list(cls.XGBOOST_DEV_GRID)
        if complexity >= 3:
            grid.append({"eta":0.020,"max_depth":6,"min_child_weight":7.0,"lambda":2.8,"alpha":0.25})
        if complexity >= 4:
            grid.append({"eta":0.015,"max_depth":7,"min_child_weight":9.0,"lambda":3.5,"alpha":0.35})
        return tuple(grid)
    RANDOM_FEATURE_COUNT = 28
    _RANDOM_RECIPES = {}

    @staticmethod
    def features(
        returns: list[float], end: int | None = None, fees: dict | None = None,
        dates: list[str] | None = None,
    ) -> tuple[list[float], dict] | None:
        end = len(returns) if end is None else min(end, len(returns))
        if end < MIN_HISTORY_POINTS or not dates or len(dates) != len(returns):
            return None
        clean = [_clamp(_finite(value), -0.8, 2.0) for value in returns[:end]]
        date_values = [str(value)[:10] for value in dates[:end]]
        if any(not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) for value in date_values):
            return None
        try:
            history_start_day = _dt.date.fromisoformat(date_values[0])
            feature_day = _dt.date.fromisoformat(date_values[-1])
        except ValueError:
            return None
        long_n = min(756, len(clean) - 1)
        long_values = clean[-long_n:]
        ret_6m = _compound(clean[-min(126, len(clean)):])
        ret_1y = _compound(clean[-min(252, len(clean)):])
        total_long = _compound(long_values)
        years = max(long_n / 252.0, 0.25)
        ann = max(0.01, 1.0 + total_long) ** (1.0 / years) - 1.0
        daily_mean = sum(long_values) / len(long_values)
        daily_std = statistics.pstdev(long_values) if len(long_values) > 1 else 0.0
        volatility = daily_std * math.sqrt(252)
        risk_free = _risk_free_rate()
        sharpe = (daily_mean * 252 - risk_free) / max(volatility, 0.015)
        downside = math.sqrt(sum(min(0.0, r - risk_free / 252) ** 2 for r in long_values) / len(long_values)) * math.sqrt(252)
        sortino = (daily_mean * 252 - risk_free) / max(downside, 0.01)
        max_dd = _max_drawdown(long_values)
        calmar = (ann - risk_free) / max(abs(max_dd), 0.035)
        month_returns = []
        for start in range(max(0, len(long_values) - 504), len(long_values), 21):
            segment = long_values[start:min(start + 21, len(long_values))]
            if len(segment) >= 12:
                month_returns.append(_compound(segment))
        positive_months = sum(value > 0 for value in month_returns) / max(1, len(month_returns))
        rolling_year = []
        recent = long_values[-min(756, len(long_values)):]
        if len(recent) >= 252:
            for finish in range(252, len(recent) + 1, 21):
                rolling_year.append(_compound(recent[finish - 252:finish]))
        worst_year = min(rolling_year) if rolling_year else ret_1y
        rolling_quarter = []
        if len(recent) >= 63:
            for finish in range(63, len(recent) + 1, 21):
                rolling_quarter.append(_compound(recent[finish - 63:finish]))
        stability = -(statistics.pstdev(rolling_quarter) if len(rolling_quarter) > 1 else 0.0)
        trend_values = clean[-min(252, len(clean)):]
        logs, wealth = [], 1.0
        for value in trend_values:
            wealth *= max(0.01, 1.0 + value)
            logs.append(math.log(max(wealth, 1e-9)))
        n = len(logs); x_mean = (n - 1) / 2.0; y_mean = sum(logs) / n
        xx = sum((i - x_mean) ** 2 for i in range(n))
        xy = sum((i - x_mean) * (logs[i] - y_mean) for i in range(n))
        slope = xy / max(xx, 1e-12)
        fitted_var = sum((slope * (i - x_mean)) ** 2 for i in range(n))
        total_var = sum((value - y_mean) ** 2 for value in logs)
        r2 = _clamp(fitted_var / max(total_var, 1e-12), 0.0, 1.0)
        trend_quality = _clamp(slope * 252, -1.0, 1.5) * (0.35 + 0.65 * r2)
        sorted_returns = sorted(long_values); tail_count = max(5, int(len(sorted_returns) * 0.05))
        cvar = sum(sorted_returns[:tail_count]) / tail_count
        recent_year = clean[-min(252, len(clean)):]; wealth = peak = 1.0
        for value in recent_year:
            wealth *= max(0.01, 1.0 + value); peak = max(peak, wealth)
        recovery = wealth / peak - 1.0

        log_prefix = [0.0]
        for value in clean:
            log_prefix.append(log_prefix[-1] + math.log(max(0.01, 1.0 + value)))

        def compound_range(start: int, finish: int) -> float:
            return math.exp(log_prefix[finish] - log_prefix[start]) - 1.0

        def calendar_window(years: int) -> tuple[int, list[float], float, bool]:
            cutoff = _years_before(feature_day, years)
            start_index = bisect.bisect_left(date_values, cutoff.isoformat())
            if start_index >= len(clean) - 1:
                return start_index, [], 0.0, False
            try:
                actual_days = (feature_day - _dt.date.fromisoformat(date_values[start_index])).days
            except ValueError:
                return start_index, [], 0.0, False
            complete = actual_days >= 365 * years - 45
            return start_index, clean[start_index:], actual_days / 365.2425, complete

        def ann_window_years(years: int) -> float:
            start_index, values, actual_years, complete = calendar_window(years)
            if not values or not complete or actual_years <= 0:
                return 0.0
            total = compound_range(start_index, len(clean))
            return max(0.01, 1.0 + total) ** (1.0 / actual_years) - 1.0

        ret_5y_ann = ann_window_years(5)
        ret_7y_ann = ann_window_years(7)
        ret_10y_ann = ann_window_years(10)
        five_start, five_values, _five_years, _five_complete = calendar_window(5)
        max_dd_5y = _max_drawdown(five_values) if five_values else 0.0

        def worst_rolling_years(years: int) -> float:
            values = []
            for finish in range(MIN_HISTORY_POINTS, len(clean) + 1, 21):
                try:
                    finish_day = _dt.date.fromisoformat(date_values[finish - 1])
                except ValueError:
                    continue
                cutoff = _years_before(finish_day, years)
                start_index = bisect.bisect_left(date_values, cutoff.isoformat(), 0, finish)
                if start_index >= finish - 1:
                    continue
                try:
                    span = (finish_day - _dt.date.fromisoformat(date_values[start_index])).days
                except ValueError:
                    continue
                if span >= 365 * years - 45:
                    values.append(compound_range(start_index, finish))
            return min(values) if values else 0.0

        rolling_3y_worst = worst_rolling_years(3)
        rolling_5y_worst = worst_rolling_years(5)
        wealth = peak = 1.0; peak_index = 0; longest_recovery_days = 0; drawdowns = []
        for idx, value in enumerate(five_values):
            wealth *= max(0.01, 1.0 + value)
            if wealth >= peak:
                peak = wealth; peak_index = idx
            else:
                try:
                    recovery_days = (
                        _dt.date.fromisoformat(date_values[five_start + idx])
                        - _dt.date.fromisoformat(date_values[five_start + peak_index])
                    ).days
                except (ValueError, IndexError):
                    recovery_days = idx - peak_index
                longest_recovery_days = max(longest_recovery_days, recovery_days)
            drawdowns.append(wealth / max(peak, 1e-12) - 1.0)
        ulcer = math.sqrt(sum(dd*dd for dd in drawdowns) / max(1, len(drawdowns)))
        sorted_five = sorted(five_values)
        stress_n = max(5, int(len(sorted_five) * 0.05)) if sorted_five else 1
        bear_stress = abs(sum(sorted_five[:stress_n]) / stress_n) * math.sqrt(252) if sorted_five else 0.0
        annual_blocks = []
        for end_pos in range(252, len(five_values)+1, 252):
            annual_blocks.append(_compound(five_values[end_pos-252:end_pos]))
        regime_stability = -(statistics.pstdev(annual_blocks) if len(annual_blocks) > 1 else 0.0)
        history_years = max(0.0, (feature_day - history_start_day).days / 365.2425)
        long_evidence = _clamp((history_years - 3.0) / 7.0, 0.0, 1.0)
        costs = _holding_costs(fees)
        if fees is None:
            model_cost_3y, model_cost_5y, model_cost_10y = 0.20, 0.30, 0.45
        else:
            model_cost_3y, model_cost_5y, model_cost_10y = costs["transaction_cost_3y"], costs["transaction_cost_5y"], costs["transaction_cost_10y"]
        vector = [
            ret_6m, ret_1y, ann, _clamp(sharpe, -5, 8), _clamp(sortino, -5, 12), _clamp(calmar, -5, 10),
            max_dd, -volatility, worst_year, positive_months, trend_quality, -abs(cvar) * math.sqrt(252), stability,
            recovery, -model_cost_3y, -model_cost_5y, -model_cost_10y,
            ret_5y_ann, ret_7y_ann, ret_10y_ann, max_dd_5y,
            rolling_3y_worst, rolling_5y_worst, -longest_recovery_days / (5.0 * 365.2425), -ulcer,
            -bear_stress, regime_stability, long_evidence,
        ]
        sensitivity = {}
        for rf in (0.0, DEFAULT_RISK_FREE_RATE, 0.03):
            s = (daily_mean * 252 - rf) / max(volatility, 0.015)
            d = math.sqrt(sum(min(0.0, r - rf / 252) ** 2 for r in long_values) / len(long_values)) * math.sqrt(252)
            sensitivity[f"{rf:.3f}"] = {"sharpe": s, "sortino": (daily_mean * 252 - rf) / max(d, 0.01)}
        stats = {
            "return_6m": ret_6m, "return_1y": ret_1y, "return_3y_ann": ann, "volatility": volatility,
            "max_drawdown": max_dd, "sharpe": sharpe, "sortino": sortino, "calmar": calmar,
            "positive_months": positive_months, "worst_year": worst_year, "current_drawdown": recovery,
            "return_5y_ann": ret_5y_ann, "return_7y_ann": ret_7y_ann, "return_10y_ann": ret_10y_ann,
            "max_drawdown_5y": max_dd_5y, "rolling_3y_worst": rolling_3y_worst, "rolling_5y_worst": rolling_5y_worst,
            "recovery_days_5y": longest_recovery_days, "ulcer_index_5y": ulcer, "bear_stress_5y": bear_stress,
            "regime_stability_5y": regime_stability, "long_evidence_strength": long_evidence,
            "observations": end, "history_years": history_years, "feature_date": date_values[-1],
            "risk_free_rate": risk_free, "risk_free_sensitivity": sensitivity, **costs,
        }
        return vector, stats

    @staticmethod
    def _solve_ridge(xs: list[list[float]], ys: list[float], sample_weights: list[float], lam: float) -> list[float]:
        if not xs:
            return []
        columns = len(xs[0])
        matrix = [[0.0] * columns for _ in range(columns)]
        target = [0.0] * columns
        for row, y, weight in zip(xs, ys, sample_weights):
            for i in range(columns):
                target[i] += weight * row[i] * y
                for j in range(i, columns):
                    matrix[i][j] += weight * row[i] * row[j]
        for i in range(columns):
            matrix[i][i] += lam
            for j in range(i):
                matrix[i][j] = matrix[j][i]
        augmented = [matrix[i][:] + [target[i]] for i in range(columns)]
        for pivot in range(columns):
            best = max(range(pivot, columns), key=lambda row: abs(augmented[row][pivot]))
            augmented[pivot], augmented[best] = augmented[best], augmented[pivot]
            divisor = augmented[pivot][pivot]
            if abs(divisor) < 1e-12:
                continue
            for column in range(pivot, columns + 1):
                augmented[pivot][column] /= divisor
            for row in range(columns):
                if row == pivot:
                    continue
                factor = augmented[row][pivot]
                if abs(factor) < 1e-15:
                    continue
                for column in range(pivot, columns + 1):
                    augmented[row][column] -= factor * augmented[pivot][column]
        return [augmented[i][-1] for i in range(columns)]

    @classmethod
    def _random_features(cls, row: list[float], seed: int) -> list[float]:
        n = len(row)
        key = (seed, n, cls.RANDOM_FEATURE_COUNT)
        recipes = cls._RANDOM_RECIPES.get(key)
        if recipes is None:
            rng = random.Random(seed)
            recipes = tuple((rng.randrange(n), rng.randrange(n), rng.randrange(n), rng.randrange(5)) for _ in range(cls.RANDOM_FEATURE_COUNT))
            cls._RANDOM_RECIPES[key] = recipes
        result = []
        for a, b, c, mode in recipes:
            if mode == 0: value = row[a] * row[b]
            elif mode == 1: value = abs(row[a] - row[b])
            elif mode == 2: value = row[a] * row[a] * (1.0 if row[a] >= 0 else -1.0)
            elif mode == 3: value = max(row[a], 0.0) + min(row[b], 0.0)
            else: value = math.tanh(1.25 * row[a] - 0.75 * row[b] + 0.50 * row[c])
            result.append(_clamp(value, -2.0, 2.0))
        return result

    @staticmethod
    def _universe_membership_at(fund: dict, as_of_date: str) -> tuple[bool, bool]:
        date = str(as_of_date or "")[:10]
        inception = str(fund.get("inception_date") or "")[:10]
        termination = str(fund.get("termination_date") or "")[:10]
        if inception and date < inception:
            return False, True
        if termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and date > termination:
            return False, True
        history = [row for row in (fund.get("catalog_history") or []) if isinstance(row, dict)]
        if history:
            for span in history:
                start = str(span.get("from") or "0000-00-00")[:10]
                finish = str(span.get("to") or span.get("last_observed") or "9999-99-99")[:10]
                if start <= date <= finish:
                    return span.get("active") is not False, True
            # Before the first local observation (or in a gap) is deliberately unknown.
            return True, False
        # Inception proves the fund existed, but not that it belonged to the investable point-in-time universe.
        return True, False

    @staticmethod
    def _eligibility_at(fund: dict, end: int, as_of_date: str | None = None) -> tuple[bool, bool]:
        dates = fund.get("dates") or []
        if end <= 0 or end > len(dates):
            return False, False
        date = str(as_of_date or dates[end - 1])[:10]
        try:
            feature_day = _dt.date.fromisoformat(date)
            observation_day = _dt.date.fromisoformat(str(dates[end - 1])[:10])
        except ValueError:
            return False, False
        if observation_day > feature_day or (feature_day - observation_day).days > 31:
            return False, False
        inception = str(fund.get("inception_date") or dates[0])[:10]
        termination = str(fund.get("termination_date") or "")[:10]
        if inception and date < inception:
            return False, False
        if termination and re.fullmatch(r"\d{4}-\d{2}-\d{2}", termination) and date > termination:
            return False, False
        history = fund.get("availability_history") or []
        if history:
            for span in history:
                if not isinstance(span, dict):
                    continue
                start = str(span.get("from") or "0000-00-00")[:10]
                finish = str(span.get("to") or "9999-99-99")[:10]
                if start <= date <= finish:
                    return span.get("purchasable") is not False, True
            # 有历史记录但该日期不在任何覆盖区间：状态未知，而不是默认“已知可购”。
            return True, False
        return True, False

    @staticmethod
    def _eligible_at(fund: dict, end: int, as_of_date: str | None = None) -> bool:
        return AdaptiveRanker._eligibility_at(fund, end, as_of_date)[0]

    @staticmethod
    def _aggregate_underlyings(funds: list[dict]) -> list[dict]:
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        output = []
        for key, shares in groups.items():
            representative = max(
                shares,
                key=lambda fund: (
                    len(fund.get("returns") or []),
                    _share_preference(str(fund.get("name") or "")),
                    -int(str(fund.get("code") or "999999")) if str(fund.get("code") or "").isdigit() else 0,
                ),
            )
            clone = dict(representative)
            clone["underlying_fund_id"] = key
            clone["share_codes"] = sorted(str(row.get("code") or "") for row in shares)
            clone["share_count"] = len(shares)
            output.append(clone)
        output.sort(key=lambda fund: str(fund.get("code") or ""))
        return output

    @staticmethod
    def _quarterly_rebalance_dates(funds: list[dict], horizon_days: int = TARGET_THREE_YEAR_DAYS) -> list[str]:
        first_dates, last_dates = [], []
        for fund in funds:
            dates = fund.get("dates") or []
            if dates and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[0])[:10]) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(dates[-1])[:10]):
                first_dates.append(str(dates[0])[:10]); last_dates.append(str(dates[-1])[:10])
        if not first_dates or not last_dates:
            return []
        start = _dt.date.fromisoformat(min(first_dates))
        finish = _dt.date.fromisoformat(max(last_dates)) - _dt.timedelta(days=horizon_days)
        output = []
        for year in range(start.year, finish.year + 1):
            for month in (3, 6, 9, 12):
                day = _dt.date(year, month, calendar.monthrange(year, month)[1])
                while day.weekday() >= 5:
                    day -= _dt.timedelta(days=1)
                if start <= day <= finish:
                    output.append(day.isoformat())
        return output[-72:]

    def _build_snapshots(self, funds: list[dict], target_spec: dict | None = None) -> tuple[list[dict], dict]:
        spec = dict(target_spec or TARGET_SPECS[1])
        weights = dict(spec.get("weights") or {})
        horizon = str(spec.get("horizon") or "3y")
        horizon_days = TARGET_FIVE_YEAR_DAYS if horizon == "5y" else TARGET_THREE_YEAR_DAYS
        underlying_funds = self._aggregate_underlyings(funds)
        snapshots, feature_memo = [], {}
        availability_checks = availability_known = 0
        universe_checks = universe_known = 0
        for rebalance_date in self._quarterly_rebalance_dates(underlying_funds, horizon_days):
            day = _dt.date.fromisoformat(rebalance_date)
            endpoint_dates = {
                "6m": (day + _dt.timedelta(days=TARGET_HALF_YEAR_DAYS)).isoformat(),
                "1y": (day + _dt.timedelta(days=TARGET_ONE_YEAR_DAYS)).isoformat(),
                "3y": (day + _dt.timedelta(days=TARGET_THREE_YEAR_DAYS)).isoformat(),
                "5y": (day + _dt.timedelta(days=TARGET_FIVE_YEAR_DAYS)).isoformat(),
            }
            rows = []
            for fund in underlying_funds:
                returns = fund.get("returns") or []
                dates = fund.get("dates") or []
                if len(dates) != len(returns):
                    continue
                end = bisect.bisect_right(dates, rebalance_date)
                if end < MIN_HISTORY_POINTS:
                    continue
                endpoint_indices = {key: bisect.bisect_right(dates, value) for key, value in endpoint_dates.items()}
                required = set(weights)
                if any(endpoint_indices[key] <= end for key in required):
                    continue
                required_obs = {"6m":MIN_HALF_YEAR_OBSERVATIONS, "1y":MIN_ONE_YEAR_OBSERVATIONS,
                                "3y":MIN_THREE_YEAR_OBSERVATIONS, "5y":MIN_FIVE_YEAR_OBSERVATIONS}
                segments = {key: returns[end:endpoint_indices[key]] for key in required}
                if any(len(segments[key]) < required_obs[key] for key in required):
                    continue
                universe_checks += 1
                universe_eligible, universe_is_known = self._universe_membership_at(fund, rebalance_date)
                universe_known += int(universe_is_known)
                if not universe_eligible:
                    continue
                availability_checks += 1
                eligible, known = self._eligibility_at(fund, end, rebalance_date)
                availability_known += int(known)
                if not eligible:
                    continue
                _pit_product, pit_fees, pit_fees_verified = self._pit_fields(fund, rebalance_date)
                fee_fingerprint = json.dumps(pit_fees if pit_fees_verified else {}, sort_keys=True,
                                             ensure_ascii=True, separators=(",", ":"))
                memo_key = (fund["code"], end, fee_fingerprint)
                feature_result = feature_memo.get(memo_key)
                if feature_result is None:
                    feature_result = self.features(returns, end, pit_fees if pit_fees_verified else None, dates=dates)
                    feature_memo[memo_key] = feature_result
                if not feature_result:
                    continue
                utilities, drawdowns = {}, {}
                for key, values in segments.items():
                    years = {"6m":0.5,"1y":1.0,"3y":3.0,"5y":5.0}[key]
                    total = _compound(values)
                    ann = max(0.01, 1.0 + total) ** (1.0 / years) - 1.0
                    dd = abs(_max_drawdown(values))
                    vol = statistics.pstdev(values) * math.sqrt(252) if len(values) > 1 else 0.0
                    utilities[key] = ann - (0.42 + 0.05 * min(years, 5.0)) * dd - 0.08 * vol
                    drawdowns[key] = dd
                final_index = endpoint_indices[horizon]
                rows.append({
                    "code":fund["code"], "features":feature_result[0], "utilities":utilities,
                    "drawdown":drawdowns[horizon], "end":end, "future_end":endpoint_dates[horizon],
                    "observation_date":str(dates[end-1])[:10], "name":fund.get("name", ""),
                    "type":fund.get("type", ""), "underlying":fund.get("underlying_fund_id") or _underlying_key(fund),
                })
            if len(rows) < 24:
                continue
            component_ranks = {key:_rank_scale([row["utilities"][key] for row in rows]) for key in weights}
            combined = [sum(_finite(weight) * component_ranks[key][i] for key, weight in weights.items())
                        for i in range(len(rows))]
            raw_rows = [row["features"] for row in rows]
            buckets = [_asset_bucket(row["name"], row["type"]) for row in rows]
            snapshots.append({
                "rows": self._scale_feature_rows(raw_rows, buckets),
                "targets": _rank_scale(combined),
                "target_components": {key:component_ranks[key] for key in weights},
                "target_weights": weights,
                "target_spec": spec.get("name", horizon),
                "codes":[row["code"] for row in rows], "drawdowns":[row["drawdown"] for row in rows],
                "ends":[row["end"] for row in rows], "future_ends":[row["future_end"] for row in rows],
                "feature_observation_dates":[row["observation_date"] for row in rows],
                "underlying_keys":[row["underlying"] for row in rows],
                "buckets": buckets,
                "regime":self._regime_from_rows(raw_rows), "feature_date":rebalance_date,
                "target_end_date":endpoint_dates[horizon], "cross_section_synchronized":True,
            })
        snapshots.sort(key=lambda snap: snap["feature_date"])
        return snapshots, {
            "historical_availability_coverage":availability_known/max(1,availability_checks),
            "historical_universe_known_coverage":universe_known/max(1,universe_checks),
            "source_share_count":len(funds), "underlying_count":len(underlying_funds),
            "duplicate_shares_removed":max(0,len(funds)-len(underlying_funds)), "funds":underlying_funds,
            "target_spec":spec,
        }

    @staticmethod
    def _non_overlapping_tail(snapshots: list[dict], limit: int) -> list[dict]:
        chosen = []
        next_feature_start = ""
        for snap in reversed(snapshots):
            if not next_feature_start or str(snap.get("target_end_date") or "") <= next_feature_start:
                chosen.append(snap)
                next_feature_start = str(snap.get("feature_date") or "")
                if len(chosen) >= limit:
                    break
        return list(reversed(chosen))

    @staticmethod
    def _regime_from_rows(rows: list[list[float]]) -> str:
        if not rows:
            return "range"
        ret6 = _median([row[0] for row in rows])
        vol = _median([-row[7] for row in rows])
        trend = _median([row[10] for row in rows])
        if ret6 < -0.08 or (ret6 < 0 and vol > 0.24):
            return "risk_off"
        if vol > 0.28:
            return "high_vol"
        if ret6 > 0.12 and trend > 0.08:
            return "trend"
        if ret6 > 0.05:
            return "risk_on"
        return "range"

    @staticmethod
    def _scale_feature_rows(rows: list[list[float]], buckets: list[str]) -> list[list[float]]:
        if not rows:
            return []
        groups = {}
        for i, bucket in enumerate(buckets):
            groups.setdefault(bucket, []).append(i)
        global_columns = list(zip(*rows))
        global_scaled = [_rank_scale(list(column)) for column in global_columns]
        output = [[0.0] * len(rows[0]) for _ in rows]
        for indexes in groups.values():
            if len(indexes) < 4:
                for i in indexes:
                    output[i] = [global_scaled[j][i] for j in range(len(global_columns))]
                continue
            for j in range(len(global_columns)):
                scaled = _rank_scale([rows[i][j] for i in indexes])
                for local, i in enumerate(indexes):
                    output[i][j] = scaled[local]
        return output

    def _fit_hierarchical_linear(self, xs: list[list[float]], ys: list[float], weights: list[float], buckets: list[str]) -> tuple[list[float], dict]:
        global_weights = self._solve_ridge(xs, ys, weights, 0.9) if xs else [0.0] * len(self.FEATURE_NAMES)
        global_weights = self._normalized_linear_weights(global_weights)
        asset_models = {}
        for bucket in sorted(set(buckets)):
            indexes = [i for i, value in enumerate(buckets) if value == bucket]
            if len(indexes) < ASSET_MODEL_MIN_SAMPLES:
                continue
            bx = [xs[i] for i in indexes]; by = [ys[i] for i in indexes]; bw = [weights[i] for i in indexes]
            asset_models[bucket] = {
                "linear_weights": self._normalized_linear_weights(self._solve_ridge(bx, by, bw, 1.05)),
                "training_samples": len(indexes),
            }
        return global_weights, asset_models

    @staticmethod
    def _hierarchical_linear_predict(row: list[float], bucket: str, global_weights: list[float], asset_models: dict | None) -> float:
        global_value = sum(a*b for a,b in zip(global_weights or [], row))
        spec = (asset_models or {}).get(bucket) if isinstance(asset_models, dict) else None
        asset_weights = spec.get("linear_weights") if isinstance(spec, dict) else None
        if not asset_weights:
            return global_value
        asset_value = sum(a*b for a,b in zip(asset_weights, row))
        return GLOBAL_ASSET_BLEND * global_value + ASSET_SPECIFIC_BLEND * asset_value

    @staticmethod
    def _normalized_linear_weights(weights: list[float]) -> list[float]:
        scale = sum(abs(v) for v in weights) or 1.0
        return [_clamp(v/scale, -1.5, 1.5) for v in weights]

    @classmethod
    def _normalized_asset_models(cls, models: dict) -> dict:
        output = {}
        for bucket, spec in (models or {}).items():
            if not isinstance(spec, dict) or not spec.get("linear_weights"):
                continue
            output[bucket] = {
                **spec,
                "linear_weights": cls._normalized_linear_weights(list(spec.get("linear_weights") or [])),
            }
        return output

    @staticmethod
    def _history_snapshot(history, as_of_date: str, value_keys: tuple[str, ...]) -> dict:
        if not isinstance(history, list) or not as_of_date:
            return {}
        best_date, best = "", {}
        for row in history:
            if not isinstance(row, dict):
                continue
            date = str(row.get("feature_date") or row.get("effective_date") or row.get("date") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or date > as_of_date[:10] or date < best_date:
                continue
            value = None
            for key in value_keys:
                if isinstance(row.get(key), dict):
                    value = row.get(key); break
            if value is None and isinstance(row.get("values"), dict):
                value = row.get("values")
            if value is not None:
                best_date, best = date, dict(value)
        return best

    @classmethod
    def _pit_fields(cls, fund: dict, as_of_date: str) -> tuple[dict, dict, bool]:
        product = cls._history_snapshot(fund.get("product_features_history"), as_of_date, ("product_features", "features"))
        fees = cls._history_snapshot(fund.get("fees_history"), as_of_date, ("fees",))
                                                                                               
                                                                                         
        fee_verified = bool(fees)
        return product, fees, fee_verified

    @staticmethod
    def _product_quality(fund: dict, profile: str, as_of_date: str | None = None) -> float:
        f = fund.get("product_features") if isinstance(fund.get("product_features"), dict) else {}
        if not f:
            return 0.0
        bucket = _asset_bucket(fund.get("name", ""), fund.get("type", ""))
        score = 0.0
        inception = str(fund.get("inception_date") or "")[:10]
        age_years = float("nan")
        try:
            reference_day = _dt.date.fromisoformat(str(as_of_date)[:10]) if as_of_date else _china_today()
            inception_day = _dt.date.fromisoformat(inception)
            if inception_day <= reference_day:
                age_years = max(0.0, (reference_day - inception_day).days / 365.2425)
        except (ValueError, TypeError):
            pass
        if bucket in {"指数", "QDII/海外"}:
            te = _finite(f.get("tracking_error_annual"), float("nan"))
            size = _finite(f.get("fund_size_billion"), float("nan"))
            if math.isfinite(te): score += _clamp(0.03 - te, -0.04, 0.03)
            if math.isfinite(size): score += 0.012 * _clamp(math.log1p(max(0.0, size)) / 4.0, 0.0, 1.0)
            if math.isfinite(age_years): score += 0.008 * _clamp((age_years - 2.0) / 8.0, -0.5, 1.0)
        elif bucket == "主动权益":
            size = _finite(f.get("fund_size_billion"), float("nan"))
            tenure = _finite(f.get("manager_tenure_years"), float("nan"))
            changes = _finite(f.get("manager_changes_3y"), float("nan"))
            alpha = _finite(f.get("benchmark_alpha_3y"), float("nan"))
            drift = _finite(f.get("style_drift"), float("nan"))
            if math.isfinite(size): score += 0.006 * _clamp(math.log1p(max(0.0, size)) / 4.0, 0.0, 1.0)
            if math.isfinite(age_years): score += 0.006 * _clamp((age_years - 3.0) / 8.0, -0.5, 1.0)
            if math.isfinite(tenure): score += 0.012 * _clamp((tenure - 2.0) / 5.0, -1.0, 1.0)
            if math.isfinite(changes): score -= 0.010 * _clamp(changes / 3.0, 0.0, 1.5)
            if math.isfinite(alpha): score += 0.025 * _clamp(alpha / 0.10, -1.0, 1.0)
            if math.isfinite(drift): score -= 0.015 * _clamp(drift, 0.0, 1.0)
        elif bucket == "债券":
            size = _finite(f.get("fund_size_billion"), float("nan"))
            credit = _finite(f.get("credit_risk_score"), float("nan"))
            equity = _finite(f.get("equity_exposure"), float("nan"))
            if math.isfinite(size): score += 0.005 * _clamp(math.log1p(max(0.0, size)) / 4.0, 0.0, 1.0)
            if math.isfinite(age_years): score += 0.005 * _clamp((age_years - 2.0) / 8.0, -0.5, 1.0)
            if math.isfinite(credit): score -= 0.020 * _clamp(credit, 0.0, 1.0)
            if profile == "稳健" and math.isfinite(equity): score -= 0.020 * _clamp(equity / 0.20, 0.0, 1.0)
        return score

    _OPTIONAL_ML_LAST_STATUS = "not-attempted"
    _OPTIONAL_TREE2_LAST_STATUS = "not-attempted"

    @staticmethod
    def _ranking_labels(ys: list[float], group_sizes: list[int] | None, levels: int = 16):
        if not group_sizes or sum(int(v) for v in group_sizes) != len(ys) or any(int(v) < 2 for v in group_sizes):
            return None
        labels = []
        cursor = 0
        for size in group_sizes:
            size = int(size)
            segment = ys[cursor:cursor + size]
            scaled = _rank_scale(segment)
            labels.extend(int(round(_clamp(value, 0.0, 1.0) * (levels - 1))) for value in scaled)
            cursor += size
        return labels

    @classmethod
    def _ensure_lightgbm(cls):
        settings = _load_install_settings()
        if settings.get("lightgbm") is not True:
            cls._OPTIONAL_ML_LAST_STATUS = "disabled-by-install-profile"
            return None
        active_dir = _active_dependency_dir(settings)
        if active_dir is None:
            cls._OPTIONAL_ML_LAST_STATUS = "local-lightgbm-pending-or-missing"
            return None
        if not _loaded_modules_are_local(active_dir, ("numpy", "scipy", "lightgbm")):
            cls._OPTIONAL_ML_LAST_STATUS = "refused-preloaded-nonlocal-native-stack"
            return None
        _activate_local_dependencies()
        try:
            import lightgbm as lgb
            module_path = Path(getattr(lgb, "__file__", "")).resolve()
            if active_dir.resolve() not in module_path.parents:
                cls._OPTIONAL_ML_LAST_STATUS = "refused-nonlocal-lightgbm"
                return None
            cls._OPTIONAL_ML_LAST_STATUS = f"available-local:{getattr(lgb, '__version__', 'unknown')}"
            return lgb
        except Exception as exc:
            cls._OPTIONAL_ML_LAST_STATUS = f"unavailable-local:{type(exc).__name__}"
            return None

    @classmethod
    def _ensure_xgboost(cls):
        settings = _load_install_settings()
        if settings.get("advanced_tree") is not True:
            cls._OPTIONAL_TREE2_LAST_STATUS = "disabled-by-install-profile"
            return None
        active_dir = _active_dependency_dir(settings)
        if active_dir is None:
            cls._OPTIONAL_TREE2_LAST_STATUS = "local-xgboost-pending-or-missing"
            return None
        if not _loaded_modules_are_local(active_dir, ("numpy", "scipy", "xgboost")):
            cls._OPTIONAL_TREE2_LAST_STATUS = "refused-preloaded-nonlocal-native-stack"
            return None
        _activate_local_dependencies()
        try:
            import xgboost as xgb
            module_path = Path(getattr(xgb, "__file__", "")).resolve()
            if active_dir.resolve() not in module_path.parents:
                cls._OPTIONAL_TREE2_LAST_STATUS = "refused-nonlocal-xgboost"
                return None
            cls._OPTIONAL_TREE2_LAST_STATUS = f"available-local:{getattr(xgb, '__version__', 'unknown')}"
            return xgb
        except Exception as exc:
            cls._OPTIONAL_TREE2_LAST_STATUS = f"unavailable-local:{type(exc).__name__}"
            return None

    @classmethod
    def _train_optional_lightgbm(cls, xs: list[list[float]], ys: list[float], weights: list[float], group_sizes: list[int] | None = None, hyperparams: dict | None = None, num_boost_round: int = 110):
        lgb = cls._ensure_lightgbm()
        labels = cls._ranking_labels(ys, group_sizes)
        if lgb is None or len(xs) < 180 or labels is None:
            if lgb is not None:
                cls._OPTIONAL_ML_LAST_STATUS = f"insufficient-ranking-data:{len(xs)}"
            return None, None
        try:
            import numpy as np
            matrix = np.asarray(xs, dtype=float)
            sample_weights = np.asarray(weights, dtype=float) if weights else None
            dataset = lgb.Dataset(
                matrix, label=np.asarray(labels, dtype=int), weight=sample_weights,
                group=[int(value) for value in group_sizes], free_raw_data=True,
            )
            params = {
                "objective":"lambdarank", "metric":"ndcg", "ndcg_eval_at":[5,10],
                "label_gain":list(range(16)), "learning_rate":0.035,
                "num_leaves":15, "max_depth":5, "min_data_in_leaf":20,
                "feature_fraction":0.90, "bagging_fraction":0.90, "bagging_freq":1,
                "lambda_l1":0.15, "lambda_l2":1.2, "verbosity":-1,
                "seed":20260817, "feature_fraction_seed":20260817, "bagging_seed":20260817,
                "deterministic":True, "force_col_wise":True,
                "num_threads":_adaptive_ml_threads(),
            }
            if hyperparams:
                params.update({key:value for key,value in hyperparams.items() if key in {"learning_rate","num_leaves","max_depth","lambda_l1","lambda_l2"}})
            booster = lgb.train(params, dataset, num_boost_round=_adaptive_boost_rounds(num_boost_round))
            spec = {
                "backend":"lightgbm-lambdarank", "model_string":booster.model_to_string(),
                "params":params, "training_samples":len(xs), "groups":len(group_sizes),
                "ranking_label_levels":16, "weight_semantics":"query-group-mean-of-row-time-weights",
            }
            cls._OPTIONAL_ML_LAST_STATUS = f"trained-lambdarank:{len(xs)}:{len(group_sizes)}groups"
            return spec, (lambda row, b=booster, np=np: float(b.predict(np.asarray([row], dtype=float))[0]))
        except Exception as exc:
            cls._OPTIONAL_ML_LAST_STATUS = f"train-failed:{type(exc).__name__}"
            return None, None

    @classmethod
    def _train_optional_xgboost(cls, xs: list[list[float]], ys: list[float], weights: list[float], group_sizes: list[int] | None = None, hyperparams: dict | None = None, num_boost_round: int = 110):
        xgb = cls._ensure_xgboost()
        labels = cls._ranking_labels(ys, group_sizes)
        if xgb is None or len(xs) < 180 or labels is None:
            if xgb is not None:
                cls._OPTIONAL_TREE2_LAST_STATUS = f"insufficient-ranking-data:{len(xs)}"
            return None, None
        try:
            import numpy as np
            matrix = np.asarray(xs, dtype=float)
            dtrain = xgb.DMatrix(matrix, label=np.asarray(labels, dtype=float))
            normalized_groups = [int(value) for value in group_sizes]
            dtrain.set_group(normalized_groups)
            if weights and len(weights) == len(xs) and sum(normalized_groups) == len(xs):
                group_weights = []
                offset = 0
                for size in normalized_groups:
                    chunk = [_finite(value, 1.0) for value in weights[offset:offset + size]]
                    group_weights.append(max(1e-6, statistics.fmean(chunk) if chunk else 1.0))
                    offset += size
                # XGBoost learning-to-rank defines weights per query/group, not per row.
                dtrain.set_weight(np.asarray(group_weights, dtype=float))
            adaptive_settings = _load_install_settings()
            xgb_device = "cuda" if adaptive_settings.get("xgboost_device") == "cuda" else "cpu"
            params = {
                "objective":"rank:ndcg", "eval_metric":"ndcg@10", "eta":0.035,
                "max_depth":5, "min_child_weight":4.0, "subsample":0.90,
                "colsample_bytree":0.90, "lambda":1.2, "alpha":0.10,
                "tree_method":"hist", "device":xgb_device, "seed":20260817, "nthread":_adaptive_ml_threads(),
            }
            if hyperparams:
                params.update({key:value for key,value in hyperparams.items() if key in {"eta","max_depth","min_child_weight","lambda","alpha"}})
            cuda_fallback = False
            try:
                booster = xgb.train(params, dtrain, num_boost_round=_adaptive_boost_rounds(num_boost_round), verbose_eval=False)
            except Exception as cuda_exc:
                if params.get("device") != "cuda":
                    raise
                _record_cuda_failure(cuda_exc)
                params["device"] = "cpu"
                booster = xgb.train(params, dtrain, num_boost_round=_adaptive_boost_rounds(num_boost_round), verbose_eval=False)
                cuda_fallback = True
            raw = bytes(booster.save_raw(raw_format="ubj"))
            spec = {
                "backend":"xgboost-rank-ndcg", "model_b64":base64.b64encode(raw).decode("ascii"),
                "params":params, "training_samples":len(xs), "groups":len(group_sizes),
                "ranking_label_levels":16,
            }
            cls._OPTIONAL_TREE2_LAST_STATUS = (
                f"trained-rank-ndcg:{len(xs)}:{len(group_sizes)}groups"
                + (":cuda-fallback-cpu" if cuda_fallback else "")
            )
            return spec, (lambda row, b=booster, xgb=xgb, np=np: float(b.predict(xgb.DMatrix(np.asarray([row], dtype=float)))[0]))
        except Exception as exc:
            cls._OPTIONAL_TREE2_LAST_STATUS = f"train-failed:{type(exc).__name__}"
            return None, None

    @staticmethod
    def _optional_predictor(spec: dict | None):
        if not isinstance(spec, dict):
            return None
        backend = str(spec.get("backend") or "")
        settings = _load_install_settings()
        try:
            active_dir = _active_dependency_dir(settings)
            if active_dir is None:
                return None
            required_loaded = ("numpy", "scipy", "lightgbm") if backend == "lightgbm-lambdarank" else ("numpy", "scipy", "xgboost")
            if not _loaded_modules_are_local(active_dir, required_loaded):
                return None
            _activate_local_dependencies()
            if backend == "lightgbm-lambdarank" and spec.get("model_string") and settings.get("lightgbm") is True:
                import lightgbm as lgb
                import numpy as np
                module_path = Path(getattr(lgb, "__file__", "")).resolve()
                if active_dir.resolve() not in module_path.parents:
                    return None
                booster = lgb.Booster(model_str=spec["model_string"])
                return lambda row, b=booster, np=np: float(b.predict(np.asarray([row], dtype=float))[0])
            if backend == "xgboost-rank-ndcg" and spec.get("model_b64") and settings.get("advanced_tree") is True:
                import xgboost as xgb
                import numpy as np
                module_path = Path(getattr(xgb, "__file__", "")).resolve()
                if active_dir.resolve() not in module_path.parents:
                    return None
                booster = xgb.Booster()
                booster.load_model(bytearray(base64.b64decode(spec["model_b64"])))
                configured_device = str(settings.get("xgboost_device") or "cpu")
                trained_device = str((spec.get("params") or {}).get("device") or "cpu")
                device = "cuda" if configured_device == "cuda" and trained_device == "cuda" else "cpu"
                booster.set_param({"device": device})
                return lambda row, b=booster, xgb=xgb, np=np: float(b.predict(xgb.DMatrix(np.asarray([row], dtype=float)))[0])
        except Exception:
            return None
        return None

    def _validation_metrics(self, snapshots: list[dict], predict) -> dict:
        rank_ics, top_utils, draw_quality, regimes, top_sets = [], [], [], [], []
        for snap in snapshots:
            preds = [predict(row) for row in snap["rows"]]; targets = snap["targets"]
            rank_ics.append(_spearman(preds, targets))
            k = min(10, len(preds))
            if k <= 0: continue
            order = sorted(range(len(preds)), key=lambda i: preds[i], reverse=True)[:k]
            top_utils.append(sum(targets[i] for i in order) / k)
            dd_scaled = _rank_scale([-snap["drawdowns"][i] for i in range(len(preds))])
            draw_quality.append(sum(dd_scaled[i] for i in order) / k)
            top_sets.append({snap["codes"][i] for i in order}); regimes.append((snap["regime"], rank_ics[-1]))
        rank_ic = sum(rank_ics) / max(1, len(rank_ics)); top10_utility = sum(top_utils) / max(1, len(top_utils))
        drawdown_quality = sum(draw_quality) / max(1, len(draw_quality))
        turnover_values = [1.0 - len(a & b) / max(1, len(a | b)) for a,b in zip(top_sets, top_sets[1:])]
        turnover = sum(turnover_values) / len(turnover_values) if turnover_values else 0.0
        per_regime = {}
        for regime, value in regimes: per_regime.setdefault(regime, []).append(value)
        regime_means = [sum(vs)/len(vs) for vs in per_regime.values()]
        worst_regime = min(regime_means) if regime_means else 0.0
        dispersion = statistics.pstdev(rank_ics) if len(rank_ics) > 1 else 0.0
        stability = 0.5 * (rank_ic - dispersion) + 0.5 * worst_regime
        quality = 0.30*rank_ic + 0.25*top10_utility + 0.20*drawdown_quality + 0.15*stability - 0.10*turnover
        return {
            "rank_ic": rank_ic, "median_rank_ic": statistics.median(rank_ics) if rank_ics else 0.0,
            "positive_rank_ic_ratio": sum(v > 0 for v in rank_ics)/max(1,len(rank_ics)),
            "worst_rank_ic": min(rank_ics) if rank_ics else 0.0, "rank_ic_std": dispersion,
            "top10_utility": top10_utility, "drawdown_quality": drawdown_quality,
            "regime_stability": stability, "worst_regime_rank_ic": worst_regime,
            "turnover": turnover, "model_quality": quality, "windows": len(rank_ics),
        }


    def _ensemble_validation_metrics(self, snapshots: list[dict], predictors: dict, weights: dict) -> dict:
        rank_ics, top_utils, draw_quality, regimes, top_sets = [], [], [], [], []
        for snap in snapshots:
            component_predictions = {}
            for name, predictor in predictors.items():
                values = [predictor(row) for row in snap["rows"]]
                ranks = _rank_scale(values)
                component_predictions[name] = [2.0 * value - 1.0 for value in ranks]
            predictions = []
            for index in range(len(snap["rows"])):
                predictions.append(sum(
                    max(0.0, _finite(weights.get(name))) * values[index]
                    for name, values in component_predictions.items()
                ))
            targets = snap["targets"]
            rank_ics.append(_spearman(predictions, targets))
            k = min(10, len(predictions))
            if k <= 0:
                continue
            order = sorted(range(len(predictions)), key=lambda i: predictions[i], reverse=True)[:k]
            top_utils.append(sum(targets[i] for i in order) / k)
            dd_scaled = _rank_scale([-snap["drawdowns"][i] for i in range(len(predictions))])
            draw_quality.append(sum(dd_scaled[i] for i in order) / k)
            top_sets.append({snap["codes"][i] for i in order})
            regimes.append((snap["regime"], rank_ics[-1]))
        rank_ic = sum(rank_ics) / max(1, len(rank_ics))
        top10_utility = sum(top_utils) / max(1, len(top_utils))
        drawdown_quality = sum(draw_quality) / max(1, len(draw_quality))
        turnover_values = [
            1.0 - len(left & right) / max(1, len(left | right))
            for left, right in zip(top_sets, top_sets[1:])
        ]
        turnover = sum(turnover_values) / len(turnover_values) if turnover_values else 0.0
        per_regime = {}
        for regime, value in regimes:
            per_regime.setdefault(regime, []).append(value)
        regime_means = [sum(values) / len(values) for values in per_regime.values()]
        worst_regime = min(regime_means) if regime_means else 0.0
        dispersion = statistics.pstdev(rank_ics) if len(rank_ics) > 1 else 0.0
        stability = 0.5 * (rank_ic - dispersion) + 0.5 * worst_regime
        quality = (
            0.30*rank_ic + 0.25*top10_utility + 0.20*drawdown_quality
            + 0.15*stability - 0.10*turnover
        )
        return {
            "rank_ic": rank_ic,
            "median_rank_ic": statistics.median(rank_ics) if rank_ics else 0.0,
            "positive_rank_ic_ratio": sum(value > 0 for value in rank_ics) / max(1, len(rank_ics)),
            "worst_rank_ic": min(rank_ics) if rank_ics else 0.0,
            "rank_ic_std": dispersion,
            "top10_utility": top10_utility,
            "drawdown_quality": drawdown_quality,
            "regime_stability": stability,
            "worst_regime_rank_ic": worst_regime,
            "turnover": turnover,
            "model_quality": quality,
            "windows": len(rank_ics),
        }

    @staticmethod
    def _training_flatten(group):
        xs, ys, ws, buckets, group_sizes = [], [], [], [], []
        latest = max((snap["feature_date"] for snap in group), default="")
        latest_day = _dt.date.fromisoformat(latest) if latest else _china_today()
        for snap in group:
            try:
                age = max(0.0, (latest_day - _dt.date.fromisoformat(snap["feature_date"])).days / 365.25)
            except ValueError:
                age = 0.0
            weight = math.exp(-0.08 * age)
            xs.extend(snap["rows"]); ys.extend(snap["targets"]); ws.extend([weight] * len(snap["rows"]))
            group_sizes.append(len(snap["rows"]))
            snap_buckets = list(snap.get("buckets") or [])
            if len(snap_buckets) != len(snap["rows"]):
                snap_buckets = ["其他"] * len(snap["rows"])
            buckets.extend(snap_buckets)
        return xs, ys, ws, buckets, group_sizes

    @staticmethod
    def _training_entry_values(rows):
        return [0.32*r[1] + 0.28*r[10] + 0.20*r[6] + 0.12*r[7] + 0.08*r[13] - 0.10*max(0.0, r[0]-1.0) for r in rows]

    @staticmethod
    def _training_one_metrics(preds, snap):
        targets = snap["targets"]
        ric = _spearman(preds, targets) if len(preds) >= 3 else 0.0
        k = min(10, len(preds)); order = sorted(range(len(preds)), key=lambda i: preds[i], reverse=True)[:k]
        top = sum(targets[i] for i in order) / max(1, k)
        ddq = _rank_scale([-v for v in snap["drawdowns"]]); draw = sum(ddq[i] for i in order) / max(1, k)
        return ric, top, draw

    @staticmethod
    def _training_aggregate(records):
        if not records:
            return {"windows":0,"rank_ic_mean":0.0,"rank_ic_median":0.0,"rank_ic_positive_ratio":0.0,"rank_ic_worst":0.0,"rank_ic_p25":0.0,"model_quality":-9.0}
        rics=[r[0] for r in records]; tops=[r[1] for r in records]; draws=[r[2] for r in records]
        sr=sorted(rics); p25=sr[max(0,int(0.25*(len(sr)-1)))]
        med=statistics.median(rics); mean=sum(rics)/len(rics); pos=sum(v>0 for v in rics)/len(rics); worst=min(rics)
        quality=0.32*med+0.18*p25+0.18*mean+0.14*(2*pos-1)+0.10*(sum(tops)/len(tops))+0.08*(sum(draws)/len(draws))
        return {"windows":len(rics),"rank_ic_mean":mean,"rank_ic_median":med,"rank_ic_positive_ratio":pos,
                "rank_ic_worst":worst,"rank_ic_p25":p25,"top10_utility":sum(tops)/len(tops),
                "drawdown_quality":sum(draws)/len(draws),"model_quality":quality}

    @staticmethod
    def _training_eligible_folds(snaps):
        folds=[]
        for idx,snap in enumerate(snaps):
            prior=[s for s in snaps[:idx] if str(s.get("target_end_date") or "") <= str(snap.get("feature_date") or "")]
            samples=sum(len(s["rows"]) for s in prior)
            if len(prior)>=3 and samples>=120:
                folds.append((prior,snap))
        return folds[-40:]

    def _training_split_evaluation_folds(self, folds):
        selected=self._non_overlapping_tail([snap for _,snap in folds], OOS_DEPLOYMENT_WINDOWS + OOS_UNTOUCHED_TEST_WINDOWS)
        keys={str(snap.get("feature_date") or "") for snap in selected}
        independent=[fold for fold in folds if str(fold[1].get("feature_date") or "") in keys]
        if len(independent) < 3:
            return [], [], [], independent
        if len(independent) < 5:
            audit_count=1; deployment_count=1
        else:
            audit_count=min(2, max(1, len(independent)//2))
            deployment_count=min(2, len(independent)-audit_count-1)
        if deployment_count < 1:
            return [], [], [], independent
        untouched=independent[-audit_count:]
        deployment=independent[-(audit_count+deployment_count):-audit_count]
        first_deployment=str(deployment[0][1].get("feature_date") or "")
        development=[fold for fold in folds if str(fold[1].get("target_end_date") or "") <= first_deployment]
        return development, deployment, untouched, independent

    def _training_development_target_search(self, funds: list[dict]):
        """Development-only target/blend search; deployment and untouched folds are only reserved here, never scored for selection."""
        target_trials = []
        horizon_cache = {}
        for horizon in {str(spec.get("horizon") or "3y") for spec in TARGET_SPECS}:
            base_spec = next(spec for spec in TARGET_SPECS if str(spec.get("horizon") or "3y") == horizon)
            horizon_cache[horizon] = self._build_snapshots(funds, base_spec)
        for spec in TARGET_SPECS:
            horizon = str(spec.get("horizon") or "3y")
            base_snaps, info = horizon_cache[horizon]
            weights = dict(spec.get("weights") or {})
            snaps = []
            for base in base_snaps:
                components = base.get("target_components") or {}
                if any(key not in components for key in weights):
                    continue
                combined = [sum(_finite(weight) * components[key][i] for key, weight in weights.items()) for i in range(len(base["rows"]))]
                snap = dict(base)
                snap["targets"] = _rank_scale(combined)
                snap["target_weights"] = weights
                snap["target_spec"] = spec.get("name", horizon)
                snaps.append(snap)
            folds = self._training_eligible_folds(snaps)
            development_folds, deployment_folds, untouched_folds, independent_folds = self._training_split_evaluation_folds(folds)
            if len(development_folds) < MIN_OOS_GATE_WINDOWS or not deployment_folds or not untouched_folds:
                continue
            cached = []
            for prior, snap in development_folds:
                xs, ys, ws, bks, _groups = self._training_flatten(prior)
                gw, am = self._fit_hierarchical_linear(xs, ys, ws, bks)
                sb = snap.get("buckets") or ["其他"] * len(snap["rows"])
                long_pred = [self._hierarchical_linear_predict(row, bucket, gw, am) for row, bucket in zip(snap["rows"], sb)]
                cached.append((snap, [2*v-1 for v in _rank_scale(long_pred)], [2*v-1 for v in _rank_scale(self._training_entry_values(snap["rows"]))]))
            for blend in LONG_TERM_BLEND_CANDIDATES:
                records = [self._training_one_metrics([blend*l + (1-blend)*e for l, e in zip(lr, er)], snap) for snap, lr, er in cached]
                metrics = self._training_aggregate(records)
                target_trials.append((metrics["model_quality"], metrics["rank_ic_median"], metrics["rank_ic_p25"], spec, blend, snaps, info, folds, development_folds, deployment_folds, untouched_folds, independent_folds, metrics))
        return max(target_trials, key=lambda x: (x[0], x[1], x[2])) if target_trials else None

    def _training_deployment_gate(self, training_funds, deployment_folds, deployment_training, best_baseline, best_ai, fit_mode_model, aggregate, paired_bootstrap_rankic, candidate_dev_gate, universe_coverage):
        deployment_snaps = [snap for _, snap in deployment_folds]
        deployment_baseline_model = fit_mode_model(deployment_training, best_baseline, "labels matured before independent deployment validation start")
        baseline_oos = self._full_pipeline_oos(training_funds, deployment_snaps, deployment_baseline_model, "均衡") if deployment_baseline_model else aggregate([])
        deployment_candidate_model = fit_mode_model(deployment_training, best_ai, "labels matured before independent deployment validation start") if best_ai else None
        candidate_oos = self._full_pipeline_oos(training_funds, deployment_snaps, deployment_candidate_model, "均衡") if deployment_candidate_model else aggregate([])
        bootstrap = paired_bootstrap_rankic(candidate_oos, baseline_oos)
        rankic_uplift = _finite(candidate_oos.get("rank_ic_median"), -9.0) - _finite(baseline_oos.get("rank_ic_median"), 0.0)
        quality_uplift = _finite(candidate_oos.get("quality"), -9.0) - _finite(baseline_oos.get("quality"), 0.0)
        passed = bool(
            candidate_dev_gate and deployment_candidate_model is not None
            and candidate_oos.get("windows", 0) >= 1
            and candidate_oos.get("windows_non_overlapping") is True
            and rankic_uplift >= DEPLOYMENT_MIN_RANKIC_UPLIFT
            and quality_uplift >= DEPLOYMENT_MIN_QUALITY_UPLIFT
            and bootstrap.get("ci90_low", -9.0) >= DEPLOYMENT_BOOTSTRAP_LOWER_FLOOR
        )
        if universe_coverage < UNIVERSE_EXPERT_ONLY_COVERAGE:
            reason = "historical universe coverage <25%: robust Expert/defensive/low-volatility only"
        elif universe_coverage < UNIVERSE_COMPLEX_ML_COVERAGE and not best_ai:
            reason = "historical universe coverage 25%-60%: Ridge allowed, complex ML disabled"
        elif not candidate_dev_gate:
            reason = "development candidate did not clear stability/uplift prerequisites"
        elif deployment_candidate_model is None:
            reason = "frozen candidate could not be refit before deployment validation"
        elif not passed:
            reason = f"independent deployment uplift insufficient: RankIC {rankic_uplift:+.3f}, quality {quality_uplift:+.3f}, bootstrap90 low {bootstrap.get('ci90_low',-9.0):+.3f}"
        else:
            reason = "independent deployment validation passed predefined uplift and bootstrap gates"
        return {
            "passed": passed, "reason": reason, "candidate_oos": candidate_oos, "baseline_oos": baseline_oos,
            "rankic_uplift": rankic_uplift, "quality_uplift": quality_uplift, "bootstrap": bootstrap,
        }

    def _training_untouched_audit(self, training_funds, untouched_folds, evaluation_training, deployment_gate_passed, best_ai, best_baseline, gate_reason, fit_mode_model, aggregate):
        ai_enabled = deployment_gate_passed
        selected_mode = best_ai if ai_enabled else best_baseline
        evaluation_model = fit_mode_model(evaluation_training, selected_mode, "all labels matured before untouched audit start; deployment gate already frozen")
        if evaluation_model is None:
            ai_enabled = False
            selected_mode = best_baseline
            gate_reason += "; selected family refit failed, reverted to robust baseline"
            evaluation_model = fit_mode_model(evaluation_training, selected_mode, "baseline refit before untouched audit")
        untouched_snaps = [snap for _, snap in untouched_folds]
        full_oos = self._full_pipeline_oos(training_funds, untouched_snaps, evaluation_model, "均衡") if evaluation_model else aggregate([])
        return ai_enabled, selected_mode, gate_reason, evaluation_model, untouched_snaps, full_oos

    def _training_production_refit(self, training_funds, untouched_snaps, evaluation_training, ai_enabled, selected_mode, best_baseline, gate_reason, evaluation_model, full_oos, fit_mode_model, aggregate, mode_components, long_blend):
        # Untouched outcomes never promote/demote a family and never enter production coefficients/trees.
        production_model = fit_mode_model(evaluation_training, selected_mode, "production refit uses only labels matured before untouched audit start; untouched outcomes never enter coefficients/trees")
        if production_model is None and selected_mode != best_baseline:
            ai_enabled = False
            selected_mode = best_baseline
            gate_reason += "; production refit unavailable, reverted to robust baseline"
            evaluation_model = fit_mode_model(evaluation_training, selected_mode, "baseline refit before untouched audit")
            full_oos = self._full_pipeline_oos(training_funds, untouched_snaps, evaluation_model, "均衡") if evaluation_model else aggregate([])
            production_model = fit_mode_model(evaluation_training, selected_mode, "baseline production refit excluding untouched audit outcomes")
        if production_model is None:
            production_model = {
                "linear_weights":[0.0]*len(self.FEATURE_NAMES), "asset_models":{},
                "asset_model_blend":{"global":GLOBAL_ASSET_BLEND,"asset_specific":ASSET_SPECIFIC_BLEND},
                "nonlinear_models":[], "optional_ml":None, "optional_tree2":None,
                "component_weights":mode_components("expert"), "baseline_mode":"expert",
                "long_term_blend":long_blend, "training_samples":0, "fit_dataset":"emergency expert fallback",
            }
            ai_enabled = False
            selected_mode = "expert"
        return ai_enabled, selected_mode, gate_reason, evaluation_model, full_oos, production_model

    def train(self, funds: list[dict]) -> dict:
        """Anchored walk-forward selection. Untouched tail is never used to choose model family/ML."""
        expert_scale = sum(abs(v) for v in self.EXPERT_WEIGHTS) or 1.0
        expert_weights = [v/expert_scale for v in self.EXPERT_WEIGHTS]
        baseline_predictors = {
            "expert": lambda row: sum(a*b for a,b in zip(expert_weights,row)),
            "defensive": lambda row: 0.34*row[6]+0.28*row[7]+0.16*row[8]+0.12*row[12]+0.10*row[15],
            "low_volatility": lambda row: 0.34*row[7]+0.24*row[6]+0.16*row[20]+0.14*row[24]+0.12*row[27],
            "quality_momentum": lambda row: 0.24*row[17]+0.18*row[2]+0.14*row[3]+0.12*row[6]+0.12*row[10]+0.10*row[21]+0.10*row[27],
        }

        flatten = self._training_flatten
        entry_values = self._training_entry_values
        one_metrics = self._training_one_metrics
        aggregate = self._training_aggregate
        eligible_folds = self._training_eligible_folds
        split_evaluation_folds = self._training_split_evaluation_folds

        development_selection = self._training_development_target_search(funds)
        if development_selection is None:
            model=LocalStore.default_model(); model.update({
                "trained_at":_now_iso(),"universe_size":len(funds),"universe_codes":sorted(str(f.get("code") or "") for f in funds),
                "model_status":"expert-fallback-insufficient-independent-long-horizon-folds","baseline_mode":"expert",
                "target":"long-horizon independent validation unavailable: expert fallback","target_selection":"development target search required independent deployment + untouched windows",
                "survivorship_bias":True,"engine":"anchored walk-forward long-horizon target search + diversified Top10",
            }); return model

        _,_,_,selected_spec,long_blend,snapshots,snapshot_info,folds,development_folds,deployment_folds,untouched_folds,independent_folds,target_cv = development_selection
        training_funds=snapshot_info["funds"]
        first_deployment_feature=min((snap["feature_date"] for _,snap in deployment_folds),default="")
        first_test_feature=min((snap["feature_date"] for _,snap in untouched_folds),default="")
        deployment_training=[snap for snap in snapshots if first_deployment_feature and snap["target_end_date"]<=first_deployment_feature]
        evaluation_training=[snap for snap in snapshots if first_test_feature and snap["target_end_date"]<=first_test_feature]
        if not deployment_training:
            deployment_training=[snap for snap in snapshots if snap not in [f[1] for f in deployment_folds+untouched_folds]]
        if not evaluation_training:
            evaluation_training=[snap for snap in snapshots if snap not in [f[1] for f in untouched_folds]]

        family_names=[*baseline_predictors.keys(),"linear","nonlinear","ensemble","lightgbm","ensemble_ml","xgboost","ensemble_xgb","ensemble_dual_tree"]
        family_records={name:[] for name in family_names}
        family_top_counts={name:{} for name in family_names}; family_eligible_counts={name:{} for name in family_names}
        def record_family(name, preds, snap):
            family_records[name].append(one_metrics(preds, snap))
            codes=list(snap.get("codes") or [])
            for code in codes:
                family_eligible_counts[name][code]=family_eligible_counts[name].get(code,0)+1
            k=min(10,len(preds)); order=sorted(range(len(preds)),key=lambda i:preds[i],reverse=True)[:k]
            for i in order:
                if i < len(codes):
                    code=codes[i]; family_top_counts[name][code]=family_top_counts[name].get(code,0)+1
        def tune_tree_params(prior, trainer, grid):
            # Inner validation is strictly earlier than the outer development snapshot; untouched folds are never seen here.
            if len(prior) < 5:
                return dict(grid[min(1, len(grid)-1)])
            inner_train = prior[:-2]; inner_valid = prior[-2:]
            ix,iy,iw,ib,ig = flatten(inner_train)
            if len(ix) < 180:
                return dict(grid[min(1, len(grid)-1)])
            trials=[]
            for params in grid:
                _spec,predict = trainer(ix,iy,iw,ig,hyperparams=dict(params),num_boost_round=70)
                if predict is None:
                    continue
                records=[]
                for valid_snap in inner_valid:
                    long_rank=[2*v-1 for v in _rank_scale([predict(row) for row in valid_snap["rows"]])]
                    entry_rank=[2*v-1 for v in _rank_scale(entry_values(valid_snap["rows"]))]
                    preds=[long_blend*l+(1-long_blend)*e for l,e in zip(long_rank,entry_rank)]
                    records.append(one_metrics(preds,valid_snap))
                metrics=aggregate(records)
                trials.append((metrics.get("model_quality",-9.0),metrics.get("rank_ic_median",-9.0),dict(params)))
            return max(trials,key=lambda row:(row[0],row[1]))[2] if trials else dict(grid[min(1, len(grid)-1)])

        universe_coverage=_clamp(_finite(snapshot_info.get("historical_universe_known_coverage"),0.0),0.0,1.0)
        allow_linear_model=universe_coverage >= UNIVERSE_EXPERT_ONLY_COVERAGE
        allow_complex_ml=universe_coverage >= UNIVERSE_COMPLEX_ML_COVERAGE
        allow_tree_models=allow_complex_ml and len(deployment_folds) >= MIN_TREE_DEPLOYMENT_WINDOWS
        nonlinear_seeds = self._adaptive_nonlinear_seeds()
        lgb_grid = self._adaptive_lightgbm_grid()
        xgb_grid = self._adaptive_xgboost_grid()
        lgb_param_votes={}; xgb_param_votes={}
        ml_dev_windows=0; tree2_dev_windows=0
        for prior,snap in development_folds:
            xs,ys,ws,bks,groups=flatten(prior); gw,asset_models=self._fit_hierarchical_linear(xs,ys,ws,bks)
            nonlinear=[]
            for seed in nonlinear_seeds:
                rx=[self._random_features(row,seed) for row in xs]; nonlinear.append((seed,self._solve_ridge(rx,ys,ws,1.2)))
            sb=snap.get("buckets") or ["其他"]*len(snap["rows"])
            component={name:[fn(row) for row in snap["rows"]] for name,fn in baseline_predictors.items()}
            component["linear"]=[self._hierarchical_linear_predict(row,bucket,gw,asset_models) for row,bucket in zip(snap["rows"],sb)]
            component["nonlinear"]=[sum(sum(a*b for a,b in zip(w,self._random_features(row,seed))) for seed,w in nonlinear)/len(nonlinear) for row in snap["rows"]]
            if allow_tree_models:
                lgb_params=tune_tree_params(prior,self._train_optional_lightgbm,lgb_grid)
                xgb_params=tune_tree_params(prior,self._train_optional_xgboost,xgb_grid)
                lgb_key=json.dumps(lgb_params,sort_keys=True,separators=(",",":")); xgb_key=json.dumps(xgb_params,sort_keys=True,separators=(",",":"))
                lgb_param_votes[lgb_key]=lgb_param_votes.get(lgb_key,0)+1; xgb_param_votes[xgb_key]=xgb_param_votes.get(xgb_key,0)+1
                ml_spec,ml_predict=self._train_optional_lightgbm(xs,ys,ws,groups,hyperparams=lgb_params)
                tree2_spec,tree2_predict=self._train_optional_xgboost(xs,ys,ws,groups,hyperparams=xgb_params)
            else:
                ml_spec=tree2_spec=None; ml_predict=tree2_predict=None
            if ml_predict is not None:
                component["lightgbm"]=[ml_predict(row) for row in snap["rows"]]; ml_dev_windows+=1
            if tree2_predict is not None:
                component["xgboost"]=[tree2_predict(row) for row in snap["rows"]]; tree2_dev_windows+=1
            entry_rank=[2*v-1 for v in _rank_scale(entry_values(snap["rows"]))]
            for name in list(baseline_predictors)+["linear","nonlinear"]:
                lr=[2*v-1 for v in _rank_scale(component[name])]; record_family(name, [long_blend*l+(1-long_blend)*e for l,e in zip(lr,entry_rank)], snap)
            er=[2*v-1 for v in _rank_scale(component["expert"])]; lr=[2*v-1 for v in _rank_scale(component["linear"])]; nr=[2*v-1 for v in _rank_scale(component["nonlinear"])]
            mix=[0.30*a+0.40*b+0.30*c for a,b,c in zip(er,lr,nr)]
            record_family("ensemble", [long_blend*l+(1-long_blend)*e for l,e in zip(mix,entry_rank)], snap)
            mr=xr=None
            if ml_predict is not None:
                mr=[2*v-1 for v in _rank_scale(component["lightgbm"])]
                record_family("lightgbm", [long_blend*l+(1-long_blend)*e for l,e in zip(mr,entry_rank)], snap)
                mix_ml=[0.22*a+0.28*b+0.20*c+0.30*d for a,b,c,d in zip(er,lr,nr,mr)]
                record_family("ensemble_ml", [long_blend*l+(1-long_blend)*e for l,e in zip(mix_ml,entry_rank)], snap)
            if tree2_predict is not None:
                xr=[2*v-1 for v in _rank_scale(component["xgboost"])]
                record_family("xgboost", [long_blend*l+(1-long_blend)*e for l,e in zip(xr,entry_rank)], snap)
                mix_xgb=[0.22*a+0.28*b+0.20*c+0.30*d for a,b,c,d in zip(er,lr,nr,xr)]
                record_family("ensemble_xgb", [long_blend*l+(1-long_blend)*e for l,e in zip(mix_xgb,entry_rank)], snap)
            if mr is not None and xr is not None:
                mix_dual=[0.18*a+0.24*b+0.18*c+0.22*d+0.18*e for a,b,c,d,e in zip(er,lr,nr,mr,xr)]
                record_family("ensemble_dual_tree", [long_blend*l+(1-long_blend)*e for l,e in zip(mix_dual,entry_rank)], snap)

        def voted_params(votes, grid):
            if not votes:
                return dict(grid[min(1, len(grid)-1)])
            key=max(votes,key=lambda k:(votes[k],k))
            return json.loads(key)
        frozen_lgb_params=voted_params(lgb_param_votes,lgb_grid)
        frozen_xgb_params=voted_params(xgb_param_votes,xgb_grid)
        family_metrics={name:aggregate(rows) for name,rows in family_records.items()}
        robust_baselines=("expert","defensive","low_volatility") if universe_coverage < UNIVERSE_EXPERT_ONLY_COVERAGE else tuple(baseline_predictors)
        best_baseline=max(robust_baselines,key=lambda n:family_metrics[n]["model_quality"])
        if not allow_linear_model:
            allowed_ai=[]
        elif not allow_complex_ml:
            allowed_ai=["linear"]
        else:
            allowed_ai=["linear","nonlinear","ensemble"]
            if allow_tree_models:
                allowed_ai += ["ensemble_ml","lightgbm","ensemble_xgb","xgboost","ensemble_dual_tree"]
        ai_candidates=[name for name in allowed_ai if family_metrics[name]["windows"]>=MIN_OOS_GATE_WINDOWS]
        best_ai=max(ai_candidates,key=lambda n:family_metrics[n]["model_quality"]) if ai_candidates else ""
        candidate=family_metrics.get(best_ai,aggregate([])); baseline=family_metrics[best_baseline]
        candidate_dev_gate=bool(best_ai and candidate["windows"]>=MIN_OOS_GATE_WINDOWS and candidate["rank_ic_median"]>0
                                and candidate["rank_ic_positive_ratio"]>=0.55 and candidate["rank_ic_worst"]>-0.45
                                and candidate["model_quality"]>baseline["model_quality"]
                                and candidate["rank_ic_median"]>=baseline["rank_ic_median"])

        def mode_components(mode):
            if mode=="lightgbm": return {"expert":0.0,"linear":0.0,"nonlinear":0.0,"external":1.0,"tree2":0.0}
            if mode=="xgboost": return {"expert":0.0,"linear":0.0,"nonlinear":0.0,"external":0.0,"tree2":1.0}
            if mode=="ensemble_ml": return {"expert":0.22,"linear":0.28,"nonlinear":0.20,"external":0.30,"tree2":0.0}
            if mode=="ensemble_xgb": return {"expert":0.22,"linear":0.28,"nonlinear":0.20,"external":0.0,"tree2":0.30}
            if mode=="ensemble_dual_tree": return {"expert":0.18,"linear":0.24,"nonlinear":0.18,"external":0.22,"tree2":0.18}
            if mode=="ensemble": return {"expert":0.30,"linear":0.40,"nonlinear":0.30,"external":0.0,"tree2":0.0}
            if mode=="linear": return {"expert":0.0,"linear":1.0,"nonlinear":0.0,"external":0.0,"tree2":0.0}
            if mode=="nonlinear": return {"expert":0.0,"linear":0.0,"nonlinear":1.0,"external":0.0,"tree2":0.0}
            return {"expert":1.0,"linear":0.0,"nonlinear":0.0,"external":0.0,"tree2":0.0}

        def fit_mode_model(group, mode, label):
            x,y,w,b,groups=flatten(group)
            if not x:
                return None
            linear,assets=self._fit_hierarchical_linear(x,y,w,b)
            linear=self._normalized_linear_weights(linear); assets=self._normalized_asset_models(assets)
            needs_nonlinear=mode in {"nonlinear","ensemble","ensemble_ml","ensemble_xgb","ensemble_dual_tree"}
            nonlinear=[]
            if needs_nonlinear:
                for seed in nonlinear_seeds:
                    rx=[self._random_features(row,seed) for row in x]
                    weights=self._solve_ridge(rx,y,w,1.2)
                    nonlinear.append({"seed":seed,"lambda":1.2,"weights":self._normalized_linear_weights(weights)})
            needs_ml=mode in {"lightgbm","ensemble_ml","ensemble_dual_tree"}
            needs_tree2=mode in {"xgboost","ensemble_xgb","ensemble_dual_tree"}
            ml,_=self._train_optional_lightgbm(x,y,w,groups,hyperparams=frozen_lgb_params) if needs_ml else (None,None)
            tree2,_=self._train_optional_xgboost(x,y,w,groups,hyperparams=frozen_xgb_params) if needs_tree2 else (None,None)
            if needs_ml and ml is None:
                return None
            if needs_tree2 and tree2 is None:
                return None
            return {
                "linear_weights":linear,"asset_models":assets,"asset_model_blend":{"global":GLOBAL_ASSET_BLEND,"asset_specific":ASSET_SPECIFIC_BLEND},
                "nonlinear_models":nonlinear,"optional_ml":ml,"optional_tree2":tree2,
                "optional_ml_status":self._OPTIONAL_ML_LAST_STATUS,"optional_tree2_status":self._OPTIONAL_TREE2_LAST_STATUS,
                "component_weights":mode_components(mode),"baseline_mode":mode,"long_term_blend":long_blend,
                "training_samples":len(x),"fit_dataset":label,
            }

        def paired_bootstrap_rankic(candidate_metrics, baseline_metrics):
            left=list(candidate_metrics.get("rank_ic_values") or [])
            right=list(baseline_metrics.get("rank_ic_values") or [])
            n=min(len(left),len(right))
            if n <= 0:
                return {"windows":0,"mean_uplift":-9.0,"ci90_low":-9.0,"ci90_high":-9.0}
            diffs=[_finite(left[i])-_finite(right[i]) for i in range(n)]
            if n == 1:
                return {"windows":1,"mean_uplift":diffs[0],"ci90_low":diffs[0],"ci90_high":diffs[0]}
            rng=random.Random(20260818 + n)
            means=[]
            for _ in range(600):
                means.append(sum(diffs[rng.randrange(n)] for _j in range(n))/n)
            means.sort()
            return {"windows":n,"mean_uplift":sum(diffs)/n,"ci90_low":means[int(0.05*(len(means)-1))],"ci90_high":means[int(0.95*(len(means)-1))]}

        deployment = self._training_deployment_gate(
            training_funds, deployment_folds, deployment_training, best_baseline, best_ai,
            fit_mode_model, aggregate, paired_bootstrap_rankic, candidate_dev_gate, universe_coverage,
        )
        deployment_gate_passed = deployment["passed"]
        gate_reason = deployment["reason"]
        candidate_deployment_oos = deployment["candidate_oos"]
        baseline_deployment_oos = deployment["baseline_oos"]
        rankic_uplift = deployment["rankic_uplift"]
        quality_uplift = deployment["quality_uplift"]
        uplift_bootstrap = deployment["bootstrap"]

        ai_enabled, selected_mode, gate_reason, evaluation_model, untouched_snaps, full_oos = self._training_untouched_audit(
            training_funds, untouched_folds, evaluation_training, deployment_gate_passed, best_ai, best_baseline,
            gate_reason, fit_mode_model, aggregate,
        )
        ai_enabled, selected_mode, gate_reason, evaluation_model, full_oos, production_model = self._training_production_refit(
            training_funds, untouched_snaps, evaluation_training, ai_enabled, selected_mode, best_baseline, gate_reason,
            evaluation_model, full_oos, fit_mode_model, aggregate, mode_components, long_blend,
        )

        prod_linear=production_model.get("linear_weights") or [0.0]*len(self.FEATURE_NAMES)
        prod_assets=production_model.get("asset_models") or {}
        prod_nonlinear=production_model.get("nonlinear_models") or []
        prod_ml=production_model.get("optional_ml")
        prod_tree2=production_model.get("optional_tree2")
        production_use_ml=prod_ml is not None; production_use_tree2=prod_tree2 is not None
        components=production_model.get("component_weights") or mode_components(selected_mode)
        prod_x,_,_,_,_=flatten(evaluation_training)
        selected_top10_stability={code: family_top_counts.get(selected_mode,{}).get(code,0)/max(1,eligible) for code,eligible in family_eligible_counts.get(selected_mode,{}).items()}
        all_eval_snaps=[snap for _,snap in deployment_folds+untouched_folds]
        split_boundaries={"walk_forward_folds":len(folds),"development_folds":len(development_folds),"deployment_validation_folds":len(deployment_folds),"untouched_test_folds":len(untouched_folds),
                          "independent_evaluation_folds":len(independent_folds),"deployment_feature_start":first_deployment_feature,"test_feature_start":first_test_feature,
                          "train_target_end_max":max((s["target_end_date"] for s in evaluation_training),default=""),
                          "target_horizon":selected_spec["horizon"],"target_weights":selected_spec["weights"],
                          "oos_windows_non_overlapping":all(str(a.get("target_end_date") or "") <= str(b.get("feature_date") or "") for a,b in zip(all_eval_snaps,all_eval_snaps[1:])),
                          "purge_rule":"each fold trains only on labels whose target_end <= fold feature_date",
                          "ml_selection_rule":"target/model/tree hyperparameters use development only; frozen candidate must pass independent deployment validation; untouched audit never selects",
                          "universe_model_policy":"<25% robust baselines only; 25%-60% Ridge only; >=60% complex ML eligible; tree models additionally require >=2 independent deployment windows"}
        deployment_gate={"passed":deployment_gate_passed,"reason":gate_reason,"candidate_mode":best_ai or "none","baseline_mode":best_baseline,
                         "rank_ic_median_uplift":rankic_uplift,"quality_uplift":quality_uplift,"bootstrap_rankic_uplift":uplift_bootstrap,
                         "min_rank_ic_uplift":DEPLOYMENT_MIN_RANKIC_UPLIFT,"min_quality_uplift":DEPLOYMENT_MIN_QUALITY_UPLIFT,"bootstrap_lower_floor":DEPLOYMENT_BOOTSTRAP_LOWER_FLOOR,
                         "historical_universe_known_coverage":universe_coverage,"tree_models_allowed":allow_tree_models}
        return {
            "version":MODEL_VERSION,"trained_at":_now_iso(),"feature_names":self.FEATURE_NAMES,"linear_weights":prod_linear,"asset_models":prod_assets,
            "asset_model_blend":{"global":GLOBAL_ASSET_BLEND,"asset_specific":ASSET_SPECIFIC_BLEND},
            "ridge_lambda":0.9,"nonlinear_models":prod_nonlinear if ai_enabled else [],"optional_ml":prod_ml if production_use_ml else None,"optional_tree2":prod_tree2 if production_use_tree2 else None,
            "optional_ml_status":self._OPTIONAL_ML_LAST_STATUS,"optional_ml_development_windows":ml_dev_windows,"optional_tree2_status":self._OPTIONAL_TREE2_LAST_STATUS,"optional_tree2_development_windows":tree2_dev_windows,"component_weights":components,
            "lightgbm_frozen_dev_params":frozen_lgb_params,"xgboost_frozen_dev_params":frozen_xgb_params,
            "baseline_mode":selected_mode,"long_term_blend":long_blend,"evaluation_model":evaluation_model,"production_model":production_model,
            "validation_ic":full_oos.get("rank_ic_median",full_oos.get("rank_ic_mean",0.0)),"model_quality":full_oos.get("quality",0.0),
            "validation_metrics":full_oos,"full_pipeline_oos":full_oos,"untouched_test_oos":full_oos,
            "candidate_deployment_oos":candidate_deployment_oos,"baseline_deployment_oos":baseline_deployment_oos,"expert_development_oos":family_metrics.get("expert",{}),
            "development_candidate_oos":candidate,"development_baseline_oos":baseline,"deployment_gate":deployment_gate,
            "baseline_metrics":{"walk_forward":family_metrics,"selected":best_baseline,"selected_ai_family":best_ai or "none","target_cv":target_cv},
            "training_samples":sum(len(s["rows"]) for s in evaluation_training),"tuning_samples":sum(len(f[1]["rows"]) for f in development_folds),
            "deployment_validation_samples":sum(len(f[1]["rows"]) for f in deployment_folds),
            "validation_samples":sum(len(s["rows"]) for s in untouched_snaps),"production_training_samples":len(prod_x),
            "universe_size":len(training_funds),"source_share_count":snapshot_info["source_share_count"],"duplicate_shares_removed":snapshot_info["duplicate_shares_removed"],
            "universe_codes":sorted(f["code"] for f in training_funds),"historical_availability_coverage":snapshot_info["historical_availability_coverage"],
            "historical_universe_known_coverage":snapshot_info.get("historical_universe_known_coverage",0.0),"historical_availability_used_for_model_selection":False,
            "ai_enabled":ai_enabled,"model_status":f"{selected_mode}-deployment-validated" if ai_enabled else f"{selected_mode}-guardrailed-baseline",
            "split_boundaries":split_boundaries,"selection_dataset":"development selects target/family/hyperparameters; independent deployment validation gates production; non-overlapping untouched audit reports only; production refit after freeze",
            "survivorship_bias":True,"historical_universe_mode":"point-in-time inception/termination + current stale histories + persistent inactive archive; pre-first-observation gaps remain possible",
            "target":f"OOS-selected {selected_spec['name']} weights={selected_spec['weights']} risk-adjusted forward utility",
            "target_spec":selected_spec,"target_selection":"selected by development anchored walk-forward median/p25/mean RankIC and win stability",
            "development_top10_stability_by_code":selected_top10_stability,
            "development_top10_stability_windows":len(development_folds),
            "engine":"three-layer anchored walk-forward; coverage-gated Ridge/tree models; independent deployment validation; non-overlapping untouched audit; diversified Top10",
        }


    @staticmethod
    def _market_regime(usable: list[dict]) -> str:
        ret6 = _median([item["stats"]["return_6m"] for item in usable])
        vol = _median([item["stats"]["volatility"] for item in usable])
        trends = _median([item["feature_vector"][10] for item in usable])
        if ret6 < -0.08 or (ret6 < 0 and vol > 0.24):
            return "risk_off"
        if vol > 0.28:
            return "high_vol"
        if ret6 > 0.12 and trends > 0.08:
            return "trend"
        if ret6 > 0.05:
            return "risk_on"
        return "range"

    @staticmethod
    def _choose_share_classes(funds: list[dict], holding_years: int) -> list[dict]:
        years = _expected_holding_years(holding_years)
        groups: dict[str, list[dict]] = {}
        for fund in funds:
            groups.setdefault(_underlying_key(fund), []).append(fund)
        chosen = []
        for underlying, shares in groups.items():
            def preference(fund: dict):
                verified = fund.get("fees_verified") is True
                cost = _share_class_cost(fund, years) if verified else float("inf")
                return (
                    0 if verified else 1,
                    cost,
                    -len(fund.get("returns") or []),
                    -_share_preference(str(fund.get("name") or "")),
                    str(fund.get("code") or ""),
                )
            selected = dict(min(shares, key=preference))
            selected["underlying_fund_id"] = underlying
            selected["selected_holding_years"] = years
            selected["selected_share_class_cost"] = (
                _share_class_cost(selected, years) if selected.get("fees_verified") is True else None
            )
            selected["alternative_share_codes"] = sorted(
                str(row.get("code") or "") for row in shares
                if str(row.get("code") or "") != str(selected.get("code") or "")
            )
            chosen.append(selected)
        return chosen

    def score(
        self, funds: list[dict], model: dict, profile: str,
        feature_cache: dict | None = None, as_of_date: str | None = None,
        holding_years: int | None = None,
    ) -> list[dict]:
        usable = []
        feature_cache = feature_cache if feature_cache is not None else {}
        years = _expected_holding_years(holding_years)
        for fund in self._choose_share_classes(funds, years):
            availability_status = str(
                fund.get("availability_status")
                or ("confirmed_purchasable" if fund.get("availability_declared") is True else "unknown")
            )
            if availability_status in PURCHASE_UNAVAILABLE_STATUSES:
                continue
            if (
                fund.get("availability_declared") is True
                and as_of_date is None
                and _age_seconds(fund.get("availability_declared_at")) > _availability_max_age_seconds()
            ):
                continue
            returns = fund.get("returns") or []
            fees = fund.get("fees") if fund.get("fees_verified") else None
            dates = fund.get("dates") or []
            fingerprint = (
                len(returns), fund.get("latest_date"), str(dates[-1]) if dates else "",
                round(_finite(returns[-1]) if returns else 0.0, 12),
                json.dumps(fees or {}, sort_keys=True, ensure_ascii=True, separators=(",", ":")),
            )
            cached = feature_cache.get(fund["code"])
            if cached and cached.get("fingerprint") == fingerprint:
                result = (cached["vector"], cached["stats"])
            else:
                result = self.features(returns, fees=fees, dates=dates)
                if result:
                    feature_cache[fund["code"]] = {
                        "fingerprint": fingerprint, "vector": result[0], "stats": result[1]
                    }
            if result:
                asset_class = _asset_bucket(fund.get("name", ""), fund.get("type", ""))
                usable.append({
                    **fund,
                    "feature_vector": result[0],
                    "stats": result[1],
                    "asset_class": asset_class,
                    "asset_bucket": asset_class,
                    "wrapper": _wrapper_type(fund.get("type", "")),
                })
        if len(usable) < 10:
            return []

        scaled_rows = self._scale_feature_rows(
            [item["feature_vector"] for item in usable],
            [item["asset_class"] for item in usable],
        )
        for item, scaled in zip(usable, scaled_rows):
            item["scaled"] = scaled

        regime = self._market_regime(usable)
        expert_weights = self.EXPERT_WEIGHTS[:]
        if profile == "稳健":
            expert_weights = [0.12,0.24,0.38,0.68,0.64,0.76,1.18,0.94,0.92,0.48,0.16,0.72,0.72,0.42,0.38,0.58,0.52,0.72,0.62,0.48,1.18,0.96,1.06,0.72,0.92,0.82,0.78,0.82]
        elif profile == "进取":
            expert_weights = [0.52,0.72,0.88,0.62,0.38,0.38,0.42,0.18,0.28,0.26,0.58,0.22,0.26,0.12,0.18,0.26,0.22,1.08,0.82,0.62,0.52,0.62,0.68,0.28,0.36,0.42,0.54,0.62]
        if regime == "risk_off":
            for idx in (6,7,8,11,12,13,15,16):
                expert_weights[idx] *= 1.25
            for idx in (0,1,2,10):
                expert_weights[idx] *= 0.75
        elif regime == "trend":
            for idx in (2,3,10):
                expert_weights[idx] *= 1.20
        elif regime == "high_vol":
            for idx in (6,7,11,12):
                expert_weights[idx] *= 1.20
        expert_scale = sum(abs(value) for value in expert_weights) or 1.0
        expert_weights = [value / expert_scale for value in expert_weights]

        linear_weights = model.get("linear_weights") or [0.0] * len(self.FEATURE_NAMES)
        asset_models = model.get("asset_models") if isinstance(model.get("asset_models"), dict) else {}
        nonlinear_models = model.get("nonlinear_models") or []
        optional_predict = self._optional_predictor(model.get("optional_ml"))
        tree2_predict = self._optional_predictor(model.get("optional_tree2"))
        components = dict(
            model.get("component_weights")
            or {"expert":1.0, "linear":0.0, "nonlinear":0.0, "external":0.0, "tree2":0.0}
        )
        if optional_predict is None:
            components["external"] = 0.0
        if tree2_predict is None:
            components["tree2"] = 0.0
        if regime == "risk_off":
            components["expert"] = components.get("expert", 0.0) * 1.20
            components["nonlinear"] = components.get("nonlinear", 0.0) * 0.90
        component_total = sum(max(0.0, value) for value in components.values()) or 1.0
        components = {key: max(0.0, value) / component_total for key, value in components.items()}

        raw_components = {"expert": [], "linear": [], "nonlinear": [], "external": [], "tree2": []}
        for item in usable:
            vector = item["scaled"]
            raw_components["expert"].append(sum(w*x for w, x in zip(expert_weights, vector)))
            raw_components["linear"].append(self._hierarchical_linear_predict(vector, item.get("asset_class", "其他"), linear_weights, asset_models))
            nonlinear_values = []
            for model_row in nonlinear_models:
                rf = self._random_features(vector, int(model_row.get("seed", 0)))
                nonlinear_values.append(
                    sum(w*x for w, x in zip(model_row.get("weights") or [], rf))
                )
            raw_components["nonlinear"].append(
                sum(nonlinear_values) / len(nonlinear_values) if nonlinear_values else 0.0
            )
            raw_components["external"].append(
                optional_predict(vector) if optional_predict is not None else 0.0
            )
            raw_components["tree2"].append(
                tree2_predict(vector) if tree2_predict is not None else 0.0
            )

        scaled_components = {}
        for key, values in raw_components.items():
            if (key == "external" and optional_predict is None) or (key == "tree2" and tree2_predict is None) or (key == "nonlinear" and not nonlinear_models):
                scaled_components[key] = [0.0] * len(values)
            else:
                ranks = _rank_scale(values)
                scaled_components[key] = [2.0 * value - 1.0 for value in ranks]

        baseline_mode = str(model.get("baseline_mode") or "ensemble")
        for index, item in enumerate(usable):
            vector = item["scaled"]
            if baseline_mode == "defensive":
                raw = 0.34*vector[6] + 0.28*vector[7] + 0.16*vector[8] + 0.12*vector[12] + 0.10*vector[15]
            elif baseline_mode == "low_volatility":
                raw = 0.34*vector[7] + 0.24*vector[6] + 0.16*vector[20] + 0.14*vector[24] + 0.12*vector[27]
            elif baseline_mode == "quality_momentum":
                raw = 0.24*vector[17] + 0.18*vector[2] + 0.14*vector[3] + 0.12*vector[6] + 0.12*vector[10] + 0.10*vector[21] + 0.10*vector[27]
            elif baseline_mode == "expert":
                raw = scaled_components["expert"][index]
            else:
                raw = sum(
                    components.get(key, 0.0) * scaled_components[key][index]
                    for key in scaled_components
                )

            long_raw = raw + self._product_quality(item, profile, as_of_date)
            if item["stats"]["return_6m"] > 0.50 and item["stats"]["volatility"] > 0.25:
                long_raw -= 0.03
            timing_raw = 0.31*vector[1] + 0.27*vector[10] + 0.19*vector[6] + 0.11*vector[7] + 0.07*vector[13]
            valuation_signal = _valuation_entry_signal(item) if as_of_date is None else 0.0
            timing_raw += 0.05 * valuation_signal
            item["ValuationTimingSignal"] = round(100.0 * valuation_signal, 1)
            if item["stats"]["return_6m"] > 0.45:
                timing_raw -= 0.18 * _clamp((item["stats"]["return_6m"]-0.45)/0.35,0.0,1.0)
            item["long_raw_score"] = long_raw
            item["entry_raw_score"] = timing_raw
            item["raw_score"] = long_raw
            item["market_regime"] = regime
            item["theme_label"] = _theme(item.get("name", ""))

            component_values = [
                scaled_components["expert"][index],
                scaled_components["linear"][index],
            ]
            if nonlinear_models:
                component_values.append(scaled_components["nonlinear"][index])
            if optional_predict is not None:
                component_values.append(scaled_components["external"][index])
            if tree2_predict is not None:
                component_values.append(scaled_components["tree2"][index])
            disagreement = statistics.pstdev(component_values) if len(component_values) > 1 else 0.0
            history_factor = (
                0.65 * min(1.0, _finite(item["stats"].get("history_years")) / 10.0)
                + 0.35 * _clamp(_finite(item["stats"].get("long_evidence_strength")), 0.0, 1.0)
            )
            evidence_factor, evidence_inputs = _model_evidence_factor(model, item)
            metadata_factor = 1.0 if item.get("fees_verified") is True else 0.92
            consistency = _clamp(
                0.58 + 0.32*history_factor - 0.35*disagreement, 0.25, 0.95
            )
            item["model_evidence_factor"] = round(100.0 * evidence_factor, 1)
            item["model_evidence_inputs"] = evidence_inputs
            item["model_consistency"] = round(
                100.0 * _clamp(consistency * evidence_factor * metadata_factor, 0.15, 0.95),
                0,
            )
            stability_map = model.get("development_top10_stability_by_code") or {}
            stability = _clamp(_finite(stability_map.get(str(item.get("code") or "")), 0.0), 0.0, 1.0)
            item["Top10SelectionStability"] = round(100.0 * stability, 1)

        long_ranks = _rank_scale([item["long_raw_score"] for item in usable])
        entry_ranks = _rank_scale([item["entry_raw_score"] for item in usable])
        blend = _clamp(_finite(model.get("long_term_blend"), 0.80), 0.65, 0.95)
        for item, long_pct, entry_pct in zip(usable, long_ranks, entry_ranks):
            item["LongTermQualityScore"] = round(100.0 * long_pct, 1)
            item["EntryTimingScore"] = round(100.0 * entry_pct, 1)
            item["long_term_quality_score"] = item["LongTermQualityScore"]
            item["entry_timing_score"] = item["EntryTimingScore"]
            item["score_blend"] = {"long_term":blend, "entry_timing":1.0-blend}
            item["raw_score"] = blend * (2.0*long_pct-1.0) + (1.0-blend) * (2.0*entry_pct-1.0)

        by_class = {}
        for item in usable:
            by_class.setdefault(item["asset_class"], []).append(item)
        for rows in by_class.values():
            percentiles = _rank_scale([row["raw_score"] for row in rows])
            for item, pct in zip(rows, percentiles):
                item["category_percentile"] = round(100.0 * pct, 0)

        overall = _rank_scale([item["raw_score"] for item in usable])
        for item, pct in zip(usable, overall):
            item["overall_percentile"] = round(100.0 * pct, 0)
            item["score"] = item["overall_percentile"]
            # Current purchasability/completeness affects today's Top10 only; historical OOS remains PIT/performance-only.
            if as_of_date is None:
                availability_confidence = _alipay_availability_confidence(item)
                integrity_score = _product_integrity_score(item)
                availability_adjustment = 0.78 + 0.22 * availability_confidence / 100.0
                integrity_adjustment = 0.90 + 0.10 * integrity_score / 100.0
            else:
                availability_confidence = 100
                integrity_score = 100.0
                availability_adjustment = 1.0
                integrity_adjustment = 1.0
            item["PurchaseEvidenceScore"] = availability_confidence
            item["AlipayAvailabilityConfidence"] = availability_confidence  # legacy cache compatibility; not a probability
            item["product_integrity_score"] = round(integrity_score, 1)
            item["availability_adjustment"] = round(availability_adjustment, 4)
            item["product_integrity_adjustment"] = round(integrity_adjustment, 4)
            item["final_ranking_utility"] = (
                _finite(item["overall_percentile"], 50.0) / 100.0
                * availability_adjustment
                * integrity_adjustment
            )
            stats = item["stats"]
            qscore = _finite(item.get("LongTermQualityScore"))
            item["long_term_quality"] = "优秀" if qscore >= 85 else "良好" if qscore >= 65 else "一般" if qscore >= 40 else "偏弱"
            six_month = stats.get("return_6m", 0.0)
            tscore = _finite(item.get("EntryTimingScore"))
            item["timing_view"] = "偏热" if six_month > 0.45 and tscore < 70 else "积极" if tscore >= 70 else "偏弱" if tscore < 30 else "中性"
            if qscore >= 85 and tscore >= 55 and not (six_month > 0.45 and tscore < 70):
                item["absolute_buy_rating"] = "长期核心持有"
            elif qscore >= 70 and tscore >= 45:
                item["absolute_buy_rating"] = "值得分批买入"
            elif six_month > 0.45 or (qscore >= 55 and tscore < 30):
                item["absolute_buy_rating"] = "当前偏贵/偏热"
            elif qscore >= 55 and tscore >= 35:
                item["absolute_buy_rating"] = "可观察"
            else:
                item["absolute_buy_rating"] = "仅为相对Top100，不建议现在买入"
            if as_of_date is None:
                pit_cov = _clamp(_finite(model.get("historical_universe_known_coverage"), 0.0), 0.0, 1.0)
                pit_windows = int(_finite((model.get("full_pipeline_oos") or {}).get("windows"), 0))
                if pit_cov < PIT_RATING_MIN_UNIVERSE_COVERAGE or pit_windows < PIT_RATING_MIN_OOS_WINDOWS:
                    item["absolute_buy_rating"] = "值得关注（PIT/OOS证据积累中）"
                    item["pit_rating_capped"] = True
            item["risk"] = self._risk_label(item)
            item["reason"] = self._reason(item)

        usable.sort(
            key=lambda item: (item.get("final_ranking_utility", 0.0), item["model_consistency"], item["raw_score"]),
            reverse=True,
        )
        return usable


    @staticmethod
    def _return_correlation(left: dict, right: dict, lookback: int = 504) -> float:
        ld, lr = left.get("dates") or [], left.get("returns") or []; rd, rr = right.get("dates") or [], right.get("returns") or []
        if len(ld) != len(lr) or len(rd) != len(rr): return 0.0
        lmap=dict(zip(ld[-lookback:],lr[-lookback:])); rmap=dict(zip(rd[-lookback:],rr[-lookback:])); common=sorted(set(lmap)&set(rmap))
        if len(common) < 126: return 0.0
        return _clamp(_pearson([lmap[d] for d in common],[rmap[d] for d in common]),-1.0,1.0)

    def select_portfolio(self, scored: list[dict], profile: str) -> list[dict]:
        self.last_constraint_error = ""
        if not scored:
            return []
        correlation_lambda = {"稳健":0.24,"均衡":0.17,"进取":0.11}.get(profile,0.17)
        max_asset = {"稳健":5,"均衡":6,"进取":7}.get(profile,6)
        selected=[]; theme_counts={}; company_counts={}; asset_counts={}; used_underlying=set()
        pool=[dict(item, ai_raw_rank=i+1) for i,item in enumerate(scored)]

        def allowed(item, relaxed=False):
            underlying=_underlying_key(item)
            if underlying in used_underlying: return False
            theme=str(item.get("theme") or item.get("theme_label") or _theme(item.get("name", "")))
            company=str(item.get("fund_company") or "").strip()
            asset=str(item.get("asset_bucket") or item.get("asset_class") or "其他")
            specific_theme=theme not in ("", "宽基/全市场", "其他")
            if not relaxed and specific_theme and theme_counts.get(theme,0)>=2: return False
            if not relaxed and company and company_counts.get(company,0)>=2: return False
            if not relaxed and asset_counts.get(asset,0)>=max_asset: return False
            return True

        while len(selected)<10:
            candidates=[]
            for item in pool:
                if not allowed(item,False) or any(x["code"]==item["code"] for x in selected): continue
                max_corr=max((max(0.0,self._return_correlation(item,x)) for x in selected),default=0.0)
                base=_finite(item.get("final_ranking_utility"), _finite(item.get("overall_percentile"),50.0)/100.0)
                objective=base-correlation_lambda*max_corr
                candidates.append((objective,base,-max_corr,-int(item.get("ai_raw_rank",9999)),item,max_corr))
            if not candidates:
                break
            _,_,_,_,item,max_corr=max(candidates,key=lambda x:x[:4])
            item=dict(item); item["portfolio_max_correlation"]=max_corr
            item["portfolio_selection_score"]=_finite(item.get("final_ranking_utility"), _finite(item.get("overall_percentile"))/100.0)-correlation_lambda*max_corr
            selected.append(item); used_underlying.add(_underlying_key(item))
            theme=str(item.get("theme") or item.get("theme_label") or _theme(item.get("name", "")))
            company=str(item.get("fund_company") or "").strip(); asset=str(item.get("asset_bucket") or item.get("asset_class") or "其他")
            theme_counts[theme]=theme_counts.get(theme,0)+1
            if company: company_counts[company]=company_counts.get(company,0)+1
            asset_counts[asset]=asset_counts.get(asset,0)+1
        if len(selected)<10:
            for item in pool:
                if len(selected)>=10: break
                if not allowed(item,True) or any(x["code"]==item["code"] for x in selected): continue
                clone=dict(item); clone["portfolio_max_correlation"]=max((max(0.0,self._return_correlation(clone,x)) for x in selected),default=0.0)
                selected.append(clone); used_underlying.add(_underlying_key(clone))
        if len(selected)<10:
            self.last_constraint_error=f"组合约束后仅选出 {len(selected)} 只不同底层基金"
        for rank,item in enumerate(selected,1): item["ranking_rank"]=rank
        return selected[:10]



    @staticmethod
    def _fixed_weight_portfolio_path(paths: list[dict]) -> tuple[float, list[float]]:
        clean_paths = []
        for path in paths:
            dates, returns = path.get("dates") or [], path.get("returns") or []
            if len(dates) == len(returns) and dates:
                clean_paths.append(dict(zip(dates, returns)))
        if not clean_paths:
            return 0.0, []
        calendar_dates = sorted(set().union(*(set(path) for path in clean_paths)))
        wealth = [1.0] * len(clean_paths)
        previous_nav = 1.0
        portfolio_returns = []
        for day in calendar_dates:
            for index, path in enumerate(clean_paths):
                if day in path:
                    wealth[index] *= max(0.01, 1.0 + _clamp(_finite(path[day]), -0.95, 3.0))
            nav = sum(wealth) / len(wealth)
            portfolio_returns.append(nav / max(previous_nav, 1e-12) - 1.0)
            previous_nav = nav
        return previous_nav - 1.0, portfolio_returns

    def _full_pipeline_oos(self, funds: list[dict], snapshots: list[dict], model: dict, profile: str = "均衡") -> dict:
        fund_map={f["code"]:f for f in funds}; rank_ics=[]; regime_ics=[]; excess=[]; dds=[]; sortinos=[]; corrs=[]; top_sets=[]; constraint_failures=[]
        for snap in snapshots:
            hist=[]; forward={}; all_forward=[]
            for code,end,future_end in zip(snap.get("codes",[]),snap.get("ends",[]),snap.get("future_ends",[])):
                fund=fund_map.get(code);
                if not fund: continue
                dates=fund.get("dates") or []; returns=fund.get("returns") or []
                final_index=bisect.bisect_right(dates,str(future_end)[:10])
                fwd=returns[end:final_index]; fwd_dates=dates[end:final_index]
                if len(fwd)<MIN_ONE_YEAR_OBSERVATIONS: continue
                feature_date=str(snap.get("feature_date") or "")[:10]
                pit_product,pit_fees,pit_fees_verified=self._pit_fields(fund,feature_date)
                clone={**fund,"returns":list(returns[:end]),"dates":list(dates[:end]),
                       "latest_date":feature_date,"availability_declared":True,"availability_declared_at":feature_date,
                       "product_features":pit_product,"fees":pit_fees,"fees_verified":pit_fees_verified}
                                                                                                    
                clone.pop("display_nav",None); clone.pop("display_nav_date",None)
                hist.append(clone); forward[code]={"dates":fwd_dates,"returns":fwd}; all_forward.append(forward[code])
            scored=self.score(hist,model,profile,{},as_of_date=str(snap.get("feature_date") or ""))
            chosen=self.select_portfolio(scored,profile)
            chosen=[x for x in chosen if x["code"] in forward]
            if len(chosen) != 10:
                constraint_failures.append(self.last_constraint_error or f"{snap.get('feature_date')} 未选满10只")
                continue
            pred={x["code"]:x["raw_score"] for x in scored}; target_map={c:t for c,t in zip(snap["codes"],snap["targets"])}; common=[c for c in pred if c in target_map]
            rank_ics.append(_spearman([pred[c] for c in common],[target_map[c] for c in common]) if len(common)>=3 else 0.0)
            regime_ics.append((str(snap.get("regime") or "unknown"), rank_ics[-1]))
            top_sets.append({x["code"] for x in chosen}); selected=[forward[x["code"]] for x in chosen]
            top_return,portfolio_daily=self._fixed_weight_portfolio_path(selected)
            bench,_bench_daily=self._fixed_weight_portfolio_path(all_forward); excess.append(top_return-bench)
            dds.append(abs(_max_drawdown(portfolio_daily))); rf=_risk_free_rate()/252; downside=math.sqrt(sum(min(0.0,r-rf)**2 for r in portfolio_daily)/max(1,len(portfolio_daily)))*math.sqrt(252)
            sortinos.append((sum(portfolio_daily)/max(1,len(portfolio_daily))*252-_risk_free_rate())/max(downside,0.01))
            pair=[]
            for i in range(len(chosen)):
                for j in range(i+1,len(chosen)): pair.append(max(0.0,self._return_correlation(chosen[i],chosen[j])))
            corrs.append(sum(pair)/len(pair) if pair else 0.0)
        turnovers=[1.0-len(a&b)/max(1,len(a|b)) for a,b in zip(top_sets,top_sets[1:])]; mean=lambda xs: sum(xs)/max(1,len(xs))
        ric=mean(rank_ics); ex=mean(excess); win=sum(v>0 for v in excess)/max(1,len(excess)); dd=max(dds) if dds else 0.0; so=mean(sortinos); turn=mean(turnovers); corr=mean(corrs)
        by_regime={}
        for regime,value in regime_ics: by_regime.setdefault(regime,[]).append(value)
        worst_regime=min((mean(values) for values in by_regime.values()), default=0.0)
        median_ric=statistics.median(rank_ics) if rank_ics else 0.0
        sorted_ric=sorted(rank_ics); p25=sorted_ric[max(0,int(0.25*(len(sorted_ric)-1)))] if sorted_ric else 0.0
        quality=0.24*median_ric+0.14*p25+0.12*ric+0.22*ex+0.10*(2*win-1)+0.07*_clamp(so/3.0,-1,1)-0.06*dd-0.03*turn-0.06*corr
        non_overlapping=all(str(left.get("target_end_date") or "") <= str(right.get("feature_date") or "") for left,right in zip(snapshots,snapshots[1:]))
        return {"windows":len(rank_ics),"rank_ic_mean":ric,"rank_ic_median":median_ric,"rank_ic_p25":p25,"rank_ic_positive_ratio":sum(v>0 for v in rank_ics)/max(1,len(rank_ics)),"rank_ic_worst":min(rank_ics) if rank_ics else 0.0,"rank_ic_values":list(rank_ics),"worst_regime_rank_ic":worst_regime,"top10_excess_return":ex,"oos_annual_excess_return":ex,"candidate_pool_equal_weight_win_rate":win,"candidate_pool_equal_weight_excess_return":ex,"top10_benchmark_win_rate":win,"benchmark_definition":"same-window eligible candidate-pool equal-weight buy-and-hold","max_oos_drawdown":dd,"oos_sortino":so,"turnover":turn,"portfolio_correlation":corr,"quality":quality,"portfolio_assumption":"initial-equal-weight-buy-and-hold","windows_non_overlapping":non_overlapping,"fold_purge_rule":"training labels mature before each evaluation feature date","constraint_failures":constraint_failures}

    @staticmethod
    def _risk_label(item: dict) -> str:
        volatility = item["stats"]["volatility"]
        coarse = _coarse_type(item["type"])
        if coarse == "债券" and volatility < 0.07:
            return "中低"
        if volatility < 0.10:
            return "中"
        if volatility < 0.20:
            return "中高"
        return "高"

    @staticmethod
    def _reason(item: dict) -> str:
        stats = item["stats"]
        strengths = []
        if stats["sharpe"] >= 1.0:
            strengths.append("风险调整收益较强")
        if stats["max_drawdown"] > -0.16:
            strengths.append("长期回撤较低")
        cost_5y = stats.get("transaction_cost_5y")
        if cost_5y is not None and cost_5y <= 0.06 and item.get("fees_verified"):
            strengths.append("长期额外交易成本较低")
        if stats["positive_months"] >= 0.60:
            strengths.append("月度胜率较稳")
        if stats["return_3y_ann"] >= 0.10:
            strengths.append("三年复利靠前")
        if stats["current_drawdown"] < -0.16:
            strengths.append("当前仍在回撤")
        if stats["return_6m"] > 0.50:
            strengths.append("近期涨幅偏热")
        if not strengths:
            strengths.append("多周期综合均衡")
        return "；".join(strengths[:2])


# ===== 分析引擎功能单元 =====

class AvailabilityResolver:
    """Own signed-Alipay resolution, fallback policy and short-lived availability caching."""
    def __init__(self, source, signed_source):
        self.source = source
        self.signed_source = signed_source
        self.cache: dict[str, dict] | None = None
        self.cache_at = 0.0

    def snapshot(self, force: bool = False) -> tuple[dict[str, dict], dict]:
        now_mono = time.monotonic()
        if not force and isinstance(self.cache, dict) and now_mono - self.cache_at < AVAILABILITY_REFRESH_SECONDS:
            return {code: dict(row) for code, row in self.cache.items()}, {"cached": True}
        try:
            snapshot = self.signed_source.snapshot()
            before = len(snapshot)
            if hasattr(self.source, "structural_prefilter"):
                snapshot = self.source.structural_prefilter(snapshot)
            if len(snapshot) < DISPLAY_TOP_N:
                raise DataError(f"支付宝签名可购池经结构筛选后仅 {len(snapshot)} 个具体份额，低于 Top {DISPLAY_TOP_N} 最低输出要求")
            state = {"mode": "signed-alipay", "error": "", "prefilter": {"before": before, "after": len(snapshot), "performance_blind": True}}
        except DataError as exc:
            if not hasattr(self.source, "public_fallback_universe"):
                raise
            snapshot = self.source.public_fallback_universe()
            state = {"mode": "public-market-fallback", "error": str(exc), "prefilter": {"before": None, "after": len(snapshot), "performance_blind": True}}
        self.cache = {code: dict(row) for code, row in snapshot.items()}
        self.cache_at = now_mono
        return snapshot, state


class HistoryRepository:
    """Small storage boundary so AnalysisEngine does not know SQLite/cache representation details."""
    def __init__(self, store):
        self.store = store

    def archive(self) -> dict[str, dict]:
        rows = self.store.cache.get("funds", {})
        return rows if isinstance(rows, dict) else {}

    def save_cache(self, dirty_codes: set[str] | None = None) -> None:
        self.store.save_cache(dirty_codes=dirty_codes)

    def save_model(self, model: dict) -> None:
        self.store.save_model(model)


class ModelTrainer:
    """Training entry point; deployment/coverage gates live inside AdaptiveRanker.train."""
    def __init__(self, ranker):
        self.ranker = ranker

    def train(self, funds: list[dict]) -> dict:
        return self.ranker.train(funds)


class PortfolioSelector:
    """Selection boundary. OOS keeps the original diversified Top10; the GUI exposes a de-duplicated Top100 ranking."""
    def __init__(self, ranker):
        self.ranker = ranker

    def select(self, scored: list[dict], profile: str) -> list[dict]:
        return self.ranker.select_portfolio(scored, profile)

    def select_top(self, scored: list[dict], profile: str, count: int = DISPLAY_TOP_N) -> list[dict]:
        count = max(1, int(count))
        selected = []
        used_underlying = set()
        for raw_rank, item in enumerate(scored, 1):
            if str(item.get("availability_status") or "") in PURCHASE_UNAVAILABLE_STATUSES:
                continue
            underlying = _underlying_key(item)
            if underlying in used_underlying:
                continue
            clone = dict(item)
            clone["ai_raw_rank"] = raw_rank
            clone["ranking_rank"] = len(selected) + 1
            clone["portfolio_max_correlation"] = 0.0
            clone["portfolio_selection_score"] = _finite(
                clone.get("final_ranking_utility"),
                _finite(clone.get("overall_percentile"), 50.0) / 100.0,
            )
            selected.append(clone)
            used_underlying.add(underlying)
            if len(selected) >= count:
                break
        return selected


class FreshnessGate:
    """Actual-session-aware NAV freshness checks; holiday heuristics remain fallback only."""
    @staticmethod
    def filter_latest(rows: dict[str, dict], today: _dt.date, max_sessions: int) -> dict[str, dict]:
        fresh = {}
        for code, row in (rows or {}).items():
            try:
                day = _dt.date.fromisoformat(str(row.get("nav_date") or "")[:10])
            except ValueError:
                continue
            nav = _finite(row.get("nav"), float("nan"))
            if math.isfinite(nav) and nav > 0 and _expected_market_sessions(day, today) <= max_sessions:
                fresh[code] = row
        return fresh


# ===== 分析引擎 =====

class AnalysisEngine:
    def __init__(self, source=None, availability=None, store=None):
            self.source = source or FundDataSource()
            self.availability = availability or AlipayAvailabilitySource()
            self.store = store or LocalStore()
            self.ranker = AdaptiveRanker()
            self.availability_resolver = AvailabilityResolver(self.source, self.availability)
            self.history_repository = HistoryRepository(self.store)
            self.model_trainer = ModelTrainer(self.ranker)
            self.portfolio_selector = PortfolioSelector(self.ranker)
            self.freshness_gate = FreshnessGate()
            self.funds: list[dict] = []
            self.market_funds: list[dict] = []
            self.feature_cache: dict[str, dict] = {}
            self.last_refresh_status = {}
            self.last_cross_check = {}
            self._cross_check_cache: dict[tuple[str,str], dict] = {}
            self.lock = threading.RLock()
            self._availability_cache = None
            self._availability_cache_at = 0.0
            self._last_full_nav_refresh_at = 0.0
            self.last_freshness_gate = {"ok": False, "reason": "尚未执行正式结果新鲜度门控"}

    def ensure_source_contract(self, progress=lambda *_: None) -> dict:
            if hasattr(self.source, "startup_contract_test"):
                return self.source.startup_contract_test(progress=progress)
            progress("数据源检查不可用，使用当前适配器", 100)
            return {"checked": False, "details": {}}


    def _availability_snapshot(self, force: bool = False) -> dict[str, dict]:
        snapshot, state = self.availability_resolver.snapshot(force=force)
        if not state.get("cached"):
            self.last_availability_mode = str(state.get("mode") or "")
            self.last_availability_error = str(state.get("error") or "")
            self.last_candidate_prefilter = dict(state.get("prefilter") or {})
        return {code: dict(row) for code, row in snapshot.items()}


    def cache_age_hours(self) -> float:
        stamp = _parse_iso(self.store.cache.get("updated_at"))
        if stamp is None:
            return float("inf")
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return max(0.0, (_dt.datetime.now().astimezone() - stamp).total_seconds() / 3600)

    def maintenance_status(self) -> dict:
        self.store.check_cache_integrity()
        current_model = self.store.model if isinstance(self.store.model, dict) else {}
        trained_at = _parse_iso(current_model.get("trained_at"))
        if trained_at is not None and trained_at.tzinfo is None:
            trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        age_days = float("inf") if trained_at is None else max(0.0, (_dt.datetime.now().astimezone() - trained_at).total_seconds() / 86400.0)
        availability = self._availability_snapshot(force=True)
        old_codes = set(current_model.get("availability_codes") or [])
        new_codes = set(availability)
        change_ratio = (len(old_codes ^ new_codes) / max(1, len(old_codes | new_codes))) if old_codes else 1.0
        force_reason = str(current_model.get("force_retrain_reason") or "")
        due_age = age_days >= MODEL_RETRAIN_DAYS
        due_universe = change_ratio >= MODEL_UNIVERSE_CHANGE_THRESHOLD
        due = bool(force_reason or due_age or due_universe or current_model.get("version") != MODEL_VERSION)
        if due_universe and not force_reason:
            current_model["force_retrain_reason"] = "maintenance-availability-change"
        reason = force_reason or ("model-age" if due_age else "availability-change" if due_universe else "schema-version" if current_model.get("version") != MODEL_VERSION else "not-due")
        return {
            "due": due, "reason": reason, "model_age_days": age_days,
            "availability_change_ratio": change_ratio, "availability_count": len(new_codes),
            "checked_at": _now_iso(),
        }

    def load_cached(self) -> bool:
        """Restore the last locally valid ranking without requiring an online availability request."""
        self.last_freshness_gate = {"ok": False, "reason": "本地上次有效结果；尚未完成本次启动的在线新鲜度复核"}
        self.last_availability_mode = "cached-last-known"
        archive = self.history_repository.archive()
        active = []
        market_cached = []

        for code, item in archive.items():
            if not isinstance(item, dict):
                continue
            returns, dates = item.get("returns") or [], item.get("dates") or []
            if (
                item.get("training_representative") is True
                and len(returns) >= MIN_HISTORY_POINTS
                and len(returns) == len(dates)
            ):
                market_cached.append({"code": code, **item})

        for code, item in archive.items():
            if not isinstance(item, dict) or item.get("ranking_candidate") is not True:
                continue
            returns, dates = item.get("returns") or [], item.get("dates") or []
            if len(returns) < MIN_HISTORY_POINTS or len(returns) != len(dates):
                continue
            if not self._history_recent_enough(item, max_days=5):
                continue
            active.append({"code": code, **item})

        with self.lock:
            self.funds = active
            self.market_funds = market_cached or active
            self.feature_cache.clear()
        cache_age_seconds = self.cache_age_hours() * 3600.0
        if math.isfinite(cache_age_seconds):
            self._last_full_nav_refresh_at = time.monotonic() - max(0.0, cache_age_seconds)
        eligible_underlying = {
            _underlying_key(item) for item in active
            if str(item.get("availability_status") or "") not in PURCHASE_UNAVAILABLE_STATUSES
        }
        return len(eligible_underlying) >= DISPLAY_TOP_N


    @staticmethod
    def _history_fresh(item: dict) -> bool:
        stamp = _parse_iso(item.get("updated_at"))
        if stamp is None:
            return False
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        return (_dt.datetime.now().astimezone() - stamp).total_seconds() < 14 * 3600

    @staticmethod
    def _history_recent_enough(item: dict, max_days: int = 5) -> bool:
        try:
            latest = _dt.date.fromisoformat(str(item.get("latest_date") or "")[:10])
        except ValueError:
            return False
                                                                                                  
                                                                                                   
                                         
        return _expected_market_sessions(latest, _china_today()) <= max_days

    @staticmethod
    def _cache_item(item: dict) -> dict:
        keys = (
            "name","type","dates","returns","latest_nav","latest_date","updated_at","day_change",
            "availability_declared","availability_status","availability_note","fund_data_source",
            "availability_declared_at","availability_generated_at","availability_expires_at",
            "availability_sequence","availability_signature_alg","availability_source",
            "availability_source_id","availability_evidence","availability_schema_version",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete",
            "fee_field_verified","annual_cost","embedded_annual_cost","purchase_cost",
            "transaction_cost_3y","transaction_cost_5y","transaction_cost_10y",
            "total_share_class_cost_3y","total_share_class_cost_5y","total_share_class_cost_10y",
            "holding_cost_3y","holding_cost_5y","holding_cost_10y","available_from","available_to",
            "availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status","underlying_fund_id","master_code",
            "primary_code","inception_date","termination_date","merged_into","catalog_active",
            "catalog_first_seen","catalog_last_seen","metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","return_pending_adjustment","return_basis",
            "return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
            "ranking_candidate","training_representative","representative_history_code",
            "share_specific_history","share_history_truncated_at_inception","return_basis","return_basis_label","catalog_history",
        )
        return {key: item.get(key) for key in keys}


    @staticmethod
    def _normalized_spans(history) -> list[dict]:
        out, seen = [], set()
        if not isinstance(history, list):
            return out
        for span in history:
            if not isinstance(span, dict):
                continue
            start = str(span.get("from") or "")[:10]
            finish = str(span.get("to") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", start):
                continue
            key = (start, finish, bool(span.get("purchasable", True)))
            if key in seen:
                continue
            seen.add(key)
            out.append({**span, "from": start, "to": finish, "purchasable": span.get("purchasable", True) is True})
        out.sort(key=lambda x: (x["from"], x.get("to") or "9999-99-99"))
        return out

    @classmethod
    def _merge_observed_availability(cls, declared: dict, cached: dict | None) -> list[dict]:
                                                                                                    
                                                                                                
        source_history = cls._normalized_spans(declared.get("availability_history"))
        cached_history = cls._normalized_spans((cached or {}).get("availability_history"))
        history = source_history or cached_history
        if declared.get("availability_declared") is not True:
            return history
        observed = str(declared.get("availability_generated_at") or declared.get("availability_declared_at") or "")[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            return history
        for span in history:
            finish = span.get("to") or "9999-99-99"
            if span.get("purchasable") is True and span.get("from", "") <= observed <= finish:
                return history
        history.append({"from": observed, "to": "", "purchasable": True, "evidence": "observed-signed-manifest"})
        history.sort(key=lambda x: x.get("from", ""))
        return history

    @classmethod
    def _close_observed_availability(cls, cached: dict, observed: str) -> dict:
        result = dict(cached)
        history = cls._normalized_spans(result.get("availability_history"))
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            try:
                previous_day = (_dt.date.fromisoformat(observed) - _dt.timedelta(days=1)).isoformat()
            except ValueError:
                previous_day = observed
            for span in reversed(history):
                if span.get("purchasable") is True and not span.get("to"):
                    if span.get("from", "") <= previous_day:
                        span["to"] = previous_day
                    else:
                        history.remove(span)
                    break
        result["availability_history"] = history
        result["availability_declared"] = False
        return result

    @staticmethod
    def _unknown_market_declaration(meta: dict) -> dict:
        return {
            "availability_declared": False, "availability_status": "unknown",
            "availability_declared_at": "", "availability_generated_at": _now_iso(),
            "availability_expires_at": "", "availability_sequence": 0,
            "availability_signature_alg": "", "availability_source": "东方财富公开基金全集（非支付宝）",
            "availability_source_id": "eastmoney-public-market",
            "availability_evidence": "仅用于全市场模型训练；支付宝状态未知",
            "availability_note": "支付宝可购状态未知（仅在今天的最终候选过滤阶段处理）",
            "availability_schema_version": 0, "fund_data_source": "东方财富基金公开清单/历史净值",
            "fees_verified": False, "fees": {}, "fees_history": [],
            "available_from": "", "available_to": "", "availability_history": [],
            "share_class": "", "product_features": {}, "product_features_history": [],
            "benchmark": "", "index_code": "", "fund_company": "", "theme": "",
            **_holding_costs({}),
        }

    @staticmethod
    def _retained_training_pool(current_market: list[dict], archive: dict) -> list[dict]:
        output = {str(item.get("code") or ""): item for item in current_market}
        for code, cached in (archive or {}).items():
            if code in output or not isinstance(cached, dict):
                continue
            if cached.get("training_representative") is not True and cached.get("catalog_active") is not False:
                continue
            dates, returns = cached.get("dates") or [], cached.get("returns") or []
            if len(returns) < MIN_HISTORY_POINTS or len(dates) != len(returns):
                continue
            output[code] = {"code": code, **cached, "catalog_active": False}
        return list(output.values())


    @staticmethod
    def _classify_public_purchase_status(status_text: str, termination_date: str = "") -> str:
        text = re.sub(r"\s+", "", str(status_text or ""))
        if termination_date or any(word in text for word in ("基金清盘", "清盘", "终止运作", "基金终止")):
            return "closed"
        # Must be checked before "暂停申购" because it contains that substring.
        if any(word in text for word in ("暂停大额申购", "限制大额申购", "大额申购上限", "限购")):
            return "limited_purchasable"
        if any(word in text for word in ("暂停申购", "终止申购")):
            return "purchase_suspended"
        if any(word in text for word in ("封闭期", "暂停交易")):
            return "closed"
        if "暂停赎回" in text:
            return "redemption_suspended"
        if any(word in text for word in ("开放申购", "可申购", "开放")):
            return "public_open"
        return "unknown"

    @staticmethod
    def _public_status_note(status: str) -> str:
        return {
            "limited_purchasable": "平台公开证据：仍可小额申购但存在限购；保留候选并轻度降权（非支付宝官方确认）",
            "purchase_suspended": "平台公开证据：暂停/终止申购；从当前买入候选中排除",
            "redemption_suspended": "平台公开证据：赎回受限；不等同于暂停申购，保留候选并提示退出限制",
            "closed": "平台公开证据：封闭/终止/清盘；从当前买入候选中排除",
            "public_open": "公开可购证据：公开渠道显示开放申购（非支付宝官方确认；EvidenceScore非概率）",
            "unknown": "支付宝状态未知；公开证据不足，不冒充支付宝确认",
        }.get(status, "支付宝状态未知；公开证据不足")

    @staticmethod
    def _apply_share_history_semantics(item: dict) -> dict:
        """Never present representative history as independent A/C/I share-class history."""
        rep_code = str(item.get("representative_history_code") or item.get("code") or "")
        code = str(item.get("code") or "")
        dates = list(item.get("dates") or [])
        returns = list(item.get("returns") or [])
        if len(dates) != len(returns):
            return item
        inherited = bool(rep_code and code and rep_code != code)
        item["share_specific_history"] = not inherited
        item["return_basis"] = "underlying_fund_history" if inherited else "share_class_history"
        item["return_basis_label"] = "底层基金历史（非该份额独立历史）" if inherited else "该份额公开历史"
        inception = str(item.get("inception_date") or "")[:10]
        if inherited and re.fullmatch(r"\d{4}-\d{2}-\d{2}", inception) and dates:
            cut = bisect.bisect_left(dates, inception)
            if cut > 0 and cut < len(dates):
                item["dates"] = dates[cut:]
                item["returns"] = returns[cut:]
                item["share_history_truncated_at_inception"] = inception
        return item


    @staticmethod
    def _append_effective_history(item: dict, key: str, values: dict, effective_date: str) -> None:
        if not isinstance(values, dict) or not values or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(effective_date)[:10]):
            return
        history_key = f"{key}_history"
        history = [row for row in (item.get(history_key) or []) if isinstance(row, dict)]
        day = str(effective_date)[:10]
        payload = {"effective_date": day, key: dict(values)}
        history = [row for row in history if str(row.get("effective_date") or row.get("date") or "")[:10] != day]
        history.append(payload); history.sort(key=lambda row: str(row.get("effective_date") or row.get("date") or "")[:10])
        item[history_key] = history[-40:]

    def _enrich_structural_metadata(self, active: list[dict], model: dict, progress=lambda *_: None) -> None:
        if not active or not hasattr(self.source, "metadata_many"):
            model["public_metadata_coverage"] = 0.0
            return
        prelim = self.ranker.score(active, model, "均衡", {}, holding_years=5)
        # Avoid two-stage truncation bias: Top100 gets a >=400-underlying safety band before
        # fee/company/index metadata can affect final scores and share-class selection.
        enrich_limit = max(DISPLAY_TOP_N + 400, _adaptive_limit("metadata_enrich_candidates", METADATA_ENRICH_CANDIDATES, DISPLAY_TOP_N + 400))
        selected_underlyings = {
            _underlying_key(item) for item in prelim[:min(len(prelim), enrich_limit)]
        }
        targets = {
            item["code"] for item in active
            if _underlying_key(item) in selected_underlyings
        }
        lookup = {item["code"]: item for item in active}
        pending = []
        for code in sorted(targets):
            item = lookup.get(code)
            if not item:
                continue
            asset_class = _asset_bucket(item.get("name", ""), item.get("type", ""))
            metadata_complete = (
                bool(item.get("fund_company"))
                and (asset_class != "指数" or bool(item.get("index_code")))
                and bool(item.get("product_features"))
                and item.get("fees_verified") is True
            )
            if metadata_complete and _age_seconds(item.get("metadata_checked_at")) < 90 * 86400:
                continue
            pending.append(item)
        if pending:
            progress(
                f"补齐 Top100+安全带候选区 {len(pending)} 个具体份额的公司/指数/主题/完整费率",
                89,
            )
            metadata = self.source.metadata_many(pending)
            for code, values in metadata.items():
                item = lookup.get(code)
                if not item or not isinstance(values, dict):
                    continue
                for field in (
                    "fund_company", "benchmark", "index_code", "theme", "inception_date",
                    "termination_date", "public_purchase_status", "public_purchase_status_secondary", "fund_manager", "product_features", "metadata_source", "metadata_checked_at",
                    "availability_public_signals", "availability_public_confirmations", "metadata_sources",
                ):
                    if values.get(field):
                        item[field] = values[field]
                for field in (
                    "fees", "fees_verified", "fees_source", "fee_schedule_complete",
                    "fee_field_verified", "annual_cost", "embedded_annual_cost",
                    "purchase_cost", "transaction_cost_3y", "transaction_cost_5y", "transaction_cost_10y",
                    "total_share_class_cost_3y", "total_share_class_cost_5y", "total_share_class_cost_10y",
                    "holding_cost_3y", "holding_cost_5y", "holding_cost_10y",
                ):
                    if field in values:
                        item[field] = values[field]
                effective_date = str(values.get("metadata_checked_at") or _now_iso())[:10]
                features_now = dict(item.get("product_features") or {})
                try:
                    current_day = _dt.date.fromisoformat(effective_date)
                    cutoff = (current_day - _dt.timedelta(days=TARGET_THREE_YEAR_DAYS)).isoformat()
                except ValueError:
                    cutoff = ""
                historical_feature_rows = [row for row in (item.get("product_features_history") or []) if isinstance(row, dict)]
                dated_rows = []
                for row in historical_feature_rows:
                    day = str(row.get("effective_date") or row.get("date") or "")[:10]
                    vals = row.get("product_features") if isinstance(row.get("product_features"), dict) else {}
                    if cutoff and cutoff <= day < effective_date:
                        dated_rows.append((day, vals))
                earliest_known = min((str(row.get("effective_date") or row.get("date") or "")[:10] for row in historical_feature_rows), default="")
                if cutoff and earliest_known and earliest_known <= (current_day - _dt.timedelta(days=1000)).isoformat():
                    manager_sequence = [str(vals.get("manager_name") or "").strip() for _, vals in sorted(dated_rows)]
                    manager_sequence.append(str(features_now.get("manager_name") or "").strip())
                    manager_sequence = [name for name in manager_sequence if name]
                    if len(manager_sequence) >= 2:
                        changes = sum(a != b for a,b in zip(manager_sequence, manager_sequence[1:]))
                        features_now["manager_changes_3y"] = float(changes)
                    style_sequence = [str(vals.get("style_label") or "").strip() for _, vals in sorted(dated_rows)]
                    style_sequence.append(str(features_now.get("style_label") or "").strip())
                    style_sequence = [label for label in style_sequence if label]
                    if len(style_sequence) >= 2:
                        changes = sum(a != b for a,b in zip(style_sequence, style_sequence[1:]))
                        features_now["style_drift"] = changes / max(1, len(style_sequence)-1)
                item["product_features"] = features_now
                self._append_effective_history(item, "product_features", features_now, effective_date)
                if item.get("fees_verified") is True:
                    self._append_effective_history(item, "fees", item.get("fees") or {}, effective_date)
                status_text = str(item.get("public_purchase_status") or "")
                if item.get("availability_status") not in {"confirmed_purchasable", "closed"}:
                    classified = self._classify_public_purchase_status(status_text, str(item.get("termination_date") or ""))
                    item["availability_status"] = classified
                    signals = _public_availability_signals(item)
                    item["availability_public_signals"] = sorted(signals)
                    item["availability_public_confirmations"] = len(signals)
                    item["availability_note"] = self._public_status_note(classified)
                    self._apply_share_history_semantics(item)
        considered = [lookup[code] for code in targets if code in lookup]
        for item in considered:
            status_text = str(item.get("public_purchase_status") or "")
            if item.get("availability_status") not in {"confirmed_purchasable", "closed"}:
                classified = self._classify_public_purchase_status(status_text, str(item.get("termination_date") or ""))
                item["availability_status"] = classified
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
                item["availability_public_confirmations"] = len(signals)
                item["availability_note"] = self._public_status_note(classified)
                self._apply_share_history_semantics(item)
        complete = sum(
            bool(item.get("fund_company"))
            and (
                _asset_bucket(item.get("name", ""), item.get("type", "")) != "指数"
                or bool(item.get("index_code"))
            )
            for item in considered
        )
        model["public_metadata_coverage"] = complete / max(1, len(considered))
        model["metadata_enriched_candidates"] = len(considered)


    @staticmethod
    def _observe_catalog_history(cached: dict, active: bool, observed: str) -> list[dict]:
        history = [dict(row) for row in (cached.get("catalog_history") or []) if isinstance(row, dict)]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", observed):
            return history
        if history and history[-1].get("active") is active and not history[-1].get("to"):
            history[-1]["last_observed"] = observed
            return history[-80:]
        if history and not history[-1].get("to"):
            try:
                history[-1]["to"] = (_dt.date.fromisoformat(observed) - _dt.timedelta(days=1)).isoformat()
            except ValueError:
                history[-1]["to"] = observed
        history.append({"from": observed, "to": "", "last_observed": observed, "active": bool(active)})
        return history[-80:]

    def _persist_current(self) -> None:
        archive = dict(self.history_repository.archive())
        current_codes = {item["code"] for item in self.funds}
        observed_dates = [
            str(
                item.get("availability_generated_at")
                or item.get("availability_declared_at")
                or ""
            )[:10]
            for item in self.funds
        ]
        observed_dates = [
            value
            for value in observed_dates
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value)
        ]
        observed = max(observed_dates, default=_china_today().isoformat())
        signed_observation = any(
            item.get("availability_declared") is True for item in self.funds
        )

        for code, cached in list(archive.items()):
            if not isinstance(cached, dict):
                continue
            cached["ranking_candidate"] = False
            cached["training_representative"] = False
            if signed_observation and code not in current_codes:
                archive[code] = self._close_observed_availability(
                    cached, observed
                )

        for item in self.market_funds or []:
            cached = (
                archive.get(item["code"])
                if isinstance(archive.get(item["code"]), dict)
                else {}
            )
            merged = dict(item)
            merged["catalog_history"] = self._observe_catalog_history(cached, item.get("catalog_active") is not False, observed)
            merged["training_representative"] = True
            merged["ranking_candidate"] = False
            if signed_observation and item["code"] not in current_codes:
                closed = self._close_observed_availability(cached, observed)
                merged["availability_history"] = (
                    closed.get("availability_history") or []
                )
                merged["availability_declared"] = False
                merged["availability_status"] = "unknown"
            else:
                merged["availability_history"] = self._merge_observed_availability(
                    merged, cached
                )
            archive[item["code"]] = self._cache_item(merged)

        for item in self.funds:
            cached = (
                archive.get(item["code"])
                if isinstance(archive.get(item["code"]), dict)
                else {}
            )
            merged = dict(item)
            merged["catalog_history"] = self._observe_catalog_history(cached, item.get("catalog_active") is not False, observed)
            merged["ranking_candidate"] = True
            merged["training_representative"] = bool(
                cached.get("training_representative")
            )
            merged["availability_history"] = self._merge_observed_availability(
                merged, cached
            )
            archive[item["code"]] = self._cache_item(merged)

        master = dict(self.store.cache.get("fund_master", {}))
        for code, item in archive.items():
            if not isinstance(item, dict):
                continue
            previous = master.get(code) if isinstance(master.get(code), dict) else {}
            master[code] = {
                "code": code,
                "name": item.get("name"),
                "type": item.get("type"),
                "underlying_fund_id": (
                    item.get("underlying_fund_id")
                    or _underlying_key({"code": code, **item})
                ),
                "inception_date": (
                    item.get("inception_date")
                    or ((item.get("dates") or [""])[0])
                ),
                "termination_date": item.get("termination_date") or "",
                "merged_into": item.get("merged_into") or "",
                "catalog_first_seen": (
                    previous.get("catalog_first_seen")
                    or item.get("catalog_first_seen")
                    or _china_today().isoformat()
                ),
                "catalog_last_seen": (
                    item.get("catalog_last_seen")
                    or previous.get("catalog_last_seen")
                    or ""
                ),
                "catalog_active": item.get("catalog_active") is True,
            }

        self.store.cache = {
            "version": CACHE_VERSION,
            "updated_at": _now_iso(),
            "funds": archive,
            "fund_master": master,
        }
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        self.history_repository.save_cache()


    @staticmethod
    def _quick_start_representatives(representatives: list[dict], limit: int | None = None) -> list[dict]:
        """Performance-blind deterministic stratified sample for the first visible Top10."""
        if limit is None:
            limit = _adaptive_limit("quick_start_representatives", QUICK_START_REPRESENTATIVES, 32)
        limit = max(1, int(limit))
        if len(representatives) <= limit:
            return list(representatives)
        buckets = {}
        for item in representatives:
            buckets.setdefault(str(item.get("asset_class") or "其他"), []).append(item)
        for rows in buckets.values():
            rows.sort(key=lambda item: hashlib.sha256(str(item.get("code") or "").encode("utf-8")).hexdigest())
        labels = sorted(buckets)
        chosen = []
        cursor = 0
        while len(chosen) < limit and labels:
            label = labels[cursor % len(labels)]
            rows = buckets[label]
            if rows:
                chosen.append(rows.pop(0))
            if not rows:
                labels.remove(label)
                cursor = 0
            else:
                cursor += 1
        return chosen

    def _refresh_history_pool(self, representatives: list[dict], existing: dict[str, dict], progress, quick_callback=None, quick_profile: str = "均衡", quick_holding_years: int = 5):
        completed, total, results, historical_results, failures = 0, len(representatives), [], [], []
        dirty_checkpoint_codes: set[str] = set()

        def checkpoint_history():
            if not dirty_checkpoint_codes or _cancel_requested():
                return
            codes = set(dirty_checkpoint_codes)
            latest_rows = {row["code"]: row for row in historical_results if row.get("code") in codes}
            cache_funds = dict(self.history_repository.archive())
            for code, row in latest_rows.items():
                merged = dict(cache_funds.get(code) or {})
                merged.update(row); merged["training_representative"] = True
                cache_funds[code] = self._cache_item(merged)
            self.store.cache["funds"] = cache_funds
            self.store.cache["version"] = CACHE_VERSION
            self.store.cache["updated_at"] = _now_iso()
            self.history_repository.save_cache(dirty_codes=codes)
            dirty_checkpoint_codes.difference_update(codes)

        def load_one(candidate):
            cached = existing.get(candidate["code"])
            cached_usable = (
                isinstance(cached, dict)
                and len(cached.get("returns") or []) >= MIN_HISTORY_POINTS
                and len(cached.get("returns") or []) == len(cached.get("dates") or [])
            )
            if cached_usable:
                history = (
                    self.source.update_history(candidate["code"], cached)
                    if hasattr(self.source, "update_history")
                    else {
                        "dates": cached["dates"], "returns": cached["returns"],
                        "latest_nav": cached.get("latest_nav"), "latest_date": cached.get("latest_date", ""),
                    }
                )
            else:
                history = self.source.history(candidate["code"])
            item = {**candidate, **history, "updated_at": _now_iso()}
            item["inception_date"] = item.get("inception_date") or ((item.get("dates") or [""])[0])
            item["underlying_fund_id"] = item.get("underlying_fund_id") or _underlying_key(item)
            return item

        history_worker_cap = _adaptive_worker_count("history", 6)
        initial_workers = min(history_worker_cap, max(2, (os.cpu_count() or 4) // 2 + 1))

        def download_batch(batch: list[dict], phase_start: float, phase_span: float, label: str) -> None:
            nonlocal completed
            if not batch:
                return
            workers = initial_workers
            batch_done = 0
            cursor = 0
            while cursor < len(batch):
                if _cancel_requested():
                    raise concurrent.futures.CancelledError("程序正在退出")
                wave_size = min(len(batch) - cursor, max(24, workers * 8))
                wave = batch[cursor:cursor + wave_size]
                cursor += wave_size
                wave_success = wave_fail = 0
                with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="fund-data") as executor:
                    future_map = {executor.submit(load_one, candidate): candidate for candidate in wave}
                    for future in concurrent.futures.as_completed(future_map):
                        candidate = future_map[future]
                        completed += 1; batch_done += 1
                        try:
                            item = future.result()
                            if len(item.get("returns") or []) >= MIN_HISTORY_POINTS:
                                if self._history_recent_enough(item, max_days=5):
                                    historical_results.append(item); results.append(item); dirty_checkpoint_codes.add(item["code"]); wave_success += 1
                                else:
                                    inactive = dict(item)
                                    inactive["catalog_active"] = False
                                    inactive["termination_date"] = inactive.get("termination_date") or str(inactive.get("latest_date") or "")[:10]
                                    inactive["ranking_candidate"] = False
                                    historical_results.append(inactive); dirty_checkpoint_codes.add(inactive["code"]); wave_success += 1
                            else:
                                wave_fail += 1
                        except Exception as exc:
                            wave_fail += 1
                            failures.append((candidate["code"], str(exc)))
                        if completed % HISTORY_CHECKPOINT_BATCH == 0:
                            checkpoint_history()
                        progress(f"{label} {batch_done}/{len(batch)} · 全部 {completed}/{total} · 有效 {len(results)} · 并发{workers}", phase_start + phase_span * batch_done / max(1, len(batch)))
                ratio = wave_success / max(1, wave_success + wave_fail)
                if ratio >= 0.94 and workers < history_worker_cap:
                    workers = min(history_worker_cap, workers + 2)
                elif ratio < 0.78 and workers > 2:
                    workers = max(2, workers // 2)
                checkpoint_history()

        quick_representatives = self._quick_start_representatives(representatives)
        quick_codes = {item["code"] for item in quick_representatives}
        remaining_representatives = [item for item in representatives if item["code"] not in quick_codes]
        download_batch(quick_representatives, 8, 25, "阶段1结构盲选历史")

        if callable(quick_callback) and len(results) >= 10:
            try:
                quick_model = self.store.model if self.store.model.get("version") == MODEL_VERSION else LocalStore.default_model()
                quick_scored = self.ranker.score(results, quick_model, quick_profile, {}, holding_years=quick_holding_years)
                quick_top = self.portfolio_selector.select(quick_scored, quick_profile)
                if len(quick_top) >= 10:
                    for item in quick_top:
                        item["preliminary_phase1"] = True
                        item["absolute_buy_rating"] = "分析中/预览候选"
                        item["formal_result"] = False
                    quick_callback(quick_top[:10])
                    progress("首版候选预览已显示；继续补齐全量历史、元数据与 OOS 排名训练", 34)
            except Exception as exc:
                _record_diagnostic("quick-preview", exc)

        download_batch(remaining_representatives, 35, 31, "阶段2全量代表历史")
        if len(results) < 25:
            if self.load_cached():
                raise DataError("本次底层代表历史更新失败，已保留上次可用结果")
            raise DataError(f"有效历史数据仅 {len(results)} 个底层代表，无法可靠训练")
        training_pool = self._retained_training_pool(historical_results or results, existing)
        return results, historical_results, training_pool, quick_representatives, failures

    def _decide_model_retrain(self, current_model: dict, training_pool: list[dict], force: bool = False) -> tuple[bool, float, float, str]:
        trained_at = _parse_iso(current_model.get("trained_at"))
        if trained_at is not None and trained_at.tzinfo is None:
            trained_at = trained_at.replace(tzinfo=_dt.datetime.now().astimezone().tzinfo)
        model_age_days = float("inf") if trained_at is None else max(0.0, (_dt.datetime.now().astimezone() - trained_at).total_seconds() / 86400.0)
        old_codes = set(current_model.get("universe_codes") or [])
        new_codes = {item["code"] for item in training_pool if item.get("code")}
        change_ratio = len(old_codes ^ new_codes) / max(1, len(old_codes | new_codes)) if old_codes else 1.0
        auto_update_model = _model_auto_update_enabled()
        force_reason = str(current_model.get("force_retrain_reason") or "")
        should = bool(force or force_reason or trained_at is None or current_model.get("version") != MODEL_VERSION or (auto_update_model and (model_age_days >= MODEL_RETRAIN_DAYS or change_ratio >= 0.05)))
        reason = "manual-force" if force else force_reason or ("never-trained" if trained_at is None else "schema-version" if current_model.get("version") != MODEL_VERSION else "age-or-universe-change" if should else "not-due")
        return should, model_age_days, change_ratio, reason

    def _build_candidate_universe(self, availability: dict[str, dict], existing: dict[str, dict]) -> list[dict]:
        if getattr(self, "last_availability_mode", "") == "public-market-fallback":
            market_rows = [
                {"code": code, "name": row.get("name") or code, "type": row.get("type") or "其他"}
                for code, row in availability.items()
            ]
        else:
            market_rows = self.source.all_funds()
        market = {item["code"]: item for item in market_rows}
        for code, declared in availability.items():
            market.setdefault(code, {"code": code, "name": declared.get("name") or code, "type": declared.get("type") or "其他"})

        today_text = _china_today().isoformat()
        structural_fields = (
            "benchmark", "index_code", "fund_company", "fund_manager", "theme", "underlying_fund_id",
            "master_code", "primary_code", "inception_date", "termination_date", "merged_into",
            "metadata_source", "metadata_checked_at", "product_features", "product_features_history", "fees_history",
        )
        all_candidates = []
        for code, meta in market.items():
            declared = availability.get(code)
            cached = existing.get(code) if isinstance(existing.get(code), dict) else {}
            name = (declared or {}).get("name") or meta.get("name") or cached.get("name") or code
            fund_type = (declared or {}).get("type") or meta.get("type") or cached.get("type") or "其他"
            if not _candidate_allowed(name, fund_type):
                continue
            cached_termination = str(cached.get("termination_date") or "")[:10]
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", cached_termination) and cached_termination <= today_text:
                continue
            cached_inception = str(cached.get("inception_date") or "")[:10]
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", cached_inception):
                try:
                    if (_china_today() - _dt.date.fromisoformat(cached_inception)).days < 1040:
                        continue
                except ValueError:
                    pass
            base = {**meta, **self._unknown_market_declaration(meta), "code": code, "name": name, "type": fund_type}
            for field in structural_fields:
                if cached.get(field):
                    base[field] = cached[field]
            if declared:
                base.update(self._availability_fields(declared))
                base["name"], base["type"] = name, fund_type
                base["availability_history"] = self._merge_observed_availability(declared, cached)
            else:
                base["availability_history"] = self._normalized_spans(cached.get("availability_history"))
            base["catalog_active"] = True
            base["catalog_first_seen"] = cached.get("catalog_first_seen") or today_text
            base["catalog_last_seen"] = today_text
            base["asset_class"] = _asset_bucket(name, fund_type)
            base["wrapper"] = _wrapper_type(fund_type)
            all_candidates.append(base)
        if len(all_candidates) < 25:
            raise DataError(f"公开全市场中符合结构条件的具体份额仅 {len(all_candidates)} 个，样本不足")
        return all_candidates

    def _persist_results(self, model: dict, training_pool: list[dict], active_results: list[dict]) -> None:
        if _cancel_requested():
            raise concurrent.futures.CancelledError("程序正在退出")
        with self.lock:
            self.market_funds = training_pool
            self.funds = active_results
            self.feature_cache.clear()
            self.history_repository.save_model(model)
            self._persist_current()

    def retrain_model_from_current_history(self, progress=lambda *_: None, reason: str = "advanced-ai-became-ready") -> dict:
        """Retrain only the model from the already-loaded history; no network refresh and no user action."""
        with self.lock:
            training_pool = [dict(item) for item in (self.market_funds or []) if isinstance(item, dict)]
            if len(training_pool) < 25:
                archive = self.history_repository.archive()
                training_pool = [
                    {"code": code, **item} for code, item in archive.items()
                    if isinstance(item, dict) and item.get("training_representative") is True
                    and len(item.get("returns") or []) >= MIN_HISTORY_POINTS
                    and len(item.get("returns") or []) == len(item.get("dates") or [])
                ]
        if len(training_pool) < 25:
            raise DataError(f"本地成熟历史仅 {len(training_pool)} 个底层代表，暂不足以执行高级 AI 自动补训")
        progress("高级 AI 依赖已就绪；使用本轮已缓存历史自动补训，不重复下载净值", 72)
        old_model = self.store.model
        training_dependency_dir = _active_dependency_dir()
        model = self.model_trainer.train(training_pool)
        model["training_dependency_dir"] = training_dependency_dir.name if training_dependency_dir is not None else ""
        for key in ("full_market_scanned_shares", "representative_history_downloads", "quick_start_representatives", "retained_inactive_funds", "survivorship_bias", "survivorship_mitigation", "survivorship_note"):
            if key in old_model and key not in model:
                model[key] = old_model[key]
        model["auto_update_model"] = _model_auto_update_enabled()
        model["automatic_retrain_reason"] = reason
        model["advanced_dependency_retrain_at"] = _now_iso()
        model.pop("force_retrain_reason", None)
        with self.lock:
            self.history_repository.save_model(model)
            self.feature_cache.clear()
        progress("高级 AI 自动补训完成；当前结果已切换到新模型", 100)
        return model

    def rebuild(self, progress=lambda *_: None, force: bool = False, quick_callback=None, quick_profile: str = "均衡", quick_holding_years: int = 5) -> None:
        progress("读取支付宝可购证据；不可得时仅使用公开市场候选并明确标注‘非支付宝可购确认’", 1)
        availability = self._availability_snapshot(force=True)
        progress("结构筛选并先聚合 A/C/I 等具体份额，不读取近期收益", 4)

        existing = (
            self.store.cache.get("funds", {})
            if isinstance(self.store.cache.get("funds", {}), dict)
            else {}
        )
        all_candidates = self._build_candidate_universe(availability, existing)

        groups = {}
        for item in all_candidates:
            group_key = (
                _base_name(item.get("name", "")).casefold(),
                item["asset_class"],
                item["wrapper"],
            )
            groups.setdefault(group_key, []).append(item)

        representatives = []
        shares_by_group = {}
        group_key_by_rep = {}
        for group_key, shares in groups.items():
            def rep_preference(item):
                cached = (
                    existing.get(item["code"])
                    if isinstance(existing.get(item["code"]), dict)
                    else {}
                )
                usable_cache = (
                    len(cached.get("returns") or []) >= MIN_HISTORY_POINTS
                    and len(cached.get("returns") or []) == len(cached.get("dates") or [])
                )
                return (
                    0 if usable_cache else 1,
                    -_share_preference(item.get("name", "")),
                    item["code"],
                )

            representative = min(shares, key=rep_preference)
            representatives.append(representative)
            shares_by_group[group_key] = shares
            group_key_by_rep[representative["code"]] = group_key

        representatives.sort(key=lambda item: item["code"])
        progress(
            f"结构阶段 {len(all_candidates)} 个具体份额已聚合为 "
            f"{len(representatives)} 个底层代表；开始历史增量",
            8,
        )

        results, historical_results, training_pool, quick_representatives, failures = self._refresh_history_pool(
            representatives, existing, progress, quick_callback=quick_callback,
            quick_profile=quick_profile, quick_holding_years=quick_holding_years,
        )
        retained_inactive = sum(
            item.get("catalog_active") is False for item in training_pool
        )
        current_model = self.store.model
        should_retrain, model_age_days, change_ratio, retrain_reason = self._decide_model_retrain(current_model, training_pool, force=force)
        auto_update_model = _model_auto_update_enabled()
        if should_retrain:
            progress(
                "anchored walk-forward 选择长期目标/模型；随后用全部已成熟长期标签重训 production_model",
                69,
            )
            training_dependency_dir = _active_dependency_dir()
            model = self.model_trainer.train(training_pool)
            model["training_dependency_dir"] = training_dependency_dir.name if training_dependency_dir is not None else ""
            model["automatic_retrain_reason"] = retrain_reason
            model.pop("force_retrain_reason", None)
        else:
            progress(
                f"历史已增量刷新；AI 年龄 {model_age_days:.1f} 天，"
                f"底层池变化 {change_ratio:.1%}，本轮不重训",
                80,
            )
            model = current_model

        model["availability_codes"] = sorted(availability)
        model["availability_snapshot_at"] = _now_iso()
        model["full_market_scanned_shares"] = len(all_candidates)
        model["representative_history_downloads"] = len(representatives)
        model["quick_start_representatives"] = len(quick_representatives)
        model["auto_update_model"] = auto_update_model
        model["retained_inactive_funds"] = retained_inactive
        model["survivorship_bias"] = True
        model["survivorship_mitigation"] = "point-in-time inception/termination + stale histories + persistent inactive archive"
        model["survivorship_note"] = (
            f"已纳入 {retained_inactive} 个历史退出/非活动底层样本并按历史日期做 universe 过滤；"
            "若公开基金目录未覆盖首次运行前已经彻底消失的基金，仍保留剩余存续偏差告警。"
        )

        prelim = self.ranker.score(
            results, model, "均衡", {}, holding_years=5
        )
        finalist_rep_codes = {
            item["code"] for item in prelim[:_adaptive_limit("metadata_enrich_candidates", METADATA_ENRICH_CANDIDATES, 80)]
        }

        expanded = []
        for representative in results:
            if representative["code"] not in finalist_rep_codes:
                continue
            group_key = group_key_by_rep.get(representative["code"])
            shares = shares_by_group.get(group_key, [representative])
            underlying_id = _underlying_key(representative)
            for share in shares:
                cached = (
                    existing.get(share["code"])
                    if isinstance(existing.get(share["code"]), dict)
                    else {}
                )
                item = {
                    **share,
                    "dates": list(representative.get("dates") or []),
                    "returns": list(representative.get("returns") or []),
                    "latest_nav": representative.get("latest_nav"),
                    "latest_date": representative.get("latest_date"),
                    "updated_at": representative.get("updated_at"),
                    "underlying_fund_id": underlying_id,
                    "representative_history_code": representative["code"],
                }
                for field in (
                    "fees", "fees_verified", "fees_source", "fee_schedule_complete",
                    "fee_field_verified", "annual_cost", "embedded_annual_cost",
                    "purchase_cost", "transaction_cost_3y", "transaction_cost_5y", "transaction_cost_10y",
                    "total_share_class_cost_3y", "total_share_class_cost_5y", "total_share_class_cost_10y",
                    "holding_cost_3y", "holding_cost_5y", "holding_cost_10y", "fund_company", "benchmark", "index_code",
                    "theme", "product_features", "product_features_history", "fees_history", "fund_manager", "public_purchase_status", "metadata_checked_at",
                ):
                    if field in cached:
                        item[field] = cached[field]
                self._apply_share_history_semantics(item)
                expanded.append(item)

        current_filter_codes = set(availability)
        active_results = [
            item for item in expanded if item["code"] in current_filter_codes
        ]
        if len({_underlying_key(item) for item in active_results}) < DISPLAY_TOP_N:
            active_results = [
                item for item in expanded
                if str(item.get("availability_status") or "") not in PURCHASE_UNAVAILABLE_STATUSES
            ]
        if len({_underlying_key(item) for item in active_results}) < DISPLAY_TOP_N:
            raise DataError(
                "最终候选区历史充分的底层基金不足 100 个，无法输出 Top 100"
            )

        self._enrich_structural_metadata(active_results, model, progress)
        active_results = [item for item in active_results if str(item.get("availability_status") or "") not in PURCHASE_UNAVAILABLE_STATUSES]
        if len({_underlying_key(item) for item in active_results}) < DISPLAY_TOP_N:
            raise DataError(f"公开申购状态过滤后可用于 Top{DISPLAY_TOP_N} 的不同底层基金不足 {DISPLAY_TOP_N} 个")
        progress(
            "按完整费率选择 A/C/I 具体份额，并生成去重后的长期综合排名 Top 100",
            93,
        )
        self._persist_results(model, training_pool, active_results)

        self._last_full_nav_refresh_at = 0.0
        gate = self._final_freshness_gate(quick_profile, quick_holding_years, progress)
        if gate.get("ok"):
            progress("正式 Top100 已通过新鲜度/申购状态强制门控；AI 与 SQLite 已保存", 100)
        else:
            progress("新鲜度门控未通过；仅保留‘上次有效 Top100’语义，不冒充当前结果", 100)


    @staticmethod
    def _return_correlation(left: dict, right: dict, lookback: int = 504) -> float:
        ld, lr = left.get("dates") or [], left.get("returns") or []
        rd, rr = right.get("dates") or [], right.get("returns") or []
        if len(ld) != len(lr) or len(rd) != len(rr):
            return 0.0
        lmap = dict(zip(ld[-lookback:], lr[-lookback:]))
        rmap = dict(zip(rd[-lookback:], rr[-lookback:]))
        common = sorted(set(lmap) & set(rmap))
        if len(common) < 126:
            return 0.0
        return _clamp(_pearson([lmap[d] for d in common], [rmap[d] for d in common]), -1.0, 1.0)

    def rankings(
        self,
        profile: str,
        *,
        cross_verify: bool = True,
        holding_years: int | None = None,
    ) -> list[dict]:
        with self.lock:
            scored = self.ranker.score(
                self.funds,
                self.store.model,
                profile,
                self.feature_cache,
                holding_years=_expected_holding_years(holding_years),
            )
            chosen = self.portfolio_selector.select_top(scored, profile, DISPLAY_TOP_N)
            raw_rank = {item["code"]: index+1 for index,item in enumerate(scored)}
            warnings = []
            if chosen and all(item.get("long_term_quality") in {"一般", "偏弱"} for item in chosen):
                warnings.append("这是相对前100，不代表当前适合立即买入")
            if not (self.last_freshness_gate or {}).get("ok"):
                warnings.append("上次有效 Top100：本次强制新鲜度门控尚未通过")
            if chosen and any(item.get("pit_rating_capped") for item in chosen):
                warnings.append("PIT宇宙/OOS证据不足，绝对买入评级已硬降级")
            self.last_ranking_warning = "；".join(warnings)
            for rank, item in enumerate(chosen, 1):
                item["ai_raw_rank"] = raw_rank.get(item["code"], rank)
                item["ranking_rank"] = rank
            chosen = _validate_formal_results(chosen)

        if (
            cross_verify
            and len(chosen) >= 10
            and hasattr(getattr(self, "source", None), "cross_verify_top10")
        ):
            try:
                keys = [
                    (
                        item["code"],
                        str(
                            item.get("display_nav_date")
                            or item.get("latest_date")
                            or ""
                        ),
                    )
                    for item in chosen[:10]
                ]
                if all(key in self._cross_check_cache for key in keys):
                    for item, key in zip(chosen[:10], keys):
                        item.update(self._cross_check_cache[key])
                    self.last_cross_check = {
                        "verified": sum(
                            bool(item.get("independent_source_verified"))
                            for item in chosen[:10]
                        ),
                        "requested": 10,
                        "source": "新浪财经基金中心",
                        "cached": True,
                    }
                else:
                    self.last_cross_check = self.source.cross_verify_top10(chosen[:10])
                    for item, key in zip(chosen[:10], keys):
                        self._cross_check_cache[key] = {
                            field: item.get(field)
                            for field in (
                                "independent_source_verified",
                                "metadata_cross_verified",
                                "independent_source",
                                "independent_source_nav",
                                "independent_source_note",
                            )
                        }
                for item in chosen:
                    item["AlipayAvailabilityConfidence"] = _alipay_availability_confidence(item)
            except Exception as exc:
                self.last_cross_check = {
                    "verified": 0,
                    "requested": 10,
                    "source": "新浪财经基金中心",
                    "error": str(exc)[:160],
                }
        return chosen


    @staticmethod
    def _apply_latest_rows(funds: list[dict], latest: dict[str, dict]) -> int:
        updated_series=0; lookup={item["code"]:item for item in funds}
        for code,row in latest.items():
            item=lookup.get(code)
            if not item: continue
            old_date=str(item.get("latest_date") or ((item.get("dates") or [""])[-1])); old_nav=_finite(item.get("latest_nav"),float("nan"))
            new_date=str(row.get("nav_date") or "")[:10]; new_nav=_finite(row.get("nav"),float("nan")); source_day=_finite(row.get("day_change"),float("nan"))
            if row.get("name"): item["name"]=row["name"]
            if row.get("latest_sources"):
                item["latest_sources"] = list(row.get("latest_sources") or [])
                item["latest_public_confirmations"] = int(_finite(row.get("latest_public_confirmations"), len(item["latest_sources"])))
                signals = _public_availability_signals(item)
                item["availability_public_signals"] = sorted(signals)
                item["availability_public_confirmations"] = len(signals)
            if math.isfinite(new_nav) and new_nav>0: item["display_nav"]=new_nav
            if new_date: item["display_nav_date"]=new_date
            if math.isfinite(source_day): item["day_change"]=source_day
            if new_date and new_date>old_date and math.isfinite(new_nav) and new_nav>0 and math.isfinite(old_nav) and old_nav>0:
                nav_return=new_nav/old_nav-1.0; source_return=source_day/100.0 if math.isfinite(source_day) else float("nan")
                                                                                                     
                                                                                                                             
                agreed=math.isfinite(source_return) and abs(source_return-nav_return)<=max(0.0035,0.15*abs(source_return))
                if agreed:
                    item.setdefault("dates",[]).append(new_date); item.setdefault("returns",[]).append(_clamp(nav_return,-0.8,2.0))
                    item["latest_nav"]=new_nav; item["latest_date"]=new_date; item["return_pending_adjustment"]=False; item["updated_at"]=_now_iso(); updated_series+=1
                else:
                    item["return_pending_adjustment"]=True
            elif new_date==old_date and math.isfinite(new_nav) and new_nav>0:
                item["latest_nav"]=new_nav
        return updated_series

    def _resolve_pending_adjustments(self, funds: list[dict], max_workers: int = 4) -> int:
        pending = [item for item in funds if item.get("return_pending_adjustment") is True]
        if not pending:
            return 0
        resolved = 0
        def resolve(item):
            cached = {"dates": list(item.get("dates") or []), "returns": list(item.get("returns") or []),
                      "latest_nav": item.get("latest_nav"), "latest_date": item.get("latest_date", "")}
            return self.source.update_history(item["code"], cached) if hasattr(self.source, "update_history") else self.source.history(item["code"])
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(max_workers, len(pending)), thread_name_prefix="corp-action") as pool:
            futures = {pool.submit(resolve, item): item for item in pending}
            for future in concurrent.futures.as_completed(futures):
                item = futures[future]
                try:
                    history = future.result()
                except Exception:
                    continue
                dates, returns = history.get("dates") or [], history.get("returns") or []
                if len(dates) == len(returns) and len(returns) >= MIN_HISTORY_POINTS and str(history.get("latest_date") or "") >= str(item.get("display_nav_date") or ""):
                    for key in ("dates","returns","latest_nav","latest_date","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations"):
                        if key in history:
                            item[key] = history[key]
                    item["return_pending_adjustment"] = False; item["updated_at"] = _now_iso(); resolved += 1
        return resolved

    @staticmethod
    def _availability_fields(declared: dict) -> dict:
        keys = (
            "availability_declared","availability_status","availability_note","fund_data_source","availability_declared_at","availability_generated_at","availability_expires_at","availability_sequence","availability_signature_alg",
            "availability_source","availability_source_id","availability_evidence","availability_schema_version",
            "fees_verified","fees","fees_history","fees_source","fee_schedule_complete","fee_field_verified","annual_cost","embedded_annual_cost","purchase_cost",
            "transaction_cost_3y","transaction_cost_5y","transaction_cost_10y",
            "total_share_class_cost_3y","total_share_class_cost_5y","total_share_class_cost_10y",
            "holding_cost_3y","holding_cost_5y","holding_cost_10y",
            "available_from","available_to","availability_history","share_class","product_features","product_features_history",
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status",
            "underlying_fund_id","master_code","primary_code","inception_date","termination_date","merged_into",
            "metadata_source","metadata_checked_at",
            "display_nav","display_nav_date","return_pending_adjustment","return_basis","return_provider_fallbacks","return_corporate_actions","return_accumulated_confirmations",
        )
        optional_structural = {
            "benchmark","index_code","fund_company","fund_manager","theme","public_purchase_status","underlying_fund_id","master_code","primary_code",
            "inception_date","termination_date","merged_into","metadata_source","metadata_checked_at","product_features","product_features_history","fees_history",
        }
        return {
            key: declared[key] for key in keys if key in declared
            and (key not in optional_structural or declared.get(key) not in (None, "", {}, []))
        }

    def _sync_candidate_pool(
        self,
        availability: dict[str, dict],
    ) -> tuple[list[str], list[str], list[str]]:
        with self.lock:
            current = {item["code"]: item for item in self.funds}

        availability_codes = set(availability)
        current_codes = set(current)
        removed_codes = sorted(current_codes - availability_codes)
        kept = []

        for code, item in current.items():
            if code not in availability_codes:
                continue
            declared = availability[code]
            updated = dict(item)
            updated.update(self._availability_fields(declared))
            updated["availability_history"] = self._merge_observed_availability(
                declared, item
            )
            updated["name"] = (
                declared.get("name") or updated.get("name") or code
            )
            updated["type"] = (
                declared.get("type") or updated.get("type") or "其他"
            )
            if _candidate_allowed(updated["name"], updated["type"]):
                kept.append(updated)

        archive = self.history_repository.archive()
        current_group_lookup = {}
        for item in kept:
            group_key = (
                _base_name(item.get("name", "")).casefold(),
                _asset_bucket(item.get("name", ""), item.get("type", "")),
                _wrapper_type(item.get("type", "")),
            )
            current_group_lookup.setdefault(group_key, item)

        added_items = []
        failed_new = []
        deferred = 0
        for code in sorted(availability_codes - current_codes):
            declared = availability[code]
            cached = (
                archive.get(code)
                if isinstance(archive.get(code), dict)
                else None
            )
            name = (
                declared.get("name")
                or (cached or {}).get("name")
                or code
            )
            fund_type = (
                declared.get("type")
                or (cached or {}).get("type")
                or "其他"
            )
            if not _candidate_allowed(name, fund_type):
                continue

            candidate = None
            if cached:
                dates, returns = (
                    cached.get("dates") or [],
                    cached.get("returns") or [],
                )
                if (
                    len(returns) >= MIN_HISTORY_POINTS
                    and len(dates) == len(returns)
                    and self._history_recent_enough(cached, max_days=5)
                ):
                    candidate = {
                        "code": code,
                        **cached,
                        **self._availability_fields(declared),
                    }

            if candidate is None:
                group_key = (
                    _base_name(name).casefold(),
                    _asset_bucket(name, fund_type),
                    _wrapper_type(fund_type),
                )
                representative = current_group_lookup.get(group_key)
                if representative is not None:
                    candidate = {
                        **declared,
                        "code": code,
                        "name": name,
                        "type": fund_type,
                        "dates": list(representative.get("dates") or []),
                        "returns": list(representative.get("returns") or []),
                        "latest_nav": representative.get("latest_nav"),
                        "latest_date": representative.get("latest_date"),
                        "updated_at": representative.get("updated_at"),
                        "underlying_fund_id": _underlying_key(representative),
                        "representative_history_code": representative.get(
                            "representative_history_code",
                            representative.get("code"),
                        ),
                    }

            if candidate is None:
                deferred += 1
                continue

            candidate.update(self._availability_fields(declared))
            self._apply_share_history_semantics(candidate)
            candidate["availability_history"] = self._merge_observed_availability(
                declared, cached if isinstance(cached, dict) else None
            )
            candidate["name"] = name
            candidate["type"] = fund_type
            added_items.append(candidate)

        with self.lock:
            self.funds = kept + added_items
            for code in removed_codes:
                self.feature_cache.pop(code, None)
            for item in added_items:
                self.feature_cache.pop(item["code"], None)

        self.last_sync_deferred_count = deferred
        return (
            [item["code"] for item in added_items],
            removed_codes,
            failed_new,
        )


    def _final_freshness_gate(self, profile: str, holding_years: int | None = None, progress=lambda *_: None) -> dict:
        """Formal Top100 is current only after a fresh NAV + purchase-status recheck of the displayed set."""
        years = _expected_holding_years(holding_years)
        with self.lock:
            preliminary = self.ranker.score(self.funds, self.store.model, profile, self.feature_cache, holding_years=years)
            displayed = self.portfolio_selector.select_top(preliminary, profile, DISPLAY_TOP_N)
            gate_candidates = displayed[:FINAL_FRESHNESS_CANDIDATES]
            codes = [item["code"] for item in gate_candidates]
            provisional_top = [item["code"] for item in displayed[:DISPLAY_TOP_N]]
        if len(provisional_top) < DISPLAY_TOP_N:
            self.last_freshness_gate = {"ok": False, "reason": f"正式门控前候选不足{DISPLAY_TOP_N}只"}
            return self.last_freshness_gate
        progress(f"正式展示前强制复核 Top{len(codes)} 最新净值与申购状态", 96)
        report = self.source.latest_many(codes)
        rows = report.get("rows") or {}
        today = _china_today(); fresh_rows = self.freshness_gate.filter_latest(rows, today, FRESH_NAV_MAX_MARKET_SESSIONS)
        fresh_coverage = len(fresh_rows) / max(1, len(codes))
        displayed_fresh_coverage = sum(code in fresh_rows for code in provisional_top) / max(1, len(provisional_top))
        metadata = self.source.metadata_many(gate_candidates) if hasattr(self.source, "metadata_many") else {}
        meta_coverage = len(metadata) / max(1, len(codes))
        with self.lock:
            lookup = {item["code"]: item for item in self.funds}
            for code, values in metadata.items():
                item = lookup.get(code)
                if not item or not isinstance(values, dict):
                    continue
                for field in ("public_purchase_status", "public_purchase_status_secondary", "termination_date", "metadata_checked_at", "availability_public_signals", "availability_public_confirmations"):
                    if field in values and values.get(field) not in (None, ""):
                        item[field] = values[field]
                if item.get("availability_status") != "confirmed_purchasable":
                    classified = self._classify_public_purchase_status(str(item.get("public_purchase_status") or ""), str(item.get("termination_date") or ""))
                    item["availability_status"] = classified
                    item["availability_note"] = self._public_status_note(classified)
                self._apply_share_history_semantics(item)
            self.funds = [item for item in self.funds if str(item.get("availability_status") or "") not in PURCHASE_UNAVAILABLE_STATUSES]
            if fresh_coverage >= FINAL_FRESHNESS_COVERAGE and displayed_fresh_coverage >= FINAL_FRESHNESS_COVERAGE and meta_coverage >= FINAL_FRESHNESS_COVERAGE:
                self._apply_latest_rows(self.funds, fresh_rows)
                self._resolve_pending_adjustments(self.funds)
                self._persist_current()
                rescored = self.ranker.score(self.funds, self.store.model, profile, self.feature_cache, holding_years=years)
                ok = len(self.portfolio_selector.select_top(rescored, profile, DISPLAY_TOP_N)) >= DISPLAY_TOP_N
            else:
                ok = False
        reason = (
            f"Top{len(codes)}新鲜净值{fresh_coverage:.1%}、展示Top{DISPLAY_TOP_N}新鲜{displayed_fresh_coverage:.1%}、申购状态复核{meta_coverage:.1%}"
        )
        self.last_freshness_gate = {"ok": bool(ok), "fresh_coverage": fresh_coverage, "displayed_fresh_coverage": displayed_fresh_coverage, "metadata_coverage": meta_coverage, "reason": reason, "checked_at": _now_iso()}
        return dict(self.last_freshness_gate)

    def refresh_latest(
        self,
        profile: str,
        holding_years: int | None = None,
        *,
        force_availability: bool = False,
        force_full_nav: bool = False,
        progress=lambda *_: None,
    ) -> dict:
        started = time.monotonic()
        progress("检查数据源可用性", 4)
        self.ensure_source_contract(
            lambda text, pct: progress(
                text, 4.0 + 6.0 * _clamp(_finite(pct), 0.0, 100.0) / 100.0
            )
        )
        years = _expected_holding_years(holding_years)

        progress("获取最新可购证据", 12)
        availability = self._availability_snapshot(force=force_availability)

        progress("同步基金候选池", 22)
        added, removed, failed_new = self._sync_candidate_pool(availability)

        progress("计算本轮净值复核范围", 30)
        with self.lock:
            all_codes = [item["code"] for item in self.funds]
            priority_scored = self.ranker.score(
                self.funds,
                self.store.model,
                profile,
                self.feature_cache,
                holding_years=years,
            )
            priority_displayed = self.portfolio_selector.select_top(
                priority_scored, profile, DISPLAY_TOP_N
            )
            priority_codes = [item["code"] for item in priority_displayed]

        if len(priority_codes) < DISPLAY_TOP_N:
            self._persist_current()
            raise DataError(f"当前候选且历史数据充足的底层基金不足 {DISPLAY_TOP_N} 个")

        full_due = (
            force_full_nav
            or self._last_full_nav_refresh_at <= 0
            or time.monotonic() - self._last_full_nav_refresh_at
            >= FULL_NAV_REFRESH_SECONDS
            or bool(added or removed)
        )
        request_codes = all_codes if full_due else priority_codes
        progress(f"正在获取最新净值，共 {len(request_codes)} 只基金", 34)
        report = self.source.latest_many(
            request_codes,
            progress=lambda text, pct: progress(
                text,
                34.0 + 42.0 * _clamp(_finite(pct), 0.0, 100.0) / 100.0,
            ),
        )
        rows = report.get("rows") or {}
        requested = int(report.get("requested", len(request_codes)))
        received = int(report.get("received", len(rows)))
        returned_coverage = received / max(1, requested)

        progress("检查净值日期与完整性", 80)
        today = _china_today()
        fresh_rows = {}
        stale_codes = []
        for code, row in rows.items():
            date_text = str(row.get("nav_date") or "")[:10]
            try:
                nav_date = _dt.date.fromisoformat(date_text)
            except ValueError:
                stale_codes.append(code)
                continue
            nav = _finite(row.get("nav"), float("nan"))
            sessions = _expected_market_sessions(nav_date, today)
            if (
                math.isfinite(nav)
                and nav > 0
                and sessions <= FRESH_NAV_MAX_MARKET_SESSIONS
            ):
                fresh_rows[code] = row
            else:
                stale_codes.append(code)

        fresh_coverage = len(fresh_rows) / max(1, requested)
        priority_missing = sorted(set(priority_codes) - set(fresh_rows))
        priority_complete = not priority_missing
        ranking_updated = bool(
            full_due
            and fresh_coverage >= REFRESH_MIN_COVERAGE
            and priority_complete
        )

        updated_series = 0
        resolved_adjustments = 0
        progress("重新计算 Top100", 90)

        if ranking_updated:
            with self.lock:
                updated_series = self._apply_latest_rows(
                    self.funds, fresh_rows
                )
                resolved_adjustments = self._resolve_pending_adjustments(
                    self.funds
                )
                updated_series += resolved_adjustments
                self._persist_current()
                results = self.rankings(
                    profile, holding_years=years
                )
            self._last_full_nav_refresh_at = time.monotonic()
            status = (
                f"全候选净值：返回 {returned_coverage:.1%} / "
                f"新鲜 {fresh_coverage:.1%} / 陈旧 {len(stale_codes)}；"
                f"Top {len(priority_codes)} 全部新鲜，已重排"
            )
        elif not full_due:
            with self.lock:
                lookup = {item["code"]: item for item in self.funds}
                for code, row in fresh_rows.items():
                    item = lookup.get(code)
                    if not item:
                        continue
                    nav = _finite(row.get("nav"), float("nan"))
                    if math.isfinite(nav) and nav > 0:
                        item["display_nav"] = nav
                    item["display_nav_date"] = str(
                        row.get("nav_date") or ""
                    )[:10]
                    day_change = _finite(
                        row.get("day_change"), float("nan")
                    )
                    if math.isfinite(day_change):
                        item["day_change"] = day_change
                self._persist_current()
                results = self.rankings(
                    profile, holding_years=years
                )
            status = (
                f"Top {len(priority_codes)} 高频复核：返回 "
                f"{returned_coverage:.1%} / 新鲜 {fresh_coverage:.1%} / "
                f"陈旧 {len(stale_codes)}；完整全池重排每约20分钟执行"
            )
        else:
            with self.lock:
                self._persist_current()
                results = self.rankings(
                    profile, holding_years=years
                )
            status = (
                f"全候选净值：返回 {returned_coverage:.1%} / "
                f"新鲜 {fresh_coverage:.1%} / 陈旧 {len(stale_codes)}；"
            )
            if fresh_coverage < REFRESH_MIN_COVERAGE:
                status += (
                    f"低于新鲜覆盖门槛 {REFRESH_MIN_COVERAGE:.1%}，"
                    "排名未更新"
                )
            else:
                status += (
                    f"Top候选仍有 {len(priority_missing)} 个不新鲜，"
                    "排名未更新"
                )

        results = _validate_formal_results(results)
        current_gate_ok = bool(priority_complete and fresh_coverage >= REFRESH_MIN_COVERAGE)
        self.last_freshness_gate = {
            "ok": current_gate_ok,
            "fresh_coverage": fresh_coverage,
            "displayed_fresh_coverage": (len(priority_codes) - len(priority_missing)) / max(1, len(priority_codes)),
            "availability_checked": True,
            "reason": f"当前可购状态已复核；Top{len(priority_codes)} 最新净值覆盖 {((len(priority_codes)-len(priority_missing))/max(1,len(priority_codes))):.1%}",
            "checked_at": _now_iso(),
        }

        progress("刷新完成", 100)
        return {
            "results": results,
            "status": status,
            "coverage": fresh_coverage,
            "returned_coverage": returned_coverage,
            "fresh_coverage": fresh_coverage,
            "stale_count": len(stale_codes),
            "stale_codes": sorted(stale_codes),
            "requested": requested,
            "received": received,
            "fresh_received": len(fresh_rows),
            "failed_codes": report.get("failed_codes") or [],
            "priority_codes": sorted(priority_codes),
            "priority_missing_codes": priority_missing,
            "priority_complete": priority_complete,
            "ranking_updated": ranking_updated,
            "full_refresh": full_due,
            "new_codes": added,
            "removed_codes": removed,
            "failed_new_codes": failed_new,
            "updated_series": updated_series,
            "resolved_adjustments": resolved_adjustments,
            "elapsed_seconds": time.monotonic() - started,
        }



# ===== UI / 控制台 =====

class AppState:
    STARTING = "starting"
    BUILDING = "building"
    READY = "ready"
    REFRESHING = "refreshing"
    RETRY_WAIT = "retry_wait"
    ERROR = "error"


class FundsApp:
    def __init__(self, root, tk, ttk, messagebox):
        self.root, self.tk, self.ttk, self.messagebox = root, tk, ttk, messagebox
        _GLOBAL_STOP_EVENT.clear()
        self.engine = AnalysisEngine()
        self.events = queue.Queue()
        self.stop_event = _GLOBAL_STOP_EVENT
        self.workers = WorkerManager(self.stop_event)

        self.busy = False
        self.refreshing = False
        self.maintenance_running = False
        self.formal_results_ready = False
        self.app_state = AppState.STARTING

        self.refresh_policy = SmartRefreshPolicy()
        self.next_refresh = float("inf")
        self.next_maintenance = time.monotonic() + 60.0
        self.current = []
        self._row_items = {}

        self.profile = tk.StringVar(value="均衡")
        self.holding_years = tk.IntVar(value=_expected_holding_years())

        self.result_title = tk.StringVar(value="基金优选 Top100")
        self.status = tk.StringVar(value="正在准备基金排名")
        self.progress_value = tk.DoubleVar(value=0.0)
        self.progress_percent = tk.StringVar(value="0%")
        self.progress_detail = tk.StringVar(value="准备开始")
        self.elapsed_text = tk.StringVar(value="已用时 00:00")
        self.operation_started_at = None

        self.data_date = tk.StringVar(value="—")
        self.data_date_detail = tk.StringVar(value="最新净值日期")
        self.data_status = tk.StringVar(value="正在准备")
        self.data_status_detail = tk.StringVar(value="等待首次结果")
        self.ai_status = tk.StringVar(value="模型待载入")
        self.ai_background_status = tk.StringVar(value="结果优先，AI 增强稍后准备")
        self.clock = tk.StringVar(value="等待分析")
        self.refresh_reason = tk.StringVar(value="自动刷新将在分析完成后开始")
        self.last_update_text = tk.StringVar(value="最后更新 —")

        self.loading_spinner = tk.StringVar(value="● ○ ○")
        self.error_title = tk.StringVar(value="暂时无法取得基金数据")
        self.error_message = tk.StringVar(value="程序会自动重试。")
        self.retry_text = tk.StringVar(value="")

        self.detail_title = tk.StringVar(value="选择一只基金查看详情")
        self.detail_meta = tk.StringVar(value="")
        self.detail_metrics = tk.StringVar(value="")
        self.detail_reason = tk.StringVar(value="")
        self.detail_note = tk.StringVar(value="")

        self.initial_error_streak = 0
        self.initial_retry_job = None
        self.initial_retry_due_at = None
        self.schedule_started = False

        self._dependency_ready_at = None
        self._dependency_prepare_started = False
        self._dependency_prepare_job = None
        self._advanced_retrain_pending = False
        self._advanced_retrain_started = False

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(120, self._poll_events)
        self.root.after(1000, self._tick)
        self._start_initial()

    # ---------- common UI state ----------

    @staticmethod
    def _format_elapsed(seconds: float) -> str:
        total = max(0, int(seconds))
        hours, rem = divmod(total, 3600)
        minutes, secs = divmod(rem, 60)
        if hours:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    @staticmethod
    def _friendly_error_message(exc_text: str) -> str:
        text = str(exc_text or "")
        lower = text.lower()
        messages = []
        if "契约" in text or "熔断" in text or "格式" in text:
            messages.append("主要数据源校验暂未通过")
        if "timed out" in lower or "timeout" in lower or "超时" in text:
            messages.append("备用数据源或网络响应超时")
        elif "网络请求失败" in text or "network" in lower or "urlopen" in lower:
            messages.append("暂时无法连接数据源")
        if "不足" in text and "基金" in text:
            messages.append("当前可安全用于排名的数据暂时不足")
        if not messages:
            messages.append("本次数据更新未完成")
        return "；".join(dict.fromkeys(messages))

    @staticmethod
    def _friendly_progress(text: str) -> tuple[str, str]:
        raw = re.sub(r"\s+", " ", str(text or "")).strip()
        if not raw:
            return "正在处理", ""
        if "阶段1结构盲选历史" in raw or "阶段2" in raw or "历史增量" in raw:
            return "下载基金历史数据", raw
        if "anchored walk-forward" in raw or "production_model" in raw:
            return "训练长期 AI 模型", "正在验证长期模型并更新本地模型"
        if "高级 AI" in raw and "补训" in raw:
            return "增强 AI 模型", raw
        if "可购" in raw or "申购状态" in raw or "支付宝" in raw:
            return "检查基金可购证据", raw
        if "目录" in raw or "数据源" in raw or "契约" in raw:
            return "检查数据源", raw
        if "最新净值" in raw or "净值日期" in raw or "新鲜" in raw:
            return "获取并复核最新净值", raw
        if "元数据" in raw or "费率" in raw or "基金信息" in raw:
            return "补充基金信息", raw
        if "结构" in raw or "候选池" in raw:
            return "整理基金候选池", raw
        if "Top100" in raw or "Top 100" in raw or "排名" in raw:
            return "生成基金 Top100", raw
        if "刷新完成" in raw:
            return "刷新完成", raw
        if "完成" in raw:
            return raw, ""
        # Keep concise texts as the main line and longer diagnostics/details below.
        if len(raw) <= 28:
            return raw, ""
        return raw[:28].rstrip("：；,， ") + "…", raw

    def _set_progress(self, text: str, pct: float | None = None):
        title, detail = self._friendly_progress(text)
        self.status.set(title)
        self.progress_detail.set(detail or str(text or ""))
        if pct is not None:
            value = max(0.0, min(100.0, _finite(pct)))
            self.progress_value.set(value)
            self.progress_percent.set(f"{value:.0f}%")

    def _begin_operation(self, text: str, pct: float = 0.0, detail: str = ""):
        self.operation_started_at = time.monotonic()
        self.elapsed_text.set("已用时 00:00")
        self._set_progress(detail or text, pct)
        if detail:
            self.status.set(text)

    def _finish_operation(self, text: str | None = None, pct: float | None = None):
        if text is not None:
            self._set_progress(text, pct)
        elif pct is not None:
            value = max(0.0, min(100.0, _finite(pct)))
            self.progress_value.set(value)
            self.progress_percent.set(f"{value:.0f}%")
        if self.operation_started_at is not None:
            elapsed = time.monotonic() - self.operation_started_at
            self.elapsed_text.set(f"已用时 {self._format_elapsed(elapsed)}")
        self.operation_started_at = None

    def _set_app_state(self, state: str):
        self.app_state = state
        if not hasattr(self, "refresh_button"):
            return
        if state == AppState.BUILDING:
            self.refresh_button.configure(text="分析中…", state="disabled")
        elif state == AppState.REFRESHING:
            self.refresh_button.configure(text="刷新中…", state="disabled")
        elif state == AppState.READY:
            self.refresh_button.configure(text="刷新", state="normal")
        elif state == AppState.RETRY_WAIT:
            self.refresh_button.configure(text="立即重试", state="normal")
        elif state == AppState.ERROR:
            self.refresh_button.configure(
                text="重新尝试" if self.formal_results_ready else "立即重试",
                state="normal",
            )
        else:
            self.refresh_button.configure(text="刷新", state="disabled")

    def _show_content(self, mode: str):
        frame = {
            "table": self.table_frame,
            "loading": self.loading_frame,
            "error": self.error_frame,
        }.get(mode, self.loading_frame)
        frame.tkraise()

    # ---------- UI ----------

    def _build_ui(self):
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("1420x820")
        self.root.minsize(1180, 700)
        self.root.configure(bg="#0F172A")
        try:
            self.root.iconname(APP_NAME)
        except Exception:
            pass

        style = self.ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except self.tk.TclError:
            pass

        font = ("Microsoft YaHei UI", 10)
        style.configure(".", font=font)
        style.configure("Root.TFrame", background="#0F172A")
        style.configure("Card.TFrame", background="#111827")
        style.configure("Detail.TFrame", background="#172033")
        style.configure("Title.TLabel", background="#0F172A", foreground="#F8FAFC", font=("Microsoft YaHei UI", 20, "bold"))
        style.configure("Sub.TLabel", background="#0F172A", foreground="#94A3B8", font=("Microsoft YaHei UI", 10))
        style.configure("HeaderMeta.TLabel", background="#0F172A", foreground="#94A3B8", font=("Microsoft YaHei UI", 9))
        style.configure("CardTitle.TLabel", background="#111827", foreground="#64748B", font=("Microsoft YaHei UI", 9))
        style.configure("CardValue.TLabel", background="#111827", foreground="#F8FAFC", font=("Microsoft YaHei UI", 12, "bold"))
        style.configure("CardSub.TLabel", background="#111827", foreground="#94A3B8", font=("Microsoft YaHei UI", 9))
        style.configure("DetailTitle.TLabel", background="#172033", foreground="#F8FAFC", font=("Microsoft YaHei UI", 13, "bold"))
        style.configure("DetailMeta.TLabel", background="#172033", foreground="#94A3B8", font=("Microsoft YaHei UI", 9))
        style.configure("DetailBody.TLabel", background="#172033", foreground="#E2E8F0", font=("Microsoft YaHei UI", 10))
        style.configure("DetailMuted.TLabel", background="#172033", foreground="#94A3B8", font=("Microsoft YaHei UI", 9))
        style.configure("ProgressTitle.TLabel", background="#111827", foreground="#F8FAFC", font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("ProgressPercent.TLabel", background="#111827", foreground="#93C5FD", font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("ProgressDetail.TLabel", background="#111827", foreground="#94A3B8", font=("Microsoft YaHei UI", 9))
        style.configure("LoadingTitle.TLabel", background="#111827", foreground="#F8FAFC", font=("Microsoft YaHei UI", 16, "bold"))
        style.configure("LoadingBody.TLabel", background="#111827", foreground="#94A3B8", font=("Microsoft YaHei UI", 10))
        style.configure("LoadingSpinner.TLabel", background="#111827", foreground="#3B82F6", font=("Microsoft YaHei UI", 16, "bold"))
        style.configure("ErrorTitle.TLabel", background="#111827", foreground="#F8FAFC", font=("Microsoft YaHei UI", 16, "bold"))
        style.configure("ErrorBody.TLabel", background="#111827", foreground="#CBD5E1", font=("Microsoft YaHei UI", 10))
        style.configure("Warn.TLabel", background="#0F172A", foreground="#F59E0B", font=("Microsoft YaHei UI", 9))
        style.configure("TButton", padding=(14, 8), background="#2563EB", foreground="#FFFFFF", borderwidth=0)
        style.map("TButton", background=[("active", "#3B82F6"), ("disabled", "#243044")], foreground=[("disabled", "#94A3B8")])
        style.configure("Treeview", background="#111827", fieldbackground="#111827", foreground="#E2E8F0", rowheight=38, borderwidth=0)
        style.configure("Treeview.Heading", background="#172033", foreground="#CBD5E1", relief="flat", padding=(7, 9), font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#1D4ED8")], foreground=[("selected", "#FFFFFF")])
        style.configure("Horizontal.TProgressbar", background="#3B82F6", troughcolor="#243044", borderwidth=0, lightcolor="#3B82F6", darkcolor="#3B82F6")

        outer = self.ttk.Frame(self.root, style="Root.TFrame", padding=(22, 18, 22, 14))
        outer.pack(fill="both", expand=True)

        header = self.ttk.Frame(outer, style="Root.TFrame")
        header.pack(fill="x")
        titles = self.ttk.Frame(header, style="Root.TFrame")
        titles.pack(side="left", fill="x", expand=True)
        self.ttk.Label(titles, textvariable=self.result_title, style="Title.TLabel").pack(anchor="w")
        self.ttk.Label(titles, text="长期综合排名 · 数据自动更新", style="Sub.TLabel").pack(anchor="w", pady=(4, 0))

        controls = self.ttk.Frame(header, style="Root.TFrame")
        controls.pack(side="right", anchor="e")
        self.ttk.Label(controls, textvariable=self.last_update_text, style="HeaderMeta.TLabel").grid(row=0, column=0, padx=(0, 12))
        self.refresh_button = self.ttk.Button(controls, text="刷新", command=lambda: self._start_refresh(manual=True))
        self.refresh_button.grid(row=0, column=1)

        cards = self.ttk.Frame(outer, style="Root.TFrame")
        cards.pack(fill="x", pady=(16, 12))
        for column in range(4):
            cards.columnconfigure(column, weight=1, uniform="summary")

        def add_card(column, title, value_var, sub_var):
            card = self.ttk.Frame(cards, style="Card.TFrame", padding=(14, 11))
            card.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 6, 0 if column == 3 else 6))
            self.ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
            self.ttk.Label(card, textvariable=value_var, style="CardValue.TLabel").pack(anchor="w", pady=(4, 1))
            self.ttk.Label(card, textvariable=sub_var, style="CardSub.TLabel").pack(anchor="w")

        add_card(0, "数据日期", self.data_date, self.data_date_detail)
        add_card(1, "数据状态", self.data_status, self.data_status_detail)
        add_card(2, "AI 模型", self.ai_status, self.ai_background_status)
        add_card(3, "自动刷新", self.clock, self.refresh_reason)

        self.content_container = self.ttk.Frame(outer, style="Card.TFrame")
        self.content_container.pack(fill="both", expand=True)
        self.content_container.rowconfigure(0, weight=1)
        self.content_container.columnconfigure(0, weight=1)

        # Table + detail view.
        self.table_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.table_frame.grid(row=0, column=0, sticky="nsew")
        self.table_frame.rowconfigure(0, weight=1)
        self.table_frame.columnconfigure(0, weight=1)

        table_wrap = self.ttk.Frame(self.table_frame, style="Card.TFrame", padding=(1, 1, 0, 1))
        table_wrap.grid(row=0, column=0, sticky="nsew")
        table_wrap.rowconfigure(0, weight=1)
        table_wrap.columnconfigure(0, weight=1)

        columns = ("rank", "fund", "type", "evidence", "quality", "timing", "risk", "ann3", "nav")
        self.tree = self.ttk.Treeview(table_wrap, columns=columns, show="headings", selectmode="browse")
        headings = {
            "rank": "排名",
            "fund": "基金名称",
            "type": "类型",
            "evidence": "可购证据",
            "quality": "长期质量",
            "timing": "当前择时",
            "risk": "风险",
            "ann3": "近3年年化",
            "nav": "最新净值",
        }
        widths = {"rank": 52, "fund": 205, "type": 80, "evidence": 112, "quality": 88, "timing": 88, "risk": 82, "ann3": 94, "nav": 86}
        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(
                column,
                width=widths[column],
                minwidth=50 if column != "fund" else 150,
                anchor="w" if column == "fund" else "center",
                stretch=(column == "fund"),
            )
        scrollbar = self.ttk.Scrollbar(table_wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.tag_configure("odd", background="#111827")
        self.tree.tag_configure("even", background="#151F30")
        self.tree.tag_configure("top3", font=("Microsoft YaHei UI", 10, "bold"))
        self.tree.bind("<<TreeviewSelect>>", self._update_detail_panel)

        detail = self.ttk.Frame(self.table_frame, style="Detail.TFrame", padding=(16, 15))
        detail.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        detail.configure(width=320)
        detail.grid_propagate(False)
        self.ttk.Label(detail, textvariable=self.detail_title, style="DetailTitle.TLabel", wraplength=285, justify="left").pack(anchor="w")
        self.ttk.Label(detail, textvariable=self.detail_meta, style="DetailMeta.TLabel", wraplength=285, justify="left").pack(anchor="w", pady=(5, 13))
        self.ttk.Label(detail, textvariable=self.detail_metrics, style="DetailBody.TLabel", wraplength=285, justify="left").pack(anchor="w")
        self.ttk.Separator(detail, orient="horizontal").pack(fill="x", pady=14)
        self.ttk.Label(detail, text="入选理由", style="DetailMeta.TLabel").pack(anchor="w")
        self.ttk.Label(detail, textvariable=self.detail_reason, style="DetailBody.TLabel", wraplength=285, justify="left").pack(anchor="w", pady=(5, 12))
        self.ttk.Label(detail, textvariable=self.detail_note, style="DetailMuted.TLabel", wraplength=285, justify="left").pack(anchor="w")

        # Loading state.
        self.loading_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.loading_frame.grid(row=0, column=0, sticky="nsew")
        loading_center = self.ttk.Frame(self.loading_frame, style="Card.TFrame")
        loading_center.place(relx=0.5, rely=0.48, anchor="center")
        self.ttk.Label(loading_center, textvariable=self.loading_spinner, style="LoadingSpinner.TLabel").pack()
        self.ttk.Label(loading_center, text="正在准备基金排名", style="LoadingTitle.TLabel").pack(pady=(12, 5))
        self.ttk.Label(loading_center, textvariable=self.status, style="LoadingBody.TLabel").pack()
        self.ttk.Label(loading_center, textvariable=self.progress_percent, style="CardValue.TLabel").pack(pady=(10, 2))
        self.ttk.Label(loading_center, text="首次分析可能需要一些时间，结果会分阶段出现", style="LoadingBody.TLabel").pack()
        self.ttk.Label(loading_center, textvariable=self.elapsed_text, style="LoadingBody.TLabel").pack(pady=(5, 0))

        # Error state.
        self.error_frame = self.ttk.Frame(self.content_container, style="Card.TFrame")
        self.error_frame.grid(row=0, column=0, sticky="nsew")
        error_center = self.ttk.Frame(self.error_frame, style="Card.TFrame")
        error_center.place(relx=0.5, rely=0.48, anchor="center")
        self.ttk.Label(error_center, textvariable=self.error_title, style="ErrorTitle.TLabel").pack()
        self.ttk.Label(error_center, textvariable=self.error_message, style="ErrorBody.TLabel", wraplength=560, justify="center").pack(pady=(10, 7))
        self.ttk.Label(error_center, textvariable=self.retry_text, style="LoadingBody.TLabel").pack(pady=(0, 12))
        self.ttk.Button(error_center, text="立即重试", command=lambda: self._start_refresh(manual=True)).pack()

        progress_area = self.ttk.Frame(outer, style="Card.TFrame", padding=(14, 10))
        progress_area.pack(fill="x", pady=(12, 0))
        progress_header = self.ttk.Frame(progress_area, style="Card.TFrame")
        progress_header.pack(fill="x")
        self.ttk.Label(progress_header, textvariable=self.status, style="ProgressTitle.TLabel").pack(side="left")
        self.ttk.Label(progress_header, textvariable=self.progress_percent, style="ProgressPercent.TLabel").pack(side="right")
        self.progress = self.ttk.Progressbar(progress_area, variable=self.progress_value, maximum=100, mode="determinate")
        self.progress.pack(fill="x", pady=(8, 5))
        detail_row = self.ttk.Frame(progress_area, style="Card.TFrame")
        detail_row.pack(fill="x")
        self.ttk.Label(
            detail_row,
            textvariable=self.progress_detail,
            style="ProgressDetail.TLabel",
            wraplength=980,
            justify="left",
        ).pack(side="left", fill="x", expand=True)
        self.ttk.Label(detail_row, textvariable=self.elapsed_text, style="ProgressDetail.TLabel").pack(side="right", padx=(12, 0))

        self.ttk.Label(
            outer,
            text="⚠ 未验签基金不代表支付宝确认可购，交易前请以支付宝页面的可购、费率、限购与适当性信息为准。",
            style="Warn.TLabel",
        ).pack(fill="x", pady=(8, 0))

        self._show_content("loading")
        self._set_app_state(AppState.STARTING)

    # ---------- dependency preparation ----------

    def _ensure_dependency_prepare_started(self):
        if self._dependency_prepare_started or self.stop_event.is_set():
            return
        self._dependency_prepare_started = True
        self.ai_background_status.set("AI 增强组件：后台准备中")
        self._start_dependency_prepare()

    def _start_dependency_prepare(self):
        """Prepare optional AI backends only after the first usable ranking is visible."""
        def worker():
            try:
                before = _load_install_settings()
                before_target = _active_dependency_dir(before)
                before_required = bool(before.get("lightgbm") is True or before.get("advanced_tree") is True)
                before_ok = False
                if before_required and before_target is not None:
                    before_ok, _ = _dependency_import_probe(before_target, before)
                settings = _configure_hardware_adaptive(
                    force=False,
                    allow_install=True,
                    status_callback=lambda text: self.events.put(("dependency_progress", text)),
                )
                after_target = _active_dependency_dir(settings)
                pending_target = _pending_dependency_dir(settings)
                after_required = bool(settings.get("lightgbm") is True or settings.get("advanced_tree") is True)
                after_ok = False
                if pending_target is not None:
                    detail = "新 AI 依赖已核验；为避免 native DLL 热切换，将在下次启动自动激活"
                elif after_required and after_target is not None:
                    after_ok, detail = _dependency_import_probe(after_target, settings)
                else:
                    detail = "标准库后端"
                became_ready = bool(pending_target is None and after_required and after_ok and (not before_ok or before_target != after_target))
                self.events.put(("dependency_ready", became_ready, _now_iso(), detail))
            except Exception as exc:
                _record_diagnostic("dependency-background", exc)
                self.events.put(("dependency_failed", f"{type(exc).__name__}: {exc}"))

        self.workers.start(target=worker, name="ai-dependency-prepare")

    def _maybe_start_advanced_retrain(self):
        if not self._advanced_retrain_pending or self._advanced_retrain_started or self.busy or self.refreshing:
            return
        active_dir = _active_dependency_dir()
        if not _model_missed_dependency_ready(self.engine.store.model, self._dependency_ready_at, active_dir):
            self._advanced_retrain_pending = False
            self.ai_background_status.set("AI 增强组件已就绪 · 当前模型无需重复训练")
            return
        self._advanced_retrain_pending = False
        self._advanced_retrain_started = True
        self.busy = True
        self.ai_background_status.set("AI 增强组件：正在用本地历史补训")
        self.refresh_button.configure(text="AI增强中…", state="disabled")
        profile = self.profile.get()
        holding_years = self.holding_years.get()

        def worker():
            try:
                self.engine.retrain_model_from_current_history(
                    lambda text, pct: self.events.put(("dependency_retrain_progress", text, pct)),
                    reason="advanced-ai-became-ready-after-model-training",
                )
                rows = self.engine.rankings(profile, holding_years=holding_years)
                self.events.put(("advanced_retrain_results", rows))
            except Exception as exc:
                _record_diagnostic("advanced-ai-retrain", exc)
                self.events.put(("dependency_retrain_error", f"{type(exc).__name__}: {exc}"))
            finally:
                self.events.put(("advanced_retrain_done",))

        self.workers.start(target=worker, name="advanced-ai-retrain")

    # ---------- maintenance ----------

    def _maybe_start_maintenance(self):
        if self.maintenance_running or self.busy or self.refreshing or not self.formal_results_ready or self.stop_event.is_set():
            return
        self.maintenance_running = True
        profile = self.profile.get()
        holding_years = self.holding_years.get()

        def worker():
            try:
                _configure_hardware_adaptive(force=False, allow_install=True)
                status = self.engine.maintenance_status()
                if status.get("due"):
                    self.events.put((
                        "maintenance_progress",
                        f"后台维护：模型 {status.get('model_age_days', 0):.1f} 天 · 候选池变化 {status.get('availability_change_ratio', 0):.1%}",
                    ))
                    self.engine.rebuild(
                        lambda text, pct: self.events.put(("maintenance_progress_value", text, pct)),
                        force=False,
                        quick_callback=None,
                        quick_profile=profile,
                        quick_holding_years=holding_years,
                    )
                    rows = self.engine.rankings(profile, holding_years=holding_years)
                    self.events.put(("maintenance_results", rows, status))
                else:
                    self.events.put(("maintenance_checked", status))
            except concurrent.futures.CancelledError:
                pass
            except Exception as exc:
                _record_diagnostic("maintenance", exc)
                self.events.put(("maintenance_error", f"{type(exc).__name__}: {exc}"))
            finally:
                self.events.put(("maintenance_done",))

        self.workers.start(target=worker, name="daily-maintenance")

    # ---------- initial analysis / refresh ----------

    def _cancel_initial_retry(self):
        self.initial_retry_due_at = None
        if self.initial_retry_job is not None:
            try:
                self.root.after_cancel(self.initial_retry_job)
            except self.tk.TclError:
                pass
            self.initial_retry_job = None

    def _schedule_initial_retry(self):
        if self.stop_event.is_set() or self.formal_results_ready:
            return
        self.initial_error_streak += 1
        delay = min(300, 15 * (2 ** min(self.initial_error_streak - 1, 5)))
        self._cancel_initial_retry()
        self.initial_retry_due_at = time.monotonic() + delay
        self.retry_text.set(f"{delay} 秒后自动重试 · 重试 {self.initial_error_streak}")
        self.data_status.set("等待重试")
        self.data_status_detail.set(f"{delay} 秒后自动重试")
        self.status.set("暂时无法取得数据，正在等待自动重试")
        self.progress_detail.set("保持网络连接即可；也可以点击“立即重试”")
        self.initial_retry_job = self.root.after(delay * 1000, self._retry_initial_if_needed)
        self._set_app_state(AppState.RETRY_WAIT)

    def _retry_initial_if_needed(self):
        self.initial_retry_job = None
        self.initial_retry_due_at = None
        if (
            not self.formal_results_ready
            and not self.busy
            and not self.refreshing
            and not self.stop_event.is_set()
        ):
            self._start_initial(force=True)

    def _start_initial(self, force: bool = False):
        if self.busy or self.refreshing or self.stop_event.is_set():
            return
        self._cancel_initial_retry()
        self.busy = True
        self._set_app_state(AppState.BUILDING)
        self._begin_operation("正在准备基金排名" if not force else "正在重新分析", 0, "读取本地数据并检查基金数据源")
        if not self.formal_results_ready:
            self._show_content("loading")
            self.data_status.set("正在分析")
            self.data_status_detail.set("结果会分阶段出现")
            self.retry_text.set("")

        profile = self.profile.get()
        holding_years = self.holding_years.get()

        def worker():
            try:
                cached = self.engine.load_cached()
                if cached:
                    self.events.put((
                        "cached_results",
                        self.engine.rankings(
                            profile,
                            holding_years=holding_years,
                        ),
                    ))
                    self.events.put(("progress", "已显示上次结果，正在检查最新数据…", 2))

                needs_model_retrain = bool(self.engine.store.model.get("force_retrain_reason"))
                needs_rebuild = bool(force or not cached or self.engine.cache_age_hours() >= 14 or needs_model_retrain)
                label = "分析完成 · 已保留最近一次可用 Top100"

                if needs_rebuild:
                    try:
                        self.engine.ensure_source_contract()
                    except DataError as exc:
                        _record_diagnostic("initial-source-check", exc)
                        self.events.put(("progress", "数据源检查异常，正在尝试备用方案", 3))
                    self.engine.rebuild(
                        lambda text, pct: self.events.put(("progress", text, pct)),
                        force=force,
                        quick_callback=lambda rows: self.events.put(("stage1_results", rows)),
                        quick_profile=profile,
                        quick_holding_years=holding_years,
                    )
                    rows = self.engine.rankings(
                        profile,
                        holding_years=holding_years,
                    )
                    if (self.engine.last_freshness_gate or {}).get("ok"):
                        label = "分析完成 · Top100 已通过最新数据复核"
                else:
                    try:
                        outcome = self.engine.refresh_latest(
                            profile,
                            holding_years,
                            force_availability=False,
                            force_full_nav=False,
                            progress=lambda text, pct: self.events.put(("progress", text, max(3.0, pct))),
                        )
                        rows = outcome["results"]
                        if (self.engine.last_freshness_gate or {}).get("ok"):
                            label = "上次有效 Top100 已完成当前可购状态与最新净值复核"
                        else:
                            label = "已显示上次有效 Top100 · 当前复核覆盖不足"
                    except Exception as exc:
                        _record_diagnostic("initial-cached-freshness", exc)
                        rows = self.engine.rankings(
                            profile,
                            holding_years=holding_years,
                        )
                        label = "已显示上次有效 Top100 · 当前在线复核未完成"

                self.events.put(("results", _validate_formal_results(rows), label))
            except Exception as exc:
                self.events.put(("error", str(exc)))
            finally:
                self.events.put(("done",))

        self.workers.start(target=worker, name="initial-analysis")

    def _start_refresh(self, manual: bool = False):
        if self.refreshing or self.busy or self.maintenance_running or self.stop_event.is_set():
            return

        # A failed first build or a preview-only build must restart the complete analysis.
        if not self.formal_results_ready:
            self._start_initial(force=True)
            return

        self.refreshing = True
        self._set_app_state(AppState.REFRESHING)
        self.data_status.set("正在刷新")
        self.data_status_detail.set("当前列表保留，完成后自动更新")
        self.clock.set("刷新中…")
        self.refresh_reason.set("正在复核最新基金数据")
        if manual:
            self._begin_operation("正在重新检查基金数据", 2, "手动刷新：重新检查数据源、可购证据和最新净值")
        else:
            self._begin_operation("正在检查最新基金数据", 2, "自动刷新：复核可购证据与净值新鲜度")

        profile = self.profile.get()
        holding_years = self.holding_years.get()

        def worker():
            started = time.monotonic()
            try:
                outcome = self.engine.refresh_latest(
                    profile,
                    holding_years,
                    force_availability=manual,
                    force_full_nav=manual,
                    progress=lambda text, pct: self.events.put(("progress", text, pct)),
                )
                self.events.put(("refresh_results", outcome))
            except Exception as exc:
                self.events.put(("refresh_error", str(exc), time.monotonic() - started))
            finally:
                self.events.put(("refresh_done",))

        self.workers.start(target=worker, name="latest-refresh")

    # ---------- results / details ----------

    @staticmethod
    def _short_evidence_label(item: dict, signed_mode: bool) -> str:
        status = str(item.get("availability_status") or "")
        if status == "confirmed_purchasable":
            return "支付宝确认"
        if status == "limited_purchasable":
            return "限购可购"
        if signed_mode:
            return "已验签候选"
        score = _finite(item.get("PurchaseEvidenceScore"), _purchase_evidence_score(item))
        return f"公开证据 {score:.0f}"

    def _render(self, results, *, formal: bool = True):
        results = list(results or [])
        if formal:
            results = _validate_formal_results(results)
            self.formal_results_ready = True
        self.current = results
        self._row_items = {}
        self._show_content("table")

        selected_code = None
        selected = self.tree.selection()
        if selected:
            selected_item = self._row_items.get(selected[0])
            if selected_item:
                selected_code = selected_item.get("code")
        if selected_code is None and hasattr(self, "_selected_code"):
            selected_code = self._selected_code

        for child in self.tree.get_children():
            self.tree.delete(child)

        signed_mode = getattr(self.engine, "last_availability_mode", "") == "signed-alipay"
        latest_dates = []
        selected_id = None
        for rank, item in enumerate(results, 1):
            stats = item.get("stats") or {}
            nav = item.get("display_nav", item.get("latest_nav"))
            nav_value = _finite(nav, float("nan"))
            nav_text = "—" if not math.isfinite(nav_value) else f"{nav_value:.4f}"
            date = item.get("display_nav_date") or item.get("latest_date") or ((item.get("dates") or [""])[-1])
            if date:
                latest_dates.append(str(date)[:10])
            ann3 = _finite(stats.get("return_3y_ann"), float("nan"))
            ann3_text = "—" if not math.isfinite(ann3) else f"{ann3:+.1%}"
            quality = f"{item.get('long_term_quality', '—')} {_finite(item.get('LongTermQualityScore')):.0f}"
            timing = f"{item.get('timing_view', '—')} {_finite(item.get('EntryTimingScore')):.0f}"
            fund_text = f"{item.get('name', '—')} · {item.get('code', '')}"
            row_id = f"fund_{item.get('code', rank)}_{rank}"
            tags = ["even" if rank % 2 == 0 else "odd"]
            if rank <= 3:
                tags.append("top3")
            self.tree.insert(
                "",
                "end",
                iid=row_id,
                values=(
                    rank,
                    fund_text,
                    item.get("asset_class", item.get("type", "—")),
                    self._short_evidence_label(item, signed_mode),
                    quality,
                    timing,
                    item.get("risk", "—"),
                    ann3_text,
                    nav_text,
                ),
                tags=tuple(tags),
            )
            self._row_items[row_id] = item
            if item.get("code") == selected_code:
                selected_id = row_id

        if selected_id is None and self.tree.get_children():
            selected_id = self.tree.get_children()[0]
        if selected_id:
            self.tree.selection_set(selected_id)
            self.tree.focus(selected_id)
            self.tree.see(selected_id)
            self._update_detail_panel()

        preview = bool(results and any(item.get("preliminary_phase1") is True for item in results))
        gate = getattr(self.engine, "last_freshness_gate", {}) or {}
        latest_date = max(latest_dates) if latest_dates else "—"
        self.data_date.set(latest_date)

        confirmed = sum(str(item.get("availability_status") or "") == "confirmed_purchasable" for item in results)
        limited = sum(str(item.get("availability_status") or "") == "limited_purchasable" for item in results)
        if preview and not formal:
            self.data_status.set("预览已显示")
            self.data_status_detail.set("完整 Top100 仍在分析")
        elif signed_mode and gate.get("ok"):
            self.data_status.set("● 数据正常")
            self.data_status_detail.set(f"支付宝确认 {confirmed}/{len(results)} · 限购 {limited}")
        elif signed_mode:
            self.data_status.set("● 最新数据待复核")
            self.data_status_detail.set(f"支付宝确认 {confirmed}/{len(results)}")
        elif gate.get("ok"):
            self.data_status.set("● 数据正常")
            self.data_status_detail.set("公开市场候选 · 非支付宝确认")
        else:
            self.data_status.set("● 可用结果")
            self.data_status_detail.set("公开候选 · 最新数据仍在复核")

        model = self.engine.store.model if isinstance(self.engine.store.model, dict) else {}
        trained = str(model.get("trained_at") or "—")[:10]
        if model.get("ai_enabled"):
            self.ai_status.set("● AI 已启用")
        else:
            self.ai_status.set("基础模型")
        if not self._dependency_prepare_started:
            self.ai_background_status.set(f"训练 {trained} · {int(_finite(model.get('universe_size'), 0))} 只底层基金")

        self.last_update_text.set(_dt.datetime.now().astimezone().strftime("最后更新 %H:%M"))

    def _update_detail_panel(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return
        item = self._row_items.get(selected[0])
        if not item:
            return
        self._selected_code = item.get("code")
        stats = item.get("stats") or {}
        code = str(item.get("code") or "")
        name = str(item.get("name") or "—")
        asset = str(item.get("asset_class", item.get("type", "—")) or "—")
        wrapper = str(item.get("wrapper") or "普通")
        evidence = _purchase_evidence_label(item)
        self.detail_title.set(name)
        self.detail_meta.set(f"{code} · {asset} · {wrapper}\n{evidence}")

        ann3 = _finite(stats.get("return_3y_ann"), float("nan"))
        ann5 = _finite(stats.get("return_5y_ann"), float("nan"))
        dd5 = _finite(stats.get("max_drawdown_5y"), float("nan"))
        sharpe = _finite(stats.get("sharpe"), float("nan"))
        quality = _finite(item.get("LongTermQualityScore"), float("nan"))
        timing = _finite(item.get("EntryTimingScore"), float("nan"))
        consistency = _finite(item.get("model_consistency"), float("nan"))
        percentile = _finite(item.get("category_percentile"), float("nan"))
        nav = _finite(item.get("display_nav", item.get("latest_nav")), float("nan"))
        nav_date = str(item.get("display_nav_date") or item.get("latest_date") or "—")[:10]
        cost = _share_class_cost(item, item.get("selected_holding_years", 5)) if item.get("fees_verified") else None

        def pct(value):
            return "—" if not math.isfinite(value) else f"{value:+.1%}"

        metrics = [
            f"长期质量      {quality:.0f}    当前择时      {timing:.0f}" if math.isfinite(quality) and math.isfinite(timing) else "长期质量 / 当前择时：—",
            f"近3年年化    {pct(ann3)}    近5年年化    {pct(ann5)}",
            f"近5年回撤    {pct(dd5)}    夏普          {sharpe:.2f}" if math.isfinite(sharpe) else f"近5年回撤    {pct(dd5)}    夏普          —",
            f"同类百分位    {percentile:.0f}%    模型稳定      {consistency:.0f}/100" if math.isfinite(percentile) and math.isfinite(consistency) else "同类百分位 / 模型稳定：—",
            f"风险          {item.get('risk', '—')}    最新净值      {nav:.4f}" if math.isfinite(nav) else f"风险          {item.get('risk', '—')}    最新净值      —",
            f"净值日期      {nav_date}    预计5年成本    {cost:.1%}" if cost is not None else f"净值日期      {nav_date}    预计5年成本    费率待确认",
        ]
        self.detail_metrics.set("\n\n".join(metrics))
        self.detail_reason.set(str(item.get("reason") or "暂无详细说明"))
        self.detail_note.set(
            "交易前请在支付宝确认可购、费率、限购与适当性。"
            if str(item.get("availability_status") or "") != "confirmed_purchasable"
            else "该基金具备支付宝确认的可购证据；交易条件仍以支付宝页面为准。"
        )

    # ---------- event loop ----------

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]

                if kind == "progress":
                    self._set_progress(event[1], event[2])

                elif kind == "cached_results":
                    self._render(event[1], formal=True)
                    self._show_content("table")
                    self.data_status.set("本地结果已显示")
                    self.data_status_detail.set("正在后台检查最新数据")
                    self._set_progress("已显示上次结果，正在检查最新数据…", 2)

                elif kind == "stage1_results":
                    if not self.formal_results_ready:
                        self._render(event[1], formal=False)
                        self.data_status.set("预览已显示")
                        self.data_status_detail.set("继续分析完整 Top100")
                    self._set_progress("首批基金预览已显示，继续分析完整候选池", max(_finite(self.progress_value.get()), 34))

                elif kind == "results":
                    self._render(event[1], formal=True)
                    self.initial_error_streak = 0
                    self._cancel_initial_retry()
                    self.retry_text.set("")
                    self._finish_operation(event[2], 100)
                    self._set_app_state(AppState.READY)
                    if not self.schedule_started:
                        delay = self.refresh_policy.initial_delay(event[1])
                        self.next_refresh = time.monotonic() + delay
                        self.schedule_started = True
                    if not self._dependency_prepare_started:
                        self._dependency_prepare_job = self.root.after(2000, self._ensure_dependency_prepare_started)

                elif kind == "refresh_results":
                    outcome = event[1]
                    self._render(outcome["results"], formal=True)
                    delay = self.refresh_policy.on_success(outcome)
                    self.next_refresh = time.monotonic() + delay
                    self.refresh_reason.set(self.refresh_policy.last_reason)
                    self._finish_operation("刷新完成", 100)
                    self.progress_detail.set(outcome["status"])
                    self._set_app_state(AppState.READY)

                elif kind == "error":
                    raw = event[1]
                    _record_diagnostic("ui-initial-error", raw, "InitialAnalysisError")
                    friendly = self._friendly_error_message(raw)
                    if not self.formal_results_ready:
                        self.error_title.set("暂时无法取得基金数据")
                        self.error_message.set(f"{friendly}。程序会自动重试，不需要额外操作。")
                        self._show_content("error")
                        self._finish_operation("本次分析未完成")
                        self._schedule_initial_retry()
                    else:
                        delay = self.refresh_policy.on_error(0.0)
                        self.next_refresh = time.monotonic() + delay
                        self._show_content("table")
                        self.data_status.set("● 保留上次数据")
                        self.data_status_detail.set("本次更新未完成 · 稍后自动再试")
                        self._finish_operation("本次更新未完成")
                        self.progress_detail.set(f"已保留上次结果 · {friendly}")
                        self._set_app_state(AppState.ERROR)

                elif kind == "refresh_error":
                    raw = event[1]
                    _record_diagnostic("ui-refresh-error", raw, "RefreshError")
                    delay = self.refresh_policy.on_error(event[2] if len(event) > 2 else 0.0)
                    self.next_refresh = time.monotonic() + delay
                    self.refresh_reason.set(self.refresh_policy.last_reason)
                    self._show_content("table")
                    self.data_status.set("● 保留上次数据")
                    self.data_status_detail.set("本轮刷新未完成 · 已安排自动再试")
                    self._finish_operation("本轮刷新未完成")
                    self.progress_detail.set(f"已保留上次数据 · {self._friendly_error_message(raw)}")
                    self._set_app_state(AppState.ERROR)

                elif kind == "done":
                    self.busy = False
                    self._maybe_start_advanced_retrain()

                elif kind == "refresh_done":
                    self.refreshing = False
                    if self.app_state == AppState.REFRESHING:
                        self._set_app_state(AppState.READY if self.formal_results_ready else AppState.ERROR)
                    self._maybe_start_advanced_retrain()

                elif kind == "dependency_progress":
                    text = re.sub(r"\s+", " ", str(event[1])).strip()
                    self.ai_background_status.set("AI 增强组件：" + (text[:34] + "…" if len(text) > 35 else text))

                elif kind == "dependency_ready":
                    became_ready, ready_at, detail = bool(event[1]), event[2], event[3]
                    self._dependency_ready_at = ready_at
                    if became_ready:
                        self._advanced_retrain_pending = True
                        self.ai_background_status.set("AI 增强组件已就绪 · 等待空闲时自动补训")
                        self._maybe_start_advanced_retrain()
                    else:
                        self.ai_background_status.set(f"AI 增强组件已检查 · {str(detail)[:28]}")

                elif kind == "dependency_failed":
                    self.ai_background_status.set("AI 增强组件准备失败 · 已继续使用现有模型")

                elif kind == "dependency_retrain_progress":
                    pct = max(0.0, min(100.0, _finite(event[2])))
                    title, _detail = self._friendly_progress(event[1])
                    self.ai_background_status.set(f"{title} · {pct:.0f}%")

                elif kind == "advanced_retrain_results":
                    self._render(event[1], formal=True)
                    self.ai_background_status.set("AI 增强补训完成 · 当前排名已切换到新模型")

                elif kind == "dependency_retrain_error":
                    self.ai_background_status.set("AI 增强补训未完成 · 已保留当前有效模型")

                elif kind == "advanced_retrain_done":
                    self.busy = False
                    self._advanced_retrain_started = False
                    if self.formal_results_ready and not self.refreshing and not self.maintenance_running:
                        self._set_app_state(AppState.READY)

                elif kind == "maintenance_progress":
                    self.refresh_button.configure(text="维护中…", state="disabled")
                    self._begin_operation("正在进行后台维护", 0, event[1])

                elif kind == "maintenance_progress_value":
                    self._set_progress("后台维护 · " + str(event[1]), event[2])

                elif kind == "maintenance_results":
                    self._render(event[1], formal=True)
                    info = event[2]
                    self._finish_operation("后台维护完成", 100)
                    self.progress_detail.set(f"模型与历史数据已更新 · 候选池变化 {info.get('availability_change_ratio', 0):.1%}")

                elif kind == "maintenance_checked":
                    info = event[1]
                    self.progress_detail.set(f"后台检查完成 · 模型 {info.get('model_age_days', 0):.1f} 天 · 候选池变化 {info.get('availability_change_ratio', 0):.1%}")

                elif kind == "maintenance_error":
                    self.progress_detail.set("后台维护未完成 · 已保留当前有效模型与结果")

                elif kind == "maintenance_done":
                    self.maintenance_running = False
                    self.next_maintenance = time.monotonic() + MAINTENANCE_CHECK_SECONDS
                    if self.formal_results_ready and not self.refreshing and not self.busy:
                        self._set_app_state(AppState.READY)

        except queue.Empty:
            pass
        if not self.stop_event.is_set():
            self.root.after(150, self._poll_events)

    def _tick(self):
        now = time.monotonic()

        if self.operation_started_at is not None:
            self.elapsed_text.set(f"已用时 {self._format_elapsed(now - self.operation_started_at)}")

        if self.app_state == AppState.BUILDING and not self.formal_results_ready:
            spinner_frames = ("● ○ ○", "○ ● ○", "○ ○ ●")
            index = int(now) % len(spinner_frames)
            self.loading_spinner.set(spinner_frames[index])

        if self.initial_retry_due_at is not None and not self.formal_results_ready:
            remaining_retry = max(0, int(math.ceil(self.initial_retry_due_at - now)))
            self.retry_text.set(f"{remaining_retry} 秒后自动重试 · 重试 {self.initial_error_streak}")
            self.data_status.set("等待重试")
            self.data_status_detail.set(f"{remaining_retry} 秒后自动重试")

        if math.isfinite(self.next_refresh):
            remaining = max(0.0, self.next_refresh - now)
            self.clock.set(f"{_human_seconds(remaining)}后")
            self.refresh_reason.set(self.refresh_policy.last_reason)
            if remaining <= 0 and not self.refreshing and not self.busy and not self.maintenance_running:
                self.next_refresh = float("inf")
                self._start_refresh()
        else:
            if self.refreshing:
                self.clock.set("刷新中…")
            elif self.app_state == AppState.RETRY_WAIT:
                self.clock.set("等待重试")
            else:
                self.clock.set("等待分析")

        if (
            now >= self.next_maintenance
            and not self.maintenance_running
            and not self.busy
            and not self.refreshing
            and self.formal_results_ready
        ):
            self.next_maintenance = float("inf")
            self._maybe_start_maintenance()

        if not self.stop_event.is_set():
            self.root.after(1000, self._tick)

    def close(self):
        if self.stop_event.is_set():
            return
        try:
            self.root.withdraw()
        except self.tk.TclError:
            pass
        self.stop_event.set()
        self.next_refresh = float("inf")
        self.next_maintenance = float("inf")
        self._cancel_initial_retry()
        if self._dependency_prepare_job is not None:
            try:
                self.root.after_cancel(self._dependency_prepare_job)
            except self.tk.TclError:
                pass
        _terminate_child_processes()
        self.workers.shutdown()
        # A transaction that already started is allowed to finish before process teardown.
        with _STORAGE_COMMIT_LOCK:
            pass
        try:
            self.root.destroy()
        except self.tk.TclError:
            pass


def _validate_runtime(*, formal=False) -> list[tuple[str,str]]:
    checks = []
    if sys.version_info < MIN_PYTHON:
        raise DataError(f"需要 Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} 或更高版本")
    checks.append(("OK", f"基础运行 Python >= {MIN_PYTHON[0]}.{MIN_PYTHON[1]}"))
    if sys.version_info >= (3, 12):
        checks.append(("OK", "推荐 NVIDIA AI Python >= 3.12（高级 XGBoost 路径可用）"))
    else:
        checks.append(("INFO", "基础运行可用；推荐 NVIDIA AI 环境使用 Python >= 3.12，高级 XGBoost 路径在当前 Python 下关闭"))
    if struct.calcsize("P") * 8 != 64:
        raise DataError("需要 64 位 Python")
    checks.append(("OK", "64-bit Python"))
    if os.name == "nt":
        version = sys.getwindowsversion()
        machine = platform.machine().upper()
        if version.major < 10 or version.build < 22000 or machine not in {"AMD64", "X86_64"}:
            raise DataError("正式环境要求 Windows 11 x64（AMD64）")
        checks.append(("OK", "Windows 11 x64 / AMD64（正式环境）"))
    else:
        if formal:
            raise DataError("正式环境要求 Windows 11 x64")
        checks.append(("SKIP", f"Windows 11 x64（当前测试环境为 {platform.system()}）"))
    try:
        _validate_app_path_isolation()
    except StorageError as exc:
        raise DataError(str(exc)) from exc
    checks.append(("OK", "全部应用可写路径 resolve 后仍位于用户选择目录，且无 symlink/junction/reparse point"))
    probe = BASE_DIR / ".BestAlipayFunds_write_test.tmp"
    try:
        _atomic_bytes(probe, b"ok")
        if probe.read_bytes() != b"ok":
            raise OSError("write verification failed")
    except (OSError, StorageError) as exc:
        raise DataError(f"用户选择的文件夹不可写或路径隔离失败：{BASE_DIR}\n{exc}") from exc
    finally:
        try:
            probe.unlink(missing_ok=True)
        except OSError:
            pass
    checks.append(("OK", "用户选择的文件夹可写 + 原子写入"))
    return checks


def _bind_runtime_folder(folder: Path) -> None:
    """Bind every app-owned writable path and common dependency cache/temp path to the chosen folder."""
    global BASE_DIR, CACHE_PATH, CACHE_ROLLBACK_PATH, MODEL_PATH, MODEL_ROLLBACK_PATH, ALIPAY_FILE_PATH, SETTINGS_PATH
    global DEPS_DIR, DEPS_TMP_DIR, DEPS_BACKUP_DIR, RUNTIME_TMP_DIR
    requested_base = Path(folder)
    if _path_is_reparse_or_symlink(requested_base):
        raise StorageError(f"拒绝把符号链接/junction/reparse point 作为应用根目录：{requested_base}")
    base = requested_base.resolve()
    BASE_DIR = base
    CACHE_PATH = base / "BestAlipayFunds_cache.sqlite3"
    CACHE_ROLLBACK_PATH = base / "BestAlipayFunds_cache.rollback.sqlite3"
    MODEL_PATH = base / "BestAlipayFunds_AI.json"
    MODEL_ROLLBACK_PATH = base / "BestAlipayFunds_AI.rollback.json"
    ALIPAY_FILE_PATH = base / "BestAlipayFunds_AlipayAvailability.json"
    SETTINGS_PATH = base / "BestAlipayFunds_Settings.json"
    DEPS_DIR = base / "BestAlipayFunds_deps"
    DEPS_TMP_DIR = base / "BestAlipayFunds_deps.tmp"
    DEPS_BACKUP_DIR = base / "BestAlipayFunds_deps.rollback"
    RUNTIME_TMP_DIR = base / ".BestAlipayFunds_runtime"
    cache_root = base / ".BestAlipayFunds_cache"
    # Validate all pre-existing app-owned files/dirs before creating or writing anything.
    _validate_app_path_isolation()
    _ensure_isolated_app_dir(RUNTIME_TMP_DIR)
    _ensure_isolated_app_dir(cache_root)
    env_paths = {
        "TEMP": RUNTIME_TMP_DIR,
        "TMP": RUNTIME_TMP_DIR,
        "TMPDIR": RUNTIME_TMP_DIR,
        "PIP_CACHE_DIR": cache_root / "pip",
        "XDG_CACHE_HOME": cache_root,
        "NUMBA_CACHE_DIR": cache_root / "numba",
        "CUDA_CACHE_PATH": cache_root / "cuda",
        "JOBLIB_TEMP_FOLDER": RUNTIME_TMP_DIR,
    }
    for key, value in env_paths.items():
        safe_value = _ensure_isolated_app_dir(Path(value))
        os.environ[key] = str(safe_value)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PYTHONNOUSERSITE"] = "1"
    sys.dont_write_bytecode = True
    tempfile.tempdir = str(RUNTIME_TMP_DIR)
    for entry in list(sys.path):
        try:
            candidate = Path(entry)
        except (TypeError, ValueError):
            continue
        if candidate.name == "BestAlipayFunds_deps" or candidate.name.startswith(DEPS_DIR_PREFIX):
            try:
                if candidate.resolve().parent != base:
                    sys.path.remove(entry)
            except OSError:
                sys.path.remove(entry)
    _promote_pending_dependency_dir()
    _bootstrap_local_dependency_path()


def _choose_non_system_folder() -> Path:
    """Normal Windows startup asks exactly one user choice: an existing folder on a non-system drive."""
    if os.name != "nt":
        return BASE_DIR
    import tkinter as tk
    from tkinter import filedialog, messagebox
    system_drive = str(os.environ.get("SystemDrive") or Path(os.environ.get("SystemRoot", r"C:\Windows")).drive or "C:").upper()
    chooser = tk.Tk()
    chooser.withdraw()
    try:
        try:
            chooser.attributes("-topmost", True)
        except tk.TclError:
            pass
        while True:
            selected = filedialog.askdirectory(parent=chooser, title="选择非系统盘文件夹", mustexist=True)
            if not selected:
                raise SystemExit(0)
            selected_path = Path(selected)
            if _path_is_reparse_or_symlink(selected_path):
                messagebox.showerror(APP_NAME, "请选择普通文件夹，不要选择符号链接/junction/reparse point。", parent=chooser)
                continue
            folder = selected_path.resolve()
            drive = folder.drive.upper()
            if not re.fullmatch(r"[A-Z]:", drive) or drive == system_drive:
                messagebox.showerror(APP_NAME, "请选择非系统盘文件夹。", parent=chooser)
                continue
            probe = folder / ".BestAlipayFunds_folder_probe.tmp"
            try:
                with open(probe, "xb") as handle:
                    handle.write(b"ok")
                probe.unlink(missing_ok=True)
            except OSError:
                try:
                    probe.unlink(missing_ok=True)
                except OSError:
                    pass
                messagebox.showerror(APP_NAME, "这个文件夹不可写，请选择另一个非系统盘文件夹。", parent=chooser)
                continue
            return folder
    finally:
        try:
            chooser.destroy()
        except Exception:
            pass


def _set_windows_dpi():
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def main():
    if sys.version_info < MIN_PYTHON:
        message = f"需要 Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} 或更高版本（64 位）。"
        print(message)
        raise SystemExit(2)
    _set_windows_dpi()
    _bind_runtime_folder(_choose_non_system_folder())
    # First paint never waits for pip; optional NVIDIA/ML dependencies are prepared in the GUI background.
    _configure_hardware_adaptive(force=False, allow_install=False)
    try:
        _validate_runtime(formal=(os.name == "nt"))
    except DataError as exc:
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror(APP_NAME, f"启动检查失败：{exc}")
        except Exception:
            print(f"启动检查失败：{exc}", file=sys.stderr)
        raise SystemExit(2)
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk
        root = tk.Tk()
        FundsApp(root, tk, ttk, messagebox)
        root.mainloop()
    except ImportError as exc:
        print(f"启动失败：当前 Python 缺少 Tk 图形界面组件：{exc}", file=sys.stderr)
        raise SystemExit(2)
    except Exception as exc:
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror(APP_NAME, f"启动失败：{exc}")
        except Exception:
            print(f"启动失败：{exc}", file=sys.stderr)
        if not isinstance(exc, DataError):
            raise


if __name__ == "__main__":
    main()
